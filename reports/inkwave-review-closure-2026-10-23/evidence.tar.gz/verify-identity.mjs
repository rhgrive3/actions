import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
const site=path.resolve(process.argv[2]||'work/review-closure/site');
const m=JSON.parse(fs.readFileSync(path.join(site,'inkwave-build.json')));
const sha=value=>createHash('sha256').update(value).digest('hex');
assert.equal(sha(JSON.stringify(m.files)),m.inputHash);
assert.equal(sha(JSON.stringify(m.artifacts)),m.contentHash);
for(const [file,hash] of Object.entries(m.files)){
  const [prefix,...rest]=file.split('/');
  const mapped=prefix==='upstream'?'inkwave-public':prefix==='patch'?'patches/splatoon3':prefix==='build-script'?'scripts':'patches/'+prefix;
  assert.equal(sha(fs.readFileSync(path.join(mapped,...rest))),hash,file);
}
for(const [file,hash] of Object.entries(m.artifacts))assert.equal(sha(fs.readFileSync(path.join(site,file))),hash,file);
const identity=JSON.parse(fs.readFileSync('work/review-closure/build-identity.json'));
assert.equal(identity.inputsVerified,Object.keys(m.files).length);
assert.equal(identity.artifactsVerified,Object.keys(m.artifacts).length);
assert.equal(identity.inputHash,m.inputHash);assert.equal(identity.contentHash,m.contentHash);
for(const leaf of identity.leaves)assert.equal(sha(fs.readFileSync(leaf.path)),leaf.sha256,leaf.path);
console.log(JSON.stringify({status:'passed',inputs:Object.keys(m.files).length,artifacts:Object.keys(m.artifacts).length,inputHash:m.inputHash,contentHash:m.contentHash}));
