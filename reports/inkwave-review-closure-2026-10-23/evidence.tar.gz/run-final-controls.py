import ast, json, re, subprocess, sys
from pathlib import Path
root=Path('work/review-closure/final-controls')
files=['weapon-class-state-continuity', 'turf-combat', 'turf-finish', 'disconnected-main-projectiles', 'issue-six-followup-network-paint']
results=[]
for stem in files:
    file=Path('patches/splatoon3/tests')/(stem+'.test.mjs')
    names=[ast.literal_eval(m.group(1)) for m in re.finditer(r'''^test\(('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"),''', file.read_text(),re.M)]
    if not names: raise RuntimeError('no tests found: '+str(file))
    for offset in range(0,len(names),6):
        selected=names[offset:offset+6]
        pattern='^(?:'+'|'.join(re.escape(n) for n in selected)+')$'
        log=root/(stem+'-'+str(offset//6+1)+'.log')
        with log.open('w') as output:
            code=subprocess.run(['timeout','180s','node','--max-old-space-size=2048','--experimental-vm-modules','--experimental-global-webcrypto','--test','--test-name-pattern='+pattern,str(file)],stdout=output,stderr=subprocess.STDOUT).returncode
        counts=dict(re.findall(r'^ℹ (tests|pass|fail|skipped|cancelled) (\d+)$',log.read_text(),re.M))
        result=dict(file=str(file),offset=offset,selected=len(selected),exit=code,counts=counts,log=str(log))
        results.append(result); (root/'retained-shards.json').write_text(json.dumps(results,indent=2)); print(json.dumps(result),flush=True)
        if code: sys.exit(code)
