import gzip, hashlib, io, json, re, tarfile
from pathlib import Path

root=Path('work/review-closure')
dest=Path('reports/inkwave-review-closure-2026-10-23')
sha=lambda data: hashlib.sha256(data).hexdigest()
def counts(name):
    data=(root/name).read_text()
    result={key:int(value) for key,value in re.findall(r'^ℹ (tests|pass|fail|skipped|cancelled) (\d+)$',data,re.M)}
    assert set(result)=={'tests','pass','fail','skipped','cancelled'},(name,result)
    return result
for name in ['final-source.log','emitted.log']:
    assert counts(name)=={'tests':211,'pass':211,'fail':0,'skipped':0,'cancelled':0}
assert counts('isolated-baseline.log')=={'tests':95,'pass':31,'fail':64,'skipped':0,'cancelled':0}
assert counts('isolated-bootstrap-final-before.log')=={'tests':21,'pass':0,'fail':21,'skipped':0,'cancelled':0}
assert counts('final-network-and-sub.log')=={'tests':123,'pass':123,'fail':0,'skipped':0,'cancelled':0}
shards={}
for directory,total,processes in [('final-retained',145,26),('final-controls',39,9)]:
    rows=json.loads((root/directory/'retained-shards.json').read_text())
    assert len(rows)==processes
    assert sum(int(row['counts']['pass']) for row in rows)==total
    assert sum(row['selected'] for row in rows)==total
    for row in rows:
        assert row['exit']==0
        assert int(row['counts']['fail'])==int(row['counts']['skipped'])==int(row['counts']['cancelled'])==0
    shards[directory]={'tests':total,'pass':total,'processes':processes,'fail':0,'skipped':0,'cancelled':0}
browser=json.loads((root/'browser.json').read_text())
assert browser['status']=='passed' and browser['cases']==len(browser['rows'])==265 and browser['errors']==[]
assert all(row['status']=='passed' for row in browser['rows'])
for file,expected in browser['sourceHashes'].items(): assert sha(Path(file).read_bytes())==expected
assert sha((dest/'browser-harness.mjs').read_bytes())==browser['harnessSha256']
assert sha(Path('patches/splatoon3/bootstrap.mjs').read_bytes())==browser['bootstrapSha256']
assert (root/'browser.exit').read_text().strip()=='0'
npm=(root/'npm-test-final.log').read_text()
phases=['check:patches','audit:migration','test:direct-source','test:quality','test:relay','test:backup','test:queue-recovery']
previous=-1
for phase in phases:
    marker='> inkwave-workspace@1.0.0 '+phase
    index=npm.index(marker); assert index>previous; previous=index
assert not re.search(r'^not ok |^npm (?:ERR!|error)',npm,re.M)
assert re.findall(r'^# tests (\d+)$',npm,re.M)==['20','18','23','28']
assert re.findall(r'^# pass (\d+)$',npm,re.M)==['20','18','23','28']
for key in ['fail','cancelled','skipped']: assert re.findall(r'^# '+key+r' (\d+)$',npm,re.M)==['0']*4
assert 'Ran 4 tests in ' in npm and '\nOK\n' in npm
assert re.search(r'# duration_ms [\d.]+\s*$',npm)
npm_record={'status':'passed','command':'timeout 600s npm test','phaseOrder':phases,'tapSuites':[20,18,23,28],
    'backupTests':4,'fail':0,'skipped':0,'cancelled':0,
    'completionEvidence':'The package.json && chain reached its final test:queue-recovery command, whose complete final TAP reports 28/28 and duration; the process ended. No separate exit-status file was captured.',
    'packageSha256':sha(Path('package.json').read_bytes()),'logSha256':sha((root/'npm-test-final.log').read_bytes()),
    'initialRun':{'command':'timeout 180s npm test','exit':124,'status':'timed out during parallel heavy verification','log':'npm-test-first-timeout.log'}}
(root/'npm-completion.json').write_text(json.dumps(npm_record,indent=2)+'\n')
identity=json.loads((root/'build-identity.json').read_text())
assert identity['status']=='passed' and identity['inputsVerified']==1363 and identity['artifactsVerified']==2018
assert browser['inputHash']==identity['inputHash'] and browser['contentHash']==identity['contentHash']
for row in identity['leaves']: assert sha(Path(row['path']).read_bytes())==row['sha256']
assert json.loads((root/'startup-budget.log').read_text())['status']=='passed'
assert json.loads((root/'final-identity-audit.log').read_text())['status']=='passed'

selected=[Path(name) for name in ['isolated-baseline.log','isolated-bootstrap-final-before.log','baseline-identity.json',
    'final-source.log','emitted.log','browser.log','browser.json','browser.exit','build.log','build-identity.json',
    'startup-budget.log','final-network-and-sub.log','npm-test-first-timeout.log','npm-test-final.log','npm-completion.json',
    'final-identity-audit.log','verify-identity.mjs','run-final-retained.py','run-final-controls.py','package-evidence.py']]
for directory in ['final-retained','final-controls']:
    selected += [p.relative_to(root) for p in sorted((root/directory).glob('*.log'))]
    selected += [p.relative_to(root) for p in sorted((root/directory).glob('*.json'))]
assert len(selected)==59, len(selected)
entries=[]
with (dest/'evidence.tar.gz').open('wb') as output:
    with gzip.GzipFile(fileobj=output,mode='wb',filename='',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for relative in sorted(set(selected)):
                data=(root/relative).read_bytes(); name=str(relative)
                info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
                archive.addfile(info,io.BytesIO(data));entries.append({'path':name,'bytes':len(data),'sha256':sha(data)})
sources=sorted(Path('patches/splatoon3/tests').glob('*-review.test.mjs'))
sources += [Path('patches/splatoon3/tests/source-fixture.mjs'),Path('patches/splatoon3/tests/special-evidence-fixture.mjs'),
    Path('patches/splatoon3/bootstrap.mjs'),dest/'browser-harness.mjs',dest/'verify-browser.mjs',Path('reports/inkwave-review-closure-2026-10-23.md')]
receipt={'schema':1,'sourceBase':'21b7959a11f59dc5649ee73be72aa99cba11d1be',
    'publishedComparisonBase':'26a4db4123d23162a3dbf8a12150b1b5bc6ccf64','referenceVersion':'Splatoon 3 11.3.0',
    'scope':'Local review fixes; existing PR work excluded; no push, merge or deployment.',
    'baseline':{'tests':116,'pass':31,'fail':85,'skipped':0,'cancelled':0,'runtimeUntouched':True,'testFilesShaMatch':True},
    'checks':{'source':counts('final-source.log'),'emitted':counts('emitted.log'),
        'browser':{'browser':browser['browser'],'cases':265,'runtimeCases':190,'nativeInputCases':54,'completeBootstrapCases':21,'errors':0,'exit':0},
        **shards,'networkAndNativeSub':counts('final-network-and-sub.log'),'npm':npm_record,'build':'passed','startupBudget':'passed'},
    'build':identity,'sourceFiles':[{'path':str(p),'sha256':sha(p.read_bytes())} for p in sources],
    'reviewStop':'No additional reproducible issue in the reviewed paths after fixes; not a claim of a bug-free entire game.',
    'limits':'Controlled native fixtures with dummy Character/frozen ordinary integration and JSON transport. Actual minified browser modules and synthetic DOM input; every bootstrap installer, but no rendered main Game, real relay, physical touch or Switch comparison.',
    'archive':{'path':'evidence.tar.gz','bytes':(dest/'evidence.tar.gz').stat().st_size,'sha256':sha((dest/'evidence.tar.gz').read_bytes()),'files':entries}}
(dest/'receipt.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':'passed','archiveFiles':len(entries),'archiveBytes':receipt['archive']['bytes'],'archiveSha256':receipt['archive']['sha256']}))
