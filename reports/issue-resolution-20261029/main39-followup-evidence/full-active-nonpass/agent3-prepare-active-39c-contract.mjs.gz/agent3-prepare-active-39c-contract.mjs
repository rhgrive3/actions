import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {parse} from '/workspace/wt-agent5/patches/loading-cache/vendor/acorn.mjs';
const root='/workspace/wt-agent5',out='/workspace/scratch/agent3-full-active-39c';
const wrapper='/workspace/scratch/agent3-run-active-39c.mjs';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const ast=parse(fs.readFileSync(wrapper,'utf8'),{ecmaVersion:'latest',sourceType:'module'});
const decl=ast.body.filter(n=>n.type==='VariableDeclaration').flatMap(n=>n.declarations).find(n=>n.id.name==='qa');
assert.equal(decl.init.callee.name,'Set');
const qa=new Set(decl.init.arguments[0].elements.map(n=>{assert.equal(n.type,'Literal');return n.value;}));
const queue=[...qa];
for(let i=0;i<queue.length;i++){
 const name=queue[i];if(!/\.(m?js)$/.test(name))continue;
 const module=parse(fs.readFileSync(root+'/'+name,'utf8'),{ecmaVersion:'latest',sourceType:'module'});
 for(const n of module.body)if(['ImportDeclaration','ExportNamedDeclaration','ExportAllDeclaration'].includes(n.type)&&n.source?.value?.startsWith('.')){
  const relative=path.relative(root,path.resolve(root,path.dirname(name),n.source.value));
  if(!qa.has(relative)){qa.add(relative);queue.push(relative);}
 }
}
const qaBindings=[...qa].sort().map(file=>({file,sha256:hash(fs.readFileSync(root+'/'+file)),gitBlob:git('rev-parse','39c2060fe5d27ea1d8182861a07e79da99e8915e:'+file)}));
const node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';
const modulePath=root+'/node_modules/playwright/index.mjs';
const {chromium}=await import(modulePath);
const toolFiles=[modulePath,root+'/node_modules/playwright/package.json',root+'/node_modules/playwright/lib/index.js',root+'/node_modules/playwright-core/package.json',root+'/node_modules/playwright-core/browsers.json',root+'/node_modules/playwright-core/lib/coreBundle.js'];
const actualExecutable='/home/agent/.cache/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-linux64/chrome-headless-shell';
const parentWrapper='/workspace/scratch/agent1-run-active-8cb5.mjs';
const contract={kind:'full-active-39c-current-build',createdAt:new Date().toISOString(),head:'39c2060fe5d27ea1d8182861a07e79da99e8915e',site:'/workspace/scratch/main0904-integrated-site',contentHash:'f27791906bcf7a0a1c7e6c6520dbfc513157b6ca1c98b89f5de3029915375308',inputHash:'427e1471ed7225bd6cd7508b2b9960b9893857dcf7a4b4adb3bf91ab3cee5cf0',expectedArtifacts:2267,expectedInputs:1550,wrapper,wrapperSha256:hash(fs.readFileSync(wrapper)),parentWrapper,parentWrapperSha256:hash(fs.readFileSync(parentWrapper)),node,nodeSha256:hash(fs.readFileSync(node)),qaBindingsSha256:hash(JSON.stringify(qaBindings)),toolBindings:toolFiles.map(file=>({file,sha256:hash(fs.readFileSync(file))})),pairedExecutable:chromium.executablePath(),pairedExecutableSha256:hash(fs.readFileSync(chromium.executablePath())),actualExecutable,actualExecutableSha256:hash(fs.readFileSync(actualExecutable)),args:['scripts/check-inkwave-browser.mjs','--site','/workspace/scratch/main0904-integrated-site','--evidence-dir',out+'/evidence','--profile-dir',out+'/profile','--exact-source'],scope:{fullActive:true,canonicalKits:65,gearSelects:12,minimapCases:7,minimapNegativeControls:6,strictRequests:true,productionEdits:false,headerOverrides:false,timeoutOverrides:false,filters:[],quick:false},identity:{sourceCleanBeforeAndAfter:true,allArtifactsBeforeAndAfter:true,allSourceInputsBeforeAndAfter:true,actualExecutableFromProc:true,actualBrowserParentIsDriver:true,allQaToolsWrapperContractUnchanged:true,ownedBrowserCleanupRequired:true}};
fs.mkdirSync(out,{recursive:true});
assert(!fs.existsSync(out+'/contract.json'),'Do not overwrite a sealed contract');
fs.writeFileSync(out+'/contract.json',JSON.stringify(contract,null,2)+'\n');
fs.writeFileSync(out+'/qa-bindings.json',JSON.stringify(qaBindings,null,2)+'\n');
console.log(JSON.stringify({contract:out+'/contract.json',sha256:hash(fs.readFileSync(out+'/contract.json')),wrapperSha256:contract.wrapperSha256,qaFiles:qaBindings.length}));
