import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {createRequire} from 'node:module';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {startProjectileThroughMenu} from '/workspace/wt-agent5/scripts/lib/inkwave-projectile-menu-start.mjs';
import {verifyRuntimeBuild} from '/workspace/wt-agent5/scripts/lib/inkwave-runtime-evidence.mjs';
import {serveProjectileCaptureFile} from '/workspace/wt-agent5/scripts/lib/inkwave-projectile-http-file.mjs';
const root='/workspace/wt-agent5',site='/workspace/scratch/main0904-integrated-site',out='/workspace/scratch/issue642-native-39c',sha='39c2060fe5d27ea1d8182861a07e79da99e8915e',quality=process.argv[2]||'high';
if(!['low','medium','high'].includes(quality))throw Error('expected low/medium/high');
const build=verifyRuntimeBuild(site,root,sha),digest=b=>createHash('sha256').update(b).digest('hex');
if(build.contentHash!=='f27791906bcf7a0a1c7e6c6520dbfc513157b6ca1c98b89f5de3029915375308'||build.inputHash!=='427e1471ed7225bd6cd7508b2b9960b9893857dcf7a4b4adb3bf91ab3cee5cf0')throw Error('unexpected build');
const helperFiles=['scripts/lib/inkwave-projectile-menu-start.mjs','scripts/lib/inkwave-runtime-evidence.mjs','scripts/lib/inkwave-projectile-http-file.mjs'],helperHashes=Object.fromEntries(helperFiles.map(file=>{const actual=digest(fs.readFileSync(path.join(root,file))),expected=digest(execFileSync('git',['show',sha+':'+file],{cwd:root}));if(actual!==expected)throw Error('changed helper: '+file);return [file,actual];}));
const result={status:'running',sourceSha:sha,contentHash:build.contentHash,inputHash:build.inputHash,quality,helperHashes,probeSha256:digest(fs.readFileSync(new URL(import.meta.url))),scope:'native emulated-touch menu and local offline Turf game; short sampled interval, no FPS or physical-device claim',requestsFailed:[],pageErrors:[],httpErrors:[],events:[],menuSamples:[],battleIdleSamples:[],battleMovementSamples:[]};
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.woff2':'font/woff2','.mp3':'audio/mpeg','.glb':'model/gltf-binary','.bin':'application/octet-stream'};
const server=http.createServer((req,res)=>{try{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),file=path.resolve(site,'.'+(pathname==='/'?'/index.html':pathname));if(!file.startsWith(site+path.sep)||!fs.statSync(file).isFile())throw Error('missing');serveProjectileCaptureFile(req,res,file,mime);}catch{res.writeHead(404);res.end('Not found');}});
let context,page;let browser,primary;
const filename=path.join(out,quality+'.json');
try{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));const address=`http://127.0.0.1:${server.address().port}/`;
 const {chromium}=createRequire('/workspace/wt-agent5/scripts/check-inkwave-projectile-visuals.mjs')('playwright');
 browser=await chromium.launch({headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader-webgl','--enable-unsafe-swiftshader','--ignore-gpu-blocklist']});
 context=await browser.newContext({viewport:{width:844,height:390},deviceScaleFactor:3,isMobile:true,hasTouch:true,serviceWorkers:'block',reducedMotion:'reduce'});page=await context.newPage();
 page.on('pageerror',e=>result.pageErrors.push(String(e.message)));page.on('requestfailed',r=>result.requestsFailed.push({url:r.url(),error:r.failure()?.errorText}));page.on('response',r=>{if(r.status()>=400)result.httpErrors.push({url:r.url(),status:r.status()});});
 await page.addInitScript(q=>localStorage.setItem('inkwave.settings',JSON.stringify({quality:q,shadows:q!=='low',bloom:q!=='low',minimap:false,cameraShake:0,colorblind:true,difficulty:'normal',matchLength:180,lastStage:'tidewater',lastMode:'turf',stageTimes:{tidewater:'day'}})),quality);
 await page.goto(address+'?map=tidewater&difficulty=normal&skipTitle',{waitUntil:'domcontentloaded',timeout:60000});
 const deadline=Date.now()+240000;
 const waitForPhase=async(predicate,label)=>{let last;while(Date.now()<deadline){try{if(await page.evaluate(predicate))return;}catch(e){last=String(e);}await new Promise(r=>setTimeout(r,250));}throw Error(label+' timed out: '+(last||''));};
 await waitForPhase(()=>{const g=window.__inkwave,G=window.__G;return !!(g?.debug&&Number.isFinite(g.bootMs)&&G?.mode==='menu'&&g.match?.attract&&g.menus?.current==='main');},'native menu');
 const sample=async label=>await page.evaluate(async({label})=>{
  const rows=[];for(let i=0;i<12;i++){
   await new Promise(resolve=>requestAnimationFrame(resolve));const g=window.__inkwave,G=window.__G,R=g.R,c=R.composer,targets=[c?.renderTarget1,c?.renderTarget2];
   const fmt=t=>{if(!t)return null;const type=t.texture.type,bpp=type===1016?8:type===35899?4:null,width=Math.floor(t.width),height=Math.floor(t.height);return {width:t.width,height:t.height,textureWidth:width,textureHeight:height,type,format:t.texture.format,depth:t.depthBuffer,bytes:bpp===null?null:width*height*bpp};};
   const ts=targets.map(fmt),pair=ts.every(Boolean)&&ts.every(t=>t.bytes!==null)?ts[0].bytes+ts[1].bytes:null,baseline=ts.every(Boolean)?(ts[0].textureWidth*ts[0].textureHeight+ts[1].textureWidth*ts[1].textureHeight)*8:null;
   rows.push({label,frame:g._frameN??null,gameTime:G.time,matchTime:g.match?.time??null,mode:G.mode,state:g.match?.state??null,attract:!!g.match?.attract,local:!!g.match?.local?.isLocal,controller:!!g.match?.controller,quality:G.settings?.quality,touch:R.mobile?.touch,ios:R.mobile?.ios,active:g.screenfx?.pass?.enabled??null,canPack:R._composerPackedCapable??null,packed:R._composerUsesPackedTarget??null,screenState:g.screenfx?.s?Object.fromEntries(['speed','stretch','edgeInk','aura','heart','hurt','swim','flood'].map(k=>[k,g.screenfx.s[k]])):null,targets:ts,colorBytes:pair,oldColorBytes:baseline,actorPos:g.match?.local?.pos?.toArray?.()??null,actorForm:g.match?.local?.form??null,fire:g.match?.local?.intent?.fire??null});
  }return rows;
 },{label});
 result.menuSamples=await sample('menu');
 await startProjectileThroughMenu(page,{waitForPhase,remainingMs:()=>deadline-Date.now(),receipt:result.events});
 await waitForPhase(()=>{const g=window.__inkwave,G=window.__G,m=g?.match;return !!(G?.mode==='match'&&m===G.match&&m?.state==='playing'&&!m.attract&&m.local?.isLocal&&m.controller&&G.projectiles&&G.renderer&&!m.paused&&!g.frozen);},'native live match');
 result.battleIdleSamples=await sample('battle-idle');
 await page.keyboard.down('w');await page.keyboard.down('Shift');
 try{result.battleMovementSamples=await sample('battle-move-swim-input');}finally{await page.keyboard.up('Shift');await page.keyboard.up('w');}
 result.browser=await page.evaluate(()=>({userAgent:navigator.userAgent,touch:navigator.maxTouchPoints,pointer:matchMedia('(pointer:coarse)').matches,devicePixelRatio:window.devicePixelRatio,webgl:window.__G.renderer.getContext().getParameter(window.__G.renderer.getContext().VERSION)}));
 const all=[...result.menuSamples,...result.battleIdleSamples,...result.battleMovementSamples];
 if(!all.every(r=>r.touch===true))throw Error('actual renderer did not use touch profile');
 if(!result.battleIdleSamples.every(r=>r.mode==='match'&&r.state==='playing'&&!r.attract&&r.local&&r.controller))throw Error('native match identity not established');
 result.status='observed';
}catch(e){primary=e;result.status='failed';result.error=String(e?.stack||e);}
finally{if(context)await context.close().catch(e=>result.events.push({closeError:String(e)}));if(browser)await browser.close().catch(e=>result.events.push({browserCloseError:String(e)}));await new Promise(r=>server.close(r));fs.writeFileSync(filename,JSON.stringify(result,null,2)+'\n');}
if(primary)throw primary;
