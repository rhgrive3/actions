import hashlib,json,os,re,subprocess,sys
from pathlib import Path
root=Path('/workspace/wt-agent5')
node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
if len(sys.argv)!=4: raise SystemExit('usage: run-pr1915-icon-emitted34.py SOURCE_SHA SITE OUTPUT_DIR')
sha,site_arg,out_arg=sys.argv[1:]; site=Path(site_arg).resolve(); out=Path(out_arg).resolve();out.mkdir(parents=True,exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def digest(b):return hashlib.sha256(b).hexdigest()
def clean():
 assert git('rev-parse','HEAD')==sha
 assert not git('status','--porcelain','--untracked-files=normal'), 'worktree must be clean'
clean()
registry=(root/'scripts/tests/inkwave-source-coverage.test.mjs').read_text()
part=registry.split('const remainingEmittedFiles = [',1)[1].split('];',1)[0]
files=re.findall(r"^  '([^']+\.test\.mjs)',?$",part,re.M)
assert len(files)==34 and len(set(files))==34
workflow=(root/'.github/workflows/validate-inkwave-update.yml').read_text()
step=workflow.split('name: Verify remaining emitted combat, weapon and visual regressions\n',1)[1].split('      - name:',1)[0]
command='          node --experimental-vm-modules --test --test-concurrency=2 \\\n'
expected=command+''.join('            '+f+(' \\\n' if i<len(files)-1 else '\n') for i,f in enumerate(files))
assert step.count(command)==1 and step[step.index(command):]==expected
assert 'verifyRuntimeBuild(process.env.INKWAVE_BUILT_SITE, process.cwd(), process.env.SOURCE_SHA)' in step
assert 'INKWAVE_CANONICAL_TRACE_MODULE:' in step and 'INKWAVE_NATIVE_TRACE_COMPARE:' in step
tracked=files+['scripts/tests/inkwave-source-coverage.test.mjs','.github/workflows/validate-inkwave-update.yml','scripts/lib/inkwave-runtime-evidence.mjs','patches/splatoon3/tests/fixtures/native-action-trace-035.json.gz']
source={f:digest((root/f).read_bytes()) for f in tracked}
env=os.environ.copy()
for key in list(env):
 if key.startswith('INKWAVE_') or key in ('TEST_FROM','TEST_TO','TEST_EMITTED'):env.pop(key,None)
env.update(SOURCE_SHA=sha,INKWAVE_BUILT_SITE=str(site),INKWAVE_CANONICAL_TRACE_MODULE=str(site/'patches/network-replication/canonical-weapon-actions.mjs'),INKWAVE_NATIVE_TRACE_COMPARE=str(root/'patches/splatoon3/tests/fixtures/native-action-trace-035.json.gz'))
def verify(label):
 js="import{verifyRuntimeBuild}from'./scripts/lib/inkwave-runtime-evidence.mjs';console.log(JSON.stringify(verifyRuntimeBuild(process.argv[1],process.cwd(),process.argv[2])))"
 raw=subprocess.check_output([node,'--input-type=module','-e',js,str(site),sha],cwd=root,env=env)
 (out/(label+'.json')).write_bytes(raw)
 return json.loads(raw)
before=verify('verify-before');clean()
selection={'sha':sha,'site':str(site),'node':node,'files':files,'sourceHashes':source,'contentHash':before['contentHash'],'inputHash':before['inputHash'],'inputs':len(before['files']),'artifacts':len(before['artifacts'])}
(out/'selection.json').write_text(json.dumps(selection,indent=2)+'\n')
command=[node,'--experimental-vm-modules','--test','--test-concurrency=2',*files]
with (out/'full-raw.tap').open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
raw=(out/'full-raw.tap').read_bytes(); text=raw.decode(errors='replace')
counts={k:int(re.findall(r'^# '+k+r' (\d+)$',text,re.M)[-1]) for k in ('tests','pass','fail','skipped')}
after=verify('verify-after');clean()
assert before==after and source=={f:digest((root/f).read_bytes()) for f in tracked}
summary={'exit':result.returncode,'counts':counts,'sourceSha':sha,'site':str(site),'contentHash':before['contentHash'],'inputHash':before['inputHash'],'inputs':len(before['files']),'artifacts':len(before['artifacts']),'tapSha256':digest(raw),'exactWorkflowFiles':len(files)}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
if result.returncode or counts['fail'] or counts['skipped']: raise SystemExit(1)
