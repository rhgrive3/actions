'use strict';
// Scratch-only additional observation; no request or page operation is filtered.
const fs = require('node:fs');
const playwright = require('/workspace/actions/node_modules/playwright');
const output = '/workspace/scratch/agent6-roll-hissen-39c/observer.json';
const originalLaunch = playwright.chromium.launch.bind(playwright.chromium);
playwright.chromium.launch = async (...args) => {
  const browser = await originalLaunch(...args);
  const observations = {schema: 1, requestFailures: [], httpErrors: [], pageErrors: [], consoleErrors: [], gl: null};
  const pages = [];
  const originalNewPage = browser.newPage.bind(browser);
  browser.newPage = async (...pageArgs) => {
    const page = await originalNewPage(...pageArgs);
    pages.push(page);
    page.on('requestfailed', request => observations.requestFailures.push({url: request.url(), error: request.failure()?.errorText ?? null}));
    page.on('response', response => { if (response.status() >= 400) observations.httpErrors.push({url: response.url(), status: response.status()}); });
    page.on('pageerror', error => observations.pageErrors.push(String(error.message)));
    page.on('console', message => { if (message.type() === 'error') observations.consoleErrors.push(message.text()); });
    return page;
  };
  const originalClose = browser.close.bind(browser);
  browser.close = async (...closeArgs) => {
    try {
      if (pages.length !== 1) throw Error('Expected exactly one observed page');
      observations.gl = await pages[0].evaluate(() => {
        const canvas = document.querySelector('canvas');
        if (!canvas) throw Error('No renderer canvas');
        const gl = canvas.getContext('webgl2') || canvas.getContext('webgl');
        if (!gl) throw Error('No WebGL context');
        const errors = [];
        for (let i = 0; i < 16; i++) { const error = gl.getError(); if (error === gl.NO_ERROR) break; errors.push(error); }
        return {renderer: gl.getParameter(gl.RENDERER), version: gl.getParameter(gl.VERSION), contextLost: gl.isContextLost(), errors};
      });
    } catch (error) { observations.inspectionError = String(error.stack || error); }
    finally { await originalClose(...closeArgs); }
    observations.accepted = !observations.inspectionError && !observations.requestFailures.length && !observations.httpErrors.length && !observations.pageErrors.length && !observations.consoleErrors.length && !observations.gl.contextLost && !observations.gl.errors.length;
    fs.writeFileSync(output, JSON.stringify(observations, null, 2) + '\n');
    if (!observations.accepted) throw Error('Independent browser/HTTP/final WebGL observation failed; see ' + output);
  };
  return browser;
};
