import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {verifyRuntimeBuild} from '/workspace/wt-agent5/scripts/lib/inkwave-runtime-evidence.mjs';
import {bindSite,verifySite} from '/workspace/wt-agent5/scripts/run-inkwave-turf-finish-isolated.mjs';

const [head,siteArgument,outArgument,expectedContentHash,expectedInputHash,...extra]=process.argv.slice(2);
assert.equal(extra.length,0);assert.match(head??'',/^[0-9a-f]{40}$/);assert.match(expectedContentHash??'',/^[0-9a-f]{64}$/);assert.match(expectedInputHash??'',/^[0-9a-f]{64}$/);
assert.ok(siteArgument&&outArgument,'Explicit fresh site and distinct evidence paths are required');
const root='/workspace/wt-agent5',site=fs.realpathSync(siteArgument),out=path.resolve(outArgument);
assert.ok(out.startsWith('/workspace/scratch/'),'Workspace-owned persistent evidence');
assert.notEqual(site,'/workspace/scratch/main-wave345-repaired-site','Historical6013 site cannot acquire the new epoch label');
assert.notEqual(expectedContentHash,'6013fcd90a3ed04ac0d3f5cec30a7088168c4ee9e9506d1e1b4be1c3cfdbea79');
assert.notEqual(expectedInputHash,'4a3ec6606981d5a6afdf82d7ec57901d424191a65eab1458980fa7203b5cfbc5');
assert.ok(!fs.existsSync(out),'One run, fresh evidence directory; never overwrite or retry an existing proof');
const node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';
const hash=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');
const binding=bindSite(site);assert.equal(binding.contentHash,expectedContentHash);assert.equal(binding.inputHash,expectedInputHash);
verifyRuntimeBuild(site,root,head);
const manifest=JSON.parse(fs.readFileSync(path.join(site,'inkwave-build.json')));
const qa=['scripts/check-inkwave-context-recovery-browser.mjs','scripts/lib/inkwave-projectile-menu-start.mjs','scripts/lib/inkwave-range-menu-entry.mjs','scripts/lib/inkwave-runtime-evidence.mjs','scripts/run-inkwave-turf-finish-isolated.mjs'];
const qaBindings=qa.map(file=>({file,sha256:hash(fs.readFileSync(root+'/'+file)),gitBlob:git('rev-parse','HEAD:'+file)}));
const modulePath=root+'/node_modules/playwright/index.mjs';
const {chromium}=await import(modulePath),version=JSON.parse(fs.readFileSync(root+'/node_modules/playwright/package.json')).version;
assert.equal(version,'1.62.1');
const distributionPath=chromium.executablePath();
const args=['scripts/check-inkwave-context-recovery-browser.mjs',site,out];
const env={...process.env,SOURCE_SHA:head,PATH:path.dirname(node)+':'+process.env.PATH};
for(const key of ['NODE_OPTIONS','NODE_PATH','CHROMIUM_PATH','PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS'])delete env[key];
fs.mkdirSync(out);
const receipt={schema:1,startedAt:new Date().toISOString(),head,site,contentHash:binding.contentHash,inputHash:binding.inputHash,revision:manifest.build.revision,command:[node,...args],nodeVersion:execFileSync(node,['--version'],{encoding:'utf8'}).trim(),playwrightVersion:version,modulePath,moduleSha256:hash(fs.readFileSync(modulePath)),distributionPath,distributionSha256:hash(fs.readFileSync(distributionPath)),distributionNote:'Playwright distribution lookup; actual launched executable must be witnessed independently from /proc.',qaBindings,siteArtifactsBeforeVerified:binding.names.length,sourceInputsBeforeVerified:Object.keys(manifest.files).length,filters:[],browserFlagOverrides:[],headerOverrides:false,timeoutOverrides:false,productionEdits:[]};
fs.writeFileSync(out+'/site-binding.json',JSON.stringify(binding,null,2)+'\n');
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({event:'strict-context-start',head,site,out,contentHash:binding.contentHash,inputHash:binding.inputHash,childCommand:receipt.command}));
const fd=fs.openSync(out+'/driver.log','wx');let exit,signal;
try{const child=spawn(node,args,{cwd:root,env,stdio:['ignore',fd,fd]});receipt.childPid=child.pid;fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');[exit,signal]=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,sig)=>resolve([code,sig]));});}finally{fs.closeSync(fd);}
Object.assign(receipt,{finishedAt:new Date().toISOString(),exit,signal});
try{verifySite(binding);verifyRuntimeBuild(site,root,head);assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');for(const row of qaBindings)assert.equal(hash(fs.readFileSync(root+'/'+row.file)),row.sha256);Object.assign(receipt,{siteArtifactsAfterVerified:binding.names.length,allBuildInputsBeforeAndAfterVerified:true,headAndQaUnchanged:true});}catch(error){receipt.postVerificationError=error.stack;}
const resultFile=out+'/result.json';
if(fs.existsSync(resultFile)){const bytes=fs.readFileSync(resultFile),result=JSON.parse(bytes);receipt.resultSha256=hash(bytes);receipt.resultSummary={ok:result.ok,error:result.error,lastStage:result.lastStage,build:result.build,errors:result.errors,requests:result.requests,httpFailures:result.httpFailures,events:result.events,cleanupError:result.cleanupError,proofStages:result.proof?.stages??result.partial?.proof?.stages??null};}
const witnessFile=out+'/actual-browser-executable.json';
if(fs.existsSync(witnessFile)){
 const witness=JSON.parse(fs.readFileSync(witnessFile));receipt.actualBrowser={path:witness.actualExecutable,sha256:witness.sha256,pid:witness.pid};
 const marker=witness.command.find(arg=>arg.startsWith('--user-data-dir='));assert.ok(marker,'Observed native browser profile owner');
 const live=[];for(const name of fs.readdirSync('/proc')){if(!/^\d+$/.test(name))continue;try{if(fs.readFileSync('/proc/'+name+'/cmdline').toString().split('\0').includes(marker))live.push(Number(name));}catch(error){if(!['ENOENT','ESRCH','EACCES'].includes(error.code))throw error;}}
 receipt.remainingOwnedProcesses=live;receipt.processesClosed=live.length===0;
}else{receipt.actualBrowserWitnessMissing=true;receipt.processesClosed=null;}
receipt.driverSha256=hash(fs.readFileSync(out+'/driver.log'));
receipt.passed=exit===0&&!signal&&!receipt.postVerificationError&&receipt.resultSummary?.ok===true&&receipt.processesClosed===true;
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({event:'strict-context-complete',passed:receipt.passed,exit,signal,result:receipt.resultSummary,processesClosed:receipt.processesClosed,postVerificationError:receipt.postVerificationError,out}));
process.exitCode=receipt.passed?0:1;
