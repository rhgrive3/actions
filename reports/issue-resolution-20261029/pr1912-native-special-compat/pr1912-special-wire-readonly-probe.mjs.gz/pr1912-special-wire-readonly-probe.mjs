import fs from 'node:fs';
import {execFileSync} from 'node:child_process';
import {fixture} from '/workspace/wt-optimized-bounded/patches/splatoon3/tests/source-fixture.mjs';
const root='/workspace/wt-optimized-bounded';
const before=execFileSync('git',['show','22f1962e:patches/splatoon3/runtime/catalogue.mjs'],{cwd:root,encoding:'utf8'});
const copy=x=>JSON.parse(JSON.stringify(x));
const rows=[];
for(const old of [true,false])for(const legacy of [false,true]){
 let clock=100;
 const f=await fixture({fullRuntime:true,productionComposition:true,realProjectiles:true,vmPerformance:{now:()=>clock*1000},
  adaptRuntime:(rel,s)=>old&&rel==='patches/splatoon3/runtime/catalogue.mjs'?before:s});
 const owner=f.make(),proxy=f.make();
 for(const a of [owner,proxy]){Object.assign(a,{nid:77,owner:'A',netLife:0});a.weapon={...a.weapon,special:'tripleSplashdown',specialCost:100};a.special=100;a._resolve=()=>{};}
 proxy.remote=true;
 const sent=[],session=myId=>({myId,hostId:'A',isHost:myId==='A',_members:new Map([['A',{}],['B',{}]]),tr:{broadcast:m=>sent.push(copy(m)),sendTo(){}}});
 const sender=new f.NetMatch(session('A'),{id:'wire',map:'reef'}),receiver=new f.NetMatch(session('B'),{id:'wire',map:'reef'});
 const match={id:'wire',state:'playing',time:180,actors:[owner],playing:()=>true};
 sender.bind(match);receiver.bind({...match,actors:[proxy]});receiver.byNid.set(77,proxy);
 const select=n=>{f.G.netm=n;f.G.match=n.match;};
 const receive=p=>{select(receiver);receiver.onMessage('A',p);const peer=receiver.peers.get('A');if(peer){peer.tr=p.ts;receiver._playEvents();}};
 select(sender);sender._sendTick();receive(sent.at(-1));clock+=.1;f.G.time=.1;
 select(sender);owner._startSpecial();sender._sendTick();const packet=sent.at(-1);
 const original=copy(packet.e);
 if(legacy){delete packet.r;packet.e=packet.e.map(e=>e.slice(0,-2));}
 const beforeFists=f.G.projectiles._catalogueFists.filter(x=>x.owner===proxy).length;
 receive(packet);
 rows.push({oldCatalogueOnly:old,legacyNativeAcceptedLayout:legacy,actualProducerEvents:original.map(e=>[e[1],e[2],e.length]),wireEvents:packet.e.map(e=>[e[1],e[2],e.length]),receiverAcceptedTimestamp:receiver.peers.get('A')?.lastTs===packet.ts,receiverQueued:receiver.peers.get('A')?.events.length,priorRemoteFists:beforeFists,remoteFists:f.G.projectiles._catalogueFists.filter(x=>x.owner===proxy).length,lastNativeEventSequence:receiver.peers.get('A')?._lastEventSeq??null});
 receiver.dispose();sender.dispose();f.G.projectiles.clear();
}
fs.writeFileSync('/workspace/scratch/pr1912-special-wire-readonly-probe.json',JSON.stringify(rows,null,2)+'\n');
console.log(JSON.stringify(rows,null,2));
