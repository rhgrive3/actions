# CI failure audit

Snapshot 2026-10-29T01:32:42.256251+00:00. Historical outcomes do not imply fixes have passed hosted CI.

## [40794006489](https://github.com/rhgrive3/actions/actions/runs/40794006489) — 035233299348

Status: in_progress ; pending: patch_tests (2), patch_tests (7), patch_tests (0).

- [browser (active, chromium webkit) (123193769369)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123193769369): Verify emitted renderer and Input resource lifetimes; Package bounded browser failure evidence. Input lifecycle: Input listener imbalance {"adds":120,"removes":120,"live":0}; subsequent evidence packaging also fails; identity-aware audit is pending final hosted CI.
- [patch_tests (5) (123193769415)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123193769415): Verify gameplay patch contracts and regressions (shard 5). NEW historical motion composition: queue-historical-source-motion-20261026.test.mjs:34: pinned walk, historical owner and subsequent visual queue compose exactly; source text mismatch.
- [patch_tests (3) (123193769465)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123193769465): Verify gameplay patch contracts and regressions (shard 3). AO/geometry VM fixture: performance-v2-geometry: ReferenceError: adaptOffscreenHairTargets is not defined; bf12bd30 addresses fixture.

## [40794005975](https://github.com/rhgrive3/actions/actions/runs/40794005975) — 51a685502c04

Status: in_progress ; pending: patch_tests (1).

- [browser (active, chromium webkit) (123189142478)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142478): Verify emitted renderer and Input resource lifetimes; Package bounded browser failure evidence. Input lifecycle: Input listener imbalance {"adds":120,"removes":120,"live":0}; subsequent evidence packaging also fails; identity-aware audit is pending final hosted CI.
- [patch_tests (4) (123189142570)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142570): Verify gameplay patch contracts and regressions (shard 4). Input and motion tests: input-owned-listeners: 12 !== 10, 22 !== 20, 12 !== 10; motion-diagnostics: ordinary unread motion clips allocate no public descriptor records.
- [patch_tests (6) (123189142580)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142580): Verify gameplay patch contracts and regressions (shard 6). AO/geometry VM fixture: performance-v2-ao: ReferenceError: adaptOffscreenHairTargets is not defined; bf12bd30 addresses fixture.
- [patch_tests (5) (123189142588)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142588): Verify gameplay patch contracts and regressions (shard 5). NEW network receipt fixture: queue-network-receipts-20261027.test.mjs:34: ReferenceError: bossBodyBlocked is not defined in extracted VM flush.
- [patch_tests (7) (123189142623)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142623): Verify gameplay patch contracts and regressions (shard 7). AO/geometry VM fixture: performance-v2-geometry: ReferenceError: adaptOffscreenHairTargets is not defined; bf12bd30 addresses fixture.

## [40796887966](https://github.com/rhgrive3/actions/actions/runs/40796887966) — d5f48a115fe2

Status: completed failure; pending: none.

- [verify-aplus-suite (123195403393)](https://github.com/rhgrive3/actions/actions/runs/40796887966/job/123195403393): Prove recurrence guards reject broken YAML and adapter anchors. CI recurrence policy: heavy full-CI lanes require successful admission preflight and final gate refuses failure: error patch_tests.

## [40796887972](https://github.com/rhgrive3/actions/actions/runs/40796887972) — d5f48a115fe2

Status: completed failure; pending: none.

- [ranked (123195403758)](https://github.com/rhgrive3/actions/actions/runs/40796887972/job/123195403758): Ranked rule and native integration regressions. Ranked plus shared fixture: stationary proof, null add, rainmaker tick and geometry assertions, plus 3 delayed-shot actual-driver assertions real delayed shot admitted; distinct failures, not one cause.

## [40796887978](https://github.com/rhgrive3/actions/actions/runs/40796887978) — d5f48a115fe2

Status: completed failure; pending: none.

- [fast-preflight (123195403675)](https://github.com/rhgrive3/actions/actions/runs/40796887978/job/123195403675): Check upstream locks, source/numeric compatibility and staged-CI invariants. Staged CI policy: tests 178, 184, 190 reject resource-lane, viewport and dependency contracts.

## [40796887990](https://github.com/rhgrive3/actions/actions/runs/40796887990) — d5f48a115fe2

Status: completed failure; pending: none.

- [compare-objects (123195403645)](https://github.com/rhgrive3/actions/actions/runs/40796887990/job/123195403645): Verify Rainmaker presentation and hands. Shared actual-driver fixture: shooter and dualies delayed-shot driver tests: real delayed shot admitted.

Current PR 1909 head 531493473e31f3ec4d01e5f5f2959e0c5d3a6bac supersedes d5. Current fast-preflight and A+ fail CI policy; Validate core fails network/wall workflow contracts. Ranked and presentation still in progress at refresh. Both Validate resource_paint_continuation jobs succeeded; the separate two-frame diagnostic failure was in a different run.

## PR 1909 head 531493473e31: current failures

- [verify-aplus-suite (123205638799)](https://github.com/rhgrive3/actions/actions/runs/40800028232/job/123205638799): Prove recurrence guards reject broken YAML and adapter anchors. CI recurrence policy: heavy full-CI lanes require successful admission preflight and final gate refuses failure: error patch_tests.
- [fast-preflight (123205638630)](https://github.com/rhgrive3/actions/actions/runs/40800028246/job/123205638630): Check upstream locks, source/numeric compatibility and staged-CI invariants. Staged CI policy: tests 178, 184, 190 reject resource-lane, viewport and dependency contracts.
- [validate_core (123207051076)](https://github.com/rhgrive3/actions/actions/runs/40800028293/job/123207051076): Verify scoped network diagnostic workflow contracts; Retain bounded Turf finish evidence; Retain exact emitted launch packet evidence. Network and wall workflow contracts: Missing mandatory complete CPU source shards; Missing npm ci --no-audit --no-fund. Later evidence uploads fail because earlier step did not produce files.

## Final refresh

Both runs completed with failure; common has five primary failed jobs and opt has six, plus their respective failed aggregate jobs. Newly completed failures:

- 40794006489: [patch_tests (2) (123193769443)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123193769443): Input and AO fixture: input-owned-listeners: 12 != 10, 22 != 20, 12 != 10; performance-v2-ao: adaptOffscreenHairTargets is not defined.
- 40794006489: [patch_tests (0) (123193769531)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123193769531): Network receipt fixture: queue-network-receipts-20261027: bossBodyBlocked is not defined inside extracted VM flush.
- 40794006489: [validate (123210904548)](https://github.com/rhgrive3/actions/actions/runs/40794006489/job/123210904548): Final aggregate: Require every source and patch regression to pass: rejected previous failed jobs.
- 40794005975: [patch_tests (1) (123189142571)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123189142571): Historical motion composition: pinned walk, clip pool, historical owner and subsequent visual queue compose exactly: text mismatch after new hair owner.
- 40794005975: [validate (123209799491)](https://github.com/rhgrive3/actions/actions/runs/40794005975/job/123209799491): Final aggregate: Require every source and patch regression to pass: rejected previous failed jobs.
