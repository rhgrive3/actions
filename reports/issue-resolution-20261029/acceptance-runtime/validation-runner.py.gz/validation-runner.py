import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path('/workspace/wt-agent6')
out = Path('/workspace/scratch/acceptance-final-validation')
out.mkdir(exist_ok=True)
node = '/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
env = os.environ.copy()
env['PATH'] = '/workspace/scratch/agent2-tools:' + str(Path(node).parent) + ':' + env['PATH']
env.pop('INKWAVE_BUILT_SITE', None)
site = root / '_site'
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root).strip()
old = json.loads(Path('/workspace/scratch/returned-final-emitted23/selection.json').read_text())
files = old['files'] + [
    'patches/network-replication/tests/combat-native-birth-timing.test.mjs',
    'patches/network-replication/tests/combat-single-round-targets.test.mjs',
    'patches/splatoon3/tests/catalog-horizontal-sector-emitted.test.mjs',
]
assert len(files) == len(set(files)) == 26
source_files = [
    'patches/splatoon3/tests/catalog-horizontal-sector-aim.test.mjs',
    'patches/splatoon3/tests/catalog-horizontal-sector-emitted.test.mjs',
    'scripts/tests/inkwave-composed-cpu-comparison.test.mjs',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def frozen_tree(ref):
    rows = subprocess.check_output(['git', 'ls-tree', '-r', '-z', ref, '--', 'patches'], cwd=root).split(b'\0')
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode()
            for row in rows if b'\t' in row and (b'/fixtures/' in row or b'/frozen/' in row)}

frozen_before = frozen_tree(sha)
assert frozen_tree('2b01cd7efbca260a611165b1e3887ff48062ccd5') == frozen_before
source_before = {f: digest((root / f).read_bytes()) for f in set(files + source_files)}

def verify(label):
    code = "import{verifyRuntimeBuild}from'./scripts/lib/inkwave-runtime-evidence.mjs';const m=verifyRuntimeBuild(process.argv[1],process.cwd(),process.argv[2]);console.log(JSON.stringify(m));"
    raw = subprocess.check_output([node, '--input-type=module', '-e', code, str(site), sha], cwd=root, env=env)
    m = json.loads(raw)
    with open(out / (label + '-manifest.json'), 'wb') as stream:
        stream.write(raw)
    return {'contentHash': m['contentHash'], 'inputHash': m['inputHash'], 'inputs': len(m['files']), 'artifacts': len(m['artifacts'])}

state = {'sourceSha': sha, 'node': subprocess.check_output([node, '--version'], text=True).strip(), 'files': files,
         'sourceFiles': source_files, 'before': verify('before'), 'testSourceHashes': source_before,
         'frozenTreeHash': digest(json.dumps(frozen_before, sort_keys=True).encode()), 'suites': []}
(out / 'selection.json').write_text(json.dumps(state, indent=2) + '\n')

def run_suite(name, chosen, emitted=False):
    run_env = env.copy()
    if emitted:
        run_env['INKWAVE_BUILT_SITE'] = str(site)
    command = [node, '--experimental-vm-modules', '--test', '--test-concurrency=2', *chosen]
    raw_path = out / (name + '.tap')
    with raw_path.open('wb') as stream:
        result = subprocess.run(command, cwd=root, env=run_env, stdout=stream, stderr=subprocess.STDOUT)
    raw = raw_path.read_bytes()
    text = raw.decode(errors='replace')
    counts = {key: int(re.findall(r'^# ' + key + r' (\d+)$', text, re.M)[-1])
              for key in ['tests', 'pass', 'fail', 'skipped']}
    record = {'name': name, 'command': command, 'emitted': emitted, 'exit': result.returncode,
              'counts': counts, 'sha256': digest(raw)}
    state['suites'].append(record)
    (out / 'state.json').write_text(json.dumps(state, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    assert result.returncode == 0 and counts['fail'] == counts['skipped'] == 0

run_suite('source-new-guards', source_files)
run_suite('emitted26', files, emitted=True)
state['after'] = verify('after')
assert state['before'] == state['after']
assert source_before == {f: digest((root / f).read_bytes()) for f in source_before}
assert frozen_tree(sha) == frozen_before
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root).strip()
state['status'] = 'passed'
(out / 'summary.json').write_text(json.dumps(state, indent=2) + '\n')
print(json.dumps({'status': 'passed', 'sourceSha': sha, 'build': state['after'], 'suites': [s['counts'] for s in state['suites']]}), flush=True)
