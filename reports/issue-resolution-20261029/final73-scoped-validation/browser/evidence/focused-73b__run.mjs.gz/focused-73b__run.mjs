// Focused UI + Minimap diagnostic, derived from the exact failed 39c full-active wrapper.
// The historical full-active failure remains unchanged and is not accepted by this scope.
// Diagnostic scope of the committed active harness. The sealed loader adds
// only the unchanged Minimap probe to its existing UI-only mode; every fatal
// assertion, request gate and cleanup path remains present.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {verifyRuntimeBuild} from '/workspace/wt-agent5/scripts/lib/inkwave-runtime-evidence.mjs';
import {bindSite,verifySite} from '/workspace/wt-agent5/scripts/run-inkwave-turf-finish-isolated.mjs';
import {parse} from '/workspace/wt-agent5/patches/loading-cache/vendor/acorn.mjs';

const root='/workspace/wt-agent5',out='/workspace/scratch/agent3-focused-ui-minimap';
const node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';
const self=fileURLToPath(import.meta.url),contractFile=out+'/contract.json';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',a,{cwd:root,encoding:'utf8'}).trim();
const contractBytes=fs.readFileSync(contractFile),contract=JSON.parse(contractBytes);
const {head,site}=contract;assert.match(head,/^[a-f0-9]{40}$/);assert.equal(contract.root,root);
assert.deepEqual(process.argv.slice(2),[process.argv[2]==='--prepare-only'?'--prepare-only':'--run']);
assert.equal(contract.wrapperSha256,hash(fs.readFileSync(self)));
assert.equal(contract.head,head);assert.equal(contract.site,site);
assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');
assert.equal(execFileSync(node,['--version'],{encoding:'utf8'}).trim(),'v22.23.4');
assert.equal(hash(fs.readFileSync(node)),contract.nodeSha256);
assert.equal(hash(fs.readFileSync(contract.parentWrapper)),contract.parentWrapperSha256);

const binding=bindSite(site),runtime=verifyRuntimeBuild(site,root,head);
assert.equal(binding.contentHash,contract.contentHash);assert.equal(binding.inputHash,contract.inputHash);
assert.equal(binding.names.length,contract.expectedArtifacts);assert.equal(Object.keys(runtime.files).length,contract.expectedInputs);

// Bind the actual static/dynamic-literal Node QA import closure. Imports inside
// page.evaluate resolve to artifact-verified browser modules instead.
const qa=new Set([
 'scripts/check-inkwave-browser.mjs','scripts/lib/inkwave-runtime-evidence.mjs',
 'scripts/tests/inkwave-ui-visual-probe-errors.test.mjs','scripts/tests/inkwave-hud-spicon-fixture.test.mjs',
 'scripts/lib/minimap-canvas-probe.mjs','scripts/lib/inkwave-turf-lead-probe.mjs',
 'scripts/run-inkwave-turf-finish-isolated.mjs','patches/loading-cache/vendor/acorn.mjs',
 'scripts/fixtures/minimap-transient-clock-20261029.json.gz',
 'scripts/fixtures/inkwave-public-capture-cache-revalidation-1915.json',
 'scripts/tests/inkwave-public-capture-cache-policy.test.mjs',
 'scripts/tests/inkwave-projectile-http-file.test.mjs','scripts/ci/inkwave-test-suites.json',
]);
const queue=[...qa];
for(let i=0;i<queue.length;i++){
 const name=queue[i];if(!/\.(m?js)$/.test(name))continue;
 const ast=parse(fs.readFileSync(root+'/'+name,'utf8'),{ecmaVersion:'latest',sourceType:'module'});
 const specs=[];
 // Static imports/reexports form the host closure. Browser-side dynamic
 // imports are deliberately not loaded by this source observer.
 for(const item of ast.body)if(['ImportDeclaration','ExportNamedDeclaration','ExportAllDeclaration'].includes(item.type)&&item.source?.value?.startsWith('.'))specs.push(item.source.value);
 for(const spec of specs){
  const file=path.resolve(root,path.dirname(name),spec);assert.ok(file.startsWith(root+'/'));
  const relative=path.relative(root,file);if(!qa.has(relative)){qa.add(relative);queue.push(relative);}
 }
}
for(const name of ['scripts/lib/minimap-canvas-probe.mjs','scripts/lib/inkwave-turf-lead-probe.mjs'])if(!qa.has(name)){
 // These are the main harness's two explicit host-side dynamic imports.
 throw Error('Main host dynamic import was not included in QA closure: '+name);
}
const qaBindings=[...qa].sort().map(file=>{
 const bytes=fs.readFileSync(root+'/'+file),blob=git('rev-parse',head+':'+file);
 assert.equal(git('hash-object','--',file),blob,'QA differs from committed source: '+file);
 return{file,sha256:hash(bytes),gitBlob:blob};
});
assert.equal(hash(JSON.stringify(qaBindings)),contract.qaBindingsSha256);
const modulePath=root+'/node_modules/playwright/index.mjs';
const {chromium}=await import(modulePath);
const pairedExecutable=chromium.executablePath();
const version=JSON.parse(fs.readFileSync(root+'/node_modules/playwright/package.json')).version;
assert.equal(version,'1.62.1');
for(const entry of contract.toolBindings)assert.equal(hash(fs.readFileSync(entry.file)),entry.sha256,entry.file);
assert.equal(pairedExecutable,contract.pairedExecutable);
assert.equal(hash(fs.readFileSync(pairedExecutable)),contract.pairedExecutableSha256);
assert.equal(fs.realpathSync(contract.actualExecutable),contract.actualExecutable);
assert.equal(hash(fs.readFileSync(contract.actualExecutable)),contract.actualExecutableSha256);
const args=['--import',out+'/loader.mjs','scripts/check-inkwave-browser.mjs','--site',site,'--evidence-dir',out+'/evidence','--profile-dir',out+'/profile','--exact-source','--ui-probes-only'];
assert.deepEqual(args,contract.args);
const env={...process.env,SOURCE_SHA:head,PLAYWRIGHT_MODULE:modulePath,PATH:path.dirname(node)+':/workspace/scratch/pr1911-ruby:'+process.env.PATH};
for(const key of ['NODE_OPTIONS','NODE_PATH','CHROMIUM_PATH','PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS'])delete env[key];
const preparation={preparedAt:new Date().toISOString(),contractSha256:hash(contractBytes),head,site,contentHash:binding.contentHash,inputHash:binding.inputHash,siteArtifactsVerified:binding.names.length,sourceInputsVerified:Object.keys(runtime.files).length,qaBindings,toolBindings:contract.toolBindings,expectedActualExecutable:contract.actualExecutable,expectedActualExecutableSha256:contract.actualExecutableSha256,command:[node,...args],nodeVersion:'v22.23.4',playwrightVersion:version,exactSource:true,scope:'focused-ui-and-minimap',fullAcceptance:false,filters:['--ui-probes-only'],quick:false,headerOverrides:false,timeoutOverrides:false};
if(process.argv[2]==='--prepare-only'){
 fs.writeFileSync(out+'/preparation.json',JSON.stringify(preparation,null,2)+'\n');
 console.log(JSON.stringify({event:'prepared-only',contractSha256:preparation.contractSha256,head,contentHash:binding.contentHash,inputHash:binding.inputHash,qaFiles:qaBindings.length,artifacts:binding.names.length,inputs:Object.keys(runtime.files).length}));
 process.exit(0);
}
assert(!fs.existsSync(out+'/receipt.json'),'Only one focused UI and Minimap run for this contract');
fs.writeFileSync(out+'/site-binding.json',JSON.stringify(binding,null,2)+'\n');
const receipt={...preparation,startedAt:new Date().toISOString(),qaBindings,pairedExecutable,pairedExecutableSha256:contract.pairedExecutableSha256,actualExecutableWitnesses:[]};
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
const witnessed=new Set();let witnessError=null,driverPid=null;
const owned=()=>fs.readdirSync('/proc').filter(p=>/^\d+$/.test(p)).flatMap(pid=>{
 try{const argv=fs.readFileSync('/proc/'+pid+'/cmdline').toString().split('\0').filter(Boolean);return argv.some(a=>a===out+'/profile'||a==='--user-data-dir='+out+'/profile')?[{pid:Number(pid),argv}]:[];}catch{return[];}
});
function observeActualExecutable(){
 for(const row of owned()){
  if(!row.argv.includes('--user-data-dir='+out+'/profile')||witnessed.has(row.pid))continue;
  try{
   const executable=fs.realpathSync('/proc/'+row.pid+'/exe');
   const status=fs.readFileSync('/proc/'+row.pid+'/status','utf8');
   const parentPid=Number(status.match(/^PPid:\s+(\d+)/m)?.[1]);
   assert.equal(parentPid,driverPid,'Actual browser must be a child of the immutable driver');
   assert.equal(executable,contract.actualExecutable,'Unexpected actual browser executable');
   assert.equal(hash(fs.readFileSync('/proc/'+row.pid+'/exe')),contract.actualExecutableSha256);
   witnessed.add(row.pid);receipt.actualExecutableWitnesses.push({...row,parentPid,executable,sha256:contract.actualExecutableSha256,at:new Date().toISOString()});
   fs.writeFileSync(out+'/actual-browser-executable.json',JSON.stringify(receipt.actualExecutableWitnesses,null,2)+'\n');
  }catch(error){witnessError=error.stack;}
 }
}
console.log(JSON.stringify({event:'focused-ui-minimap-start',head,contentHash:binding.contentHash,inputHash:binding.inputHash,output:out}));
const fd=fs.openSync(out+'/driver.log','w');let exit,signal;
try{
 const child=spawn(node,args,{cwd:root,env,stdio:['ignore',fd,fd]});driverPid=child.pid;receipt.driverPid=driverPid;
 const timer=setInterval(observeActualExecutable,200);
 try{[exit,signal]=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,sig)=>resolve([code,sig]));});}
 finally{clearInterval(timer);observeActualExecutable();}
}finally{fs.closeSync(fd);}
Object.assign(receipt,{finishedAt:new Date().toISOString(),exit,signal,witnessError});
try{
 verifySite(binding);verifyRuntimeBuild(site,root,head);
 assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');
 assert.equal(hash(fs.readFileSync(self)),contract.wrapperSha256);assert.equal(hash(fs.readFileSync(contractFile)),hash(contractBytes));
 assert.equal(hash(fs.readFileSync(node)),contract.nodeSha256);
 assert.equal(hash(fs.readFileSync(contract.actualExecutable)),contract.actualExecutableSha256);
 assert.equal(hash(fs.readFileSync(pairedExecutable)),contract.pairedExecutableSha256);
 for(const row of [...qaBindings,...contract.toolBindings])assert.equal(hash(fs.readFileSync(row.file.startsWith('/')?row.file:root+'/'+row.file)),row.sha256);
 assert(!witnessError);assert(receipt.actualExecutableWitnesses.length>0,'Actual spawned browser executable was not witnessed');
 Object.assign(receipt,{siteArtifactsAfterVerified:binding.names.length,allBuildInputsBeforeAndAfterVerified:true,headAndQaUnchanged:true,wrapperContractToolsAndExecutableUnchanged:true});
}catch(error){receipt.postVerificationError=error.stack;}
try{
 const bytes=fs.readFileSync(out+'/evidence/browser-result.json'),result=JSON.parse(bytes);
 receipt.resultSha256=hash(bytes);
 assert.equal(result.status,'passed');assert.equal(result.scope,'ui-probes-only');assert.equal(result.fullAcceptance,false);
 assert.equal(result.sourceSha,head);assert.equal(result.contentHash,binding.contentHash);
 assert.equal(result.hudAuthority.splatlingStages.length,4);assert.equal(result.hudAuthority.splatlingNegatives.length,6);
 assert.equal(result.hudAuthority.authoritativeSpread.length,4);
 for(const row of result.hudAuthority.authoritativeSpread)assert.equal(row.negatives.length,3);
 assert.equal(result.hudAuthority.winnerPodium.states.length,2);
 assert.equal(result.hudAuthority.winnerPodium.profileRestored,true);assert.equal(result.hudAuthority.winnerPodium.liveActorsUnchanged,true);
 const loaded=JSON.parse(fs.readFileSync(out+'/loaded-driver-binding.json'));assert.equal(loaded.originalHarnessSha256,contract.originalHarnessSha256);assert.equal(loaded.extendedHarnessSha256,contract.extendedHarnessSha256);assert.equal(loaded.completeReverseEquality,true);
 for(const name of ['errors','consoleErrors','requestFailures','verifiedAudioCancellations'])assert.deepEqual(result[name],[],name);
 assert.equal(result.minimapCanvas.sourceSha,head);assert.equal(result.minimapCanvas.contentHash,binding.contentHash);
 assert.equal(result.minimapCanvas.cases.length,7);
 assert.equal(Object.keys(result.minimapCanvas.negativeControls).length,6);
 for(const value of Object.values(result.minimapCanvas.negativeControls))assert.equal(value,true);
 receipt.resultSummary={status:result.status,scope:result.scope,sourceSha:result.sourceSha,contentHash:result.contentHash,fullAcceptance:false,splatlingStages:result.hudAuthority.splatlingStages.length,splatlingNegatives:result.hudAuthority.splatlingNegatives.length,authoritativeSpreadWeapons:result.hudAuthority.authoritativeSpread.length,winnerPodiumStates:result.hudAuthority.winnerPodium.states.length,minimapCases:result.minimapCanvas.cases.length,verifiedResponses:result.verifiedResponses,errors:result.errors,consoleErrors:result.consoleErrors,requestFailures:result.requestFailures,verifiedAudioCancellations:result.verifiedAudioCancellations};
}catch(error){receipt.resultVerificationError=error.stack;}
receipt.remainingOwnedProcesses=owned();receipt.processesClosed=receipt.remainingOwnedProcesses.length===0;
receipt.passed=exit===0&&!signal&&!receipt.postVerificationError&&!receipt.resultVerificationError&&receipt.resultSummary?.status==='passed'&&receipt.processesClosed;
receipt.driverSha256=hash(fs.readFileSync(out+'/driver.log'));
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({event:'focused-ui-minimap-complete',passed:receipt.passed,exit,signal,processesClosed:receipt.processesClosed,postVerificationError:receipt.postVerificationError,resultVerificationError:receipt.resultVerificationError,output:out}));
process.exitCode=receipt.passed?0:1;
