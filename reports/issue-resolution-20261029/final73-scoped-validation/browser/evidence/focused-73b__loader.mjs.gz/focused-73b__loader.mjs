// Diagnostic host-only scope extension. The committed active driver retains
// native boot and every fatal/assertion/request/cleanup path. Its existing
// --ui-probes-only mode is extended only to execute the same Minimap probe.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {registerHooks} from 'node:module';
import {pathToFileURL} from 'node:url';
const out='/workspace/scratch/agent3-focused-ui-minimap';
const contract=JSON.parse(fs.readFileSync(out+'/contract.json'));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const target=pathToFileURL(contract.root+'/scripts/check-inkwave-browser.mjs').href;
const before='  if (!uiProbesOnly) result.minimapCanvas = await runMinimapCanvasProbe(page,{root:ROOT,evidence,sourceSha,contentHash:manifest.contentHash,manifest});';
const after='  result.minimapCanvas = await runMinimapCanvasProbe(page,{root:ROOT,evidence,sourceSha,contentHash:manifest.contentHash,manifest});';
assert(process.argv.includes('--ui-probes-only'));assert(process.argv.includes('--exact-source'));
assert.equal(hash(fs.readFileSync(new URL(import.meta.url))),contract.loaderSha256);
registerHooks({load(url,context,next){
 const loaded=next(url,context);if(url!==target)return loaded;
 const source=typeof loaded.source==='string'?loaded.source:Buffer.from(loaded.source).toString();
 assert.equal(hash(source),contract.originalHarnessSha256);
 assert.equal(source.split(before).length-1,1,'one exact existing Minimap scope gate');
 const extended=source.replace(before,after);
 assert.equal(hash(extended),contract.extendedHarnessSha256);
 assert.equal(extended.replace(after,before),source,'all other committed driver bytes retained');
 fs.writeFileSync(out+'/loaded-driver-binding.json',JSON.stringify({at:new Date().toISOString(),originalHarnessSha256:hash(source),extendedHarnessSha256:hash(extended),sourceSha:contract.head,scope:'ui-probes-only plus unchanged Minimap probe',fullAcceptance:false,exactGateSites:1,completeReverseEquality:true},null,2)+'\n');
 return {...loaded,source:extended};
}});
