import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/wt-agent5')
OUT = pathlib.Path('/workspace/scratch/slosher-envelope-followup')
NODE = '/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
TEST = ROOT / 'patches/local-quality/tests/slosher-shared-envelope.test.mjs'
OUT.mkdir(exist_ok=True)
source = TEST.read_text()
owner = 'patches/splatoon3/runtime/projectile-visuals.mjs'
original = "return p && actorOf(p)==='WeaponSlosherDiffusion' ? HISSEN_PRESENTATION_SCALE : 1;"
mutants = {
    'hissen-1x': "return p && actorOf(p)==='WeaponSlosherDiffusion' ? 1 : 1;",
    'double-1_5x': "return p && actorOf(p)==='WeaponSlosherDouble' ? 1.5 : p && actorOf(p)==='WeaponSlosherDiffusion' ? HISSEN_PRESENTATION_SCALE : 1;",
}
receipt = {'node': subprocess.check_output([NODE, '--version'], text=True).strip(),
           'scope': 'Production-composed source fixture; no build, emitted or browser claim',
           'testSha256': hashlib.sha256(TEST.read_bytes()).hexdigest(), 'runs': []}
assert receipt['node'] == 'v22.23.4'

def run(name, files, expected):
    command = [NODE, '--experimental-vm-modules', '--test', '--test-concurrency=1', *files]
    log = OUT / (name + '.tap')
    with log.open('wb') as handle:
        result = subprocess.run(command, cwd=ROOT, stdout=handle, stderr=subprocess.STDOUT)
    raw = log.read_bytes()
    (OUT / (name + '.exit')).write_text(str(result.returncode) + '\n')
    entry = {'name': name, 'command': command, 'exit': result.returncode,
             'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw),
             'tail': raw.decode().splitlines()[-10:]}
    receipt['runs'].append(entry)
    (OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert result.returncode == expected, entry
    if expected:
        assert b'ERR_ASSERTION' in raw and b'# fail 1' in raw, entry
    print(json.dumps(entry), flush=True)

run('related-six-after', [
    'patches/local-quality/tests/slosher-shared-envelope.test.mjs',
    'patches/local-quality/tests/ink-volume-defaults.test.mjs',
    'patches/local-quality/tests/ink-volume-recipes.test.mjs',
    'patches/splatoon3/tests/hissen-presentation-scale.test.mjs',
    'patches/splatoon3/tests/tri-slosher-floor-visual.test.mjs',
    'patches/splatoon3/tests/projectile-visuals.test.mjs',
], 0)

for name, replacement in mutants.items():
    needle = 'fixture({fullRuntime:true,productionComposition:true,realProjectiles:true,extraExports:'
    assert source.count(needle) == 1
    adapter = ('fixture({adaptRuntime:(rel,code)=>{if(rel!==' + json.dumps(owner) + ')return code;'
               'const before=' + json.dumps(original) + ',after=' + json.dumps(replacement) + ';'
               'assert.equal(code.split(before).length-1,1,"exact runtime mutant anchor");'
               'return code.replace(before,after);},fullRuntime:true,productionComposition:true,realProjectiles:true,extraExports:')
    mutant = source.replace(needle, adapter)
    target = TEST.parent / ('.slosher-envelope-' + name + '-counterfactual.mjs')
    assert not target.exists()
    try:
        target.write_text(mutant)
        (OUT / (name + '.counterfactual.mjs.txt')).write_text(mutant)
        run(name, [str(target.relative_to(ROOT))], 1)
    finally:
        target.unlink(missing_ok=True)

assert TEST.read_text() == source
print('PASS: related suite and both production-runtime counterfactual rejections; no temporary tests remain', flush=True)
