import assert from 'node:assert/strict';
import fs from 'node:fs';
import {fixture} from '/workspace/wt-agent5/patches/splatoon3/tests/source-fixture.mjs';
const dir='/workspace/scratch/agent1-authority-phase';
const rows=[];
for(const mode of ['original','candidate']){
 const source=fs.readFileSync(dir+'/'+mode+'.mjs','utf8');
 const f=await fixture({fullRuntime:true,productionComposition:true,realProjectiles:true,adaptRuntime:(rel,code)=>rel==='patches/network-replication/trusted-native-replay.mjs'?source:code,extraExports:"export * from './patches/network-replication/trusted-native-replay.mjs';"});
 class Display{constructor(){this.root=new f.THREE.Group();this.color=new f.THREE.Color(0xffffff);}_owner(){return this.actor;}_runner(){return this.actor?.weaponRunner;}trigger(){}setVisible(){}setHurt(){}setWeapon(){}update(){}dispose(){}getMuzzle(out){return out.copy(this.root.position).add(new f.THREE.Vector3(0,1.05,.3));}}
 const roster=[{nid:1,owner:'A',life:1,team:0,slot:0,weapon:'shooter',position:[0,0,0],yaw:0},{nid:2,owner:'B',life:1,team:1,slot:0,weapon:'shooter',position:[0,0,7],yaw:Math.PI}];
 function setup(phase){
  const raw={bounds:{minX:-100,maxX:100,minZ:-100,maxZ:100},spawnPads:[[-90,0,0],[90,0,0]],spawnBarrier:0,half:[],single:[{kind:'box',min:[-100,-.5,-100],max:[100,0,100]}]},level=new f.Level(raw),physics=new f.Physics(level);
  const world={level,physics,paint:{sample:()=>0,splat:()=>0},match:{playing:()=>true,canRespawn:()=>false},enabled:false};
  let settle;const pending=new Promise(resolve=>settle=resolve);
  world[phase]=function(...args){assert.equal(this,world,'preserve trusted method receiver');if(phase==='initializeActor')args[0].spawnAt(new f.THREE.Vector3(...args[1].position),args[1].yaw);return this.enabled||phase==='initializeActor'?pending:undefined;};
  const token=f.createTrustedNativeReplay(f,{isolatedRealm:true,epoch:'match',seed:83921,world,roster,CharacterClass:Display});
  const auth={epoch:'match',owners:new Map(roster.map(r=>[r.nid,r.owner]))};
  const state=()=>JSON.parse(JSON.stringify(f.inspectTrustedNativeReplay(token)));
  const step=(fire=false)=>f.advanceTrustedNativeReplay(token,{tick:state().tick+1,dt:1/60,commands:roster.map(r=>({nid:r.nid,owner:r.owner,life:r.life,input:{fire:fire&&r.nid===1,squid:false,sub:false,jump:false,special:false,move:[0,0]},aim:[r.yaw,0],aimPoint:[0,1,40]}))},auth);
  return {world,token,state,step,settle,close:()=>f.disposeTrustedNativeReplay(token)};
 }
 for(const phase of ['beforeActors','afterActors','afterProjectiles']){
  const w=setup(phase);
  try{
   for(let i=0;i<180;i++)assert.equal(w.step().ok,true);
   const initial=w.state();assert.equal(w.step(true).ok,true);
   for(let i=0;i<80&&!w.state().effects.length;i++)assert.equal(w.step().ok,true);
   const paid=w.state();assert.ok(paid.launches.length>0);assert.ok(paid.effects.length>0);assert.ok(paid.actors[1].hp<100);
   const effect=paid.effects[0],claim=Object.fromEntries(['epoch','tick','serial','kind','attacker','attackerLife','victim','victimLife','source','damage'].map(k=>[k,effect[k]]));
   w.world.enabled=true;const advance=JSON.parse(JSON.stringify(w.step()));
   const selected=f.peekTrustedNativeContact(w.token,claim),committed=selected&&f.commitTrustedNativeContact(w.token,selected);
   rows.push({mode,phase,initialHP:initial.actors[1].hp,nativePaidHP:paid.actors[1].hp,nativeLaunches:paid.launches.length,advance,pendingPhaseSettled:false,contactCommittedBeforePhaseSettled:!!committed,remaining:w.state().contacts});
   if(mode==='original'){assert.equal(advance.ok,true);assert.ok(committed,'old module exposes a completed contact while trusted world phase is pending');}
   else{assert.equal(advance.ok,false);assert.match(advance.reason,/Asynchronous native authority phase/);assert.equal(committed,null);assert.equal(w.state().contacts,0);assert.equal(w.step().ok,false);}
  }finally{w.settle();w.close();}
 }
 try{const w=setup('initializeActor');rows.push({mode,phase:'initializeActor',accepted:true,life:w.state().actors[0].life});w.settle();w.close();assert.equal(mode,'original');}
 catch(error){assert.equal(mode,'candidate');assert.match(error.message,/Asynchronous native authority phase: initializeActor/);rows.push({mode,phase:'initializeActor',accepted:false,error:error.message});}
}
fs.writeFileSync(dir+'/result.json',JSON.stringify({scope:'Scratch component prototype only: actual production-composed Actor/Runner/Projectiles native damage, fixed display/flat world; no production installation/server/browser/lag/migration claim',rows},null,2)+'\n');
console.log(JSON.stringify(rows,null,2));
