import fs from 'node:fs';
import {fixture as sourceFixture} from '/workspace/wt-agent5/patches/splatoon3/tests/source-fixture.mjs';
import {sourceLoadedActorFixture as loadedFixture} from '/workspace/wt-agent5/patches/splatoon3/tests/source-loaded-actor-fixture.mjs';
const candidate=fs.readFileSync('/workspace/scratch/agent1-authority-phase-v2/candidate.mjs','utf8');
const target='patches/network-replication/trusted-native-replay.mjs';
export function fixture(options={}){const prior=options.adaptRuntime;return sourceFixture({...options,adaptRuntime:(rel,source)=>rel===target?candidate:prior?prior(rel,source):source});}
export function sourceLoadedActorFixture(options={}){const prior=options.moduleTransform;return loadedFixture({...options,moduleTransform:(rel,source)=>rel===target?candidate:prior?prior(rel,source):source});}
