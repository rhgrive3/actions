(() => {
  const proto=WebGL2RenderingContext.prototype, textureIds=new WeakMap(), events=[], states=new WeakMap();
  let next=1, dropped=0;
  const id=t=>t?(textureIds.get(t)||null):null;
  const append=e=>{if(events.length<30000)events.push(e);else dropped++;};
  const wrap=(name,after)=>{const original=proto[name];proto[name]=function(...args){const result=Reflect.apply(original,this,args);after.call(this,args,result);return result;};};
  wrap('createTexture',function(_a,t){if(t){textureIds.set(t,next++);append({op:'createTexture',id:id(t)});}});
  wrap('deleteTexture',function([t]){append({op:'deleteTexture',id:id(t),isTextureAfter:t?this.isTexture(t):false});});
  wrap('bindTexture',function([target,t]){let s=states.get(this);if(!s)states.set(this,s=new Map());s.set(target,id(t));});
  wrap('texStorage2D',function([target,levels,internalFormat,width,height]){append({op:'texStorage2D',id:states.get(this)?.get(target)||null,target,levels,internalFormat,width,height});});
  wrap('texImage2D',function(a){const [target,level,internalFormat]=a;append({op:'texImage2D',id:states.get(this)?.get(target)||null,target,level,internalFormat,width:typeof a[3]==='number'?a[3]:null,height:typeof a[4]==='number'?a[4]:null,format:a.length>=9?a[6]:a[3],type:a.length>=9?a[7]:a[4]});});
  wrap('framebufferTexture2D',function([target,attachment,textarget,t,level]){append({op:'framebufferTexture2D',target,attachment,textarget,id:id(t),level});});
  window.__capture642={id,events,get dropped(){return dropped;}};
})();
