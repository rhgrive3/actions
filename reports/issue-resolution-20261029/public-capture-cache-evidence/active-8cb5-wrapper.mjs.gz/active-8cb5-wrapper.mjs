import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {verifyRuntimeBuild} from '/workspace/wt-agent5/scripts/lib/inkwave-runtime-evidence.mjs';
import {bindSite,verifySite} from '/workspace/wt-agent5/scripts/run-inkwave-turf-finish-isolated.mjs';
const root='/workspace/wt-agent5',out='/workspace/scratch/agent1-full-active-8cb5',site='/workspace/scratch/main-wave345-repaired-site';
const head='8cb5dec72c3d8cf9fde8eb703873aacf16c428ee',node='/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex'),git=(...a)=>execFileSync('git',a,{cwd:root,encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');
fs.mkdirSync(out,{recursive:true});assert(!fs.existsSync(out+'/receipt.json'),'Only one full active run');
const binding=bindSite(site);assert.equal(binding.contentHash,'6013fcd90a3ed04ac0d3f5cec30a7088168c4ee9e9506d1e1b4be1c3cfdbea79');
const runtime=verifyRuntimeBuild(site,root,head);
const qa=['scripts/check-inkwave-browser.mjs','scripts/lib/minimap-canvas-probe.mjs','scripts/lib/minimap-transient-clock-reference.mjs','scripts/fixtures/minimap-transient-clock-20261029.json.gz','scripts/lib/inkwave-streamed-music-diagnostics.mjs','scripts/lib/inkwave-projectile-http-file.mjs','scripts/fixtures/inkwave-public-capture-cache-revalidation-1915.json','scripts/tests/inkwave-public-capture-cache-policy.test.mjs','scripts/tests/inkwave-projectile-http-file.test.mjs','scripts/ci/inkwave-test-suites.json'];
const qaBindings=qa.map(file=>({file,sha256:hash(fs.readFileSync(root+'/'+file)),gitBlob:git('rev-parse','HEAD:'+file)}));
const modulePath=root+'/node_modules/playwright/index.mjs';
const {chromium}=await import(modulePath),executable=chromium.executablePath(),version=JSON.parse(fs.readFileSync(root+'/node_modules/playwright/package.json')).version;
assert.equal(version,'1.62.1');
const args=['scripts/check-inkwave-browser.mjs','--site',site,'--evidence-dir',out+'/evidence','--profile-dir',out+'/profile','--exact-source'];
const env={...process.env,SOURCE_SHA:head,PLAYWRIGHT_MODULE:modulePath,PATH:path.dirname(node)+':/workspace/scratch/pr1911-ruby:'+process.env.PATH};
for(const key of ['NODE_OPTIONS','NODE_PATH','CHROMIUM_PATH','PLAYWRIGHT_SKIP_VALIDATE_HOST_REQUIREMENTS'])delete env[key];
const receipt={startedAt:new Date().toISOString(),head,site,contentHash:binding.contentHash,inputHash:binding.inputHash,command:[node,...args],nodeVersion:execFileSync(node,['--version'],{encoding:'utf8'}).trim(),playwrightVersion:version,modulePath,moduleSha256:hash(fs.readFileSync(modulePath)),executable,executableSha256:hash(fs.readFileSync(executable)),qaBindings,exactSource:true,filters:[],quick:false,headerOverrides:false,timeoutOverrides:false,siteArtifactsBeforeVerified:binding.names.length,expectedSourceInputCount:Object.keys(JSON.parse(fs.readFileSync(site+'/inkwave-build.json')).files).length};
fs.writeFileSync(out+'/site-binding.json',JSON.stringify(binding,null,2)+'\n');
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({event:'full-active-start',...receipt,qaBindings:undefined}));
const fd=fs.openSync(out+'/driver.log','w');let exit,signal;
try{const child=spawn(node,args,{cwd:root,env,stdio:['ignore',fd,fd]});[exit,signal]=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('close',(code,sig)=>resolve([code,sig]));});}finally{fs.closeSync(fd);}
Object.assign(receipt,{finishedAt:new Date().toISOString(),exit,signal});
try{
 verifySite(binding);verifyRuntimeBuild(site,root,head);assert.equal(git('rev-parse','HEAD'),head);assert.equal(git('status','--porcelain'),'');
 for(const row of qaBindings)assert.equal(hash(fs.readFileSync(root+'/'+row.file)),row.sha256);
 Object.assign(receipt,{siteArtifactsAfterVerified:binding.names.length,allBuildInputsBeforeAndAfterVerified:true,headAndQaUnchanged:true});
}catch(e){receipt.postVerificationError=e.stack;}
const resultFile=out+'/evidence/browser-result.json';
if(fs.existsSync(resultFile)){
 const bytes=fs.readFileSync(resultFile),result=JSON.parse(bytes);receipt.resultSha256=hash(bytes);
 receipt.resultSummary={status:result.status,error:result.error,sourceSha:result.sourceSha,contentHash:result.contentHash,errors:result.errors,failures:result.failures,consoleErrors:result.consoleErrors,gearSelects:result.gearSelects,gameplay:result.gameplay,verifiedResponses:result.verifiedResponses,keys:Object.keys(result)};
}
receipt.remainingOwnedProcesses=execFileSync('ps',['-eo','pid,args'],{encoding:'utf8'}).split('\n').filter(line=>line.includes(out+'/profile')&&!line.includes('ps -eo'));
receipt.processesClosed=receipt.remainingOwnedProcesses.length===0;
receipt.passed=exit===0&&!signal&&!receipt.postVerificationError&&receipt.resultSummary?.status==='passed'&&receipt.processesClosed;
receipt.driverSha256=hash(fs.readFileSync(out+'/driver.log'));
fs.writeFileSync(out+'/receipt.json',JSON.stringify(receipt,null,2)+'\n');
console.log(JSON.stringify({event:'full-active-complete',passed:receipt.passed,exit,signal,result:receipt.resultSummary,processesClosed:receipt.processesClosed,postVerificationError:receipt.postVerificationError,output:out}));
process.exitCode=receipt.passed?0:1;
