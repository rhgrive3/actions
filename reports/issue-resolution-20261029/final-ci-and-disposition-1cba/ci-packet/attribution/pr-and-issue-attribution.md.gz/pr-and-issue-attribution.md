# PR publication and issue closure accounting

Eight distinct PRs received root-published repair heads across the retained session history: seven earlier PRs plus current1914. This counts actual published repair histories, not all26 audited PRs, not eight current CI-green heads, and not merges performed by root. Current required CI applies to1914 only.

| PR | Root-published repair head | Current role |
| --- | --- | --- |
| 1907 | `76c11325bd482c47e0c4dc12830422eafdc3452d` | earlier repair history; old head not relabeled green |
| 1908 | `88f8d25d13a309ee47c59831116b1742740df517` | earlier repair history; old head not relabeled green |
| 1909 | `1035835081fdaba1a957f27aec7fe93b1abdde8d` | earlier repair history; old head not relabeled green |
| 1910 | `f9a0ed1986320dd4b95c6e422fab9ebc92b91eb5` | earlier repair history; old head not relabeled green |
| 1911 | `7efdabe38f13bc11a64008777a925ad01e8af816` | earlier repair history; old head not relabeled green |
| 1912 | `7e8601d233e2a56ee175f0c459ed304621e870b5` | earlier repair history; old head not relabeled green |
| 1914 | `1cba8c73e79565757f051bb106c6076440ca97d9` | current open CI target |
| 1915 | `6690e8017252396b327ae6088d3746765ad5835d` | earlier repair history; old head not relabeled green |

Confirmed closed issues:3. Relative to initial audit 2026-10-29T06:20:00Z, new closures:2 (#79 and #725); prior closure:1 (#1767).

| Issue | Completed closure UTC | Initial open audit |
| --- | --- | --- |
| 79 | 2026-10-29T10:42:34Z | present |
| 725 | 2026-10-29T10:42:37Z | present |
| 1767 | 2026-10-28T22:05:22Z | already closed |

GitHub identifies rhgrive3 as the closing account. This does not identify which same-account process performed an action. All26 audited PRs must not be presented as fixed;1916 owner work is preserved without root credit.
