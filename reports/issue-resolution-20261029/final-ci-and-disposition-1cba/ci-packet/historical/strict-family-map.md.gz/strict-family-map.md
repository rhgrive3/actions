# Current equivalent CI failure-family coverage

Snapshot 2026-10-29T22:16:38.679Z; exact current PR1914 `1cba8c73e79565757f051bb106c6076440ca97d9`.

Deduplicate historical failures by PR + workflow + event + check family. Only CPU shard variants collapse, and all8 exact-current-head shards must pass. Multiple old PR rows mapping to one current gate are observations covered by a current equivalent gate, not multiple newly executed current gates. Known-cause coverage also requires demonstrated cause classification; canceled/skip/missing/unknown never qualify. Historical source heads remain failed.

Original111 retained PR failed-job records form72 families; original45 live-family subset is intact. Expanded cohorts: 148 PR records/90 PR families, plus12 main-context records/7 families. Cohorts were not rewritten.

Known-cause PR primary families covered by actual current success: 60 (original45 subset: 39). Separate main push→PR context families covered: 6. Distinct current successful gate families serving these known-cause comparisons: 22. These are separate metrics, not a final all-CI-green claim.

| Historical PR / context | Workflow / family | Before jobs | Causes | Current equivalent | Counted known-cause coverage |
| --- | --- | --- | --- | --- | --- |
| main context | Validate INKWAVE update / browser (active, chromium webkit) | 123650957109 | HUD-private-spIcon-fixture | passed | true |
| main context | Validate INKWAVE update / browser (catalog, chromium) | 122991218923 | wiper-wet-retirement | passed | true |
| main context | Validate INKWAVE update / browser (network, chromium webkit) | 122991218864 | ci-source-shard-coverage | passed | true |
| main context | Validate INKWAVE update / browser (ui, chromium webkit) | 123650956955 | menu-source-epoch | passed | true |
| main context | Validate INKWAVE update / patch_tests (8-shard family) | 123650956885, 122991218931, 122991218879, 122991219015, 122991218857 | Hissen-display-multiplier-fixture, ScreenFX-constructor-cache-fixture, audio-latest-intent-fixture, ci-admission-contract, contact-FK-owner-seam, explosher-census-fixture, historical-character-owner-chain, historical-source-motion-owner-chain, roller-source-epoch, wiper-wet-retirement | passed | true |
| main context | Validate INKWAVE update / validate | 123004717466 | secondary-strict-aggregate | passed | false |
| main context | Validate INKWAVE update / validate_core | 123650956663, 122991218484 | ci-source-shard-coverage, frame-AST-fixture-boundary, sandbox-route-duplicate-module, wall-route-install-contract | passed | true |
| 1882 | INKWAVE projectile visuals / Capture after | 122299997364 | unknown-historical-native-menu-timeout | passed | false |
| 1882 | Validate INKWAVE update / patch_tests (8-shard family) | 122279728189, 122279728215, 122279728491, 122279728860 | audio-latest-intent-fixture, historical-character-owner-chain, hud-source-scheduling-epoch, solid-material-UV-fixture, unknown-historical-runner-shutdown | passed | false |
| 1882 | Validate INKWAVE update / validate | 122365763450 | secondary-strict-aggregate | passed | false |
| 1882 | Validate INKWAVE update / validate_core | 122357380445 | workflow-source-epoch | passed | true |
| 1897 | Validate INKWAVE update / browser (network, chromium webkit) | 122833440434 | ci-source-shard-coverage | passed | true |
| 1897 | Validate INKWAVE update / browser (responsive, chromium webkit) | 122833440425 | unknown-historical-webkit-setup | passed | false |
| 1897 | Validate INKWAVE update / patch_tests (8-shard family) | 122820202528 | historical-source-motion-owner-chain | passed | true |
| 1897 | Validate INKWAVE update / validate | 122855819463 | secondary-strict-aggregate | passed | false |
| 1897 | Validate INKWAVE update / validate_core | 122833440402 | ci-source-shard-coverage | passed | true |
| 1899 | Validate INKWAVE update / browser (responsive, chromium webkit) | 122232103890 | unknown-historical-webkit-setup | passed | false |
| 1900 | Validate INKWAVE update / browser (responsive, chromium webkit) | 122291734506 | unknown-historical-webkit-setup | passed | false |
| 1901 | Validate INKWAVE update / patch_tests (8-shard family) | 122530225430, 122530225540, 122530225554, 122530226048 | audio-latest-intent-fixture, historical-character-owner-chain, hud-source-scheduling-epoch, solid-material-UV-fixture, unknown-historical-runner-shutdown | passed | false |
| 1901 | Validate INKWAVE update / validate | 122538257339 | secondary-strict-aggregate | passed | false |
| 1901 | Validate INKWAVE update / validate_core | 122530479533 | workflow-source-epoch | passed | true |
| 1902 | Validate INKWAVE update / patch_tests (8-shard family) | 122540051654, 122540051803, 122540051814, 122540051939 | audio-latest-intent-fixture, historical-character-owner-chain, hud-source-scheduling-epoch, solid-material-UV-fixture, unknown-historical-runner-shutdown | passed | false |
| 1902 | Validate INKWAVE update / validate | 122566557526 | secondary-strict-aggregate | passed | false |
| 1902 | Validate INKWAVE update / validate_core | 122544332526 | workflow-source-epoch | passed | true |
| 1903 | Validate INKWAVE update / browser (network, chromium webkit) | 122838059039 | ci-source-shard-coverage | passed | true |
| 1903 | Validate INKWAVE update / validate | 122858909248 | secondary-strict-aggregate | passed | false |
| 1903 | Validate INKWAVE update / validate_core | 122838058758 | ci-source-shard-coverage | passed | true |
| 1904 | Validate INKWAVE update / patch_tests (8-shard family) | 122830646184, 122830646216 | audio-latest-intent-fixture, explosher-census-fixture, paint-source-owner-chain, soft-push-live-roster | passed | true |
| 1904 | Validate INKWAVE update / validate | 122867450196 | secondary-strict-aggregate | passed | false |
| 1904 | Validate INKWAVE update / validate_core | 122830646026 | responsive-launch-contract | passed | true |
| 1905 | Validate INKWAVE update / browser (network, chromium webkit) | 122847393658 | ci-source-shard-coverage | passed | true |
| 1905 | Validate INKWAVE update / patch_tests (8-shard family) | 122829175776, 122829175811, 122829175861, 122829175926 | audio-latest-intent-fixture, historical-character-owner-chain, hud-source-scheduling-epoch, solid-material-UV-fixture, unknown-historical-runner-shutdown | passed | false |
| 1905 | Validate INKWAVE update / validate | 122859692305 | secondary-strict-aggregate | passed | false |
| 1905 | Validate INKWAVE update / validate_core | 122847392892 | ci-source-shard-coverage | passed | true |
| 1907 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123185883602 | offscreen-hair-fixture-dependency | passed | true |
| 1907 | INKWAVE gameplay resource regressions / resource-regressions | 123185883456 | native-observation-window | passed | true |
| 1907 | INKWAVE object presentation native QA / compare-objects | 123398903470 | historical-rainmaker-air-landing-negative | passed | true |
| 1907 | INKWAVE squid regression native QA / compare-squid | 123185884158 | offscreen-hair-fixture-dependency | passed | true |
| 1907 | Validate INKWAVE update / browser (active, chromium webkit) | 123189142478, 123318672398 | browser-cache-abi, input-listener-count-oracle | passed | true |
| 1907 | Validate INKWAVE update / browser (network, chromium webkit) | 123318672348 | native-generation-readiness | passed | true |
| 1907 | Validate INKWAVE update / patch_tests (8-shard family) | 123189142570, 123189142571, 123189142580, 123189142588, 123189142623, 123360212263 | explosher-stage-fixture-readiness, historical-source-motion-owner-chain, input-listener-count-oracle, motion-unread-clip-allocation, offscreen-hair-fixture-dependency, pending-flush-fixture-closure | passed | true |
| 1907 | Validate INKWAVE update / validate | 123209799491 | secondary-strict-aggregate | passed | false |
| 1907 | Validate INKWAVE update / validate_core | 123318672225 | sparse-circleci-contract | passed | true |
| 1908 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123185883627, 123269060674 | global-sparse-JS-closure, offscreen-hair-fixture-dependency | passed | true |
| 1908 | INKWAVE composed CPU regression / source-and-emitted | 123269061091 | chromium-sandbox-runner | passed | true |
| 1908 | INKWAVE focused CI repair regressions / Repair regressions (contracts) | 123276128714 | reviewed-sparse-profile-pin | workflow_not_created | false |
| 1908 | INKWAVE gameplay resource regressions / resource-regressions | 123302140653 | zero-paint-native-window | passed | true |
| 1908 | Validate INKWAVE update / browser (active, chromium webkit) | 123193769369, 123305266041 | browser-cache-abi, input-listener-count-oracle | passed | true |
| 1908 | Validate INKWAVE update / patch_tests (8-shard family) | 123193769415, 123193769443, 123193769465, 123193769531, 123305266006 | historical-source-motion-owner-chain, input-listener-count-oracle, offscreen-hair-fixture-dependency, pending-flush-fixture-closure, scan-reference-policy | passed | true |
| 1908 | Validate INKWAVE update / validate | 123210904548 | secondary-strict-aggregate | passed | false |
| 1908 | Validate INKWAVE update / validate_core | 123305265906 | sparse-circleci-contract | passed | true |
| 1909 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123211856419, 123269103303 | ci-admission-contract, global-sparse-JS-closure | passed | true |
| 1909 | INKWAVE composed CPU regression / source-and-emitted | 123269103894 | chromium-sandbox-runner | passed | true |
| 1909 | INKWAVE fast PR preflight / fast-preflight | 123211854821 | ci-admission-contract, responsive-launch-contract | passed | true |
| 1909 | INKWAVE object presentation native QA / compare-objects | 123384446550 | historical-rainmaker-air-landing-negative | passed | true |
| 1909 | Validate INKWAVE update / browser (active, chromium webkit) | 123317585517 | browser-cache-abi | passed | true |
| 1909 | Validate INKWAVE update / browser (catalog, chromium) | 123213576174 | wiper-wet-retirement | passed | true |
| 1909 | Validate INKWAVE update / browser (network, chromium webkit) | 123213576195 | ci-source-shard-coverage | passed | true |
| 1909 | Validate INKWAVE update / patch_tests (8-shard family) | 123213576162, 123213576201, 123213576294, 123213576305, 123317585456 | audio-latest-intent-fixture, ci-admission-contract, explosher-census-fixture, historical-character-owner-chain, historical-source-motion-owner-chain, roller-source-epoch, scan-reference-policy, wiper-wet-retirement | passed | true |
| 1909 | Validate INKWAVE update / validate | 123224378721 | secondary-strict-aggregate | passed | false |
| 1909 | Validate INKWAVE update / validate_core | 123213576065, 123317585388 | ci-source-shard-coverage, sandbox-route-duplicate-module, sparse-circleci-contract, wall-route-install-contract | passed | true |
| 1910 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123206320043, 123270401001 | ci-admission-contract, global-sparse-JS-closure | passed | true |
| 1910 | INKWAVE Explosher flight glitter / native-pair | 123270400752 | historical-attract-readiness | passed | true |
| 1910 | INKWAVE composed CPU regression / source-and-emitted | 123270400991 | chromium-sandbox-runner | passed | true |
| 1910 | INKWAVE fast PR preflight / fast-preflight | 123206320237 | ci-admission-contract, responsive-launch-contract | passed | true |
| 1910 | Validate INKWAVE update / browser (active, chromium webkit) | 123319093578 | browser-cache-abi | passed | true |
| 1910 | Validate INKWAVE update / browser (catalog, chromium) | 123207404001 | wiper-wet-retirement | passed | true |
| 1910 | Validate INKWAVE update / browser (network, chromium webkit) | 123207403936 | ci-source-shard-coverage | passed | true |
| 1910 | Validate INKWAVE update / patch_tests (8-shard family) | 123207403968, 123207404030, 123207404033, 123207404059, 123319093589 | audio-latest-intent-fixture, ci-admission-contract, explosher-census-fixture, historical-character-owner-chain, historical-source-motion-owner-chain, roller-source-epoch, scan-reference-policy, wiper-wet-retirement | passed | true |
| 1910 | Validate INKWAVE update / validate | 123218537630 | secondary-strict-aggregate | passed | false |
| 1910 | Validate INKWAVE update / validate_core | 123207404126 | ci-source-shard-coverage, sandbox-route-duplicate-module, wall-route-install-contract | passed | true |
| 1911 | INKWAVE roller support counterfactual source identity / native-positive-and-fault-controls | 123302130988, 123302132069 | roller-source-epoch | passed | true |
| 1911 | Validate INKWAVE update / browser (active, chromium webkit) | 123310718635 | browser-cache-abi | passed | true |
| 1912 | INKWAVE 19-special source and runtime boundaries / special-fidelity | 123403939571 | native-special-source-team-fixture | workflow_not_created | false |
| 1912 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123403938943 | lod-historical-owner-bridge | passed | true |
| 1912 | INKWAVE composed CPU regression / source-and-emitted | 123403939257 | lod-historical-owner-bridge | passed | true |
| 1912 | INKWAVE fast PR preflight / fast-preflight | 123403939327, 123440441038 | responsive-launch-contract, wall-route-install-contract | passed | true |
| 1912 | INKWAVE terminal recovery native QA / native | 123403938501, 123440445261 | native-display-fixture-commented-out-invocation, native-display-fixture-phase | passed | true |
| 1912 | Validate INKWAVE native stage integration / contracts | 123403940091 | material-allocation-counter-fixture, native-display-fixture-phase, timer-fixture-API | passed | true |
| 1914 | INKWAVE eight headgear production candidate QA / verify-combined | 123676860966 | secondary-cancelled-aggregate | passed | false |
| 1914 | INKWAVE projectile visuals / Capture after | 123508291289, 123555276517 | range-checker-source-epoch, unknown-projectile-promise-collection | passed | false |
| 1914 | INKWAVE terminal recovery native QA / native | 123508229028, 123555216604 | unknown-audio-request-abort-owner | passed | false |
| 1914 | Validate INKWAVE update / browser (active, chromium webkit) | 123511917263, 123559081788, 123642974216 | HUD-private-spIcon-fixture, minimap-clock-reference-epoch, secondary-failure-evidence-storage-permission, unknown-silent-npm-install | passed | false |
| 1914 | Validate INKWAVE update / browser (range, chromium webkit) | 123511917219 | lazy-range-WEAPON-tab | passed | true |
| 1914 | Validate INKWAVE update / browser (ui, chromium webkit) | 123511917545 | menu-source-epoch | passed | true |
| 1914 | Validate INKWAVE update / patch_tests (8-shard family) | 123511917742, 123511917251, 123511917717, 123511917606, 123511917399, 123559081544, 123681981687, 123681981697, 123681981851, 123709310616 | HUD-private-spIcon-fixture, Hissen-display-multiplier-fixture, contact-FK-owner-seam, extracted-helper-dependencies, historical-character-owner-chain, mark-lease-time-epoch, paint-source-owner-chain, residual-ui-policy-epoch, unknown-silent-npm-install | passed | false |
| 1914 | Validate INKWAVE update / validate | 123534626982, 123578883975, 123706071475, 123736457555, 123658789940, 123676722967 | secondary-cancelled-aggregate, secondary-strict-aggregate | passed | false |
| 1914 | Validate INKWAVE update / validate_core | 123511917030 | frame-AST-fixture-boundary | passed | true |
| 1915 | INKWAVE draft CI failure reproduction / focused-regressions | 123519674119 | draft-fixture-VM-flag, historical-character-owner-chain | workflow_not_created | false |
| 1915 | INKWAVE terminal recovery native QA / native | 123519712918, 123529378823 | unknown-audio-request-abort-owner | passed | false |
| 1916 | INKWAVE A+ Quality & Security Gate / verify-aplus-suite | 123638611866 | owner-compact-HUD-source-anchor | passed | true |
| 1916 | INKWAVE isolated character asset QA / neutral-loader-fixture | 123638611418 | owner-compact-HUD-source-anchor | passed | true |
| 1916 | INKWAVE narrow HUD tank regression / browser (chromium) | 123638610375 | owner-compact-HUD-source-anchor | passed | true |
| 1916 | INKWAVE narrow HUD tank regression / browser (webkit) | 123638610889 | owner-compact-HUD-source-anchor | passed | true |
| 1916 | Validate INKWAVE update / build_site | 123638794780 | owner-compact-HUD-source-anchor | passed | true |
| 1916 | Validate INKWAVE update / validate | 123639041548 | secondary-strict-aggregate | passed | false |
| 1916 | ZEVANT account and Workers build / account | 123638611480 | owner-compact-HUD-source-anchor | passed | true |
