import collections, hashlib, json
from pathlib import Path

R=Path('/workspace/scratch')
source=R/'agent2-current-failure-family-map.json'
m=json.loads(source.read_text())
s=json.loads((R/'agent2-current-connector-latest.json').read_text())
p=next(p for p in s['prs'] if p['number']==1914)
assert m['at']==s['at'] and m['head']==p['head'] and s['complete']
family_index={(f['pr'],f['workflow'],f['event'],f['family']):f for f in m['families']}
current_checks={c['id']:c for c in p['checks']}
current_runs={r['id']:r for r in p['runs']}
alternative_path=R/'agent2-current-failed-case-equivalents.json'
alternative=json.loads(alternative_path.read_text())if alternative_path.exists()else None
alternatives={r['job']:r for r in alternative['equivalents']}if alternative and alternative['head']==p['head']else {}
original_cohorts={'baseline85','postAtomic15','postRepair1','additional8','cb9Followup2'}
def unknown(c):return c.startswith(('unknown-','unclassified-'))
def primary(c):return not c.startswith('secondary-')
records=[]
for old in m['failedJobManifest']:
    key=(old['pr'],old['workflow'],old['event'],old['family'])
    f=family_index[key];eq=f['currentEquivalent']
    if eq['accepted']:
        run=current_runs[eq['run']]
        assert (run['path'],run['event'],run['head_sha'])==(eq['path'],eq['event'],p['head'])
        assert len(eq['checks'])==eq['expectedChecks']
        if old['family']=='patch_tests (8-shard family)':assert {c['name']for c in eq['checks']}=={f'patch_tests ({i})'for i in range(8)}
        for c in eq['checks']:
            actual=current_checks[c['id']]
            assert actual['status']=='completed' and actual['conclusion']=='success' and '/runs/'+str(run['id'])+'/'in actual['details_url']
    strict_eq=eq
    alt=alternatives.get(old['job'])
    if not eq['accepted'] and alt:
        parts=[]
        for requested in alt['components']:
            runs=[r for r in p['runs']if (r['path'],r['event'])==(requested['path'],requested['event'])]
            assert len(runs)<=1
            run=runs[0]if runs else None
            checks=[c for c in p['checks']if run and '/runs/'+str(run['id'])+'/'in(c.get('details_url')or'')and(c['name'].startswith('patch_tests (')if requested['expectedChecks']==8 else c['name']==requested['family'])]
            if requested['expectedChecks']==8 and checks:assert {c['name']for c in checks}=={f'patch_tests ({i})'for i in range(8)}
            accepted=len(checks)==requested['expectedChecks']and all(c['status']=='completed'and c['conclusion']=='success'for c in checks)
            state='passed'if accepted else 'failed'if any(c['conclusion']=='failure'for c in checks)else'cancelled'if any(c['conclusion']=='cancelled'for c in checks)else'not_created'if not checks else'pending'
            parts.append({**requested,'run':run['id']if run else None,'head':p['head'],'checks':checks,'accepted':accepted,'status':state})
        accepted=all(part['accepted']for part in parts)
        eq={'equivalenceBasis':'diagnosed failed cases across current workflows','status':'passed'if accepted else'failed'if any(part['status']=='failed'for part in parts)else'pending','accepted':accepted,'path':parts[0]['path'],'event':parts[0]['event'],'run':parts[0]['run'],'expectedChecks':sum(part['expectedChecks']for part in parts),'checks':[c for part in parts for c in part['checks']],'components':parts,'sourceProof':{'path':str(alternative_path),'sha256':hashlib.sha256(alternative_path.read_bytes()).hexdigest()},'failedCaseProof':alt,'historicalEntireWorkflowReplayed':False}
    primary_causes=[c for c in old['causeIds']if primary(c)]
    secondary_only=not primary_causes
    unproven=any(unknown(c)for c in primary_causes)
    if secondary_only:disposition='excluded_secondary_only'
    elif unproven:disposition='excluded_unproven_primary'
    elif old['metadataUnverified']:disposition='excluded_unverified_metadata'
    elif not eq['accepted']:disposition='current_equivalent_'+eq['status']
    else:disposition='known_primary_current_equivalent_passed'
    explicit_owner=old['pr']==1916 and old.get('repairCredit','').startswith('Owner')
    records.append({**old,'primaryCauseIds':primary_causes,'original111':old['cohort']in original_cohorts,'strictSameWorkflowEquivalent':strict_eq,'currentEquivalent':eq,'historicalEventToCurrentEventExplicit':old['event']!=eq['event'],'countAsResolvedKnownPrimaryJob':disposition=='known_primary_current_equivalent_passed','explicitPriorOwnerRepairCredit':explicit_owner,'eligibleForRootSessionRepairCredit':not explicit_owner,'disposition':disposition,'historicalHeadRelabeledPassed':False})
assert len(records)==len({r['job']for r in records})==m['scopeCounts']['expandedFailedJobRecords']
def summarize(rows):
    eligible=[r for r in rows if r['primaryCauseIds'] and not any(unknown(c)for c in r['primaryCauseIds']) and not r['metadataUnverified']]
    causes=sorted({c for r in rows for c in r['primaryCauseIds']if not unknown(c)})
    cause_rows=[]
    for cause in causes:
        related=[r for r in rows if cause in r['primaryCauseIds']]
        accepted=all(r['countAsResolvedKnownPrimaryJob']for r in related)
        cause_rows.append({'id':cause,'historicalJobs':sorted(r['job']for r in related),'allRelatedCurrentEquivalentGatesPassed':accepted,'countAsResolvedKnownPrimaryCause':accepted,'notCountedJobs':[{'job':r['job'],'disposition':r['disposition']}for r in related if not r['countAsResolvedKnownPrimaryJob']]})
    return {'retainedDistinctFailedJobs':len(rows),'knownPrimaryEligibleFailedJobs':len(eligible),'knownPrimaryFailedJobsWithCurrentEquivalentPassed':sum(r['countAsResolvedKnownPrimaryJob']for r in rows),'knownPrimaryCauseFamilies':len(causes),'knownPrimaryCauseFamiliesAllCurrentEquivalentGatesPassed':sum(c['countAsResolvedKnownPrimaryCause']for c in cause_rows),'dispositions':dict(collections.Counter(r['disposition']for r in rows)),'countedJobIds':sorted(r['job']for r in rows if r['countAsResolvedKnownPrimaryJob']),'countedViaFailedCaseCrossWorkflowProof':[r['job']for r in rows if r['countAsResolvedKnownPrimaryJob']and r['currentEquivalent'].get('components')],'causeFamilies':cause_rows}
cohorts={'original111PR':[r for r in records if r['original111']],'expanded146PR':[r for r in records if r['scope']=='PR'and r['cohort']!='PR1914-72-followup'],'followup72PR':[r for r in records if r['cohort']=='PR1914-72-followup'],'expandedCurrentPR':[r for r in records if r['scope']=='PR'],'separate12MainContext':[r for r in records if r['scope']=='main-context']}
assert len(cohorts['original111PR'])==111 and len(cohorts['expanded146PR'])==146 and len(cohorts['followup72PR'])==2 and len(cohorts['separate12MainContext'])==12
summary={k:summarize(rows)for k,rows in cohorts.items()}
owner_rows=[r for r in cohorts['expandedCurrentPR']if r['explicitPriorOwnerRepairCredit']]
session_rows=[r for r in cohorts['expandedCurrentPR']if not r['explicitPriorOwnerRepairCredit']]
attribution={'sessionRepairEvidenceExcludingExplicitPriorOwner1916':summarize(session_rows),'explicitPriorOwner1916Preserved':summarize(owner_rows),'definition':'Total expandedPR current coverage includes6known-primary1916 owner repair jobs and1secondary fan-in. These owner jobs/cause are retained and verified, but excluded from root-session repair credit. Session-vs-owner cause counts must not be blindly added if any cause IDs overlap.','sharedPrimaryCauseIds':sorted({c for r in owner_rows for c in r['primaryCauseIds']}&{c for r in session_rows for c in r['primaryCauseIds']})}
gate=json.loads((R/'agent2-pr1914-gate-coverage-latest.json').read_text())
required_pass=all(gate[k]['created']==gate[k]['expected'] and gate[k]['notCreated']==0 and gate[k]['states']=={'success':gate[k]['expected']}for k in ['CPU8','browser7','core'])
workflows_terminal=len(p['runs'])==36 and all(r['status']=='completed' and r['conclusion']in ['success','skipped']for r in p['runs'])
ready=required_pass and workflows_terminal and not gate['missingWorkflowKeys'] and gate['allObservedActionsCheckFamilies']['notCreated']==0
out={'schema':1,'at':m['at'],'head':m['head'],'main':m['main'],'finalCIReady':ready,'provisional':not ready,'definition':'Each historical failed job ID counts once, even if several known primary cause IDs apply. Primary cause families are distinct diagnosed cause IDs and count only when every associated job in that cohort has its exact-current equivalent gate fully passed. CPU equivalents require all8 shards. Unknown primary, secondary-only, missing/cancelled/skipped/pending gates and unverified metadata do not count. Original111 is a subset of expanded146 PR jobs; main12 is separate. Historical heads remain failed.','cohorts':summary,'records':records,'excludedOperationalSecondaryJobs':m['separateExcludedOperationalSecondaryCohort'],'requiredCurrentGates':{k:gate[k]for k in ['CPU8','browser7','core']},'workflowStates':dict(collections.Counter(r['conclusion']or r['status']for r in p['runs'])),'sourceReceipt':{'path':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest()},'currentSnapshotReceipt':m['currentSnapshotReceipt'],'unknownAudit':{'path':str(R/'agent2-unproven-primary-audit.json'),'sha256':hashlib.sha256((R/'agent2-unproven-primary-audit.json').read_bytes()).hexdigest()}if (R/'agent2-unproven-primary-audit.json').exists()else None}
out['repairAttribution']=attribution
out['definition']+=' Prior expanded146PR remains immutable; followup72PR contains2 later jobs (one primary and one secondary). expandedCurrentPR is their148-job union. These overlapping cohorts must not be added.'
out['crossContextDeduplicatedSummary']={'allExplicitPRAndMainRecords':summarize(records),'excludingExplicitPriorOwner1916':[r['job']for r in records if not r['explicitPriorOwnerRepairCredit']],'excludingExplicitPriorOwner1916Summary':summarize([r for r in records if not r['explicitPriorOwnerRepairCredit']]),'definition':'Cross-context cause IDs are deduplicated across PR and main; main failure jobs remain a separate context and are never relabeled as main CI success. The original111 cohort is already inside expanded146 and is never added again.'}
(R/'agent2-primary-resolution-metrics.json').write_text(json.dumps(out,indent=2)+'\n')
md=['# Known primary CI failure coverage','',f"Snapshot {out['at']}; exact PR1914 `{out['head']}`. Final CI ready: {str(ready).lower()}. Counts are provisional until all required current gates pass.",'',out['definition'],'','| Cohort | Retained failed jobs | Known primary eligible jobs | Current equivalent passed jobs | Distinct primary causes | All associated gates passed causes |','| --- | ---: | ---: | ---: | ---: | ---: |']
for name,x in summary.items():md.append(f"| {name} | {x['retainedDistinctFailedJobs']} | {x['knownPrimaryEligibleFailedJobs']} | {x['knownPrimaryFailedJobsWithCurrentEquivalentPassed']} | {x['knownPrimaryCauseFamilies']} | {x['knownPrimaryCauseFamiliesAllCurrentEquivalentGatesPassed']} |")
md+=['','| Repair attribution within expandedPR | Known primary jobs passed | Distinct primary causes fully covered |','| --- | ---: | ---: |']
for key in ['sessionRepairEvidenceExcludingExplicitPriorOwner1916','explicitPriorOwner1916Preserved']:
    x=attribution[key];md.append(f"| {key} | {x['knownPrimaryFailedJobsWithCurrentEquivalentPassed']} | {x['knownPrimaryCauseFamiliesAllCurrentEquivalentGatesPassed']} |")
md+=['',attribution['definition'],'','Every historical job disposition and exact current workflow path/event/run/check IDs are in the JSON. Six separate operational fan-in records are excluded. The 15 historical primary events with unproven causes are covered by the separate audit and remain excluded even when current equivalent gates pass.']
(R/'agent2-primary-resolution-metrics.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'at':out['at'],'head':out['head'],'finalCIReady':ready,'cohorts':{k:{kk:vv for kk,vv in v.items()if kk not in ['countedJobIds','causeFamilies']}for k,v in summary.items()}}))
