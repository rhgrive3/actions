import hashlib,json,subprocess
from pathlib import Path

R=Path('/workspace/scratch');REPO='/workspace/wt-agent5'
m=json.loads((R/'agent2-current-failure-family-map.json').read_text());head=m['head']
def git(*args):return subprocess.check_output(['git','-C',REPO,*args])
def source(path):
    data=git('show',head+':'+path)
    return {'path':path,'blob':git('rev-parse',head+':'+path).decode().strip(),'sha256':hashlib.sha256(data).hexdigest(),'text':data.decode()}
paths=['.github/workflows/validate-inkwave-update.yml','scripts/ci/inkwave-test-suites.json','scripts/ci/run-inkwave-test-suite.mjs','scripts/check-inkwave-patches.mjs','scripts/lib/inkwave-test-shards.mjs','.github/workflows/inkwave-swim-entry-qa.yml','scripts/tests/inkwave-added-ci-contracts.test.mjs','patches/splatoon3/tests/all-specials.test.mjs','patches/local-quality/tests/queue-historical-character-20261026.test.mjs','tools/swim-entry-qa/workflow.test.mjs']
sources={p:source(p)for p in paths};yaml=sources[paths[0]]['text'];suite=json.loads(sources[paths[1]]['text'])
assert '        run: node scripts/ci/run-inkwave-test-suite.mjs verifier' in yaml.split('  validate_core:',1)[1].split('  patch_tests:',1)[0]
assert any('scripts/tests/inkwave-added-ci-contracts.test.mjs'in s['args']for s in suite['verifier']['steps'])
assert "node --experimental-vm-modules scripts/check-inkwave-patches.mjs"in yaml
runner=sources['scripts/check-inkwave-patches.mjs']['text']
assert 'discoverSourceTestFiles(ROOT)'in runner and "['--experimental-vm-modules', '--test',"in runner and '...ordinaryFiles]'in runner
shards=sources['scripts/lib/inkwave-test-shards.mjs']['text']
assert 'index % shardCount === shardIndex'in shards and "'patches/splatoon3/tests'"in shards and "'patches/local-quality/tests'"in shards
all_paths=git('ls-tree','-r','--name-only',head).decode().splitlines()
dirs=['patches/splatoon3/tests/','patches/reliability/tests/','patches/network-replication/tests/','patches/local-quality/tests/'];excluded=['patches/local-quality/tests/paint-mipmaps.test.mjs','patches/local-quality/tests/settings-hud-queue.test.mjs']
files=sorted([p for p in all_paths if p.endswith('.test.mjs')and any(p.startswith(d)for d in dirs)and p not in excluded]+['scripts/tests/inkwave-idle-resources-gates.test.mjs'])
targets=['patches/splatoon3/tests/all-specials.test.mjs','patches/local-quality/tests/queue-historical-character-20261026.test.mjs']
assignments={f:files.index(f)%8 for f in targets};assert all(f in files for f in targets)
assert 'node --experimental-vm-modules --test --test-concurrency=1 tools/swim-entry-qa/probe.test.mjs tools/swim-entry-qa/compare.test.mjs tools/swim-entry-qa/workflow.test.mjs'in sources['.github/workflows/inkwave-swim-entry-qa.yml']['text']
tests={123276128714:['current sparse checkouts retain the complete input closure and historical baseline stays full','exact job-bound sparse profiles reject missing, unexpected and misplaced CircleCI inputs','the excluded authoring workbench is not referenced by runtime/test/build input code','authoring dependency guard rejects executable fixture paths and extra consumers','synthetic sparse paths cannot hide real authoring imports or filesystem reads'],123403939571:['remote destructible hit proposal validates the owner life using the network last-life fallback'],123519674119:['historical character source retains independently pinned input and both later owner anchors (text only)','the real fixture selects emitted bytes and refuses missing emitted paths instead of source fallback']}
testfiles={123276128714:['scripts/tests/inkwave-added-ci-contracts.test.mjs'],123403939571:[targets[0]],123519674119:[targets[1],'tools/swim-entry-qa/workflow.test.mjs']}
for job,tt in tests.items():
    text='\n'.join(sources[p]['text']for p in testfiles[job])
    for title in tt:assert title in text,(job,title)
core={'path':'.github/workflows/validate-inkwave-update.yml','event':'pull_request','family':'validate_core','expectedChecks':1}
cpu={'path':'.github/workflows/validate-inkwave-update.yml','event':'pull_request','family':'patch_tests (8-shard family)','expectedChecks':8}
swim={'path':'.github/workflows/inkwave-swim-entry-qa.yml','event':'pull_request','family':'compare-swim-entry','expectedChecks':1}
components={123276128714:[core],123403939571:[cpu],123519674119:[cpu,swim]}
out={'schema':1,'head':head,'definition':'Failed-case equivalence is distinct from replaying the entire historical workflow. For three absent historical workflows, all diagnosed failed test bodies remain in current actual gates, with original assertions and required VM flags. Every component must pass; CPU requires all8 shards regardless of the per-file canonical partition recorded here. Strict same-workflow family map remains unchanged.','sourceTestFileCount':len(files),'sourceTestAssignments':assignments,'sourceEvidence':[{k:v for k,v in s.items()if k!='text'}for s in sources.values()],'equivalents':[{'job':job,'historicalWorkflowRunMissingAtCurrentHead':True,'equivalenceBasis':'all diagnosed failed cases executed by current gates','failedTestFiles':testfiles[job],'failedTestTitles':tests[job],'components':components[job]}for job in tests]}
snapshot=json.loads((R/'agent2-current-connector-latest.json').read_text());pr=next(p for p in snapshot['prs']if p['number']==1914)
assert pr['head']==head
def current_log(check_name):
    checks=[c for c in pr['checks']if c['name']==check_name]
    assert len(checks)<=1
    if not checks:return None,None
    check=checks[0];paths=list(R.glob('*current-'+('core'if check_name=='validate_core'else'swim')+'-job-'+str(check['id'])+'.log'))
    assert len(paths)<=1
    return check,paths[0]if paths else None
swim_check,swim_log=current_log('compare-swim-entry')
if swim_log:
    text=swim_log.read_text();title=tests[123519674119][1]
    hits=[{'line':i+1,'text':l}for i,l in enumerate(text.splitlines())if title in l and 'Z ok 'in l]
    assert len(hits)==2
    out['currentSwimLogProof']={'head':head,'path':str(swim_log),'sha256':hashlib.sha256(swim_log.read_bytes()).hexdigest(),'job':swim_check['id'],'successfulOriginalFailedCaseOccurrences':2,'sourceAndEmitted':True,'lines':hits}
core_check,core_log=current_log('validate_core')
if core_log:
    lines=core_log.read_text().splitlines();proof=[]
    for title in tests[123276128714]:
        hits=[{'line':i+1,'text':l}for i,l in enumerate(lines)if title in l and 'Z ok 'in l]
        assert len(hits)==1,(title,hits)
        proof+=hits
    out['currentCoreLogProof']={'head':head,'path':str(core_log),'sha256':hashlib.sha256(core_log.read_bytes()).hexdigest(),'job':core_check['id'],'successfulOriginalFailedCaseOccurrences':5,'lines':proof}
(R/'agent2-current-failed-case-equivalents.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'head':head,'sourceFiles':len(files),'sourceTestAssignments':assignments,'equivalentJobs':list(tests)}))
