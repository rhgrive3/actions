import datetime,hashlib,json,subprocess
from pathlib import Path

R=Path('/workspace/scratch');REPO='/workspace/wt-agent5'
scope=json.loads((R/'agent2-current-scope-census-latest.json').read_text())
public=json.loads((R/'agent2-final-six-public-readback.json').read_text())
pre=json.loads((R/'inkwave-validation/prepublish-1316.json').read_text())
ledger=json.loads(Path('/workspace/wt-agent5/reports/issue-resolution-20261029/current-open-issue-ledger/ledger.json').read_text())
closures=json.loads((R/'agent2-issue-closure-chronology-readback.json').read_text())
initial=json.loads((R/'agent2-fresh-inventory-20261029-0620.json').read_text())
current=json.loads((R/'agent2-pr1914-72-public-readback.json').read_text())
current_snapshot=json.loads((R/'agent2-current-connector-latest.json').read_text())
current_pr=next(p for p in current_snapshot['prs']if p['number']==1914)
assert current_snapshot['complete']
current={'at':current_snapshot['at'],'head':current_pr['head'],'state':current_pr['state'],'merged':current_pr['merged']}
old_draft=json.loads((R/'pr1915-current-status.json').read_text())
def receipt(path):
    path=Path(path);return{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
def git(*args):return subprocess.check_output(['git','-C',REPO,*args],text=True).strip()
rows=[]
for x in public['rows']:
    assert pre['heads'][str(x['pr'])]==x['head']
    ancestor=subprocess.run(['git','-C',REPO,'merge-base','--is-ancestor',x['head'],current['head']]).returncode==0
    rows.append({'pr':x['pr'],'publishedRepairHead':x['head'],'publicationStage':'earlier root six-PR publication','publicReadbackAt':public['utc'],'branch':x['branch'],'currentOpenPR':False,'includedInCurrent1914Ancestry':ancestor,'countAsRootPublishedRepairPR':True,'notClaimedHistoricalFinalHeadCIGreen':True,'proof':[receipt(R/'inkwave-validation/prepublish-1316.json'),receipt(R/'agent2-final-six-public-readback.json')]})
assert old_draft['head']=='6690e8017252396b327ae6088d3746765ad5835d'
rows.append({'pr':1915,'publishedRepairHead':old_draft['head'],'publicationStage':'prior draft CI repair, subsequently preserved by ordinary merge into1914','publicReadbackAt':'retained exact-head status/workflow metadata','currentOpenPR':False,'includedInCurrent1914Ancestry':subprocess.run(['git','-C',REPO,'merge-base','--is-ancestor',old_draft['head'],current['head']]).returncode==0,'countAsRootPublishedRepairPR':True,'rootPublicationAttribution':'Parent session explicitly identifies1915 among previous root publications; GitHub same-account identity alone is not used for process attribution.','notClaimedHistoricalFinalHeadCIGreen':True,'commit':json.loads(git('show','-s','--format={"sha":"%H","committedAt":"%cI","subject":"%s"}',old_draft['head'])),'proof':[receipt(R/'pr1915-current-status.json'),receipt(R/'agent2-pr1915-6690-exact-metadata.json')]})
rows.append({'pr':1914,'publishedRepairHead':current['head'],'publicationStage':'current exact-head follow-up','publicReadbackAt':current['at'],'currentOpenPR':current['state']=='open'and not current['merged'],'includedInCurrent1914Ancestry':True,'countAsRootPublishedRepairPR':True,'notClaimedHistoricalFinalHeadCIGreen':False,'proof':[receipt(R/'agent2-current-connector-latest.json'),receipt(R/'agent2-pr1914-72-public-readback.json')]})
rows.sort(key=lambda x:x['pr']);assert len(rows)==len({x['pr']for x in rows})==8
assert all(x['includedInCurrent1914Ancestry']for x in rows)
root_prs={x['pr']for x in rows};retained=set(scope['retainedAuditedPRs']);assert root_prs<=retained
issue_rows=[];initial_open={i['number']for i in initial['openIssues']}
for i in closures['issues']:
    issue_rows.append({'number':i['number'],'closedAt':i['closed_at'],'state':i['state'],'stateReason':i['stateReason'],'closedByAccount':i['closed_by'],'presentInInitial0620OpenAudit':i['number']in initial_open,'newClosureRelativeToInitial0620Audit':i['number']in initial_open and i['closed_at']>initial['snapshotUtc'],'closureEvents':[{'id':e['id'],'actorAccount':e.get('actor',{}).get('login'),'created_at':e['created_at'],'commit_id':e.get('commit_id')}for e in i['events']if e['event']=='closed'],'processAttribution':'Timeline identifies the account, not which same-account process performed the close.'})
out={'schema':1,'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scopeSnapshotAt':scope['at'],'retainedAuditedPRUnion':len(retained),'rootPublishedRepairPRs':len(rows),'currentOpenRootRepairPRs':sum(x['currentOpenPR']for x in rows),'historicalRootRepairPRs':sum(not x['currentOpenPR']for x in rows),'rootRepairPRNumbers':sorted(root_prs),'otherAuditedPRs':sorted(retained-root_prs),'excludedFromRootRepairCredit':[{'pr':1913,'reason':'Previously open and later externally merged; included in audited union and integration history, without a retained root publication claim in this count.'},{'pr':1916,'reason':'Owner compact-HUD anchor repair8a/dafba and external main integration; current1914 preserves it, without claiming root authored or published that PR repair.'}],'publicationRows':rows,'definition':'Eight distinct PRs received root-published repair heads across the retained session history: seven earlier PRs plus current1914. This counts actual published repair histories, not all26 audited PRs, not eight current CI-green heads, and not merges performed by root. Current required CI applies to1914 only.','issueChronology':{'initialAudit':receipt(R/'agent2-fresh-inventory-20261029-0620.json'),'initialAuditAt':initial['snapshotUtc'],'currentReadback':receipt(R/'agent2-issue-closure-chronology-readback.json'),'confirmedClosedIssues':len(issue_rows),'newClosuresSinceInitialAudit':sum(x['newClosureRelativeToInitial0620Audit']for x in issue_rows),'alreadyClosedBeforeInitialAudit':sum(not x['presentInInitial0620OpenAudit']for x in issue_rows),'rows':issue_rows,'earlier1767OpenObservation':{'at':'2026-10-28T21:04:25Z','state':'open','proof':receipt(R/'agent1-1767-final60-audit.json')},'attributionLimit':'1767 was closed after the earlier Oct28 observation but before the Oct29 initial28-issue audit. Do not count it as a new fix/closure in the later audit. The sources alone do not attribute same-account mutations to a particular process.'}}
(R/'agent2-pr-and-issue-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
md=['# PR publication and issue closure accounting','',out['definition'],'','| PR | Root-published repair head | Current role |','| --- | --- | --- |']
for x in rows:md.append(f"| {x['pr']} | `{x['publishedRepairHead']}` | {'current open CI target'if x['currentOpenPR']else'earlier repair history; old head not relabeled green'} |")
md+=['',f"Confirmed closed issues:3. Relative to initial audit {initial['snapshotUtc']}, new closures:2 (#79 and #725); prior closure:1 (#1767).",'','| Issue | Completed closure UTC | Initial open audit |','| --- | --- | --- |']
for x in issue_rows:md.append(f"| {x['number']} | {x['closedAt']} | {'present'if x['presentInInitial0620OpenAudit']else'already closed'} |")
md+=['','GitHub identifies rhgrive3 as the closing account. This does not identify which same-account process performed an action. All26 audited PRs must not be presented as fixed;1916 owner work is preserved without root credit.']
(R/'agent2-pr-and-issue-attribution.md').write_text('\n'.join(md)+'\n')
print(json.dumps({k:out[k]for k in ['at','retainedAuditedPRUnion','rootPublishedRepairPRs','currentOpenRootRepairPRs','historicalRootRepairPRs','rootRepairPRNumbers']}))
