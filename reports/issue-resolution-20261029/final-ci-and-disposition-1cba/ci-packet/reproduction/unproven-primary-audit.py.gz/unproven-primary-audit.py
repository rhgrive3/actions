import collections, datetime, hashlib, json, re
from pathlib import Path

R = Path('/workspace/scratch')
mapping = json.loads((R/'agent2-current-failure-family-map.json').read_text())
old_receipt = Path('/workspace/wt-agent2-browser-cache/reports/issue-resolution-20261029/historical-ci-unknowns/receipt.json')
prior = {r['job']: r for r in json.loads(old_receipt.read_text())['events']}
events = []
def receipt(path):
    path = Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
audio = {123508229028:(12903904643,R/'agent2-pr1914-recovery-artifact'),123555216604:(12911980160,R/'agent2-historical-recovery-12911980160'),123519712918:(12907396143,R/'agent2-historical-recovery-12907396143'),123529378823:(12907538070,R/'agent2-historical-recovery-12907538070')}
unknown_ids = {r['job'] for r in mapping['unprovenPrimaryCauseEvents']}
for record in mapping['failedJobManifest']:
    if record['job'] not in unknown_ids: continue
    row = {k:record[k] for k in ['job','pr','head','run','workflow','event','family','causeIds','rawLog','metadataEvidence']}
    row['causeIds'] = [c for c in row['causeIds'] if c.startswith('unknown-')]
    row.update({'underlyingCauseEstablished':False,'resolved':False,'countAsResolvedPrimaryJob':False,'historicalEvidenceMissing':False,'recoveryNeeded':False})
    if record['job'] in prior:
        p=prior[record['job']]
        row['observation']=p['observedFailure']
        row['missingCausalEvidence']=p['notEstablished']
        row['existingInvestigation']=receipt(old_receipt)
        row['retainedDetails']={k:v for k,v in p.items() if k not in ['pr','head','run','job','rawLogSha256','observedFailure','notEstablished']}
        row['whyNoFurtherPublicRecovery']='Original logs, full API metadata/annotations and selected original artifact members are already retained. Public APIs and these archives contain no host/kernel/crash-dump or omitted native-input provenance.'
    elif record['job'] in audio:
        aid,root=audio[record['job']]
        result=json.loads((root/'context/result.json').read_text())
        network=[json.loads(l) for l in (root/'trace-network.jsonl').read_text().splitlines()]
        failed=[r['snapshot'] for r in network if r.get('snapshot',{}).get('response',{}).get('_failureText')]
        row['observation']=f"Strict native audio startup assertion rejects {len(result['requests'])} net::ERR_ABORTED audio requests; last stage is playing, page errors and HTTP failures are empty."
        row['artifactId']=aid
        row['newlyRecoveredInThisAudit']=aid not in [12903904643,12907396143]
        if aid==12907396143:row['alreadyRetainedArtifactExtraction']=receipt(R/'agent2-pr1915-recovery-artifact/EXTRACTION_RECEIPT.json')
        row['artifactEvidence']=[receipt(root/'context/result.json'),receipt(root/'trace-network.jsonl'),receipt(root/'trace-actions-no-snapshots.jsonl')]
        row['networkFailures']=[{'url':r['request']['url'],'startedDateTime':r['startedDateTime'],'monotonicRequestStart':r.get('_monotonicTime'),'harTime':r['time'],'timings':r['timings'],'failureText':r['response']['_failureText']}for r in failed]
        admission=result.get('startup',{}).get('admission',{})
        row['audioOwnerAtAdmission']=admission.get('audioOwner')
        row['recordedAudioAbortProvenance']=admission.get('audioAborts')
        row['missingCausalEvidence']=['Identity and call stack of the abort owner','Timestamp of body abortion/requestfailed completion','Causal link between a specific lifecycle transition and each failed request']
        row['whyNoFurtherPublicRecovery']='All available original result JSON and Playwright trace/network payloads are retained. HAR request start/wait with receive=-1 does not bound abort completion; no AbortController call stack is recorded. Later ready/aborts=[] diagnostics and current passes do not establish the old cause.'
    elif record['job']==123508291289:
        root=R/'agent2-historical-projectile-367';result=json.loads((root/'projectile-visuals-result.json').read_text())
        row.update({'artifactId':12905143577,'newlyRecoveredInThisAudit':True,'artifactEvidence':[receipt(root/'projectile-visuals-result.json'),receipt(root/'chromium-browser-stderr.log'),receipt(R/'agent2-historical-projectile-367.zip')],'observation':'Two captures and wall-shooter contact scenario complete; runContactScenarios page.evaluate rejects with Resulting promise was garbage collected. Browser-disconnected event is recorded immediately before failure output.','browserDiagnostics':result['browserDiagnostics'],'advertisedBrowserTrace':result.get('browserTrace'),'actualArchiveMembers':['chromium-browser-stderr.log','projectile-visuals-result.json','wall-shooter__F0__shoulder.png','wall-shooter__F0__shoulder__projectile-crop.png','wall-shooter__wall-contact-F2-capture-F10__side.png','wall-shooter__wall-contact-F2-capture-F10__side__projectile-crop.png'],'missingCausalEvidence':['Renderer/browser exit code or crash stack','OS resource/OOM telemetry','Actual advertised browser trace, absent from artifact archive','Whether disconnect initiated or followed the page-evaluation failure'],'whyNoFurtherPublicRecovery':'Recovered original artifact has no trace or crash dump; stderr member explicitly says no browser stderr block was reported. Empty page-error array is not a captured clean browser process trace.'})
    else:
        lines=Path(record['rawLog']['path']).read_text().splitlines()
        selected=[{'line':i+1,'text':s}for i,s in enumerate(lines)if 'npm install --no-save --no-package-lock --silent' in s or '##[error]Process completed with exit code 1.' in s or 'EACCES: permission denied' in s]
        row.update({'observation':'Silent npm install/compound setup step exits1 before tests or browser execution and prints no npm diagnostic.','retainedExcerpts':selected,'missingCausalEvidence':['npm debug log or verbose stderr','Exact failing command in the compound browser setup step','Package/cache/filesystem or network failure code'],'whyNoFurtherPublicRecovery':'Neither job uploaded a primary failure artifact or npm debug log. The active browser job then independently fails evidence packaging with EACCES; that secondary failure cannot identify the earlier silent setup cause. Exact retained job-step metadata and full stdout are already available.'})
    events.append(row)
assert len(events)==len({r['job'] for r in events})==15
out={'schema':1,'auditedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'currentHeadAtAudit':mapping['head'],'scope':'15 distinct historical primary failed jobs; excluded from known-primary resolved counts regardless of present equivalent gate success.','events':events,'countsByUnprovenCause':dict(collections.Counter(r['causeIds'][0]for r in events)),'totalEvents':15,'distinctUnprovenCauseClasses':6,'artifactDownloadReadbacks':[12905143577,12911980160,12907396143,12907538070],'newArtifactRecoveries':[12905143577,12911980160,12907538070],'additionalReadbackOfAlreadyRetainedArtifact':[12907396143],'historicalLogsMissing':0,'underlyingCausesNewlyEstablished':0,'resolvedUnknownEvents':0,'secondaryEventsIncluded':0,'mutations':'Read-only GitHub artifact recovery. No CI dispatch, rerun, cancellation, workflow edit, product edit, issue close or external comment.'}
(R/'agent2-unproven-primary-audit.json').write_text(json.dumps(out,indent=2)+'\n')
md=['# Historical primary failures with unproven underlying causes','',f"Audited {out['auditedAt']}. All 15 original logs are retained. Three additional artifact archives were recovered; one previously retained archive was also read back. No additional underlying cause was established; all 15 remain excluded from resolved-primary counts.",'','| Class | Distinct failed jobs | Missing causal evidence |','| --- | ---: | --- |']
for cause,n in sorted(out['countsByUnprovenCause'].items()):
    row=next(r for r in events if cause in r['causeIds']);md.append('| '+cause+' | '+str(n)+' | '+'; '.join(row['missingCausalEvidence'])+' |')
md += ['','| PR | Job | Observed failure | Historical-source disposition |','| --- | --- | --- | --- |']
for row in events:md.append(f"| {row['pr']} | {row['job']} | {row['observation']} | {row['whyNoFurtherPublicRecovery']} |")
md += ['','Audio HAR start/wait values do not bound aborted-body completion. An empty cancellation list from a later sampled owner does not establish who aborted an earlier request. The projectile archive advertises a trace path in JSON but contains no trace ZIP. Current equivalent passes establish current acceptance only.']
(R/'agent2-unproven-primary-audit.md').write_text('\n'.join(md)+'\n')
print(json.dumps({k:out[k]for k in ['auditedAt','totalEvents','countsByUnprovenCause','historicalLogsMissing','underlyingCausesNewlyEstablished','newArtifactRecoveries']}))
