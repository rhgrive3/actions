import json, re, collections, hashlib
import gzip
import sys
from pathlib import Path

R = Path('/workspace/scratch')
HEAD_3C = '3c0f0e4ece4a5722e30fed8d57ad20240d3ce696'
EXPECTED_HEAD = sys.argv[1] if len(sys.argv)>1 else HEAD_3C
def read(name): return json.loads((R/name).read_text())
audit = read('agent2-ci-inventory-20261029.json')
original = read('agent2-unified-family-last-pre-external-merge.json')
events = {r['id']: r['event'] for r in read('agent2-ci-before-run-events.json')}
snap = read('agent2-current-connector-latest.json')
pr = next(p for p in snap['prs'] if p['number'] == 1914)
assert snap['complete'] and pr['head'] == EXPECTED_HEAD
baseline = read('agent2-pr1914-observed-gates-from-331.json')
paths = {r['name']: r['path'] for r in baseline['workflows']}
records = []
for cohort, rows in [('baseline85', audit['failureJobs']), ('postAtomic15', audit['postAtomicFailedJobs']), ('postRepair1', audit['postRepairFailedJobs']), ('additional8', read('agent2-additional-eight-actual-ci-failures.json')['rows']), ('cb9Followup2', read('agent2-current-cb9d-followup-failures.json')['rows'])]:
    for row in rows: records.append({**row, 'cohort': cohort, 'event': row.get('event') or events[row['run']]})
assert len(records) == len({r['job'] for r in records}) == 111

# The historical ledger is immutable. These IDs describe a demonstrated cause,
# not the number of original failed attempts, test cases, PRs, or repaired issues.
descriptions = {
 'ci-source-shard-coverage': 'Source-coverage fixture retained the old CPU shard contract after complete eight-shard routing.',
 'sandbox-route-duplicate-module': 'Sandbox-route test duplicated its module and redeclared test before execution.',
 'wall-route-install-contract': 'Wall-route command and exact contract referred to different reviewed install epochs.',
 'audio-latest-intent-fixture': 'Audio-sharing fixture expected historical selections instead of current owner-selected retained intent.',
 'roller-source-epoch': 'Roller counterfactual confused raw, performance-reversed and downhill-reversed source epochs.',
 'wiper-wet-retirement': 'Lazy wet slash meshes survived clear and exceeded the unchanged quiet-tail deadline.',
 'historical-character-owner-chain': 'Exact historical Character reconstruction omitted later reviewed owner transforms.',
 'explosher-census-fixture': 'Scene-census negative attempted objects drift before creating a valid category/provenance positive.',
 'ci-admission-contract': 'Exact needs/admission/final gate fixtures retained old direct dependency shape.',
 'responsive-launch-contract': 'Responsive fixture retained obsolete child launch/receipt assumptions.',
 'historical-source-motion-owner-chain': 'Historical walk/controller reconstruction omitted later reviewed owners.',
 'input-listener-count-oracle': 'Input fixture/checker froze counts before two Pointer Lock listeners; actual add/remove ownership still balanced.',
 'motion-unread-clip-allocation': 'Deferred hair evaluation read public clip descriptors and exposed diagnostic allocations.',
 'offscreen-hair-fixture-dependency': 'Production-composition test fixture omitted adaptOffscreenHairTargets.',
 'pending-flush-fixture-closure': 'Extracted pending flush omitted the new bossBodyBlocked closure.',
 'paint-source-owner-chain': 'Paint fixture compared an intermediate owner result with final composed source.',
 'soft-push-live-roster': 'Optimized soft push failed to preserve live roster/radius mutation across callbacks.',
 'solid-material-UV-fixture': 'Halyard fixture expected UV bytes for solid built-in materials that do not use UVs.',
 'hud-source-scheduling-epoch': 'Exact HUD scheduling reference omitted reviewed presentation-owner transforms.',
 'workflow-source-epoch': 'Exact workflow-body reference omitted reviewed later trigger/install/coverage changes.',
 'native-observation-window': 'Capture admitted a premature native combat observation window.',
 'chromium-sandbox-runner': 'Ubuntu latest AppArmor user namespaces rejected explicitly sandboxed Chromium before launch.',
 'global-sparse-JS-closure': 'Sparse checkout omitted tracked report/tool JavaScript required by global AST audit.',
 'reviewed-sparse-profile-pin': 'Current exact sparse profiles and fixture hash were stale after reviewed inventory expansion.',
 'historical-attract-readiness': 'Historical inverse-overlay QA pair admitted resource capture before controlled initial-attract readiness; unchanged absolute guard retained.',
 'zero-paint-native-window': 'Elapsed/frame/identity-ready observation still had zero native paint coverage.',
 'browser-cache-abi': 'Browser cache lacked distribution release; restored WebKit required ICU74 on ICU70 Ubuntu22.',
 'scan-reference-policy': 'Frozen fused-scan reference still used maxUses2 after reviewed current single-round policy1.',
 'sparse-circleci-contract': 'Exact core/CircleCI parity fixture expected account MJS excluded after global JS closure expansion.',
 'native-generation-readiness': 'Position interpolation preceded adoption of the native owner generation in QA placement.',
 'explosher-stage-fixture-readiness': 'Synthetic controlled-main fixture omitted required initialAttractWarmup metadata.',
 'native-display-fixture-phase': 'Nth-current-call cancellation stopped before texture/display transfer and invalidated the stale-display ownership test.',
 'lod-historical-owner-bridge': 'Exact A+ LOD historical source bridge omitted reviewed owner edits.',
 'native-special-source-team-fixture': 'Special producer fixture omitted an already-existing sourceTeam field.',
 'timer-fixture-API': 'Timer fixtures used record-only mocks rather than paired native pending IDs/cancellation.',
 'material-allocation-counter-fixture': 'Texture fixture expected Object.values allocation after reviewed Object.keys traversal removed it.',
 'historical-rainmaker-air-landing-negative': 'Historical Rainmaker air/landing QA negative did not model the current admitted pose contract.',
 'native-display-fixture-commented-out-invocation': 'Literal backslash-n in an owner comment swallowed declarations and native world invocation.',
}
unknown_jobs = {122833440425:'unknown-historical-webkit-setup',122291734506:'unknown-historical-webkit-setup',122232103890:'unknown-historical-webkit-setup',122829175776:'unknown-historical-runner-shutdown',122540051814:'unknown-historical-runner-shutdown',122530225554:'unknown-historical-runner-shutdown',122279728189:'unknown-historical-runner-shutdown',122299997364:'unknown-historical-native-menu-timeout'}
title_rules = [
 ('inkwave-owner-clock-diagnostic.test.mjs','ci-source-shard-coverage'),
 ('inkwave-sandbox-runner-route.test.mjs','sandbox-route-duplicate-module'),
 ('inkwave-wall-diagnostic-workflow.test.mjs','wall-route-install-contract'),
 ('added-audio-sharing.test.mjs','audio-latest-intent-fixture'),
 ('issue-847-roller-drum-support.test.mjs','roller-source-epoch'),
 ('wiper-wet-wave.test.mjs','wiper-wet-retirement'),
 ('queue-historical-character-20261026.test.mjs','historical-character-owner-chain'),
 ('explosher-stage-admission.test.mjs','explosher-census-fixture'),
 ('inkwave-idle-resources-gates.test.mjs','ci-admission-contract'),
 ('inkwave-staged-ci-policy.test.mjs','ci-admission-contract'),
 ('inkwave-ci-recurrence-guards.test.mjs','ci-admission-contract'),
 ('inkwave-responsive-child-pool.test.mjs','responsive-launch-contract'),
 ('inkwave-responsive-progress-summary.test.mjs','responsive-launch-contract'),
 ('queue-historical-source-motion-20261026.test.mjs','historical-source-motion-owner-chain'),
 ('input-owned-listeners.test.mjs','input-listener-count-oracle'),
 ('motion-diagnostics.test.mjs','motion-unread-clip-allocation'),
 ('performance-v2-ao.test.mjs','offscreen-hair-fixture-dependency'),
 ('performance-v2-geometry.test.mjs','offscreen-hair-fixture-dependency'),
 ('queue-network-receipts-20261027.test.mjs','pending-flush-fixture-closure'),
 ('queue-remaining-paint-20261026.test.mjs','paint-source-owner-chain'),
 ('queue-gameplay-review-20261026.test.mjs','soft-push-live-roster'),
 ('world-cache-queue.test.mjs','solid-material-UV-fixture'),
 ('drive-visual-audio.test.mjs','hud-source-scheduling-epoch'),
 ('continuous-browser-video.test.mjs','workflow-source-epoch'),
]
aliases = {'responsive-current-launch-contract':'responsive-launch-contract','wall-route-lockfile-install-alignment':'wall-route-install-contract'}
for record in records: record['original111'] = True
def add(pr_number,head,workflow,name,job,cause_ids,cohort,raw=None,event='pull_request',run=None,**extra):
    records.append({'pr':pr_number,'head':head,'workflow':workflow,'name':name,'job':job,'causeIds':cause_ids,'cohort':cohort,'rawLog':raw,'event':event,'run':run,**extra})
W='Validate INKWAVE update'
head367='36743577ee15efbaa0f84ec552b2490ab688cac3'
for job,name,ids in [
 (123508229028,'native',['unknown-audio-request-abort-owner']),
 (123508291289,'Capture after',['unknown-projectile-promise-collection']),
 (123511917030,'validate_core',['frame-AST-fixture-boundary']),
 (123511917742,'patch_tests (2)',['unknown-silent-npm-install']),
 (123511917263,'browser (active, chromium webkit)',['unknown-silent-npm-install','failure-evidence-storage-permission']),
 (123511917545,'browser (ui, chromium webkit)',['menu-source-epoch']),
 (123511917251,'patch_tests (0)',['historical-character-owner-chain','residual-ui-policy-epoch']),
 (123511917219,'browser (range, chromium webkit)',['lazy-range-WEAPON-tab']),
 (123511917717,'patch_tests (5)',['paint-source-owner-chain']),
 (123511917606,'patch_tests (6)',['contact-FK-owner-seam']),
 (123511917399,'patch_tests (3)',['extracted-helper-dependencies']),
 (123534626982,'validate',['secondary-strict-aggregate'])]:
    workflow='INKWAVE terminal recovery native QA' if name=='native' else 'INKWAVE projectile visuals' if name=='Capture after' else W
    p=next(e for e in read('agent2-pr1914-current-failures/receipt.json')['entries'] if e['jobId']==job)
    add(1914,head367,workflow,name,job,ids,'PR1914-367',p['rawPath'])
head331='331fdaadb061d192e83e0f82d37fbb5c3291da0a'
summary331=read('agent2-pr1914-331fdaad-ci-final-summary.json')
for row in summary331['failedJobs']:
    name=row['name'];workflow='INKWAVE terminal recovery native QA' if name=='native' else 'INKWAVE projectile visuals' if name=='Capture after' else W
    ids=['secondary-strict-aggregate'] if name=='validate' else ['unknown-audio-request-abort-owner'] if name=='native' else ['range-checker-source-epoch'] if name=='Capture after' else ['minimap-clock-reference-epoch'] if name.startswith('browser') else ['mark-lease-time-epoch']
    add(1914,head331,workflow,name,row['id'],ids,'PR1914-331',str(R/('agent2-current-failure-job-'+str(row['id'])+'.log')),run=int(re.search(r'/runs/(\d+)/',row['url']).group(1)))
add(1914,'39c2060fe5d27ea1d8182861a07e79da99e8915e',W,'browser (active, chromium webkit)',123642974216,['HUD-private-spIcon-fixture'],'PR1914-39c',str(R/'agent2-current-failure-job-123642974216.log'))
add(1914,HEAD_3C,W,'patch_tests (0)',123681981687,['HUD-private-spIcon-fixture'],'PR1914-3c',str(R/'agent2-pr1914-3c-failure-job-123681981687.log'),run=40938891054)
add(1914,HEAD_3C,W,'patch_tests (4)',123681981697,['HUD-private-spIcon-fixture'],'PR1914-3c',str(R/'agent2-pr1914-3c-failure-job-123681981697.log'),run=40938891054)
add(1914,HEAD_3C,W,'patch_tests (5)',123681981851,['HUD-private-spIcon-fixture'],'PR1914-3c',str(R/'agent2-pr1914-3c-failure-job-123681981851.log'),run=40938891054)
add(1914,HEAD_3C,W,'validate',123706071475,['secondary-strict-aggregate'],'PR1914-3c-post72-secondary',str(R/'agent2-pr1914-3c-post72-final-job-123706071475.log'),run=40938891054)
add(1914,'72c799fee36173e1255e023bad7c9a19605ad2b1',W,'patch_tests (2)',123709310616,['Hissen-display-multiplier-fixture'],'PR1914-72-followup',str(R/'agent2-pr1914-72-failure-job-123709310616.log'),run=40947302723)
add(1914,'72c799fee36173e1255e023bad7c9a19605ad2b1',W,'validate',123736457555,['secondary-strict-aggregate'],'PR1914-72-followup',str(R/'agent2-pr1914-72-failure-job-123736457555.log'),run=40947302723)
add(1914,'39c2060fe5d27ea1d8182861a07e79da99e8915e',W,'validate',123658789940,['secondary-cancelled-aggregate'],'PR1914-39c-superseded',str(R/'agent2-current-failure-job-123658789940.log'))
for job,workflow,name in [(123676722967,W,'validate'),(123676860966,'INKWAVE eight headgear production candidate QA','verify-combined')]:
    add(1914,'98ccd1c6ea143ea402319c6637cd1bca5d075a6e',workflow,name,job,['secondary-cancelled-aggregate'],'PR1914-98-superseded',str(R/('agent2-pr1914-98-secondary-job-'+str(job)+'.log')))
for head,job in [('3c6a9bb50a20cbfee2814ec35b18b6ff93c2fe05',123519712918),('6690e8017252396b327ae6088d3746765ad5835d',123529378823)]:
    add(1915,head,'INKWAVE terminal recovery native QA','native',job,['unknown-audio-request-abort-owner'],'PR1915-native',str(R/('agent2-current-failure-job-'+str(job)+'.log')))
add(1915,'3c6a9bb50a20cbfee2814ec35b18b6ff93c2fe05','INKWAVE draft CI failure reproduction','focused-regressions',123519674119,['historical-character-owner-chain','draft-fixture-VM-flag'],'PR1915-draft',str(R/'agent2-current-failure-job-123519674119.log'),event='push')
for job,workflow,name in [
 (123638794780,W,'build_site'),(123638611866,'INKWAVE A+ Quality & Security Gate','verify-aplus-suite'),
 (123638611480,'ZEVANT account and Workers build','account'),(123638611418,'INKWAVE isolated character asset QA','neutral-loader-fixture'),
 (123638610375,'INKWAVE narrow HUD tank regression','browser (chromium)'),(123638610889,'INKWAVE narrow HUD tank regression','browser (webkit)'),(123639041548,W,'validate')]:
    add(1916,'7cd2e8f7315c42ecc58eca6070f93fd33d3df018',workflow,name,job,['secondary-strict-aggregate'] if name=='validate' else ['owner-compact-HUD-source-anchor'],'PR1916-7cd',str(R/('agent2-pr1916-job-'+str(job)+'.log')),repairCredit='Owner8a1e55c/dafba preserved through main91; not root39 repair',metadataEvidence='Retained failed-check inventory plus unique executed workflow commands')
main91=read('agent2-main-91c1-ci-snapshot.json')
for row in main91['failedChecks']:
    name=row['name'];ids=['HUD-private-spIcon-fixture'] if name.startswith('browser (active') else ['menu-source-epoch'] if name.startswith('browser (ui') else ['frame-AST-fixture-boundary'] if name=='validate_core' else ['contact-FK-owner-seam','ScreenFX-constructor-cache-fixture','Hissen-display-multiplier-fixture']
    add(0,main91['head'],W,name,row['id'],ids,'main91-context',str(R/('agent2-main91-failure-job-'+str(row['id'])+'.log')),event='push',equivalentEvent='pull_request',contextOnly=True)
main_names={122991218931:'patch_tests (6)',122991218484:'validate_core',122991218879:'patch_tests (5)',123004717466:'validate',122991218864:'browser (network, chromium webkit)',122991219015:'patch_tests (4)',122991218857:'patch_tests (3)',122991218923:'browser (catalog, chromium)'}
for row in read('agent2-main-40737709268-log-manifest.json'):
    failures=[{'title':f['name'],'location':' '.join(l for l in f['context'] if 'location:' in l)} for f in row['failures']]
    r={'pr':0,'head':'e67c636b81762df56b346a09ef570964d43084df','workflow':W,'name':main_names[row['job']],'job':row['job'],'cohort':'mainE67-context','rawLog':row['rawLog'],'event':'push','equivalentEvent':'pull_request','contextOnly':True,'run':40737709268,'failures':failures}
    if row['job']==122991218923:r['causeIds']=['wiper-wet-retirement']
    records.append(r)
descriptions.update({
 'frame-AST-fixture-boundary':'Literal const-tA fixture delimiter disappeared after owner composition; actual first-frame fence retained and AST extraction repairs fixture.',
 'secondary-failure-evidence-storage-permission':'Secondary browser packager attempted a non-owned /mnt/workspace path after a primary failure; owned storage root repair preserves primary exit.',
 'menu-source-epoch':'Exact menu-layout identity bridge omitted reviewed owner bytes; full inverse and independent old/current behavior retained.',
 'residual-ui-policy-epoch':'Reference anti-poison/object-hit fixture still modeled the prior replay-window policy; original before/current admission controls retained.',
 'lazy-range-WEAPON-tab':'Range QA enumerated lazy catalogue chips before the existing real WEAPON tab was activated.',
 'contact-FK-owner-seam':'Strict contact/FK reverse transform used a stale owner seam and subsequently reported bank unavailable.',
 'extracted-helper-dependencies':'Extracted GPU/Charger/splash probes omitted presentation-clock/contact/seed collaborators after composition changes.',
 'range-checker-source-epoch':'Exact Range policy pin retained old checker bytes after the reviewed lazy-tab order repair; strict inverse preserves original pin.',
 'minimap-clock-reference-epoch':'Reference omitted reviewed event-to-update FX clock transform and compared different age epochs at emitted frame1.',
 'mark-lease-time-epoch':'AngleShooter synthetic lease omitted elapsed native birth receipt time; delayed/replayed admission controls retained.',
 'HUD-private-spIcon-fixture':'Extracted/synthetic HUD receivers lacked constructor-owned spIcon used by current native crosshair update; private receiver repair preserves native method and original assertions.',
 'draft-fixture-VM-flag':'Draft reproduction repair step omitted --experimental-vm-modules needed by the actual emitted VM fixture.',
 'owner-compact-HUD-source-anchor':'PR1916 old7cd exact #1100 HeavySplatling HUD anchor conflicted before site build; owner8a/dafba repair preserved.',
 'ScreenFX-constructor-cache-fixture':'Extracted ScreenFX update receiver omitted actual constructor-owned Float64Array(6) and invalid cache state.',
 'Hissen-display-multiplier-fixture':'Two display assertions retained pre-owner dimensions instead of explicit Hissen1.5 visual multiplier; physical/radius and other weapons unchanged.',
 'unknown-audio-request-abort-owner':'Strict native audio gate observed ERR_ABORTED; hosted abort owner/completion time remain unproven. HAR wait time does not bound abort completion.',
 'unknown-projectile-promise-collection':'Hosted visualSetup page.evaluate promise was garbage-collected; causal ownership/process termination remains unproven, later passes do not establish cause.',
 'unknown-silent-npm-install':'Silent install/compound setup exited1 with no npm diagnostic; lockfile/install ownership fixes are reviewed but exact historical install cause remains unknown.',
})
def causes(r):
    if r.get('causeIds'): return ['secondary-failure-evidence-storage-permission' if c=='failure-evidence-storage-permission' else c for c in r['causeIds']]
    if r['job'] in unknown_jobs: return [unknown_jobs[r['job']]]
    if r['name'] == 'validate' and r['workflow'] == 'Validate INKWAVE update': return ['secondary-strict-aggregate']
    if r.get('rootCauseKey'):
        k=r['rootCauseKey']
        if k == 'timer-API-and-material-counter-and-display-fixtures': return ['timer-fixture-API','material-allocation-counter-fixture','native-display-fixture-phase']
        return [aliases.get(k,k)]
    found=set()
    for f in r.get('failures',[]):
        text=f.get('location','')+' '+f.get('title','')
        hit=[v for k,v in title_rules if k in text]
        found.update(hit or ['unclassified-test-'+str(r['job'])])
    text=' '.join(r.get('diagnostics') or [])+' '+str(r.get('cause',''))
    for needle,key in [('adaptOffscreenHairTargets is not defined','offscreen-hair-fixture-dependency'),('Input listener imbalance','input-listener-count-oracle'),('Native slash/sheet tail did not retire','wiper-wet-retirement'),('Invalid native gameplay combat window','native-observation-window'),('AppArmor','chromium-sandbox-runner'),('explicit Chromium sandbox','chromium-sandbox-runner'),('global metadata AST','global-sparse-JS-closure'),('sparse audit omission','global-sparse-JS-closure'),('exact job sparse profiles','reviewed-sparse-profile-pin'),('Historical pinned364dd0','historical-attract-readiness')]:
        if needle in text:found.add(key)
    return sorted(found or {'unclassified-job-'+str(r['job'])})

for row in records: row['causeIds']=causes(row)
metadata={}
def register_metadata(source,runs,checks):
    run_map={r['id']:r for r in runs}
    for c in checks:
        m=re.search(r'/runs/(\d+)/',c.get('details_url') or '')
        if not m or int(m.group(1)) not in run_map:continue
        run=run_map[int(m.group(1))]
        metadata[c['id']]={'source':source,'run':run['id'],'workflow':run['name'],'event':run['event'],'head':run['head_sha'],'name':c['name'],'details_url':c['details_url']}
for p in audit['pullRequests']:register_metadata('agent2-ci-inventory-20261029.json',p['workflowRuns'],p['checkRuns'])
for p in read('agent2-pr1914-331fdaad-ci-completed.json')['prs']:register_metadata('agent2-pr1914-331fdaad-ci-completed.json',p['runs'],p['checks'])
for name in ['agent2-pr1914-39c-terminal-latest.json','agent2-pr1914-98-superseded-latest.json','agent2-pr1914-3c-post72-latest.json']:
    p=read(name);register_metadata(name,p['runs'],p['checks'])
terminal72=R/'agent2-pr1914-72-terminal.json'
if terminal72.exists():
    p=json.loads(terminal72.read_text());register_metadata(terminal72.name,p['runs'],p['checks'])
late=read('agent2-pr1916-7cd-exact-metadata.json')
assert not any(r['error'] for r in late['reads'])
lr=late['reads'][0]['value'];lc=late['reads'][1]['value']
assert lr['total_count']==len(lr['workflow_runs']) and lc['total_count']==len(lc['check_runs'])
register_metadata('agent2-pr1916-7cd-exact-metadata.json',lr['workflow_runs'],lc['check_runs'])
register_metadata('agent2-current-connector-latest.json',pr['runs'],pr['checks'])
prior3c=R/'agent2-pr1914-3c0f0e4e-family-snapshot.json.gz'
if prior3c.exists():
    prior=json.loads(gzip.decompress(prior3c.read_bytes()))
    for pp in prior['prs']:register_metadata(prior3c.name,pp['runs'],pp['checks'])
prior72=R/'agent2-pr1914-72c799fe-family-snapshot.json.gz'
if prior72.exists():
    prior=json.loads(gzip.decompress(prior72.read_bytes()))
    for pp in prior['prs']:register_metadata(prior72.name,pp['runs'],pp['checks'])
late367=read('agent2-pr1914-367-validate-exact-jobs.json')
old367=next(p for p in audit['pullRequests'] if p['number']==1914)
oldrun=next(r for r in old367['workflowRuns'] if r['id']==40891219880)
register_metadata('agent2-pr1914-367-validate-exact-jobs.json + original inventory run metadata',[oldrun],[{'id':j['id'],'name':j['name'],'details_url':j['html_url']} for j in late367['jobs']])
for r in records:
    if r['job'] in metadata:
        m=metadata[r['job']]
        assert (r['head'],r['workflow'],r['event'],r['name'])==(m['head'],m['workflow'],m['event'],m['name']),(r['job'],r,m)
        r['metadataEvidence']=m;r['run']=m['run'];r['url']=m['details_url']
    elif r.get('original111'):
        r['metadataEvidence']={'source':'original111 retained cohort inventory + exact run-event audit','run':r['run'],'event':r['event'],'name':r['name']}
    elif r['pr']==0:
        r['metadataEvidence']={'source':'Exact retained main run diagnosis + unique native commands + CPU shard env indices; current comparison explicitly crosses push→PR','contextOnly':True}
    elif r['job']==123529378823:
        m=read('agent2-pr1915-6690-exact-metadata.json')['run']
        assert (r['head'],r['workflow'],r['event'])==(m['head_sha'],m['name'],m['event'])
        r['run']=m['id'];r['metadataEvidence']={'source':'agent2-pr1915-6690-exact-metadata.json + pr1915-current-status.json native FAILURE','event':m['event'],'run':m['id'],'head':m['head_sha']}
    else:r['metadataUnverified']=True
def family(name): return re.sub(r'^patch_tests \(\d+\)$','patch_tests (8-shard family)',name)
def key(r):return (r['pr'],r['workflow'],r['event'],family(r['name']))
groups=collections.defaultdict(list)
for r in records:groups[key(r)].append(r)
original_keys={(r['pr'],r['workflow'],r['event'],r['family']) for r in original['families']}
assert len(original_keys)==45 and original_keys.issubset(groups)
def equivalent(workflow,event,name):
    path=paths.get(workflow)
    runs=[r for r in pr['runs'] if r['event']==event and ((path and r['path']==path) or (not path and r['name']==workflow))]
    if not runs:return {'status':'workflow_not_created','path':path,'event':event,'run':None,'checks':[],'accepted':False}
    assert len(runs)==1,(workflow,event,runs)
    run=runs[0];checks=[c for c in pr['checks'] if '/runs/'+str(run['id'])+'/' in (c.get('details_url') or '') and (bool(re.fullmatch(r'patch_tests \([0-7]\)',c['name'])) if name=='patch_tests (8-shard family)' else c['name']==name)]
    expected=8 if name=='patch_tests (8-shard family)' else 1
    accepted=len(checks)==expected and len({c['name'] for c in checks})==expected and all(c['status']=='completed' and c['conclusion']=='success' for c in checks)
    state='passed' if accepted else 'failed' if any(c['conclusion']=='failure' for c in checks) else 'cancelled' if any(c['conclusion']=='cancelled' for c in checks) else 'not_created' if not checks else 'skipped' if all(c['conclusion']=='skipped' for c in checks) else 'pending'
    return {'status':state,'path':run['path'],'event':event,'run':run['id'],'expectedChecks':expected,'checks':[{k:c.get(k) for k in ['id','name','status','conclusion','details_url']} for c in checks],'accepted':accepted}

families=[]
for k,entries in sorted(groups.items()):
    number,workflow,event,name=k;ids=sorted({c for r in entries for c in r['causeIds']})
    secondary=all(c.startswith('secondary-') for c in ids)
    unproven=any(c.startswith(('unknown-','unclassified-')) for c in ids)
    equivalence_event=entries[0].get('equivalentEvent',event)
    eq=equivalent(workflow,equivalence_event,name)
    metadata_unverified=any(r.get('metadataUnverified',False) for r in entries)
    families.append({'id':('main' if number==0 else 'PR'+str(number))+'|'+workflow+'|'+event+'|'+name,'pr':number if number else None,'scope':'main-context' if number==0 else 'PR','workflow':workflow,'event':event,'family':name,'original45':k in original_keys,'original111Family':any(r.get('original111') for r in entries),'cohorts':sorted({r['cohort'] for r in entries}),'beforeJobs':[r['job'] for r in entries],'beforeHeads':sorted({r['head'] for r in entries}),'causeIds':ids,'secondary':secondary,'hasUnprovenCause':unproven,'metadataUnverified':metadata_unverified,'currentEquivalent':eq,'eventEquivalenceExplicit':equivalence_event!=event,'currentGatePassed':eq['accepted'],'countAsKnownCauseCoveredFamily':eq['accepted'] and not secondary and not unproven and not metadata_unverified,'historicalHeadsRelabeledPassed':False})

root_causes=[]
evidence_groups={
 'ci-sandbox-sparse':['chromium-sandbox-runner','global-sparse-JS-closure'],
 'ci-profile-followup':['reviewed-sparse-profile-pin'],
 'roller-dual-epoch':['roller-source-epoch'],
 'native-paint-readiness':['zero-paint-native-window'],
 'ci-browser-contracts':['browser-cache-abi','sparse-circleci-contract'],
 'combat-scan-reference':['scan-reference-policy'],
 'combat-placement-life':['native-generation-readiness'],
 'explosher-attract-warmup':['historical-attract-readiness'],
 'explosher-stage-fixture':['explosher-stage-fixture-readiness'],
 'pr1912-lod-history-bridge':['lod-historical-owner-bridge'],
 'pr1912-native-texture-fixture':['native-display-fixture-phase','native-display-fixture-commented-out-invocation'],
 'pr1912-contracts-fixtures':['timer-fixture-API','material-allocation-counter-fixture'],
 'rainmaker-owner-current':['historical-rainmaker-air-landing-negative'],
 'pr1914-ci-reconciliation':['frame-AST-fixture-boundary','secondary-failure-evidence-storage-permission','residual-ui-policy-epoch','contact-FK-owner-seam','extracted-helper-dependencies','unknown-silent-npm-install','unknown-audio-request-abort-owner','unknown-projectile-promise-collection'],
 'pr1914-followup-proof':['range-checker-source-epoch','minimap-clock-reference-epoch','mark-lease-time-epoch'],
 'main39-followup-evidence':['menu-source-epoch','HUD-private-spIcon-fixture'],
 'hud-receiver-fixture-followup':['HUD-private-spIcon-fixture'],
 'inherited-visual-fixture-followup':['ScreenFX-constructor-cache-fixture','Hissen-display-multiplier-fixture'],
 'historical-ci-unknowns':['unknown-historical-webkit-setup','unknown-historical-runner-shutdown','unknown-historical-native-menu-timeout'],
 'ci-repair-draft':['draft-fixture-VM-flag'],
}
report_root=Path('/workspace/wt-agent5/reports/issue-resolution-20261029')
for cause in sorted({c for f in families for c in f['causeIds']}):
    related=[f for f in families if cause in f['causeIds']]
    unknown=cause.startswith(('unknown-','unclassified-'));secondary=cause.startswith('secondary-')
    root_causes.append({'id':cause,'description':descriptions.get(cause,cause),'historicalJobs':sorted({j for f in related for j in f['beforeJobs']}),'families':[f['id'] for f in related],'unknown':unknown,'secondary':secondary,'allCurrentEquivalentGatesPassed':all(f['currentGatePassed'] for f in related),'countAsKnownCauseCovered':not unknown and not secondary and all(f['currentGatePassed'] and not f['metadataUnverified'] for f in related)})
    reports=[group for group,ids in evidence_groups.items() if cause in ids] or ['final-batch']
    root_causes[-1]['relatedEvidenceReports']=[{'path':'reports/issue-resolution-20261029/'+group+'/README.md','url':'https://github.com/rhgrive3/actions/blob/'+EXPECTED_HEAD+'/reports/issue-resolution-20261029/'+group+'/README.md','currentTreeFileExists':(report_root/group/'README.md').is_file()} for group in reports]
    root_causes[-1]['repairCommitsFromRetainedCohorts']=sorted({r['repairCode'] for r in records if cause in r['causeIds'] and r.get('repairCode')})
out={'schema':1,'at':snap['at'],'currentPR':1914,'head':EXPECTED_HEAD,'main':snap['main'],'definition':'Deduplicate historical failures by PR + workflow + event + check family. Only CPU shard variants collapse, and all8 exact-current-head shards must pass. Multiple old PR rows mapping to one current gate are observations covered by a current equivalent gate, not multiple newly executed current gates. Known-cause coverage also requires demonstrated cause classification; canceled/skip/missing/unknown never qualify. Historical source heads remain failed.','originalCohorts':{'baseline85':85,'postAtomic15':15,'postRepair1':1,'additional8':8,'cb9Followup2':2},'original45Preserved':len(original_keys),'retainedHistoricalPRRecords':len(records),'retainedHistoricalPRFamilies':len(families),'counts':{'knownCauseCoveredPrimaryFamilies':sum(f['countAsKnownCauseCoveredFamily'] for f in families),'original45KnownCauseCoveredPrimaryFamilies':sum(f['countAsKnownCauseCoveredFamily'] and f['original45'] for f in families),'knownCausesAllCurrentEquivalentGatesPassed':sum(c['countAsKnownCauseCovered'] for c in root_causes),'currentEquivalentGateSuccessFamilies':sum(f['currentGatePassed'] for f in families),'unknownHistoricalEvents':len(unknown_jobs),'unclassifiedJobs':sorted(r['job'] for r in records if any(c.startswith('unclassified-') for c in r['causeIds']))},'families':families,'rootCauses':root_causes,'historicalUnknown8':[{'job':j,'causeClass':c,'resolved':False} for j,c in unknown_jobs.items()],'limits':['This initial mapping retains the immutable111-record pre-1914 cohort and its45-family live subset. Later PR1914/1915/1916/main epochs are added in a separate extension, not silently folded into these original counts.','A successful current equivalent gate does not prove an unknown historical failure cause fixed or make a closed old PR/head green.','Local-only test/diagnostic failures, issue closures,11review findings, software completion candidates and measured FPS/VRAM are separate metrics.']}
out.pop('retainedHistoricalPRRecords');out.pop('retainedHistoricalPRFamilies')
out['scopeCounts']={'originalPRFailedJobRecords':111,'originalPRFamilies':72,'expandedFailedJobRecords':len(records),'expandedPRFailedJobRecords':sum(r['pr']!=0 for r in records),'mainContextFailedJobRecords':sum(r['pr']==0 for r in records),'expandedFamiliesIncludingMainContext':len(families),'expandedPRFamilies':sum(f['scope']=='PR' for f in families),'mainContextFamilies':sum(f['scope']=='main-context' for f in families)}
out['counts']['expandedPRKnownCauseCoveredPrimaryFamilies']=sum(f['scope']=='PR' and f['countAsKnownCauseCoveredFamily'] for f in families)
out['counts']['mainContextKnownCauseCoveredPrimaryFamilies']=sum(f['scope']=='main-context' and f['countAsKnownCauseCoveredFamily'] for f in families)
out['counts']['original111KnownCauseCoveredPrimaryFamilies']=sum(f['original111Family'] and f['countAsKnownCauseCoveredFamily'] for f in families)
out['counts']['distinctCurrentSuccessfulEquivalentGatesForKnownCauses']=len({(f['currentEquivalent']['path'],f['currentEquivalent']['event'],f['family']) for f in families if f['countAsKnownCauseCoveredFamily']})
out['counts']['original45CurrentStates']=dict(collections.Counter(f['currentEquivalent']['status'] for f in families if f['original45']))
out['counts']['expandedCurrentStates']=dict(collections.Counter(f['currentEquivalent']['status'] for f in families))
pr_causes=[]
for cause in root_causes:
    related=[f for f in families if f['scope']=='PR' and cause['id'] in f['causeIds']]
    if related and not cause['unknown'] and not cause['secondary'] and all(f['currentGatePassed'] and not f['metadataUnverified'] for f in related):pr_causes.append(cause['id'])
out['counts']['knownPRRootCausesAllMappedPRGatesPassed']=len(pr_causes)
out['counts']['knownPRRootCauseIdsCovered']=pr_causes
source_names=['agent2-ci-inventory-20261029.json','agent2-unified-family-last-pre-external-merge.json','agent2-ci-before-run-events.json','agent2-additional-eight-actual-ci-failures.json','agent2-current-cb9d-followup-failures.json','agent2-pr1914-current-failures/receipt.json','agent2-pr1914-331-failures/receipt.json','agent2-pr1914-331fdaad-ci-completed.json','agent2-pr1914-367-validate-exact-jobs.json','agent2-pr1914-39c-hosted-superseded-packet/summary.json','agent2-pr1914-39c-terminal-latest.json','agent2-pr1914-98-hosted-superseded-packet/summary.json','agent2-pr1914-98-superseded-latest.json','agent2-pr1916-failures/receipt.json','agent2-pr1916-7cd-exact-metadata.json','agent2-pr1915-6690-exact-metadata.json','pr1915-current-status.json','agent2-main-91c1-ci-snapshot.json','agent2-main-40737709268-log-manifest.json','agent2-pr1914-observed-gates-from-331.json']
source_names.append('agent2-pr1914-3c-post72-latest.json')
source_names.append('agent2-pr1914-72-failure-diagnosis.json')
if terminal72.exists():source_names.append(terminal72.name)
out['sourceManifest']=[{'path':str(R/n),'bytes':(R/n).stat().st_size,'sha256':hashlib.sha256((R/n).read_bytes()).hexdigest()} for n in source_names]
snapshot_bytes=(json.dumps(snap,sort_keys=True,separators=(',',':'))+'\n').encode()
snapshot_path=R/('agent2-pr1914-'+EXPECTED_HEAD[:8]+'-family-snapshot.json.gz');snapshot_path.write_bytes(gzip.compress(snapshot_bytes,mtime=0))
out['currentSnapshotReceipt']={'path':str(snapshot_path),'uncompressedCanonicalSha256':hashlib.sha256(snapshot_bytes).hexdigest(),'gzipSha256':hashlib.sha256(snapshot_path.read_bytes()).hexdigest(),'at':snap['at']}
record_manifest=[]
for r in records:
    raw=Path(r['rawLog']) if r.get('rawLog') else next(iter(sorted(R.glob('*'+str(r['job'])+'*.log'))),None)
    proof={'job':r['job'],'pr':r['pr'] if r['pr'] else None,'scope':'main-context' if not r['pr'] else 'PR','head':r['head'],'cohort':r['cohort'],'workflow':r['workflow'],'event':r['event'],'family':family(r['name']),'causeIds':r['causeIds'],'run':r.get('run'),'url':r.get('url'),'repairCredit':r.get('repairCredit'),'metadataEvidence':r.get('metadataEvidence'),'metadataUnverified':r.get('metadataUnverified',False)}
    proof.update({'repairCode':r.get('repairCode'),'repairReceipt':r.get('repairReceipt'),'retainedCauseEvidence':r.get('cause'),'retainedFailureTitles':[f.get('title') for f in r.get('failures',[])]})
    if raw and raw.exists():
        proof['rawLog']={'path':str(raw),'bytes':raw.stat().st_size,'sha256':hashlib.sha256(raw.read_bytes()).hexdigest()}
    else:proof['rawLog']={'availability':'Original retained inventory/excerpt and its hashed source manifest; no new log download attempted.'}
    record_manifest.append(proof)
out['failedJobManifest']=record_manifest
operational=[]
for r in audit.get('cancelledPrerequisiteSecondaryJobs',[]):
    operational.append({'pr':r['pr'],'head':r['head'],'run':r['run'],'job':r['job'],'workflow':r['workflow'],'event':r['event'],'family':r['name'],'causeId':'secondary-cancelled-aggregate','countAsKnownCauseCovered':False,'source':'agent2-ci-inventory-20261029.json:cancelledPrerequisiteSecondaryJobs','rawLog':r.get('rawLog'),'rawSha256':r.get('rawSha256'),'currentEquivalent':equivalent(r['workflow'],r['event'],r['name'])})
cancel_rows=read('agent2-current-validate-cancellation-investigation.json')['rows']
for r in cancel_rows:
    for j in r['jobs']:
        if j.get('conclusion')=='failure':
            raw=R/('agent2-current-failure-job-'+str(j['id'])+'.log')
            operational.append({'pr':r['pr'],'head':r['head_sha'],'run':r['id'],'job':j['id'],'workflow':W,'event':r['event'],'family':j['name'],'causeId':'secondary-cancelled-aggregate','countAsKnownCauseCovered':False,'source':'agent2-current-validate-cancellation-investigation.json','rawLog':str(raw),'rawSha256':hashlib.sha256(raw.read_bytes()).hexdigest() if raw.exists() else None,'currentEquivalent':equivalent(W,r['event'],j['name'])})
assert len(operational)==6 and len({r['job'] for r in operational})==6
assert not ({r['job'] for r in operational}&{r['job'] for r in records})
out['separateExcludedOperationalSecondaryCohort']={'records':operational,'count':6,'includedInPrimaryResolutionCounts':False,'reason':'Preserves the pre-existing explicit operational cohort boundary: one cancelled Headgear fan-in and five cancelled-prerequisite Validate fan-ins. Correct strict rejection is not another product defect or a resolved primary cause. No initiator is inferred solely from timing.','sourceManifest':{'path':str(R/'agent2-current-validate-cancellation-investigation.json'),'sha256':hashlib.sha256((R/'agent2-current-validate-cancellation-investigation.json').read_bytes()).hexdigest()}}
out['scopeCounts']['separateExcludedOperationalSecondaryRecords']=6
out['scopeCounts']['totalUniqueJobsAcrossAllExplicitCohorts']=len(records)+6
out['unprovenPrimaryCauseEvents']=[{'job':r['job'],'pr':r['pr'] if r['pr'] else None,'head':r['head'],'causeIds':[c for c in r['causeIds'] if c.startswith('unknown-')]} for r in records if any(c.startswith('unknown-') for c in r['causeIds'])]
out['counts']['unprovenPrimaryCauseEvents']=len(out['unprovenPrimaryCauseEvents'])
out['counts']['metadataUnverifiedJobs']=[r['job'] for r in records if r.get('metadataUnverified')]
out['counts']['crossContextKnownCauseCoveredPrimaryFamilies']=out['counts'].pop('knownCauseCoveredPrimaryFamilies')
out['counts']['crossContextEquivalentGateSuccessFamilies']=out['counts'].pop('currentEquivalentGateSuccessFamilies')
out['limits'][0]='Original111 PR records and72 families preserve all85/15/1/8/2 cohorts and the original45 live-family subset. Later PR1914/15/16 and main epochs have separately labeled cohort records; main push failures are compared explicitly to current full PR jobs, not called main successes.'
assert not out['counts']['unclassifiedJobs']
target=R/'agent2-current-failure-family-map.json';target.write_text(json.dumps(out,indent=2)+'\n')
md=['# Current equivalent CI failure-family coverage','',f"Snapshot {out['at']}; exact current PR1914 `{EXPECTED_HEAD}`.",'',out['definition'],'',f"Original111 retained PR failed-job records form72 families; original45 live-family subset is intact. Expanded cohorts: {out['scopeCounts']['expandedPRFailedJobRecords']} PR records/{out['scopeCounts']['expandedPRFamilies']} PR families, plus12 main-context records/7 families. Cohorts were not rewritten.",'',f"Known-cause PR primary families covered by actual current success: {out['counts']['expandedPRKnownCauseCoveredPrimaryFamilies']} (original45 subset: {out['counts']['original45KnownCauseCoveredPrimaryFamilies']}). Separate main push→PR context families covered: {out['counts']['mainContextKnownCauseCoveredPrimaryFamilies']}. Distinct current successful gate families serving these known-cause comparisons: {out['counts']['distinctCurrentSuccessfulEquivalentGatesForKnownCauses']}. These are separate metrics, not a final all-CI-green claim.",'','| Historical PR / context | Workflow / family | Before jobs | Causes | Current equivalent | Counted known-cause coverage |','| --- | --- | --- | --- | --- | --- |']
for f in families:md.append('| '+(str(f['pr']) if f['pr'] else 'main context')+' | '+f['workflow']+' / '+f['family']+' | '+', '.join(map(str,f['beforeJobs']))+' | '+', '.join(f['causeIds'])+' | '+f['currentEquivalent']['status']+' | '+str(f['countAsKnownCauseCoveredFamily']).lower()+' |')
(R/'agent2-current-failure-family-map.md').write_text('\n'.join(md)+'\n')
print(json.dumps({k:out[k] for k in ['at','head','original45Preserved','scopeCounts','counts']}))
