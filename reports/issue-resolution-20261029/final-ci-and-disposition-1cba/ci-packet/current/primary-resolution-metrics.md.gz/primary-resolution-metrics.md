# Known primary CI failure coverage

Snapshot 2026-10-29T22:16:38.679Z; exact PR1914 `1cba8c73e79565757f051bb106c6076440ca97d9`. Final CI ready: true. Counts are provisional until all required current gates pass.

Each historical failed job ID counts once, even if several known primary cause IDs apply. Primary cause families are distinct diagnosed cause IDs and count only when every associated job in that cohort has its exact-current equivalent gate fully passed. CPU equivalents require all8 shards. Unknown primary, secondary-only, missing/cancelled/skipped/pending gates and unverified metadata do not count. Original111 is a subset of expanded146 PR jobs; main12 is separate. Historical heads remain failed. Prior expanded146PR remains immutable; followup72PR contains2 later jobs (one primary and one secondary). expandedCurrentPR is their148-job union. These overlapping cohorts must not be added.

| Cohort | Retained failed jobs | Known primary eligible jobs | Current equivalent passed jobs | Distinct primary causes | All associated gates passed causes |
| --- | ---: | ---: | ---: | ---: | ---: |
| original111PR | 111 | 92 | 92 | 38 | 38 |
| expanded146PR | 146 | 113 | 113 | 50 | 50 |
| followup72PR | 2 | 1 | 1 | 1 | 1 |
| expandedCurrentPR | 148 | 114 | 114 | 51 | 51 |
| separate12MainContext | 12 | 11 | 11 | 16 | 16 |

| Repair attribution within expandedPR | Known primary jobs passed | Distinct primary causes fully covered |
| --- | ---: | ---: |
| sessionRepairEvidenceExcludingExplicitPriorOwner1916 | 108 | 50 |
| explicitPriorOwner1916Preserved | 6 | 1 |

Total expandedPR current coverage includes6known-primary1916 owner repair jobs and1secondary fan-in. These owner jobs/cause are retained and verified, but excluded from root-session repair credit. Session-vs-owner cause counts must not be blindly added if any cause IDs overlap.

Every historical job disposition and exact current workflow path/event/run/check IDs are in the JSON. Six separate operational fan-in records are excluded. The 15 historical primary events with unproven causes are covered by the separate audit and remain excluded even when current equivalent gates pass.
