import test from 'node:test';
import assert from 'node:assert/strict';
import {setup} from './fixtures/bvh-query-fixture.mjs';
if(process.env.INKWAVE_BUILT_SITE)throw Error('UV instrument and mutation require source; run native-ground-batch against emitted output separately');
const ground=h=>({...h,normal:h.normal.toArray()});
let seed=73129;const random=()=>((seed=(Math.imul(seed,1664525)+1013904223)>>>0)/4294967296);

test('source-face UV projection occurs only for winning support with identical native output',async()=>{
 const instrumented=await setup({instrumentPhysics:true}),V=instrumented.V;
 const a=instrumented.make(),b=instrumented.make();
 const metrics=()=>instrumented.context.__nativeUv||0;
 for(const state of [a,b]){
  state.level.data.triangleFace.fill(0);
  state.level.faces.push({origin:V(-4,0,-4),u:V(1,0,0),v:V(0,0,1)});
  state.level.blocks.push({grate:false});state.level.staticBlockCount=1;
 }
 const expected={normal:V()},actual={normal:V()};
 const args=[0,2,0,2,2,.25];
 let prior=metrics();instrumented.Physics.prototype.groundProbe.call(a.physics,...args,expected,false,.12);
 assert.equal(metrics()-prior,9,'sequential reference projects all nine hits');
 prior=metrics();
 b.physics.groundProbe(...args,actual,false,.12);
 assert.deepEqual(ground(actual),ground(expected));
 assert.equal(metrics()-prior,1,'only the chosen footprint support needs a UV projection');
 // Re-run mixed holes, stepped layers and grated triangles, retaining all
 // source UV metadata comparisons against the sequential native oracle.
 for(let n=0;n<2500;n++){
  const p=[(random()-.5)*10,random()*4,(random()-.5)*10,.2+random(),.2+random(),random()*.6];
  instrumented.Physics.prototype.groundProbe.call(a.physics,...p,expected,!!(n%2),.12);
  b.physics.groundProbe(...p,actual,!!(n%2),.12);
  assert.deepEqual(ground(actual),ground(expected),'footprint '+n);
 }
 // A moving block wins all nine underlying static hits: its owner supplies
 // the selected metadata, and no source-face projection is needed.
 for(const state of [a,b])state.level.blocks.push({id:1,solid:true,grate:false,
  center:V(0,3,0),half:V(.5,.15,.5),aabbMin:V(-.5,2.85,-.5),aabbMax:V(.5,3.15,.5),
  axes:[V(1,0,0),V(0,1,0),V(0,0,1)],faces:[-1,-1,-1,-1,-1,-1]});
 prior=metrics();instrumented.Physics.prototype.groundProbe.call(a.physics,...args,expected,false,.12);
 assert.equal(metrics()-prior,9);prior=metrics();
 b.physics.groundProbe(...args,actual,false,.12);
 assert.deepEqual(ground(actual),ground(expected));assert.equal(actual.block,1);
 assert.equal(metrics()-prior,0);
 // Custom owners can inspect the per-hit scratch while processing a probe;
 // retain their original eager order instead of hiding those operations.
 b.level.blocks.pop();
 const fill=b.physics._fillGround;b.physics._fillGround=function(...x){return fill.apply(this,x);};
 prior=metrics();b.physics.groundProbe(...args,actual,false,.12);
 assert.equal(metrics()-prior,9,'custom support consumer retains eager metadata');
 b.physics._fillGround=fill;
 const block=b.level.blockForTriangle;b.level.blockForTriangle=function(...x){return block.apply(this,x);};
 prior=metrics();b.physics.groundProbe(...args,actual,false,.12);
 assert.equal(metrics()-prior,9,'custom source owner retains eager metadata');
 b.level.blockForTriangle=block;
 const dynamicQuery=b.level.queryDynamicBlocks;b.level.queryDynamicBlocks=function(...x){return dynamicQuery.apply(this,x);};
 prior=metrics();b.physics.groundProbe(...args,actual,false,.12);
 assert.equal(metrics()-prior,9,'custom dynamic query owner retains eager metadata');
 b.level.queryDynamicBlocks=dynamicQuery;
 const delegate=b.physics.dynamic.level.queryBlocks;b.physics.dynamic.level.queryBlocks=function(...x){return delegate.apply(this,x);};
 prior=metrics();b.physics.groundProbe(...args,actual,false,.12);
 assert.equal(metrics()-prior,9,'custom dynamic delegate retains eager metadata');
 b.physics.dynamic.level.queryBlocks=delegate;
 const dot=b.world._p.dot;b.world._p.dot=function(...x){return dot.apply(this,x);};
 prior=metrics();b.physics.groundProbe(...args,actual,false,.12);
 assert.equal(metrics()-prior,9,'custom vector observer retains eager metadata');
 b.world._p.dot=dot;
 // A bad positive face index on a nonwinning ring hit still throws, after
 // the same winning centre output as the sequential reference.
 for(const state of [a,b]){
  state.level.blocks.length=1;state.level.data.triangleFace.fill(-1);
  state.level.data.triangleFace[190]=0;state.level.data.triangleFace[191]=1;
 }
 const broken=[0,2,0,2,2,.5],left={normal:V()},right={normal:V()};
 assert.throws(()=>instrumented.Physics.prototype.groundProbe.call(a.physics,...broken,left,false,.12),{name:'TypeError'});
 assert.throws(()=>b.physics.groundProbe(...broken,right,false,.12),{name:'TypeError'});
 assert.deepEqual(ground(right),ground(left),'earlier selected support survives both failures');
});

test('source-face UV oracle rejects an omitted selected projection',async()=>{
 const broken=await setup({instrumentPhysics:true,breakSelectedUV:true}),V=broken.V;
 const a=broken.make(),b=broken.make();
 for(const state of [a,b]){
  state.level.data.triangleFace.fill(0);
  state.level.faces.push({origin:V(-4,0,-4),u:V(1,0,0),v:V(0,0,1)});
  state.level.blocks.push({grate:false});state.level.staticBlockCount=1;
 }
 const expected={normal:V()},actual={normal:V()},args=[0,2,0,2,2,.25];
 broken.Physics.prototype.groundProbe.call(a.physics,...args,expected,false,.12);
 b.physics.groundProbe(...args,actual,false,.12);
 assert.notDeepEqual(ground(actual),ground(expected),'mutated UV must be observable');
 assert.notEqual(expected.u,actual.u);
});
