import fs from 'node:fs';
import * as T from '/workspace/actions/inkwave-public/vendor/three/build/three.module.js';
const root='/workspace/scratch/respawn-ready-return-20261023';
const old=JSON.parse(fs.readFileSync(root+'/browser-before/receipt.json')),cur=JSON.parse(fs.readFileSync(root+'/browser-after/receipt.json'));
const b=Object.fromEntries(old.rows.map(r=>[r.label,r])),a=Object.fromEntries(cur.rows.map(r=>[r.label,r]));
const Q=x=>new T.Quaternion().fromArray(x),M=x=>new T.Matrix4().fromArray(x);
function arc(from,to,t,long){const target=to.clone();let dot=from.dot(target);if((dot<0)!==long){target.set(-target.x,-target.y,-target.z,-target.w);dot=-dot;}const angle=Math.acos(Math.max(-1,Math.min(1,dot))),s=Math.sin(angle);if(Math.abs(s)<1e-8)return from.clone();const x=Math.sin((1-t)*angle)/s,y=Math.sin(t*angle)/s;return new T.Quaternion(from.x*x+target.x*y,from.y*x+target.y*y,from.z*x+target.z*y,from.w*x+target.w*y).normalize();}
const from=Q(b['normal-60'].handR.localQuaternion);
console.log('handLocal endpoint shortdegrees',from.angleTo(Q(b['normal-61'].handR.localQuaternion))*180/Math.PI);
for(const n of [61,62,63,64,65,66,67,68,72]){
 const orig=b['normal-'+n],r=a['normal-'+n],progress=1-r.handoff.weight;
 const short=arc(from,Q(orig.handR.localQuaternion),progress,false),long=arc(from,Q(orig.handR.localQuaternion),progress,true);
 const parent=Q(r.handR.quaternion).multiply(Q(r.handR.localQuaternion).invert());
 const world=new T.Matrix4().compose(new T.Vector3().fromArray(r.handR.position),parent.multiply(long),new T.Vector3(1,1,1));
 const relative=M(orig.handR.matrixWorld).invert().multiply(M(orig.drum.matrixWorld));
 world.multiply(relative);const box=r.localDrumBounds;let min=Infinity;
 for(let x=0;x<2;x++)for(let y=0;y<2;y++)for(let z=0;z<2;z++){const v=new T.Vector3(box[x?'max':'min'][0],box[y?'max':'min'][1],box[z?'max':'min'][2]).applyMatrix4(world);min=Math.min(min,v.y);}
 console.log(n,JSON.stringify({currentLocalShortError:short.angleTo(Q(r.handR.localQuaternion)),currentMeshMin:r.worldDrumBounds.min[1],longCornerMin:min,localLongAngle:Math.acos(-Math.abs(from.dot(Q(orig.handR.localQuaternion))))*360/Math.PI}));
}
