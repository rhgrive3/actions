import fs from 'node:fs';
import assert from 'node:assert/strict';
import {spawnOwnerFixture,prepareSpawn,launchSpawn} from '/workspace/actions/patches/splatoon3/tests/respawn-spawn-owner-fixture.mjs';
const f=await spawnOwnerFixture({random:()=>.314159,moduleTransform:(relative,source)=>relative==='patches/splatoon3/runtime/weapon-handoff-motion.mjs'?fs.readFileSync('/workspace/scratch/respawn-ready-arc-20261023/before-handoff-source.mjs','utf8'):source}),a=await prepareSpawn(f),c=a.character;
launchSpawn(f,a);for(let i=0;i<300&&a.s3.squidSpawn;i++)f.tick(a,1/30);
for(let n=0;n<10;n++){
 if(n)f.tick(a,1/30);
 const st=c[Symbol.for('inkwave.s3.weapon-handoff-motion.v1')].states.get(c),v=new f.THREE.Vector3();let min=Infinity;
 c.weapon.drum.traverseVisible(mesh=>{const pos=mesh.geometry?.attributes?.position;if(!pos)return;for(let i=0;i<pos.count;i++){mesh.getVertexPosition(i,v).applyMatrix4(mesh.matrixWorld);min=Math.min(min,v.y);}});
 assert(min>=a.pos.y-1e-6,'actual old source displayed drum vertices must clear supported floor: '+min);
 console.log(JSON.stringify({n,floor:a.pos.y,bboxMin:new f.THREE.Box3().setFromObject(c.weapon.drum).min.y,vertexMin:min,fade:st.w,spawn:st.spawning,landing:st.spawnLanding,long:st.spawnLongHand,hand:c.bones.handR.quaternion.toArray()}));
}
f.reset();
