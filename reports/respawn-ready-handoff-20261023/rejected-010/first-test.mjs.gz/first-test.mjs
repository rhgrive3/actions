import test from 'node:test';
import assert from 'node:assert/strict';
import {sourceLoadedActorFixture} from './source-loaded-actor-fixture.mjs';
import {prepareSpawn, launchSpawn, installDryFloor, spawnOwnerRow, assertReady} from './respawn-spawn-owner-fixture.mjs';

let cached;
const fixture = () => cached ??= sourceLoadedActorFixture({random: () => .314159, extraExports: `
  export {spawnMotionAllowsAction, spawnPoseSnapshot} from './patches/splatoon3/runtime/spawn-pose-motion.mjs';
  export {ROLLER_POSE} from './patches/splatoon3/runtime/roller.mjs';
  export {weaponHandoffSnapshot} from './patches/splatoon3/runtime/weapon-handoff-motion.mjs';
`});
const rotation = (f, c) => c.weapon.pivot.getWorldQuaternion(new f.THREE.Quaternion());
function touchdown(f, a, dt) {
  for (let i = 0; i < 300 && a.s3.squidSpawn; i++) f.tick(a, dt);
  assert.equal(a.s3.squidSpawn, undefined);
  assert.equal(a.grounded, true);
  assert.equal(a.ground.hit, true);
}
function nativeRow(f, a) {
  const c = a.character;
  return JSON.parse(JSON.stringify({
    ...spawnOwnerRow(f, a),
    muzzle: c.getMuzzle(new f.THREE.Vector3()).toArray(),
    channels: Array.from(c.P),
    projectiles: f.G.projectiles.list.map(p => ({pos:p.pos?.toArray(), vel:p.vel?.toArray(), age:p.age, life:p.life, damage:p.damage})),
  }));
}

test('native respawn ready handoff starts immediately without a one-tick half-turn, at 30/60/120 Hz', async () => {
  const f = await fixture();
  for (const hz of [30, 60, 120]) {
    const dt = 1/hz, a = await prepareSpawn(f), c = a.character;
    launchSpawn(f, a); touchdown(f, a, dt);
    const before = rotation(f, c);
    f.tick(a, dt);
    const first = rotation(f, c), degrees = before.angleTo(first)*180/Math.PI;
    assert(degrees > .01, 'display starts moving immediately, rather than holding the old carry');
    assert(degrees < 45*60/hz, `${hz}Hz first ready step ${degrees} degrees`);
    assert(f.weaponHandoffSnapshot(c).weight > .1, 'existing bounded display fade is active');
    assertReady(f, c); // canonical ready/action is immediate, display only is faded
    assert.equal(f.spawnMotionAllowsAction(c, false), true);
    assert(c.tr[f.CHARACTER_TIMERS.T_SPAWN] < 1.4);
    for (let i=0; i<Math.ceil(.1/dt)+2; i++) {
      f.tick(a, dt);assertReady(f, c);
      assert.equal(a.ink,100);assert.equal(a.stats.turf,0);assert.equal(f.G.projectiles.list.length,0);
      assert.equal(a.weaponRunner.rolling,false);assert.equal(a.weaponRunner.flick,-1);
    }
    assert.equal(f.weaponHandoffSnapshot(c).weight, 0, 'settles within existing .1s raise plus frame rounding');
  }
});

test('display fade preserves every canonical channel, gameplay muzzle, native state and real shot trajectory', async () => {
  const f = await fixture();
  async function run(enabled, attackAt, held=false) {
    const a=await prepareSpawn(f),c=a.character;c.s3WeaponHandoffEnabled=enabled;
    launchSpawn(f,a);if(held)a.intent.fire=true;touchdown(f,a,1/60);
    const rows=[], snapshots=[];
    for(let i=0;i<45;i++){
      if(i===attackAt)a.intent.fire=true;
      f.tick(a);rows.push(nativeRow(f,a));snapshots.push(f.weaponHandoffSnapshot(c));
      if((held||i>=attackAt)&&attackAt>=0)assert.equal(snapshots.at(-1).weight,0,'attack pose has immediate priority over spawn display fade');
    }
    return {rows,snapshots};
  }
  for(const [at,held] of [[-1,false],[0,false],[2,false],[5,false],[0,true]]){
    const raw=await run(false,at,held),shown=await run(true,at,held);
    assert.deepEqual(shown.rows,raw.rows,`attackAt=${at} held=${held}: canonical/gameplay outputs`);
    if(at>0)assert(shown.snapshots.slice(0,at).some(s=>s.weight>0));
    if(at>=0)assert(shown.rows.some(r=>r.rolling||r.projectiles.length>0),'intentional attack is actually admitted');
  }
});

test('missed support retains native spawn ownership, then fades only after actual supported touchdown', async () => {
  const f=await fixture(),a=await prepareSpawn(f),c=a.character;
  launchSpawn(f,a);installDryFloor(f,-8);let retiredAir=0;
  for(let i=0;i<300&&a.s3.squidSpawn;i++){
    f.tick(a);
    if(a.s3.squidSpawn?.phase==='landing'){
      assert.equal(f.spawnMotionAllowsAction(c,true),false);
      assert.equal(f.weaponHandoffSnapshot(c).weight,0);
      if(f.spawnPoseSnapshot(c).phase==='off')retiredAir++;
    }
  }
  assert(retiredAir>0);assert.equal(a.grounded,true);assert.equal(a.pos.y,-8);
  f.tick(a);assertReady(f,c);assert.equal(f.spawnMotionAllowsAction(c,false),true);
  assert(f.weaponHandoffSnapshot(c).weight>0);
  assert.equal(a.ink,100);assert.equal(a.stats.turf,0);assert.equal(f.G.projectiles.list.length,0);
});

test('ordinary jump and weapon/life reuse cannot inherit a spawn display transition', async () => {
  const f=await fixture(),a=await prepareSpawn(f),c=a.character;
  launchSpawn(f,a);touchdown(f,a,1/60);f.tick(a);
  assert(f.weaponHandoffSnapshot(c).weight>0);
  a.intent.jump=true;f.tick(a);assert.equal(f.weaponHandoffSnapshot(c).weight,0);
  a.intent.jump=false;for(let i=0;i<100;i++)f.tick(a);
  assert.equal(f.weaponHandoffSnapshot(c).weight,0);
  a.setWeapon('shooter');a.setWeapon('roller');f.tick(a);
  assert.equal(f.weaponHandoffSnapshot(c).weight,0);
  a.reset();f.tick(a);assert.equal(f.weaponHandoffSnapshot(c).weight,0);
  f.reset();assert.equal(f.weaponHandoffSnapshot(c),null);
});
