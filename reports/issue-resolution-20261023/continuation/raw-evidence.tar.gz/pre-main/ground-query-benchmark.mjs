import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {sourceLoadedActorFixture} from '/workspace/actions/patches/splatoon3/tests/source-loaded-actor-fixture.mjs';
import {buildSourceBVH} from '/workspace/actions/patches/native-stages/runtime/source-convert.mjs';

test('native source-motion bots reuse only identical ground queries within one update at 30/60/120Hz', async () => {
  const f = await sourceLoadedActorFixture({random:()=>.4, extraExports:`
    export {installQuality} from './patches/local-quality/install.mjs';
    export {NativeLevel,NativePhysics} from './patches/native-stages/runtime/engine.mjs';
  `});
  f.installQuality(JSON.parse(fs.readFileSync(new URL('file:///workspace/actions/patches/splatoon3/profile.json'))));
  const {G,THREE}=f;
  const counts=[];
  for (const hz of [60]) {
    const traces=[];let trace=null;
    const triangles=new Float32Array([-20,0,-20,-20,0,20,20,0,-20]);
    // One half of the chart is empty. Keep a real dynamic box over its hole.
    G.level=new f.NativeLevel({triangles,...buildSourceBVH(triangles),
      normals:new Float32Array([0,1,0]), flags:new Uint32Array([3]),
      objectIds:new Uint32Array([0]),triangleFace:new Int32Array([0]),mask:new Uint8Array(),
      manifest:{id:'memo-hole',bounds:{minX:-20,maxX:20,minZ:-20,maxZ:20},
        spawnPads:[[-15,0,-15],[15,0,15]],spawnBarrier:0,
        objects:[{collidable:true,bounds:[[-20,-.2,-20],[20,0,20]]}],
        faces:[{n:[0,1,0],u:[1,0,0],v:[0,0,1],origin:[-20,0,-20],su:40,sv:40,
          triangles:[0],bounds:[[-20,0,-20],[20,0,20]]}]}});
    G.level._addBlock({kind:'box',min:[.5,-.2,.5],max:[3,.1,3],paint:false,hidden:true});
    G.physics=new f.NativePhysics(G.level);
    G.match={state:'playing',opts:{},local:null};
    G.renderer={info:{render:{frame:100}},getRenderTarget:()=>null};
    const pair=[await f.make(),await f.make()];
    const nativeGround=pair[1].character._ground;
    pair[1].character._ground=function(...args){
      if(trace)trace.push([args[0],args[1],this.root.position.y]);
      const active=this._oobGroundMemoActive;this._oobGroundMemoActive=false;
      try{return nativeGround.apply(this,args);}finally{this._oobGroundMemoActive=active;}
    };
    const ray=G.physics.raycast;let calls=0;
    G.physics.raycast=function(...args){calls++;return ray.apply(this,args);};
    const totals=[0,0];
    for(const a of pair){a.isLocal=false;a.isBot=true;const c=a.character;
      c.isLocal=false;c.lod.force=-1;c._camFrame=0;c.phys=G.physics;}
    const state={isBot:true,form:'kid',grounded:true,speed:1,vy:0,localMove:{x:0,z:1},ink:1,hp:1};
    for(let frame=0;frame<hz;frame++){
      G.time=(frame+1)/hz;trace=[];
      // The platform changes between updates. No result may survive a tick.
      G.level.blocks.at(-1).center.y=-.05+.025*Math.sin(frame);
      for(let side=0;side<2;side++){
        const c=pair[side].character;
        c.root.position.set(frame<hz/2?-1:1,.2,frame<hz/2?-1:1);
        const before=calls;
        c.update(1/hz,state);c.root.updateMatrixWorld(true);c.skeleton.update();
        totals[side]+=calls-before;
        assert.equal(c._oobGroundMemoActive,false,'memo ends with the synchronous update');
        assert.equal(c._oobGroundMemo?.length??0,0,'no retained tick results');
      }
      traces.push(trace);
      const snap=a=>{const c=a.character;return JSON.stringify({
        bones:c.boneList.map(b=>[...b.position.toArray(),...b.quaternion.toArray(),...b.matrixWorld.elements]),
        skin:Array.from(c.skeleton.boneMatrices),muzzle:c.getMuzzle(new THREE.Vector3()).toArray(),
        contacts:c.sourceMotion.retarget.contacts.map(p=>({anchor:p.anchor.toArray(),normal:p.normal.toArray(),locked:p.locked}))});};
      assert.equal(snap(pair[0]),snap(pair[1]),`${hz}Hz frame ${frame}: full pose, support and muzzle`);
    }
    const hits=pair[0].character._oobGroundMemoHits;
    assert.ok(hits>0,'actual source contacts repeat queries');
    assert.equal(totals[1]-totals[0],hits,'each avoided native ray is accounted for');
    counts.push({hz,candidate:totals[0],control:totals[1],memoHits:hits});
    const c=pair[0].character,normal=new THREE.Vector3();
    function measure(memo,reps){
      const cpu=process.cpuUsage();const start=performance.now();let checksum=0;
      for(let rep=0;rep<reps;rep++)for(const queries of traces){
        c._oobGroundBudget=true;c._oobGroundMemoActive=memo;(c._oobGroundMemo ||= []).length=0;
        for(const q of queries){c.root.position.y=q[2];checksum+=c._ground(q[0],q[1],normal)+normal.y;}
        c._oobGroundMemoActive=false;for(const hit of c._oobGroundMemo)hit.phys=null;c._oobGroundMemo.length=0;
      }
      const elapsed=process.cpuUsage(cpu);return {memo,reps,queries:reps*traces.reduce((n,q)=>n+q.length,0),checksum,cpuMs:(elapsed.user+elapsed.system)/1000,wallMs:performance.now()-start};
    }
    measure(false,200);measure(true,200);
    const rows=[false,true,true,false,false,true,true,false].map(m=>measure(m,3000));
    assert.ok(rows.every(r=>r.checksum===rows[0].checksum));
    console.log(JSON.stringify({component:'real NativePhysics, exact 60Hz sole-query trace, CPU timer, ABBA repeated; no game/device timing',rows}));

    for(const a of pair){G.scene.remove(a.character.root);a.character.dispose();}
    G.actors=[];
  }
  console.log(JSON.stringify({scope:'source-motion/native triangle and dynamic physics; query counts, not device FPS',counts}));
});
