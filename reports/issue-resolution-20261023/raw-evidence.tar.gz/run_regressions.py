import hashlib, json, os, pathlib, re, signal, subprocess, time

ROOT = pathlib.Path('/workspace/actions')
OUT = ROOT / 'work/issue-resolution-20261023/regressions'
OUT.mkdir(parents=True, exist_ok=True)
NODE = '/home/agent/.npm/_npx/52027bd8fc0022aa/node_modules/node/bin/node'
groups = {
 'clock': ['patches/network-replication/tests/owner-clock-origin.test.mjs', 'patches/network-replication/tests/issue-1767-*.test.mjs', 'server/tests/owner-clock-browser-relay.test.mjs'],
 'catalogue': ['patches/splatoon3/tests/catalogue-*admission.test.mjs', 'patches/splatoon3/tests/catalog-source-launch-1130.test.mjs', 'patches/splatoon3/tests/catalog-flick-damage-source.test.mjs', 'patches/splatoon3/tests/catalog-depletion-1130.test.mjs'],
 'weapons': ['patches/splatoon3/tests/issue-1813-*.test.mjs', 'patches/splatoon3/tests/issue-1431-*.test.mjs', 'patches/splatoon3/tests/kit-big-bubbler-contact-settlement.test.mjs', 'patches/splatoon3/tests/issue-1607-*.test.mjs'],
 'controls': ['patches/splatoon3/tests/gyro-sensitivity-*.test.mjs', 'patches/splatoon3/tests/pad-sensitivity*.test.mjs', 'patches/splatoon3/tests/issue-890-*.test.mjs', 'patches/splatoon3/tests/issue-532-*.test.mjs', 'patches/splatoon3/tests/splatling-charge-decel-1188.test.mjs'],
 'paint': ['patches/splatoon3/tests/issue-79-*.test.mjs', 'patches/splatoon3/tests/issue-992-*.test.mjs', 'patches/splatoon3/tests/storm-vertical-cutoff-735.test.mjs', 'patches/splatoon3/tests/storm-rain-calibration.test.mjs'],
 'motion': ['patches/splatoon3/tests/jump-motion.test.mjs', 'patches/splatoon3/tests/source-jump-family.test.mjs', 'patches/splatoon3/tests/issue-1097-hit-reaction.test.mjs'],
 'performance': ['patches/local-quality/tests/offscreen-visual-budget.test.mjs', 'patches/local-quality/tests/offline-offscreen-budget.test.mjs', 'patches/local-quality/tests/composer-target-adapter.test.mjs', 'patches/local-quality/tests/range-hitch-tracer.test.mjs'],
 'audio': ['patches/splatoon3/tests/audio-provenance.test.mjs', 'patches/splatoon3/tests/weapon-audio.test.mjs'],
}
results=[]
for group, patterns in groups.items():
 files=sorted({p for pattern in patterns for p in ROOT.glob(pattern)})
 if not files: raise RuntimeError('empty group: '+group)
 for file in files:
  label=group+'-'+file.stem
  command=[NODE, '--max-old-space-size=1024', '--experimental-vm-modules', '--experimental-global-webcrypto', '--test', '--test-concurrency=1', str(file.relative_to(ROOT))]
  start=time.monotonic()
  with (OUT/(label+'.tap')).open('w') as log:
   p=subprocess.Popen(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   timeout=False
   try: code=p.wait(timeout=240)
   except subprocess.TimeoutExpired:
    timeout=True;os.killpg(p.pid,signal.SIGTERM)
    try: p.wait(timeout=5)
    except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGKILL);p.wait()
    code=p.returncode
  raw=(OUT/(label+'.tap')).read_bytes();text=raw.decode(errors='replace')
  counts={key:int(value) for key,value in re.findall(r'^# (tests|pass|fail|cancelled|skipped) (\d+)$',text,re.M)}
  row={'group':group,'file':str(file.relative_to(ROOT)),'command':command,'exitCode':code,'timeout':timeout,'seconds':round(time.monotonic()-start,3),'counts':counts,'sha256':hashlib.sha256(raw).hexdigest()}
  results.append(row);(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps(row),flush=True)
print(json.dumps({'files':len(results),'failedFiles':sum(x['exitCode']!=0 for x in results),'tests':sum(x['counts'].get('tests',0) for x in results)}),flush=True)
