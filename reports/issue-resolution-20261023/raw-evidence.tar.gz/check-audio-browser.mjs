import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {chromium} from 'playwright';
const site=path.resolve('work/issue-resolution-20261023/final-site');
const manifest=JSON.parse(fs.readFileSync(path.join(site,'inkwave-build.json'))),served={};
const server=http.createServer((req,res)=>{
 try{
  const rel=decodeURIComponent(new URL(req.url,'http://localhost').pathname).slice(1);
  if(rel==='probe'){res.setHeader('content-type','text/html');res.end('<!doctype html><title>Recorded Charger onset</title>');return;}
  const file=path.resolve(site,rel);assert(file.startsWith(site+path.sep));
  const raw=fs.readFileSync(file),hash=crypto.createHash('sha256').update(raw).digest('hex');
  assert.equal(hash,manifest.artifacts[rel],rel);served[rel]=hash;
  res.setHeader('content-type',/\.m?js$/.test(rel)?'text/javascript':rel.endsWith('.json')?'application/json':'audio/mpeg');res.end(raw);
 }catch(e){res.statusCode=404;res.end(String(e));}
});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
let browser;
try{
 browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port+'/probe');
 const cases=await page.evaluate(async()=>{
  const {WeaponSoundBank}=await import('/patches/splatoon3/runtime/audio/bank.mjs');
  const {RealS3SampleLoader}=await import('/patches/splatoon3/runtime/audio/real-s3-loader.mjs');
  const results=[];
  for(const id of ['charger','s3-charger-long','s3-charger-light','s3-charger-keeper']){
   const ctx=new OfflineAudioContext(2,48000,48000),bank=new WeaponSoundBank(ctx,{realOnly:true}),loader=new RealS3SampleLoader(bank);
   await loader.ensure(id,'charge');const original=bank.authorized.pick(id,'charge');
   if(!original||loader.errors.length)throw Error('real MP3 decode failed '+id+': '+loader.errors.join(';'));
   const d=bank.resolve('main:'+id+':charge');
   if(typeof d?.build!=='function'||d.loop!==undefined)throw Error('one-shot definition missing '+id);
   const voice={ctx,t:0,out:ctx.destination,nodes:[],srcs:[],end:0,endless:false};
   const control=d.build(voice,2.5,{actor:{weaponRunner:{charge:0}}});control.pitch(.01,.05);
   const s=voice.srcs[0];
   if(voice.srcs.length!==1||s.buffer!==original.buffer||s.loop||s.playbackRate.value!==1)throw Error('recording transformed '+id);
   const rendered=await ctx.startRendering();let after=0,energy=0;
   for(let c=0;c<rendered.numberOfChannels;c++){
    const pcm=rendered.getChannelData(c);
    for(let i=0;i<pcm.length;i++){energy+=pcm[i]*pcm[i];if(i>=Math.ceil(original.buffer.duration*48000)+2)after=Math.max(after,Math.abs(pcm[i]));}
   }
   if(!(energy>0)||after!==0)throw Error('expected finite nonzero onset then exact silence '+id);
   results.push({id,duration:original.buffer.duration,loop:s.loop,playbackRate:s.playbackRate.value,sameDecodedBuffer:true,sources:voice.srcs.length,energy,maximumAfterEnd:after,loaderErrors:loader.errors});
   bank.dispose();
  }
  return results;
 });
 assert.equal(errors.length,0);
 const receipt={status:'passed',browser:browser.version(),contentHash:manifest.contentHash,cases,served,errors,limits:['Actual Chromium OfflineAudioContext and production emitted bank/loader/MP3 decode; not real-time device latency or human listening.','Existing 2022 recordings do not certify the missing S3 11.3.0 rising layer.','No WebKit or physical device execution.']};
 fs.writeFileSync('work/issue-resolution-20261023/audio-browser.json',JSON.stringify(receipt,null,2)+'\n');
 console.log(JSON.stringify({status:receipt.status,cases:cases.length,browser:receipt.browser}));
}finally{await browser?.close();await new Promise(r=>server.close(r));}
