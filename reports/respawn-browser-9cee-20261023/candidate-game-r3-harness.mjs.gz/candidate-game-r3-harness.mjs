import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {chromium} from 'playwright';

const root=process.cwd(),site=path.resolve(process.argv[2]),sha=process.argv[3],out=path.resolve(process.argv[4]),baseline=process.argv.includes('--baseline');
const componentOnly=process.argv.includes('--component-only');
const gameOnly=process.argv.includes('--game-only');
fs.mkdirSync(out,{recursive:true});
const {publicBuildIdentity,verifyPublishedSource,verifyPublicResponse}=await import(pathToFileURL(path.join(root,'scripts/lib/inkwave-public-boot-evidence.mjs')));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const m=JSON.parse(fs.readFileSync(path.join(site,'inkwave-build.json')));
const identity={...verifyPublishedSource(m,root,sha),...publicBuildIdentity(m)};
for(const [p,digest]of Object.entries(m.artifacts))assert.equal(hash(fs.readFileSync(path.join(site,p))),digest,p);
const before=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const receipt={status:'running',startedAt:new Date().toISOString(),baseline,componentOnly,identity,verifiedArtifacts:Object.keys(m.artifacts).length,
  harnessSha256:hash(fs.readFileSync(import.meta.filename)),browser:null,settings:{quality:'low',shadows:false,bloom:false,minimap:false,musicVolume:0,audioVolume:0},
  viewport:{width:900,height:620},gameCases:[],componentCases:[],errors:[],httpErrors:[],responseErrors:[],responses:[],limits:[
    'Real Game cases use native requestAnimationFrame/FixedClock/Match/PlayerController and rendered Tidewater; no manual Game._frame calls.',
    'Setup uses spawnAt and the existing freezeBots hook. Keyboard/mouse events supply live game input. This is controlled offline gameplay, not autonomous AI or network acceptance.',
    'Natural fall is a separate browser component diagnostic: synthetic Level/Physics plus actual installed Actor/Character, explicit 1/60 updates, paint/audio/FX stubs. It is not presented as the full Tidewater Game.',
    'Software Chromium, not hardware/device pacing, retail equivalence or universal exclusion when no outside recovery point exists.'
  ]};
const write=()=>fs.writeFileSync(path.join(out,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
fs.copyFileSync(import.meta.filename,path.join(out,'harness.mjs'));
write();
const mime={'.mjs':'text/javascript','.js':'text/javascript','.html':'text/html','.css':'text/css','.json':'application/json','.png':'image/png','.svg':'image/svg+xml','.webp':'image/webp','.woff2':'font/woff2'};
const componentHtml='<!doctype html><meta charset="utf-8"><link rel="icon" href="data:,"><title>Spawn component diagnostic</title><script type="importmap">{"imports":{"three":"/vendor/three/build/three.module.js","three/addons/":"/vendor/three/jsm/"}}</script><body>Actor / Physics diagnostic. No Game or renderer.</body>';
const server=http.createServer((req,res)=>{try{
  if(req.url==='/__focus_component.html'){res.writeHead(200,{'content-type':'text/html'});res.end(componentHtml);return;}
  const u=new URL(req.url,'http://local'),file=path.resolve(site,'.'+(u.pathname==='/'?'/index.html':decodeURIComponent(u.pathname)));
  if(!file.startsWith(site+'/')||!fs.statSync(file).isFile())throw Error();
  res.writeHead(200,{'content-type':mime[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);
}catch{res.writeHead(404);res.end();}});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const address='http://127.0.0.1:'+server.address().port+'/?map=tidewater&skipTitle';
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,
  args:['--no-sandbox','--disable-dev-shm-usage','--disable-features=LocalNetworkAccessChecks','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const pending=new Set();
let page;
try{
  receipt.browser=browser.version();
  const context=await browser.newContext({viewport:receipt.viewport});page=await context.newPage();
  page.on('pageerror',e=>{receipt.errors.push(e.message);write();console.log('pageerror '+e.message);});
  page.on('console',msg=>{if(msg.type()==='error'){(receipt.consoleErrors??=[]).push(msg.text());console.log('console-error '+msg.text().slice(0,180));}});
  page.on('response',res=>{
    if(res.status()>=400)receipt.httpErrors.push({url:res.url(),status:res.status()});
    if(res.status()!==200)return;
    let file;try{const u=new URL(res.url());if(u.origin!==new URL(address).origin)return;file=decodeURIComponent(u.pathname.slice(1))||'index.html';}catch{return;}
    if(!Object.hasOwn(m.artifacts,file))return;
    const work=(async()=>{try{const body=await res.body(),entry=verifyPublicResponse(res.url(),body,m,address);if(entry)receipt.responses.push(entry);}
      catch(e){receipt.responseErrors.push({file,error:e.message});}})();pending.add(work);work.finally(()=>pending.delete(work));
  });
  await page.addInitScript(settings=>{localStorage.setItem('inkwave.settings',JSON.stringify(settings));localStorage.setItem('inkwave.profile',JSON.stringify({weapon:'shooter',name:'Spawn Focus'}));},receipt.settings);
  console.log('boot '+sha+(componentOnly?' component-only':''));await page.goto(componentOnly?new URL('/__focus_component.html',address).href:address,{waitUntil:'domcontentloaded'});
  if(componentOnly){
    receipt.componentFixtureHtmlSha256=hash(componentHtml);
    await page.evaluate(async settings=>{
      const {install}=await import('/patches/splatoon3/runtime/install.mjs'),profile=await(await fetch('/patches/splatoon3/profile.json')).json(),api=install(profile);
      globalThis.NG=api.G;NG.settings=settings;NG.mode='match';NG.teamColors=[new api.THREE.Color('#ff8a14'),new api.THREE.Color('#2f5bff')];
      NG.camera=new api.THREE.PerspectiveCamera();
    },receipt.settings);
  }else{
  await page.evaluate(async()=>{globalThis.NG=(await import(new URL('src/core/ctx.js',document.baseURI))).G;});
  await page.waitForFunction(()=>NG.game?.menus&&NG.mode!=='boot'||document.getElementById('boot-error')?.textContent,null,{timeout:180000});
  assert.equal(await page.locator('#boot-error').textContent(),'');
  }
  if(!componentOnly){
  console.log('start real Game');
  // Existing Game API initializes the real Match. Menu navigation itself is
  // outside this focused gameplay test; all subsequent frames and inputs are native.
  await page.evaluate(async()=>NG.game.startMatch({mapId:'tidewater',mode:'turf',difficulty:'normal',duration:180}));
  await page.waitForFunction(()=>NG.mode==='match'&&NG.match?.state==='playing'&&!NG.match.paused,null,{timeout:180000});
  await page.waitForFunction(()=>NG.local?.alive&&!NG.local.s3?.squidSpawn,null,{timeout:180000});
  receipt.pointerLock={initial:await page.evaluate(()=>NG.game.input.locked)};
  if(!receipt.pointerLock.initial){
    console.log('normal pause/resume click for pointer lock');
    await page.keyboard.press('KeyP');
    await page.waitForFunction(()=>NG.match?.paused,null,{timeout:180000});
    await page.locator('[data-id="resume"]').click();
    await page.waitForFunction(()=>NG.game.input.locked&&!NG.match.paused,null,{timeout:180000});
    receipt.pointerLock.via='real KeyP and pause-menu RESUME click';
  }
  receipt.pointerLock.final=await page.evaluate(()=>NG.game.input.locked);write();
  await page.evaluate(()=>NG.game.debug.freezeBots());
  receipt.game=await page.evaluate(()=>{
    const gl=NG.renderer.getContext(),ext=gl.getExtension('WEBGL_debug_renderer_info');
    return {stage:NG.level.layout.id,actors:NG.actors.length,localTeam:NG.local.team,weapon:NG.local.weaponId,
      character:NG.local.character.constructor.name,characterChildren:NG.local.character.root.children.length,
      renderer:ext?gl.getParameter(ext.UNMASKED_RENDERER_WEBGL):gl.getParameter(gl.RENDERER),frozen:NG.game.frozen,
      skipRender:!!NG.game._skipRender,contextLost:gl.isContextLost(),drawCalls:NG.renderer.info.render.calls,
      clockNative:Function.prototype.toString.call(performance.now).includes('[native code]')};
  });
  assert(!receipt.game.frozen&&!receipt.game.skipRender&&!receipt.game.contextLost);assert.equal(receipt.game.stage,'tidewater');assert(receipt.game.characterChildren>0);
  console.log('real Game playing');write();
  await page.evaluate(async()=>{
    globalThis.focusPlayer=(await import(new URL('src/config.js',document.baseURI))).PLAYER;
    const a=NG.local,update=a.update;
    globalThis.focusCapture=null;
    a.update=function(dt){const value=update.call(this,dt),c=focusCapture;
      if(c&&!c.done){const r=focusPlayer,rad=(this.form==='squid'?r.s3SwimTerrainRadiusRaw:r.s3HumanoidTerrainRadiusRaw)*r.s3TerrainDistanceScale;
        c.totalTicks=(c.totalTicks||0)+1;
        if(c.rows.length<1200)c.rows.push({time:NG.time,dt,pos:this.pos.toArray(),vel:this.vel.toArray(),grounded:this.grounded,alive:this.alive,
          phase:this.s3?.squidSpawn?.phase||null,invuln:this.invuln,intent:{move:this.intent.move.toArray(),fire:this.intent.fire,jump:this.intent.jump},
          fits:NG.physics.bodyFits(this.pos,rad,this.form==='squid'?r.squidBodyLift:r.stepUp,this.form==='squid'?r.squidHeight:r.height,this.form==='squid')});
        if(NG.time>=c.until)c.done=true;
        if(c.totalTicks>1200)c.truncated=true;
      }return value;};
  });
  async function drive(kind,key,seconds){
    console.log('game '+kind);
    await page.evaluate(({kind,seconds})=>{focusCapture={kind,start:NG.time,wallStart:performance.now(),until:NG.time+seconds,rows:[],done:false};},{kind,seconds});
    await page.keyboard.down(key);
    await page.waitForFunction(()=>focusCapture?.done,null,{timeout:180000});
    await page.keyboard.up(key);
    const row=await page.evaluate(()=>({...focusCapture,wallEnd:performance.now(),end:NG.local.pos.toArray(),frozen:NG.game.frozen,skipRender:!!NG.game._skipRender,
      drawCalls:NG.renderer.info.render.calls,stage:NG.level.layout.id,paused:NG.match.paused}));
    receipt.gameCases.push(row);write();
    assert(row.rows.length>10&&row.rows.every(r=>r.dt===1/60&&r.fits&&r.alive));
    assert(!row.frozen&&!row.skipRender&&!row.paused&&row.drawCalls>0);return row;
  }
  const entry=await page.evaluate(()=>{
    const a=NG.local,p=NG.level.spawnPads[1-a.team];a.spawnAt(p.clone().add({x:-NG.level.spawnBarrier-.65,y:0,z:0}),Math.PI/2);
    NG.rig.yaw=Math.PI/2;NG.rig.pitch=-.2;return{pad:p.toArray(),radius:NG.level.spawnBarrier,start:a.pos.toArray()};
  });
  const entryResult=await drive('enemy-side-entry','KeyW',.8);entryResult.setup=entry;
  entryResult.minimum=Math.min(...entryResult.rows.map(r=>Math.hypot(r.pos[0]-entry.pad[0],r.pos[2]-entry.pad[2])));
  assert(entryResult.minimum>=4.59&&entryResult.minimum<4.65);write();
  const corner=await page.evaluate(()=>{
    const a=NG.local,p=NG.level.spawnPads[1-a.team],start=p.clone().add({x:-3,y:0,z:3.8}),r=focusPlayer;
    if(!NG.physics.bodyFits(start,r.s3HumanoidTerrainRadiusRaw*r.s3TerrainDistanceScale,r.stepUp,r.height))throw Error('Actual pad-corner setup is blocked');
    const yaw=Math.atan2(p.x-start.x,p.z-start.z);a.spawnAt(start,yaw);NG.rig.yaw=yaw;NG.rig.pitch=-.2;
    const ray=NG.physics.raycast(start.clone().add({x:0,y:.5,z:0}),start.clone().set(0,0,1),2);
    return{pad:p.toArray(),start:start.toArray(),wallHit:ray.hit,wallDistance:ray.hit?ray.dist:null,wallPoint:ray.hit?ray.point.toArray():null};
  });
  assert(corner.wallHit,'real map obstacle must be present');
  const cornerResult=await drive('enemy-pad-backwall-corner','KeyW',.65);cornerResult.setup=corner;
  cornerResult.minimum=Math.min(...cornerResult.rows.map(r=>Math.hypot(r.pos[0]-corner.pad[0],r.pos[2]-corner.pad[2])));assert(cornerResult.minimum>=4.59);write();
  await page.screenshot({path:path.join(out,'game-pad-corner.png'),timeout:60000});
  const own=await page.evaluate(()=>{const a=NG.local,p=NG.level.spawnPads[a.team];a.spawnAt(p,Math.PI/2);NG.rig.yaw=Math.PI/2;NG.rig.pitch=-.2;return p.toArray();});
  const exit=await drive('allied-exit','KeyW',1.2);exit.pad=own;
  exit.distance=Math.hypot(exit.end[0]-own[0],exit.end[2]-own[2]);assert(exit.distance>4.6);write();
  const back=await drive('allied-reentry','KeyS',1.2);back.pad=own;
  back.distance=Math.hypot(back.end[0]-own[0],back.end[2]-own[2]);assert(back.distance<4.2);write();
  console.log('game respawn/launch');
  assert(await page.evaluate(()=>NG.game.input.locked),'live mouse input requires pointer lock');
  await page.evaluate(()=>{focusCapture={kind:'respawn-launch',start:NG.time,wallStart:performance.now(),until:Infinity,rows:[],done:false};NG.local.invuln=0;NG.local.splat(null,'fall');});
  await page.waitForFunction(()=>NG.local.alive&&NG.local.s3?.squidSpawn?.phase==='aim',null,{timeout:180000});
  const aim=await page.evaluate(()=>{NG.rig.yaw=0;NG.rig.pitch=-.8;return{pos:NG.local.pos.toArray(),time:NG.time};});
  await page.mouse.down({button:'left'});
  await page.waitForFunction(()=>NG.local.s3?.squidSpawn?.phase==='flight',null,{timeout:180000});
  await page.mouse.up({button:'left'});
  await page.waitForFunction(()=>!NG.local.s3?.squidSpawn&&NG.local.alive&&NG.local.grounded,null,{timeout:180000});
  const launch=await page.evaluate(()=>{focusCapture.done=true;return{...focusCapture,aim:null,land:{pos:NG.local.pos.toArray(),time:NG.time,alive:NG.local.alive,grounded:NG.local.grounded},drawCalls:NG.renderer.info.render.calls,frozen:NG.game.frozen,skipRender:!!NG.game._skipRender};});
  launch.aim=aim;receipt.gameCases.push(launch);write();assert(launch.rows.some(r=>r.phase==='aim')&&launch.rows.some(r=>r.phase==='flight'));assert(launch.rows.every(r=>r.fits));assert(!launch.frozen&&!launch.skipRender);
  await page.screenshot({path:path.join(out,'game-respawn-land.png'),timeout:60000});
  }
  if(!gameOnly){
  console.log('component natural fall: separate diagnostic');
  await page.evaluate(async()=>{
    NG.game?.debug.freeze();globalThis.focusCapture=null;
    const [{Actor},{Level},{Physics},{Character},THREE,{PLAYER}]=await Promise.all([
      import(new URL('src/game/actor.js',document.baseURI)),import(new URL('src/world/level.js',document.baseURI)),
      import(new URL('src/game/physics.js',document.baseURI)),import(new URL('src/game/character.js',document.baseURI)),import('three'),import(new URL('src/config.js',document.baseURI))]);
    globalThis.focusSaved={scene:NG.scene,level:NG.level,physics:NG.physics,paint:NG.paint,actors:NG.actors,match:NG.match,time:NG.time,fx:NG.fx,audio:NG.audio};
    NG.scene=new THREE.Scene();NG.level=new Level({bounds:{minX:-50,maxX:50,minZ:-50,maxZ:50},spawnPads:[[-20,0,0],[20,0,0]],spawnBarrier:4.2,half:[],single:[
      {kind:'box',min:[-50,-.5,-50],max:[50,0,50]},{kind:'box',min:[13,0,-2],max:[15.1,2.2,2]}]});
    NG.physics=new Physics(NG.level);NG.paint={sample:()=>1,splat:()=>0};NG.actors=[];NG.match={mode:'turf',playing:()=>true,canRespawn:()=>false};NG.time=0;NG.fx=NG.audio=null;
    const a=new Actor({team:0,name:'component natural fall',weapon:'shooter',CharacterClass:Character,style:{hair:0,skin:2,outfit:0,eyes:0}});
    a.character.actor=a;NG.scene.add(a.character.root);NG.actors=[a];a.character.setLod('hero');
    await a.character._sourceMotionLoader;if(a.character.sourceMotion?.ready)await a.character.sourceMotion.ready;
    a.spawnAt(new THREE.Vector3(15.39,20,0),0);a.grounded=false;a.vel.set(0,0,0);a.invuln=0;a.intent.move.set(1,0,0);
    globalThis.focusComponent={actor:a,player:PLAYER,rows:[],input:{start:[15.39,20,0],velocity:[0,0,0],move:[1,0,0],dt:1/60,steps:180},
      character:{name:a.character.constructor.name,children:a.character.root.children.length,sourceMotion:a.character.sourceMotion?.status||null}};
  });
  // Small CPU diagnostic chunks; no manual Game frames or large GPU batch.
  for(let chunk=0;chunk<18;chunk++)await page.evaluate(()=>{
    const c=focusComponent,a=c.actor,p=c.player;
    for(let i=0;i<10;i++){NG.time+=1/60;a.update(1/60);c.rows.push({index:c.rows.length,pos:a.pos.toArray(),vel:a.vel.toArray(),grounded:a.grounded,
      fits:NG.physics.bodyFits(a.pos,p.s3HumanoidTerrainRadiusRaw*p.s3TerrainDistanceScale,p.stepUp,p.height),
      legacyFits:NG.physics.bodyFits(a.pos,p.radius,p.stepUp,p.height)});}
  });
  const comp=await page.evaluate(()=>({kind:'browser-component-natural-fall',input:focusComponent.input,character:focusComponent.character,rows:focusComponent.rows,
    gamePresent:!!NG.game,gameFrozen:!!NG.game?.frozen,manualGameFrames:0,rendererUsed:false,stubs:['paint','audio','FX'],terrainRadius:focusComponent.player.s3HumanoidTerrainRadiusRaw*focusComponent.player.s3TerrainDistanceScale}));
  comp.invalidCount=comp.rows.filter(r=>!r.fits).length;comp.firstInvalid=comp.rows.find(r=>!r.fits)||null;
  receipt.componentCases.push(comp);write();
  if(baseline)assert(comp.invalidCount>0,'07a must retain the independently reported same-condition failure');else assert.equal(comp.invalidCount,0);
  await page.evaluate(()=>{focusComponent.actor.character.dispose();Object.assign(NG,focusSaved);});
  }
  await Promise.all([...pending]);
  assert.equal(receipt.errors.length,0);
  assert.equal(receipt.httpErrors.length,0,'HTTP resource failures must remain visible');
  const unavailable=receipt.responseErrors.filter(e=>e.error.includes('Request content was evicted from inspector cache'));
  const invalid=receipt.responseErrors.filter(e=>!unavailable.includes(e));
  assert.equal(invalid.length,0,'response identity mismatch or unexplained capture failure');
  receipt.unavailableResponseBodies=unavailable;
  for(const suffix of ['/src/game/actor.js','/patches/splatoon3/runtime/spawn-exclusion.mjs'])assert(receipt.responses.some(r=>r.file.endsWith(suffix)||r.file===suffix.slice(1)),'actual served runtime must be byte verified: '+suffix);
  receipt.identityAfter=await page.evaluate(async()=>{const m=await(await fetch(new URL('inkwave-build.json',document.baseURI))).json();return{inputHash:m.inputHash,contentHash:m.contentHash};});
  assert.equal(receipt.identityAfter.contentHash,identity.contentHash);
  receipt.status=unavailable.length?'passed-with-response-observation-limit':'passed';receipt.finishedAt=new Date().toISOString();write();console.log(receipt.status+' '+sha);
}catch(e){receipt.status='failed';receipt.error=e.stack;receipt.failureState=await page?.evaluate(()=>({mode:NG.mode,match:NG.match?.state,paused:NG.match?.paused,locked:NG.game?.input.locked,phase:NG.local?.s3?.squidSpawn?.phase,
  alive:NG.local?.alive,pos:NG.local?.pos.toArray(),mouse:NG.game?.input.mouse,capture:globalThis.focusCapture?{kind:focusCapture.kind,totalTicks:focusCapture.totalTicks,truncated:focusCapture.truncated,rows:focusCapture.rows}:null})).catch(()=>null);write();throw e;}
finally{await browser.close();await new Promise(r=>server.close(r));assert.equal(execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),before,'pinned checkout unchanged');}
