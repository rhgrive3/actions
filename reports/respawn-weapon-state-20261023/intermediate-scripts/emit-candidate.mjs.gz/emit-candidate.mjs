import fs from 'node:fs';import path from 'node:path';import {createHash} from 'node:crypto';
import {transform} from '/workspace/actions/node_modules/esbuild/lib/main.js';
import {candidateTransform} from './candidate-transform.mjs';
import {adaptBuildSource} from '/workspace/actions/scripts/inkwave-source-composition.mjs';
const root='/workspace/actions',out='/workspace/scratch/respawn-weapon-20261023/overlay-candidate';
const receipt=[];
for(const name of ['spawn-pose-motion','roller','roller-detail-motion','respawn-lifecycle']){
 const rel='patches/splatoon3/runtime/'+name+'.mjs',raw=fs.readFileSync(path.join(root,rel),'utf8');
 const candidate=candidateTransform(rel,raw),code=adaptBuildSource(rel,candidate);
 const emitted=(await transform(code,{loader:'js',format:'esm',minify:true,charset:'utf8',legalComments:'inline',sourcefile:rel})).code;
 fs.mkdirSync(path.dirname(path.join(out,rel)),{recursive:true});fs.writeFileSync(path.join(out,rel),emitted);
 receipt.push({rel,originalSha256:createHash('sha256').update(raw).digest('hex'),candidateSha256:createHash('sha256').update(candidate).digest('hex'),emittedSha256:createHash('sha256').update(emitted).digest('hex')});
}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({scope:'review-only emitted module overlay; not a normal candidate build or publishable source tree',files:receipt},null,2));
