import {sourceLoadedActorFixture} from '/workspace/actions/patches/splatoon3/tests/source-loaded-actor-fixture.mjs';
const f=await sourceLoadedActorFixture(), {G}=f;
const a=await f.make();a.setWeapon('roller');a.slot=0;G.match={mode:'turf',opts:{},state:'playing',playing:()=>true,canRespawn:()=>true};
const row=label=>{const c=a.character;return {label,phase:a.s3?.squidSpawn?.phase,alive:a.alive,intent:a.intent.fire,prev:a._prevIntent.fire,ground:a.grounded,form:a.form,rolling:a.weaponRunner.rolling,flick:a.weaponRunner.flick,firing:a.anim.firing,charge:a.weaponRunner.charge,ink:a.ink,paint:a.stats.turf,wRoll:c.wRoll,wFire:c.wFire,Tspawn:c.tr[f.CHARACTER_TIMERS.T_SPAWN],grip:c.P.slice(f.CHARACTER_CHANNELS.ANC,f.CHARACTER_CHANNELS.ANC+3),source:c.sourceMotion.debug?.state};};
for(let i=0;i<100;i++)f.tick(a);console.log(JSON.stringify(row('idle')));
a.splat(null);while(!a.alive)f.tick(a);console.log(JSON.stringify(row('respawn-aim')));
a.intent.fire=true;f.tick(a);a.intent.fire=false;console.log(JSON.stringify(row('launch')));
for(let i=0;i<155;i++){f.tick(a);if([48,58,59,60,61,65,70,80,100,130,154].includes(i))console.log(JSON.stringify(row('tick-'+i)));}
f.reset();
