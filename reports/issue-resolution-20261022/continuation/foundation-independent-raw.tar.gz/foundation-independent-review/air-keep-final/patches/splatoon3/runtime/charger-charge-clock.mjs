// Shared native Charger charge/keep kernel. Extracted from the installed
// source owner so receiver replay uses the same laws and record fields.
export function chargerChargeSeconds(w,beforeT,dt,fundedInk,grounded,fullInkBudget=false){
 const threshold=fullInkBudget?w.inkFull:w.inkMin;
 const low=fundedInk+1e-10<threshold;
 const fundedRate=low?(w.emptyChargeRate??1/3):1;
 const airRate=grounded?1:(w.airChargeRate??1/3);
 const minimum=w.minimumChargeTime??8/60;
 const earlyDt=Math.min(dt,Math.max(0,minimum-beforeT*Math.max(1e-10,w.chargeTime))/fundedRate);
 return earlyDt*fundedRate+(dt-earlyDt)*Math.min(fundedRate,airRate);
}
export function chargerKeepRecord(w,paid){return {charge:1,remaining:w.keepChargeTime,fireDelay:w.storedFireDelay||0,laserDelay:w.storedLaserDelay||0,resurfaced:false,paid:Math.max(paid||0,w.inkFull)};}
export function chargerKeepHidden(record,dt){record.remaining-=dt;record.resurfaced=false;return record.remaining>1e-10;}
export function chargerKeepResurface(record,w){record.remaining=w.keepChargeTime;record.fireDelay=w.storedFireDelay||0;record.laserDelay=w.storedLaserDelay||0;record.resurfaced=true;}
export function chargerKeepReady(record,dt){record.fireDelay=Math.max(0,(record.fireDelay||0)-dt);record.laserDelay=Math.max(0,(record.laserDelay||0)-dt);return record.fireDelay<=1e-10;}
