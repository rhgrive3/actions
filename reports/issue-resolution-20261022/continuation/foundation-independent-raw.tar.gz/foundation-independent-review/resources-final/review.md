# Final independent review: authority 064efa6a

The same existing 58 state regression cases passed again, with all nine recorded source/test hashes unchanged before/after execution. No new special inputs, source edits or GPU work were performed.

Native resources changes extract the existing low-ink recovery clause and the existing 19F interruption constant into the shared kernel. The finite/full-charge predicate and epsilon conditions remain equivalent.

Ordinary real-Actor input is unchanged from the previous measurement: charge14F/32F/63F, R5F, release R/ZR6F, real 20Hz producer. A read-only VM export measures the actual private receiver budget.

| Charge ticks | Owner gross paid | Receiver gross paid | Owner net spent | Receiver net spent |
| --- | ---: | ---: | ---: | ---: |
| 14 | 3.764423077 | 2.552884615 | 2.931089744 | 1.886217949 |
| 32 | 9.216346154 | 8.913461538 | 8.049679487 | 8.246794872 |
| 63 | 18.000000000 | 17.091346154 | 16.833333333 | 15.424679487 |

Owner ends at 72.185897436; receiver at 74.442307692, an upper difference of 2.256410256.

The incorrect 19F R-cancel refill lock is corrected to the source 5F Sub-busy gate and refill for only the unlocked part of each interval. The previous receiver was below the owner by 0.743590; the new receiver is above by 2.256410. Thus the refill rule improves, but absolute point-estimate equality does not. Lower-bound progressive payment still excludes unobserved capture endpoints. The receiver budget stays above the owner after each charge/cancel in this trace; a normal legal-shot denial was not established. Do not claim exact ink parity.

Evidence: snapshot.json, source-unchanged.json, authority-independent.log, summary.json, ../normal-ink/result-064efa.json and loaded-authority-064efa.mjs.
