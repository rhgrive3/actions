import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './review-fixture.mjs';
const f=await fixture({productionComposition:true,includeBoss:true});
const {G,THREE}=f;
const round=(n,p=1000)=>Math.round(n*p)/p;
function setup({x=0,z=8,wall=false,wallZ=4,wallHalf=.1,air=false,height=air?3:0,realOwner=false}={}){
 f.projectiles.clear();G.boss=null;G.time=0;f.clock.set(1000);
 const blocks=wall?[{id:0,solid:true,grate:false,center:new THREE.Vector3(0,1.5,wallZ),half:new THREE.Vector3(10,3,wallHalf),axes:[new THREE.Vector3(1,0,0),new THREE.Vector3(0,1,0),new THREE.Vector3(0,0,1)],faces:[-1,-1,-1,-1,-1,-1]}]:[];
 blocks.push({id:blocks.length,solid:true,grate:false,center:new THREE.Vector3(0,-.1,0),half:new THREE.Vector3(50,.1,50),axes:[new THREE.Vector3(1,0,0),new THREE.Vector3(0,1,0),new THREE.Vector3(0,0,1)],faces:[-1,-1,0,-1,-1,-1]});
 for(const b of blocks){b.aabbMin=b.center.clone().sub(b.half);b.aabbMax=b.center.clone().add(b.half);}
 G.level={blocks,faces:[{origin:new THREE.Vector3(),u:new THREE.Vector3(1,0,0),v:new THREE.Vector3(0,0,1)}],spawnPads:[{y:0},{y:0}],groundHeight:()=>0,queryBlocks(_a,_b,_c,_d,out){out.length=0;for(let i=0;i<blocks.length;i++)out.push(i);return out;}};
 G.physics=new f.Physics(G.level);G.paint={splat:()=>0,sample:()=>2};
 const nm=f.makeNetMatch(f.makeSession('me','me',[['me','Me'],['peer','Peer']]));
 class Display {constructor(){this.root=new THREE.Group();}trigger(){}setWeapon(){}setHurt(){}setVisible(v){this.root.visible=v;}update(){} _owner(){return null;}}
 const owner=realOwner?Object.assign(new f.Actor({team:1,weapon:'charger',CharacterClass:Display}),{nid:17,owner:'peer',remote:true}):f.makeActor({nid:17,owner:'peer',remote:true,team:1,roller:false});owner.weapon=f.WEAPONS.charger;owner.pos.set(0,height,0);owner.weaponRunner=new f.WeaponRunner(owner);
 const victim=f.makeActor({nid:7,owner:'me',remote:false,team:0,roller:false});victim.pos.set(x,height,z);victim.netLife=0;
 G.actors=[owner,victim];G.match=f.bind(nm,G.actors);
 const calls=[];const apply=f.projectiles.applyHit;f.projectiles.applyHit=(...args)=>{calls.push(args);return'accepted';};
 let packed;const producer=f.makeNetMatch(f.makeSession('peer','me',[['me','Me'],['peer','Peer']]));producer.byNid.set(17,owner);producer.s.tr.broadcast=msg=>{packed=msg.a.find(row=>row[0]===17);};G.netm=nm;
 const packet=(elapsed,charging,e=[],progress=elapsed,{squid=false,held=charging,grounded=!air,tick=Math.round(elapsed*60),sub=false}={})=>{
  const ts=round(1000+elapsed);f.clock.set(ts);G.time=tick/60;
  owner.remote=false;owner.form=squid?'squid':'kid';owner.grounded=grounded;owner.intent.fire=held;owner.intent.squid=squid;owner.intent.sub=sub;owner.weaponRunner.charging=charging;owner.weaponRunner.charge=charging?Math.min(1,progress):0;
  producer._sendTick();owner.remote=true;const row=packed;assert.equal(row.length,27);assert.equal(row[26][1]&1,held?1:0);assert.equal(row[26][2],round(owner.pos.y));
  nm.onMessage('peer',{k:'t',ts,u:tick,a:[row],l:{17:0},...(e.length?{e}:{}),r:2});
  return nm.peers.get('peer');
 };
 const event=(charge=1,start=0,seq=1)=>[round(1000+start+Math.max(.15,charge)),'ev','weapon:fire',{actor:{n:17},weapon:'charger',muzzle:[0,owner.pos.y+1.05,0],dir:[0,0,1],charge,full:charge===1,len:f.projectiles.chargerReach(charge)},Math.round((start+Math.max(.15,charge))*60),seq];
 const prepare=(charge=1,override={},start=0,seq=1)=>{
  const duration=Math.max(.15,charge);for(let t=0;t<duration-.0001;t+=.05)packet(round(start+t),true,[],t);
  const e=event(charge,start,seq);Object.assign(e[3],override);const p=packet(round(start+duration),false,[e]);p.tr=1000+start+duration;p.sim=Math.round((start+duration)*60);
  nm._playEvents();return p;
 };
 const hit=(damage=160,extra={})=>nm.onMessage('peer',{k:'hit',m:nm.cfg.id,a:17,v:7,l:0,h:1,seq:1,d:damage,w:'charger',...extra});
 const advance=(peer,n=8)=>{for(let i=0;i<n;i++){f.clock.advance(1/60);G.time+=1/60;peer.sim++;peer.tr=Math.min(peer.lastTs+.15,peer.tr+1/60);f.projectiles.update(1/60);}};
 return {nm,owner,victim,calls,packet,event,prepare,hit,advance,dispose(){nm.dispose();producer.dispose();f.projectiles.applyHit=apply;f.projectiles.clear();}};
}

const x=setup({realOwner:true});const a=x.owner;let tick=0;const trace=[];a.kidT=1;a.grounded=true;a.invuln=0;
function step(fire,sub){tick++;a.remote=false;a.intent.fire=fire;a.intent.sub=sub;G.time=tick/60;f.clock.set(1000+G.time);a.update(1/60);a.remote=true;
 if(tick%3===0)x.packet(tick/60,a.weaponRunner.charging,[],a.weaponRunner.charge,{held:fire,sub,tick});
}
try{
 for(const frames of [14,32,63]){
  const before={owner:a.ink,receiver:f.reviewReadBudget(x.nm,17)?.ink??100};
  for(let n=0;n<frames;n++)step(true,false);
  const charged={owner:a.ink,receiver:f.reviewReadBudget(x.nm,17),charge:a.weaponRunner.charge,sourcePaid:a.weaponRunner.s3ChargerSpent,tick};
  for(let n=0;n<5;n++)step(true,true);
  assert.equal(a.weaponRunner.charging,false,'normal native R cancels the live charge');
  for(let n=0;n<6;n++)step(false,false);
  const after={owner:a.ink,receiver:f.reviewReadBudget(x.nm,17),tick};
  trace.push({chargeFrames:frames,before,charged,after,ownerNetSpent:before.owner-after.owner,receiverNetSpent:before.receiver-after.receiver.ink});
 }
 console.log(JSON.stringify({scope:'Normal real Actor input: charge -> hold R 5 fixed frames -> release R/ZR for 6 frames; actual 20Hz _sendTick; read-only private state export appended in VM solely for measurement; no gameplay mutation',trace},null,2));
}finally{x.dispose();}
