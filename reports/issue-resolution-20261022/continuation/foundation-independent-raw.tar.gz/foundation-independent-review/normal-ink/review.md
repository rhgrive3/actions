# Normal Charger charge / R-cancel ink review

Source owner and receiver execute the real production-composed modules. The only diagnostic extension appends a read-only export of receiver-private ledger fields in an isolated VM copy of the fixture. No gameplay expression is changed. No repository file or GPU was changed by this review.

Operations: real Actor holds ZR for 14 / 32 / 63 fixed ticks, holds R for 5 ticks to cancel, then releases R/ZR for 6 ticks; actual native `_sendTick` is sampled at 20 Hz. Input sequence is ordinary gameplay.

Loaded authority SHA256: `22cbac4fb04066cceb2d66d22c76ed3f94c50058c710ec5f2934cf7381954970`.

| Charge ticks | Source gross paid | Receiver gross paid | Source net spend | Receiver net spend |
| --- | ---: | ---: | ---: | ---: |
| 14 | 3.764423077 | 2.552884615 | 2.931089744 | 2.552884615 |
| 32 | 9.216346154 | 8.913461538 | 8.049679487 | 8.913461538 |
| 63 | 18.000000000 | 17.091346154 | 16.833333333 | 17.091346154 |

Final owner ink 72.185897436; receiver-private ink 71.442307692. Difference 0.743589744.

The current receiver derives paid progress from a lower time bound excluding the first capture interval and the final noncharging interval. It no longer lets the owner charge scalar alone erase payment. Its underpayment versus actual owner at cancellation is therefore an interval/observation difference, not exact source payment parity.

The native source allows kid refill after the 5F Sub cancellation gate and during fresh-charge startup when its busy guard permits it. The receiver imposes an inkRecoverStop of 19F after progressive spending/cancellation, so it misses some legal source recovery in these samples. The two differences act in opposite directions and do not form a single fixed correction factor.

A previous run used the old snapshot-minus-.005 payment rule while source was changing; result.json is retained separately, without exact loaded-source attestation. result-latest.json and loaded-authority.mjs are the current measured pair. This review observed a numeric ledger difference; it did not establish a normal admitted-shot denial at a funding boundary.

Evidence: normal-ink.mjs, review-fixture.mjs, result-latest.json, loaded-authority.mjs, source-hashes.json.
