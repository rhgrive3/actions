import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from '/workspace/actions/patches/network-replication/tests/robustness-fixture.mjs';
const f=await fixture({productionComposition:true,includeBoss:true});
const {G,THREE}=f;
const round=(n,p=1000)=>Math.round(n*p)/p;
function setup({x=0,z=8,wall=false,wallZ=4,wallHalf=.1}={}){
 f.projectiles.clear();G.boss=null;G.time=0;f.clock.set(1000);
 const blocks=wall?[{id:0,solid:true,grate:false,center:new THREE.Vector3(0,1.5,wallZ),half:new THREE.Vector3(10,3,wallHalf),axes:[new THREE.Vector3(1,0,0),new THREE.Vector3(0,1,0),new THREE.Vector3(0,0,1)],faces:[-1,-1,-1,-1,-1,-1]}]:[];
 G.level={blocks,faces:[],spawnPads:[{y:0},{y:0}],groundHeight:()=>0,queryBlocks(_a,_b,_c,_d,out){out.length=0;for(let i=0;i<blocks.length;i++)out.push(i);return out;}};
 G.physics=new f.Physics(G.level);G.paint={splat:()=>0,sample:()=>2};
 const nm=f.makeNetMatch(f.makeSession('me','me',[['me','Me'],['peer','Peer']]));
 const owner=f.makeActor({nid:17,owner:'peer',remote:true,team:1,roller:false});owner.weapon=f.WEAPONS.charger;owner.pos.set(0,3,0);owner.weaponRunner.charge=0;
 const victim=f.makeActor({nid:7,owner:'me',remote:false,team:0,roller:false});victim.pos.set(x,3,z);victim.netLife=0;
 G.actors=[owner,victim];G.match=f.bind(nm,G.actors);
 const calls=[];const apply=f.projectiles.applyHit;f.projectiles.applyHit=(...args)=>{calls.push(args);return'accepted';};
 const packet=(elapsed,charging,e=[],progress=elapsed)=>{
  const ts=round(1000+elapsed);f.clock.set(ts);G.time=elapsed;
  const row=f.packActor(owner,{f:1+(charging?128:0)});row[14]=charging?Math.min(1,progress):0;
  nm.onMessage('peer',{k:'t',ts,u:Math.round(elapsed*60),a:[row],l:{17:0},...(e.length?{e}:{}),r:2});
  return nm.peers.get('peer');
 };
 const event=(charge=1,start=0,seq=1)=>[round(1000+start+Math.max(.15,charge)),'ev','weapon:fire',{actor:{n:17},weapon:'charger',muzzle:[0,4.05,0],dir:[0,0,1],charge,full:charge===1,len:f.projectiles.chargerReach(charge)},Math.round((start+Math.max(.15,charge))*60),seq];
 const prepare=(charge=1,override={},start=0,seq=1)=>{
  const duration=Math.max(.15,charge);for(let t=0;t<duration-.0001;t+=.05)packet(round(start+t),true,[],t);
  const e=event(charge,start,seq);Object.assign(e[3],override);const p=packet(round(start+duration),false,[e]);p.tr=1000+start+duration;p.sim=Math.round((start+duration)*60);
  nm._playEvents();return p;
 };
 const hit=(damage=160,extra={})=>nm.onMessage('peer',{k:'hit',m:nm.cfg.id,a:17,v:7,l:0,h:1,seq:1,d:damage,w:'charger',...extra});
 const advance=(peer,n=8)=>{for(let i=0;i<n;i++){f.clock.advance(1/60);G.time+=1/60;peer.sim++;peer.tr=Math.min(peer.lastTs+.15,peer.tr+1/60);f.projectiles.update(1/60);}};
 return {nm,owner,victim,calls,packet,event,prepare,hit,advance,dispose(){nm.dispose();f.projectiles.applyHit=apply;f.projectiles.clear();}};
}

test('independent: one second airborne charge cannot mint full-charge contact',()=>{
 const x=setup();try{const p=x.prepare(1);x.hit(160);x.advance(p);
  assert.equal(x.calls.length,0,'air rate is 1/3 after minimum: one second is not a full charge');
 }finally{x.dispose();}
});
