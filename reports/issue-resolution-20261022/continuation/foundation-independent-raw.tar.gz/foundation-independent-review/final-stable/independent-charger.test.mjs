import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from '/workspace/actions/patches/network-replication/tests/robustness-fixture.mjs';
const f=await fixture({productionComposition:true,includeBoss:true});
const {G,THREE}=f;
const round=(n,p=1000)=>Math.round(n*p)/p;
function setup({x=0,z=8,wall=false,wallZ=4,wallHalf=.1,air=false,height=air?3:0,realOwner=false}={}){
 f.projectiles.clear();G.boss=null;G.time=0;f.clock.set(1000);
 const blocks=wall?[{id:0,solid:true,grate:false,center:new THREE.Vector3(0,1.5,wallZ),half:new THREE.Vector3(10,3,wallHalf),axes:[new THREE.Vector3(1,0,0),new THREE.Vector3(0,1,0),new THREE.Vector3(0,0,1)],faces:[-1,-1,-1,-1,-1,-1]}]:[];
 blocks.push({id:blocks.length,solid:true,grate:false,center:new THREE.Vector3(0,-.1,0),half:new THREE.Vector3(50,.1,50),axes:[new THREE.Vector3(1,0,0),new THREE.Vector3(0,1,0),new THREE.Vector3(0,0,1)],faces:[-1,-1,0,-1,-1,-1]});
 for(const b of blocks){b.aabbMin=b.center.clone().sub(b.half);b.aabbMax=b.center.clone().add(b.half);}
 G.level={blocks,faces:[{origin:new THREE.Vector3(),u:new THREE.Vector3(1,0,0),v:new THREE.Vector3(0,0,1)}],spawnPads:[{y:0},{y:0}],groundHeight:()=>0,queryBlocks(_a,_b,_c,_d,out){out.length=0;for(let i=0;i<blocks.length;i++)out.push(i);return out;}};
 G.physics=new f.Physics(G.level);G.paint={splat:()=>0,sample:()=>2};
 const nm=f.makeNetMatch(f.makeSession('me','me',[['me','Me'],['peer','Peer']]));
 class Display {constructor(){this.root=new THREE.Group();}trigger(){}setWeapon(){}setHurt(){}setVisible(v){this.root.visible=v;}update(){} _owner(){return null;}}
 const owner=realOwner?Object.assign(new f.Actor({team:1,weapon:'charger',CharacterClass:Display}),{nid:17,owner:'peer',remote:true}):f.makeActor({nid:17,owner:'peer',remote:true,team:1,roller:false});owner.weapon=f.WEAPONS.charger;owner.pos.set(0,height,0);owner.weaponRunner=new f.WeaponRunner(owner);
 const victim=f.makeActor({nid:7,owner:'me',remote:false,team:0,roller:false});victim.pos.set(x,height,z);victim.netLife=0;
 G.actors=[owner,victim];G.match=f.bind(nm,G.actors);
 const calls=[];const apply=f.projectiles.applyHit;f.projectiles.applyHit=(...args)=>{calls.push(args);return'accepted';};
 let packed;const producer=f.makeNetMatch(f.makeSession('peer','me',[['me','Me'],['peer','Peer']]));producer.byNid.set(17,owner);producer.s.tr.broadcast=msg=>{packed=msg.a.find(row=>row[0]===17);};G.netm=nm;
 const packet=(elapsed,charging,e=[],progress=elapsed,{squid=false,held=charging,grounded=!air,tick=Math.round(elapsed*60),sub=false}={})=>{
  const ts=round(1000+elapsed);f.clock.set(ts);G.time=tick/60;
  owner.remote=false;owner.form=squid?'squid':'kid';owner.grounded=grounded;owner.intent.fire=held;owner.intent.squid=squid;owner.intent.sub=sub;owner.weaponRunner.charging=charging;owner.weaponRunner.charge=charging?Math.min(1,progress):0;
  producer._sendTick();owner.remote=true;const row=packed;assert.equal(row.length,27);assert.equal(row[26][1]&1,held?1:0);assert.equal(row[26][2],round(owner.pos.y));
  nm.onMessage('peer',{k:'t',ts,u:tick,a:[row],l:{17:0},...(e.length?{e}:{}),r:2});
  return nm.peers.get('peer');
 };
 const event=(charge=1,start=0,seq=1)=>[round(1000+start+Math.max(.15,charge)),'ev','weapon:fire',{actor:{n:17},weapon:'charger',muzzle:[0,owner.pos.y+1.05,0],dir:[0,0,1],charge,full:charge===1,len:f.projectiles.chargerReach(charge)},Math.round((start+Math.max(.15,charge))*60),seq];
 const prepare=(charge=1,override={},start=0,seq=1)=>{
  const duration=Math.max(.15,charge);for(let t=0;t<duration-.0001;t+=.05)packet(round(start+t),true,[],t);
  const e=event(charge,start,seq);Object.assign(e[3],override);const p=packet(round(start+duration),false,[e]);p.tr=1000+start+duration;p.sim=Math.round((start+duration)*60);
  nm._playEvents();return p;
 };
 const hit=(damage=160,extra={})=>nm.onMessage('peer',{k:'hit',m:nm.cfg.id,a:17,v:7,l:0,h:1,seq:1,d:damage,w:'charger',...extra});
 const advance=(peer,n=8)=>{for(let i=0;i<n;i++){f.clock.advance(1/60);G.time+=1/60;peer.sim++;peer.tr=Math.min(peer.lastTs+.15,peer.tr+1/60);f.projectiles.update(1/60);}};
 return {nm,owner,victim,calls,packet,event,prepare,hit,advance,dispose(){nm.dispose();producer.dispose();f.projectiles.applyHit=apply;f.projectiles.clear();}};
}
test('independent: forged maximum charge scalar cannot replace receiver duration',()=>{
 const x=setup();try{
  x.packet(0,true,[],1);const e=x.event(1);e[0]=1000.15;e[4]=9;
  const p=x.packet(.15,false,[e]);p.tr=1000.15;p.sim=9;x.nm._playEvents();x.hit();x.advance(p);
  assert.equal(f.projectiles._fidelityChargerFlights.length,0);assert.equal(x.calls.length,0);
 }finally{x.dispose();}
});
test('independent: malformed receipt cannot spend real collision capability',()=>{
 const x=setup();try{const p=x.prepare();x.advance(p);
  x.hit(160,{m:'other-match'});x.hit(160,{v:17});x.hit(160,{d:161});x.hit(160,{l:1});
  assert.equal(x.calls.length,0);x.hit();assert.equal(x.calls.length,1);x.hit(160,{h:2,seq:2});assert.equal(x.calls.length,1);
 }finally{x.dispose();}
});
test('independent: collision capability expires without renewing on forged receipt arrivals',()=>{
 const x=setup();try{const p=x.prepare();x.advance(p);f.clock.advance(1);G.time+=1;
  x.hit();assert.equal(x.calls.length,0);
 }finally{x.dispose();}
});
test('independent: replacement same-ID weapon object revokes old flight contact',()=>{
 const x=setup();try{const p=x.prepare();x.advance(p);x.owner.weapon={...x.owner.weapon};
  x.hit();assert.equal(x.calls.length,0);
 }finally{x.dispose();}
});
test('independent: sender-only clock advances cannot manufacture receiver charge duration',()=>{
 const x=setup();try{
  for(let i=0;i<21;i++){
   f.clock.set(1000);const row=f.packActor(x.owner,{f:1+16+(i<20?128:0)});row[14]=1;
   const e=x.event(1);x.nm.onMessage('peer',{k:'t',ts:1000+i*.05,u:i*3,a:[row],l:{17:0},...(i===20?{e:[e]}:{}),r:2});
  }
  const p=x.nm.peers.get('peer');p.tr=1001;p.sim=60;x.nm._playEvents();x.hit();x.advance(p);
  assert.equal(f.projectiles._fidelityChargerFlights.length,0);assert.equal(x.calls.length,0);
 }finally{x.dispose();}
});
