import { SOURCE_SHOT_PAINT_KIND, SOURCE_SPLASH_PAINT_KIND } from './source-shot-footprint.mjs';
import { CHARGER_FOOTPRINT } from './main-ink-footprints.mjs';
import { WORLD_UNITS_PER_SOURCE_UNIT } from './source-distance.mjs';
import { coherentMotionStart } from './actor-motion.mjs';
import { hurtboxRadius, hurtboxHeight } from './player-hurtbox.mjs';
import { capsuleEntry, sweptWorldHit } from './weapons-collision.mjs';
import { chargerDamage, chargerInkCost, isChargerFullCharge } from './weapons.mjs';
import { attachReceiverChargerFlight, recordReceiverChargerActor, recordReceiverChargerBoss } from '../../network-replication/charger-contact-authority.mjs';
// #961: linear authoritative charge reaches the legal minimum at 8/60.
// Paint and launch endpoints must share this coordinate; retaining the old
// 1/6 early-boost boundary would create a second plateau after frame 8.
// SplashPaintParam and PaintParam use the same source distance convention as
// flight/range/depth. Applying 0.2 only to width shrank the stripe fivefold.
export const CHARGER_PAINT_WORLD_WIDTH_SCALE = WORLD_UNITS_PER_SOURCE_UNIT;
export function chargerPaintWorldRadius(sourceWidth) {
  return Math.max(0, Number.isFinite(sourceWidth) ? sourceWidth * CHARGER_PAINT_WORLD_WIDTH_SCALE : 0);
}
export const CHARGER_FIRST_LEGAL_CHARGE = 8 / 60;
export function chargerPartialCharge(charge) {
  const c = Math.max(0, Math.min(1, Number.isFinite(charge) ? charge : 0));
  return c <= CHARGER_FIRST_LEGAL_CHARGE ? 0 : (c - CHARGER_FIRST_LEGAL_CHARGE) / (1 - CHARGER_FIRST_LEGAL_CHARGE);
}
// #514: range uses the same legal-minimum band as the paint coordinate above.
// The S3 charge-frame partial ratio is max(0,min(1,(F-MinF)/(FullF-MinF))):
// https://wikiwiki.jp/splatoon3mix/検証/メインウェポン (Charger 半チャージ割合)
// Range endpoints are the pinned 11.3.0 DistanceMinCharge/DistanceMaxCharge
// https://wikiwiki.jp/splatoon3mix/検証/パラメータ情報/メイン
// This implements that linear band as an explicit model; the source verifies
// the partial-charge ratio, while exact real-world muzzle-to-target geometry
// remains separately unverified.
// The authoritative linear charge is 8/60 after the first legal 8F release, so that
// value — not raw zero — anchors DistanceMinCharge: a legal 8F tap resolves to
// 9.033 instead of the interior 11.5337 the raw-charge lerp produced. Sub-law
// releases clamp to the lower endpoint and full charge keeps
// DistanceFullCharge. Aliases keep one band law shared by paint and range;
// damage (#506), launch speed, ink, laser sight and the 1-7F gate (#304) are
// separate coordinates and stay unchanged.
export const CHARGER_MIN_LEGAL_CHARGE = CHARGER_FIRST_LEGAL_CHARGE;
export const chargerRangeCharge = chargerPartialCharge;
// Linear interpolation of extracted endpoints; ellipse rasterization remains INKWAVE's.
export function chargerPaintParameters(raw,charge){
  const full=isChargerFullCharge(charge),q=chargerPartialCharge(charge);
  const value=(record,name)=>full?record[name+'FullCharge']:record[name+'MinCharge']+(record[name+'MaxCharge']-record[name+'MinCharge'])*q;
  const width=value(raw.SplashPaintParam,'WidthHalf'),depth=value(raw.SplashPaintParam,'DepthHalf');
  const onTop=value(raw.SplashSpawnParam,'OnTopRate');
  return {width,depth,impact:value(raw.PaintParam,'Radius'),nearest:raw.SplashPaintParam.RadiusSpawnNearest,
    onTop,interval:2*depth*(1-onTop)*Math.max(1,raw.SplashSpawnParam.SkipNum),
    terminalRate:1.5}; // community-reported omitted default, NOT an explicit pinned field
}
// Extracted minimum/max/full launch speeds remain independent endpoints.
export const CHARGER_MIN_CHARGE = CHARGER_FIRST_LEGAL_CHARGE;
export function chargerLaunchSpeed(raw, charge) {
  const q = Math.max(0, Math.min(1, (charge - CHARGER_MIN_CHARGE) / (1 - CHARGER_MIN_CHARGE)));
  return 60 * (raw.SpawnSpeedMinCharge + (raw.SpawnSpeedMaxCharge - raw.SpawnSpeedMinCharge) * q);
}
const INSTALLED=Symbol.for('inkwave.charger-flight.v1'),EPS=1e-10,SIM_DT=1/60;
// #1134: an actor may only enter the authoritative candidate set when its
// swept-capsule entry lies strictly before the nearest world/kit-defense stop.
// Keeping this as one predicate prevents a later refactor from reintroducing
// "damage every capsule on the full segment, then stop at the shield" ordering.
export function chargerActorBeforeStop(entryFraction, stepLength, stopDistance) {
  return entryFraction !== null && Number.isFinite(entryFraction) &&
    entryFraction * stepLength < stopDistance - EPS;
}
// #1098: ordinary-muzzle-relative retargeting from the independently measured
// S3 Charger Root/Muzzle joint (not from the keep anchor being transformed).
// Source: Models Resource asset 342258, Wmn_Charger_NormalT.dae, SHA-256
// 7914851c0cd0c1cf30970774b22362ae7e01969ed084c95d94ad87605c951626.
// Joint-local +Y up/+Z barrel forward; exporter scene rotation/"inch" label
// are not game-unit calibration. See the behavior report and extraction script.
// This is an INKWAVE rig retarget; Nintendo's keep-charge frame binding remains
// unverified. A model extract alone cannot prove runtime engine equivalence.
export const CHARGER_SOURCE_MODEL_MUZZLE = Object.freeze({ X: 0, Y: .1781852, Z: 1.717447 });
export function storedChargerModelMuzzle(source, modelMuzzle, out) {
  if (!source || !modelMuzzle || !out ||
      ![source.X, source.Y, source.Z, modelMuzzle.x, modelMuzzle.y, modelMuzzle.z].every(Number.isFinite) ||
      source.Z <= 0 || modelMuzzle.z <= 0) return false;
  const reference = CHARGER_SOURCE_MODEL_MUZZLE;
  const scale = modelMuzzle.z / reference.Z;
  out.set(modelMuzzle.x + (source.X - reference.X) * scale,
    modelMuzzle.y + (source.Y - reference.Y) * scale,
    modelMuzzle.z + (source.Z - reference.Z) * scale);
  return true;
}
// Finite straight flight. Source supplies endpoints and radii, not recovered engine
// interpolation code. Uses the existing weapon:fire packet; no new network fields.
export function installChargerFlight(api,completion) {
  const {Projectiles,WEAPONS,THREE,G,Hit,PLAYER,emit}=api,P=Projectiles.prototype;
  if(Object.hasOwn(P,INSTALLED))return;
  Object.defineProperty(P,INSTALLED,{value:true});
  const raw=completion.weapons.charger.MoveParam,collision=completion.weapons.charger.CollisionParam;
  const nativeGhost=P.ghostFire,nativeUpdate=P.update,nativeClear=P.clear;
  // Single source of the finite flight distance (world units); begin() and the HUD reach query share it.
  // #514: remap raw charge through the legal-minimum band so the first legal
  // 8F release (authoritative linear charge 8/60) lands on DistanceMinCharge exactly.
  const reachFor=charge=>{
    charge=Math.max(0,Math.min(1,Number.isFinite(charge)?charge:0));
    if(isChargerFullCharge(charge))return raw.DistanceFullCharge;
    const q=chargerRangeCharge(charge);
    return raw.DistanceMinCharge+(raw.DistanceMaxCharge-raw.DistanceMinCharge)*q;
  };
  P.chargerReach=function(charge){return reachFor(charge);};
  const feetDown=new THREE.Vector3(0,-1,0),feetFrom=new THREE.Vector3(),feetAt=new THREE.Vector3(),feetHit=new Hit();
  function feetSplash(actor,w){
    const radius=w.feetPaintRadius;
    if(!(radius>0)||!actor?.alive)return;
    feetFrom.set(actor.pos.x,actor.pos.y+.2,actor.pos.z);
    const h=G.physics.raycast(feetFrom,feetDown,3.5,feetHit,true);
    if(!h.hit)return;
    const area=G.paint.splat(feetAt.copy(h.point).addScaledVector(h.normal,.1),radius,actor.team,{seed:0,footprint:CHARGER_FOOTPRINT,kind:SOURCE_SPLASH_PAINT_KIND,claimOwner:actor});
    actor.addTurf(area);
  }
  function begin(system,actor,w,charge,origin,dir,ghost=false,maxDistance=null,fullState=null){
    charge=Math.max(0,Math.min(1,Number.isFinite(charge)?charge:0));
    const full=ghost&&typeof fullState==='boolean'?fullState:isChargerFullCharge(charge);
    // The native runner resets chargeT immediately after this synchronous release
    // call. Snapshot it here and keep it with the in-flight shot; `charge` stays
    // the same linear value used for range and launch speed.
    const chargeT=!ghost&&Number.isFinite(actor.weaponRunner?.chargeT)?actor.weaponRunner.chargeT:null;
    const damage=ghost?0:full?w.damageMax:chargerDamage({weaponRunner:{chargeT}},w,charge);
    const speed=full?60*raw.SpawnSpeedFullCharge:chargerLaunchSpeed(raw,charge);
    const canonicalReach=full?raw.DistanceFullCharge:raw.DistanceMinCharge+(raw.DistanceMaxCharge-raw.DistanceMinCharge)*chargerRangeCharge(charge);
    const distance=maxDistance??canonicalReach;
    const direction=dir.clone().normalize();
    if(!Number.isFinite(distance)||distance<=0||direction.lengthSq()<EPS)return;
    const job={owner:actor,team:actor.team,weapon:w,charge,chargeT,damage,full,speed,range:distance,travel:0,origin:origin.clone(),dir:direction,
      pos:origin.clone(),prev:origin.clone(),hit:new Hit(),base:new THREE.Vector3(),moved:new THREE.Vector3(),seen:new Set(),ghost,nextPaint:1.2,nearestPending:true,seed:Math.random(),paint:chargerPaintParameters(completion.weapons.charger,charge),beam:null};
    if(ghost){
      const legal=(w.minimumChargeTime??8/60)/(w.chargeTime||1);
      const damageAt=q=>chargerDamage({weaponRunner:{chargeT:q}},w,q);
      const low=Math.max(legal,charge-.0005),high=Math.min(1,charge+.0005);
      if(!attachReceiverChargerFlight(system,job,full?w.damageMax:damageAt(Math.max(legal,charge)),
        chargerInkCost(w,charge,Math.max(legal,charge)),canonicalReach,
        full?w.damageMax:damageAt(low),full?w.damageMax:damageAt(high)))return;
    }
    system._ghostBeam(actor,origin,direction,.0001,charge,false);
    job.beam=system.beams.at(-1);
    (system._fidelityChargerFlights||(system._fidelityChargerFlights=[])).push(job);
    if(!ghost){
      feetSplash(actor,w);
      if(actor.weaponRunner)actor.weaponRunner.s3ChargerPostShot=16/60;
      emit('weapon:fire',{actor,weapon:w.id,muzzle:origin.clone(),dir:direction.clone(),charge,full,len:distance});
      if(actor.isLocal)emit('recoil',{amount:.005+charge*.013});
      // #982: S3 Charger fires below 50% without shot vibration.
      // charge and chargeT now share the linear progression (formerly .5
      // at 7/15 progress). Haptics use the authoritative normalized clock.
      if(actor.isLocal && chargeT >= .5)G.input?.rumble?.(.12+charge*.45,.2+charge*.35,80+charge*90);
    }
    if(actor.isLocal||actor._nearCamera?.())G.audio?.play('shoot_charger',{pos:actor.isLocal?undefined:origin,volume:actor.isLocal ? .8 : .6,pitch:1.08-.16*charge});
  }
  const keepMuzzle = completion.weapons.charger.WeaponKeepChargeParam?.MuzzleLocalPos;
  // #1098's independent Wmn_Charger_NormalT-to-INKWAVE calibration was measured
  // against the native family geometry. Per-weapon replacement meshes can move
  // their visible muzzle without moving that existing kept-charge flight origin.
  // Ordinary shots still use the actual weapon model's muzzle.
  const keepCalibrationMuzzle = new THREE.Vector3(0, 0.058, 0.686);
  const keepBody = new THREE.Vector3();
  function resolveKeepOrigin(actor, out) {
    const gun = actor.character?.weapon;
    if (!gun?.off?.localToWorld ||
        !storedChargerModelMuzzle(keepMuzzle, keepCalibrationMuzzle, out)) return false;
    gun.off.localToWorld(out); // live hand pose, shared with ordinary gun muzzle
    keepBody.copy(actor.pos); keepBody.y += actor.form === 'squid' ? .4 : 1.05;
    // Keep the native geometry/finite-value muzzle guard; unsafe points fall
    // back to the ordinary muzzle instead of spawning through nearby cover.
    return Number.isFinite(out.x) && Number.isFinite(out.y) && Number.isFinite(out.z) &&
      out.distanceToSquared(keepBody) <= 2.5 && G.physics.los(keepBody, out);
  }
  P.fireCharger=function(actor,w,charge){
    const origin=this._muzzle(actor,new THREE.Vector3()).clone();
    if (actor.weaponRunner?.s3KeepMuzzleFiring) {
      const kept = new THREE.Vector3();
      if (resolveKeepOrigin(actor, kept)) origin.copy(kept);
    }
    const dir=this._aimFrom(actor,origin,new THREE.Vector3()).clone();
    begin(this,actor,w,charge,origin,dir);
  };
  P.ghostFire=function(actor,event){
    const w=WEAPONS[event.weapon]||actor.weapon;
    if(w.kind!=='charger')return nativeGhost.call(this,actor,event);
    const origin=new THREE.Vector3().copy(event.muzzle||actor.pos),dir=new THREE.Vector3().copy(event.dir||actor.aimDir);
    begin(this,actor,w,event.charge??0,origin,dir,true,event.len??null,event.full??null);
  };
  // Reuse one downward query/Hit for each native paint point. This does not
  // increase the ray count compared with the previous 3.5-unit probe.
  const paintPoint=new THREE.Vector3(),paintDown=new THREE.Vector3(0,-1,0),paintHit=new Hit(),paintTangent=new THREE.Vector3();
  function groundUnder(point) {
    // Stage platforms and jump arcs can be much higher than the old 3.5-unit
    // paint probe; search down to the level water plane, not an arbitrary gap.
    const limit=Math.max(3.5,Math.min(512,point.y-PLAYER.waterY+6));
    return G.physics.raycast(point,paintDown,limit,paintHit,true);
  }
  function postponePaint(system,job,from,hit,radius,seed) {
    // Pooling shares the live Projectiles renderer, keeping zero new draw calls.
    if(!system.chargerDrops)return; // gameplay paint is not limited by the 64 visible-instance reservation
    const drop=system.chargerDropPool.pop()||{
      pos:new THREE.Vector3(),start:new THREE.Vector3(),target:new THREE.Vector3(),
      normal:new THREE.Vector3(),direction:new THREE.Vector3()
    };
    drop.start.copy(from);drop.pos.copy(from);
    drop.landed=!!hit?.hit;
    if(drop.landed){drop.target.copy(hit.point);drop.normal.copy(hit.normal);drop.face=hit.face;}
    else{drop.target.copy(from).setY(PLAYER.waterY-1.8);drop.normal.set(0,1,0);drop.face=-1;}
    drop.direction.copy(job.dir).addScaledVector(drop.normal,-job.dir.dot(drop.normal));
    if(drop.direction.lengthSq()<1e-8)drop.direction.set(1,0,0);
    else drop.direction.normalize();
    const stretch=Math.max(0,job.paint.depth/radius-1)*1.6;
    drop.shift=radius*stretch*0.375;drop.stretchAmt=stretch;
    drop.age=0;drop.life=Math.max(0.05,Math.sqrt(Math.max(0,2*(from.y-drop.target.y)/20)));
    drop.radius=radius;drop.owner=job.owner;drop.team=job.team;drop.seed=seed;
    system.chargerDrops.push(drop);
  }
  function splatTravelPoint(system,job,at,radius,terminal=false){
    const h=groundUnder(at),seed=Math.random();
    if(h.hit&&h.dist<=3.5){
      if(!terminal&&beginChargerWallDrop(system,job,h,completion.weapons.charger,api,true))return 0;
      paintTangent.copy(job.dir).addScaledVector(h.normal,-job.dir.dot(h.normal));
      if(paintTangent.lengthSq()<1e-8)paintTangent.set(1,0,0);else paintTangent.normalize();
      // Match the packed source WidthHalf/DepthHalf ellipse in both immediate
      // and delayed paths. GPU footprint and CPU ownership share this centre.
      const stretch=Math.max(0,job.paint.depth/radius-1)*1.6;
      paintPoint.copy(h.point).addScaledVector(h.normal,.015)
        .addScaledVector(paintTangent,-radius*stretch*.375);
      return G.paint.splat(paintPoint,radius,job.team,
        {seed,footprint:CHARGER_FOOTPRINT,kind:SOURCE_SPLASH_PAINT_KIND,
         stretch:paintTangent,stretchAmt:stretch,claimOwner:job.owner});
    }
    // Airborne ink is not destroyed: it remains a pooled bead until actual
    // ground contact. A miss only expires after falling through the water plane.
    postponePaint(system,job,at,h,radius,seed);
    return 0;
  }
  function paintTravel(system,job,end){
    if(job.ghost)return;
    const paint=job.paint,interval=paint.interval;
    if(!(interval>EPS))return;
    let area=0;
    for(;job.nextPaint<end-.3;job.nextPaint+=interval){
      // RadiusSpawnNearest belongs to the separate feet mark, not the first
      // forward line sample. Using 1.2 here overpainted every tap and full shot.
      job.nearestPending=false;
      paintPoint.copy(job.origin).addScaledVector(job.dir,job.nextPaint);
      area+=splatTravelPoint(system,job,paintPoint,chargerPaintWorldRadius(paint.width));
    }
    job.owner.addTurf(area);
  }
  function step(system,job,dt){
    job.prev.copy(job.pos);
    const length=Math.min(job.speed*dt,Math.max(0,job.range-job.travel));
    job.pos.copy(job.prev).addScaledVector(job.dir,length);
    const world=sweptWorldHit(G.physics,job.prev,job.pos,collision.InitRadiusForField,collision.EndRadiusForField,job.hit,true);
    let distance=world.hit?world.dist:length,ended=world.hit,normal=world.hit?world.normal.clone():job.dir.clone().negate(),target=null;
    const defense=system.kitDefenseCandidate?.({owner:job.owner,team:job.team,prev:job.prev,pos:job.pos,vel:job.dir,damage:job.damage,type:'beam',size:0,ghost:job.ghost,full:!!job.full});
    if(defense&&(!world.hit||defense.distance<world.dist-EPS)){distance=defense.distance;ended=true;target='defense';normal=job.dir.clone().negate();}
    const boss=G.boss?.segHit(job.prev,job.pos,collision.InitRadiusForPlayer);
    if(boss&&boss.dist<distance-EPS){distance=boss.dist;ended=true;normal=job.dir.clone().negate();target='boss';}
    const actors=[];
    for(const actor of G.actors){
      // Partial rounds meet allied bodies; full rounds retain teammate piercing.
      if(!actor.alive||actor===job.owner||(job.full&&actor.team===job.team)||job.seen.has(actor))continue;
      // A live fixed-step beam and the target must share one contact time.
      // Historical ghost catch-up does not span the current actor snapshot.
      const motion=!job.ghost && Math.abs(dt-SIM_DT)<=EPS ? coherentMotionStart(actor) : null;
      let end=job.pos;
      if(motion){
        job.base.set(motion.x0,motion.y0,motion.z0);
        // A last range-clipped segment expires before the tick ends. Scale the
        // target interval by that same flight duration, never later movement.
        const fraction=Math.min(1,length/(job.speed*dt));
        job.moved.set(job.pos.x-(actor.pos.x-motion.x0)*fraction,job.pos.y-(actor.pos.y-motion.y0)*fraction,job.pos.z-(actor.pos.z-motion.z0)*fraction);
        end=job.moved;
      }else job.base.copy(actor.pos);
      const t=capsuleEntry(job.prev,end,job.base,hurtboxRadius(actor,PLAYER),hurtboxHeight(actor,PLAYER),
        collision.InitRadiusForPlayer,collision.EndRadiusForPlayer);
      if(chargerActorBeforeStop(t,length,distance))actors.push({actor,d:t*length});
    }
    actors.sort((a,b)=>a.d-b.d||String(a.actor.nid??a.actor.name).localeCompare(String(b.actor.nid??b.actor.name)));
    const amount=job.damage;
    for(const a of actors){
      job.seen.add(a.actor);if(!job.ghost&&a.actor.team!==job.team){
        const previous=job.owner._sourceChargerAudioHit;
        job.owner._sourceChargerAudioHit={chargerDirect:true,charge:job.charge};
        try{system.applyHit(job.owner,a.actor,amount,job.weapon.id);}
        finally{job.owner._sourceChargerAudioHit=previous;}
      }
      if(job.ghost)recordReceiverChargerActor(system,job,a.actor,performance.now()/1000);
      if(!job.full){distance=a.d;ended=true;target=a.actor;normal=job.dir.clone().negate();break;}
    }
    if(target==='boss'&&!job.ghost)G.boss.hit(job.owner,amount,boss.target,job.weapon.id,boss.point.clone());
    else if(target==='boss'&&job.ghost)recordReceiverChargerBoss(system,job,boss.target,performance.now()/1000);
    if(target==='defense')defense.onHit();
    job.pos.copy(job.prev).addScaledVector(job.dir,distance);job.travel+=distance;
    paintTravel(system,job,job.travel);
    if(job.beam){job.beam.mesh.scale.z=Math.max(.0001,job.travel);job.beam.mesh.material.uniforms.uLen.value=Math.max(.0001,job.travel);}
    ended=ended||job.travel+EPS>=job.range;
    if(ended){
      // Final trail stamp at the stopping point, never beyond an obstruction.
      if(!job.ghost && target!=='defense' && !(world.hit && !target)){
        job.owner.addTurf(splatTravelPoint(system,job,job.pos,chargerPaintWorldRadius(job.paint.width)*job.paint.terminalRate,true));
      }
      if(world.hit&&!target&&!job.ghost){
        if (!beginChargerWallDrop(system,job,world,completion.weapons.charger,api)) {
          const area=G.paint.splat(world.point.clone().addScaledVector(world.normal,.12),chargerPaintWorldRadius(job.paint.impact),job.team,
            {seed:Math.random(),footprint:CHARGER_FOOTPRINT,kind:SOURCE_SHOT_PAINT_KIND,stretch:job.dir,stretchAmt:.6,claimOwner:job.owner});job.owner.addTurf(area);
        }
        G.fx?.burst(world.point,world.normal,job.owner.color,{count:10,speed:4,size:.09,paint:false});
      }
      if(!job.ghost)emit('weapon:impact',{pos:job.pos.clone(),normal,team:job.team,kind:'charger',radius:chargerPaintWorldRadius(job.paint.impact),victim:target==='boss'||target==='defense'||target?.team===job.team?null:target});
    }
    return ended;
  }
  P.update=function(dt){
    // Match native Projectiles.update before this earlier-installed owner can
    // rewind/corrupt a live flight or run contact/paint side effects.
    if(!Number.isFinite(dt)||dt<=0)return;
    advanceChargerWallDrops(this,dt,api);
    const list=this._fidelityChargerFlights;
    if(list)for(let i=list.length-1;i>=0;i--){
      const job=list[i],beam=job.beam,peer=job.ghost&&beam?._netPeer;
      let ended=false;
      if(peer){
        const clock=Math.min(peer.tr,peer.lastTs??peer.tr);
        const target=Math.max(0,Math.floor((Number.isFinite(peer.sim)&&Number.isFinite(beam._netBornTick)
          ? peer.sim-beam._netBornTick : (clock-beam._netBorn)/SIM_DT)+.0306)+1);
        job._netSteps??=0;
        const maxSteps=Math.ceil(job.range/Math.max(EPS,job.speed*SIM_DT))+2;
        while(!ended&&job._netSteps<target&&job._netSteps<maxSteps){ended=step(this,job,SIM_DT);job._netSteps++;}
      }else ended=step(this,job,dt);
      if(ended)list.splice(i,1);
    }
    return nativeUpdate.call(this,dt);
  };
  P.clear=function(...args){this._s3ChargerWallDrops=[];this._fidelityChargerFlights=[];return nativeClear.apply(this,args);};
}

// #625: charge-dependent post-contact gameplay paint. Explicit endpoints come
// from pinned 11.3.0 WeaponChargerNormal. Missing movement defaults (30,15,10,
// gravity .008) come from XarrotD's original paramtable, not zero-filled JSON.
// Seeded inclusive phase selection, linear charge interpolation, 60Hz force
// integration and overlapping raster stamps are INKWAVE calibration; the
// Nintendo engine/PRNG and the omitted main Ground radius remain unverified.
const WALL_DROP_EPS=1e-9;
const defaults=Object.freeze({FallPeriodFirstFrameMax:30,FallPeriodLastFrameMin:15,FallPeriodSecondFrame:10,FreeGravityType:'value_0_008'});
const unit=(seed,salt)=>{let x=((seed*0x100000000)>>>0)^salt;x=Math.imul(x^(x>>>16),0x7feb352d);x=Math.imul(x^(x>>>15),0x846ca68b);return ((x^(x>>>16))>>>0)/0x100000000;};
export function chargerWallDropParameters(raw,charge,splash=false,seed=.5){
 const source=splash?raw.SplashWallHitParam:raw,move={...defaults,...source?.WallDropMoveParam},paint=source?.WallDropCollisionPaintParam;
 if(!paint)throw Error('Missing Charger wall paint source');
 const q=Math.max(0,Math.min(1,(charge-8/60)/(1-8/60)));
 const radius=name=>charge===1?paint[name]:paint[name+'MinCharge']+(paint[name+'MaxCharge']-paint[name+'MinCharge'])*q;
 const frames=(min,max,salt)=>min+Math.floor(unit(seed,salt)*(max-min+1));
 const gravity=/^value_(\d+)_(\d+)$/.exec(move.FreeGravityType);
 if(!gravity)throw Error('Unsupported Charger wall-drop gravity');
 const result={first:frames(move.FallPeriodFirstFrameMin,move.FallPeriodFirstFrameMax,625),second:move.FallPeriodSecondFrame,
  last:frames(move.FallPeriodLastFrameMin,move.FallPeriodLastFrameMax,626),
  firstSpeed:move.FallPeriodFirstTargetSpeed,secondSpeed:move.FallPeriodSecondTargetSpeed,
  gravity:Number(gravity[1]+'.'+gravity[2]),shock:radius('PaintRadiusShock'),fall:radius('PaintRadiusFall'),
  ground:Number.isFinite(paint.PaintRadiusGround)?paint.PaintRadiusGround:null};
 if(!Object.entries(result).every(([k,v])=>k==='ground'&&v===null||Number.isFinite(v)&&v>=0))throw Error('Invalid Charger wall-drop source');
 return result;
}
export function beginChargerWallDrop(system,job,hit,raw,api,splash=false){
 if(job.ghost||!hit?.hit||Math.abs(hit.normal.y)>=.55||hit.block?.grate)return false;
 const seed=Number.isFinite(job.seed)?job.seed:.5,plan=chargerWallDropParameters(raw,job.charge,splash,seed);
 const state={owner:job.owner,team:job.team,ghost:false,plan,seed,frame:0,carry:0,speed:0,paintIndex:0,
  pos:hit.point.clone().addScaledVector(hit.normal,.025),normal:hit.normal.clone(),face:hit.face,
  prev:new api.THREE.Vector3(),next:new api.THREE.Vector3(),point:new api.THREE.Vector3(),hit:new api.Hit(),paintCarry:0};
 (system._s3ChargerWallDrops||=[]).push(state);stamp(state,state.pos,plan.shock,api,state.face);return true;
}
function stamp(s,point,radius,api,face){
 if(s.ghost||!(radius>0))return;
 const opts={seed:unit(s.seed,++s.paintIndex),footprint:CHARGER_FOOTPRINT,kind:SOURCE_SPLASH_PAINT_KIND,claimOwner:s.owner};
 if(Number.isInteger(face)&&face>=0)opts.face=face;
 const area=api.G.paint.splat(point,radius,s.team,opts);if(Number.isFinite(area))s.owner?.addTurf?.(area);
}
export function advanceChargerWallDrops(system,dt,api){
 const list=system._s3ChargerWallDrops;if(!list?.length||!(dt>0))return;
 for(let i=list.length-1;i>=0;i--){const s=list[i],p=s.plan;let done=false;s.carry+=dt;
  while(s.carry+WALL_DROP_EPS>=1/60&&!done){s.carry=Math.max(0,s.carry-1/60);
   if(s.frame>=p.first+p.second+p.last){done=true;break;}
   s.speed=s.frame<p.first?p.firstSpeed:s.frame<p.first+p.second?p.secondSpeed:s.speed+p.gravity;
   s.prev.copy(s.pos);s.next.copy(s.pos);s.next.y-=s.speed;
   const h=api.G.physics.segment(s.prev,s.next,s.hit,true);
   if(h.hit){if(h.normal.y>.55)stamp(s,h.point.clone().addScaledVector(h.normal,.025),p.ground,api,h.face);done=true;break;}
   s.pos.copy(s.next);const distance=s.prev.distanceTo(s.pos),spacing=Math.max(.025,p.fall*.5);
   for(let cursor=spacing-s.paintCarry;cursor<=distance+WALL_DROP_EPS;cursor+=spacing){s.point.copy(s.prev).lerp(s.pos,Math.min(1,cursor/distance));stamp(s,s.point,p.fall,api,s.face);}
   s.paintCarry=(s.paintCarry+distance)%spacing;
   if(s.paintCarry< WALL_DROP_EPS || spacing-s.paintCarry<WALL_DROP_EPS)s.paintCarry=0;
   s.frame++;
  }
  if(done||s.frame>=p.first+p.second+p.last)list.splice(i,1);
 }
}
