# Independent final test-only migration review

Lab: /workspace/scratch/actions-charger-replay-lab. Read-only reviewer; no shared source/tests edited, no GPU, commit or remote operation. Official owner freeze is copied in owner-freeze.json. Independent hashing confirms all17runtime files,12migration tests and contract document match the declared final hashes (freeze-verification.json allUnchanged=true).

## Conclusion

No blocking finding in this strict fixture migration. It updates old fixtures to the unchanged runtime contract and retains earlier gameplay/cap/proof assertions. It does NOT make the optional native1/65 proof mandatory or close global #1665/#1666. Actual initial Turf spawn is explicitly unsupported, as the new negative now demonstrates.

Independent final focused validation has40 individual passing tests: metadata22 + actual dual-VM receiver16 + legacy/malformed adoption2. The first attempted adoption whole-file run under an explicitly small384MiB heap failed at module level with V8 out-of-memory before reporting individual tests; the other38 tests in that same command passed. That infrastructure failure is preserved in independent-focused.log and is not presented as an assertion regression or hidden by a pass-only receipt. Narrow adoption selectors were then run with768MiB/oneworker and both passed (5.62sec), with no source/test mutation or assertion change.

The owner's final single affected12-file run passed88/88 in135.364sec; its complete raw is copied as owner-unified-88.log and remains distinct from this reviewer's40 focused passes. All30 declared runtime/test/doc hashes were independently rechecked AFTER that run and remain unchanged (after-unified-freeze-verification.json). This is not a complete125-file rerun. The original865/839/26, initial fixture migration72/68/4, second corrected39/37/2 and final corrective26/26 raw remain distinct and preserved by the owner.

## Exact row/legacy boundary

- Current producer is asserted exactly27 in every formerly26 assertion. Helpers deep-equal all three slot26 elements against ['iw-input-body-1', actual fire|squid|sub|jump bits, r3(actual actor.pos.y)]. Array deep equality also fixes tuple length and excludes a fabricated default raw mask/Y. These are source producer witnesses, not a copy of received values.
- Existing22special counter,23adoption tag/life/state,24Surge-or-null,25hit-authority tag/life/revision/parent assertions remain. No >=width widening or sidecar deletion is proposed.
- The original22/23/24/25 positive legacy receive loop is retained and26 added. Exact position, HP/ink/special/life and adoption/hit fallbacks remain asserted. Legacy packets are not required to invent raw input/proof.
- New malformed-present-tuple test includes null, wrongtag, illegal bits16 and unsupported physical/display gap. It verifies zero actor samples after rejection, and a genuine next native timestamp restores a normal sample. It never strips an invalid present tuple and retries as legacy.
- Earlier same-ts recovery expectation was incorrect for this EXISTING two-stage admission: valid packet time/u can advance while one actor row is skipped. Frozen test explicitly asserts packet lastTs advances and tests the next genuine source packet. Native strict-monotonic owner-clock guard was not relaxed. Packet validity and actor-row validity remain distinct.

## Physical/render Y and old controls

The93 flight assertions now use slot26 canonical physical Y, verify the intentional nonzero display difference, actual receiver physicalY and separate display offset. The landing case is the zero-offset equality control, not a forced nonzero counterexample. Original target, remaining clock, gauge, armor, invulnerability, event/duplicate and native touchdown assertions remain. Independent pre-migration probe already demonstrated source6.653127555->physical6.653 versus display6.65 and offset−.003 at all30/60/120Hz. No position tolerance was widened. The owner's corrected93 full13 passed before freeze.

## Metadata strictness

The final cap fixture matches the reviewed draft: each new native/helper import is audited exactly once; capability regex, unique source anchors and hostile VM codeGeneration/timeout remain. Only the actual pure native selector is source-extracted and audited. Nine new capability helpers always throw and have individual rejection assertions. Two unconditional observation hooks accept only the actual no-installed-G no-op boundary; supplying G throws and is tested. No contact helper or selector is globally faked to permit a hit.

All original14 direct cap rows and5wrapper accepted/queue/proof-budget assertions remain, including161unrelated-main positive/proofUses1. That fixture is explicitly synthetic equipped catalogue metadata; it no longer incorrectly requests a native Charger contact. An added native route must hit the throwing contact stub. No real native authority is manufactured by metadata.

The prequeue fixture supplies the actual compiled Boss receipt method and exact sendBossHit boundary plus synthetic PLAYER installation symbol. Original14 payload positives/negatives, prequeue order, native missing/duplicate guards remain. New missing/duplicate Boss receipt negatives prove the final composition guard still fails closed. Production adapter/provenance/guard files are unchanged.

## Initial Turf negative: substantive limit

The first draft called beginInitialSquidSpawn AFTER bind, producing source life2 against enrolled life1. A read-only instrumented reproduction (opening-diagnostic.log) showed frames0,nextReceived1,reasonnull; it proved a life mismatch was ignored and did not test unsupported source execution.

Frozen setup initializes actual Turf Squid Spawn on BOTH source and remote actors before bind, with remote ownership set as in real Match construction. The negative asserts input/enrolled life equality, all3 frames accepted(nextReceived4), resource0/effective-null actual source rows, explicit Native input requires another action owner failure, retired replay/null, matched0, source still in aim, and normal actor snapshot buffers continuing on later packets without a fresh private budget. The branch now genuinely demonstrates that the new proof does not own the ordinary initial Turf lifecycle. The contract table states this limitation and distinguishes already-landed positive fixtures. No owner-pose re-enrollment or mandatory-gate bypass was added to make the test pass.

Commands:

```
node --max-old-space-size=384 --experimental-vm-modules --experimental-global-webcrypto --test --test-concurrency=1 patches/network-replication/tests/adoption-state.test.mjs patches/network-replication/tests/combat-pvp-cap-queue.metadata.test.mjs patches/network-replication/tests/hit-payload-prequeue.metadata.test.mjs patches/network-replication/tests/receiver-charger-input.test.mjs
node --max-old-space-size=768 --experimental-vm-modules --experimental-global-webcrypto --test --test-concurrency=1 --test-name-pattern='legacy actor row lengths|malformed present physical-body' patches/network-replication/tests/adoption-state.test.mjs
```

Frozen diff, copies, hashes and raw are adjacent. No global network-completion or browser/Nintendo parity claim is made.
