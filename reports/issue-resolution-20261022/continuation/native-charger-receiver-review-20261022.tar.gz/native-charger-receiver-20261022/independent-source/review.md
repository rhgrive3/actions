# Independent read-only Charger receiver/input replay review

Scope: root lab, native Splat Charger only, pinned Splatoon 3 11.3.0 comparison baseline. CPU/source verification; no GPU, browser, Switch parity, repository edits, commit or remote operation. This does not close #1665/#1666 or the remaining 64 main owners. The new proof remains optional evidence; production damage admission still uses charger-contact-authority.mjs capture ledger and actual finite-flight contact.

## Result

No blocking source finding in the frozen new input/proof connection within its declared boundary. Independent final suites pass 54/54: receiver actual dual-VM15 + real Worker quota4 (5.25sec combined); producer15 + private actual native replay20 (3.38sec combined). Eight runtime/integration/test files in snapshot.json remained byte-identical after verification; source-unchanged.json records all comparisons. No assertion was relaxed by this reviewer.

Before freeze, the original dual-VM suite passed13/14 and expected squid after only9 held-squid frames following a shot. Original failure log and snapshot remain in the parent directory. Re-running the saved original test with only a console witness confirms BOTH actual source Actor and receiver private Actor remain kid, with identical ink82.16666666666681, verified frame75 and reason=null. This is an incorrect fixture expectation inside the native post-shot gate, not evidence of a new receiver form mismatch. Final fixture waits24 frames and asserts source itself is squid and receiver agrees. Final15 includes missing-prefix idle TTL cleanup. See ../original-nine-frame-witness.log for the deliberately retained original failing expectation; it is not counted among final54passes. The intermediate same-tick-original-witness filename happened to capture the already corrected test during concurrent author editing and is superseded by this explicit saved-original witness.

## Trust and clock review

1. Enrollment captures position/velocity/yaw at NetMatch.bind after actor setup, before owner rows can mutate a channel. Actual startup constructs a new Match, runs Match._setupRoster, calculates spawn from stage pads/team/slot and calls spawnAt; NetSession/startNetMatch then binds the match. Incoming rows cannot enroll a missing actor/life, reinitialize the private driver or grant fresh100ink. The API relies on that trusted caller order; it is not a general late-join/resume bootstrap API.
2. observe requires the live session/match/world/physics/level identity, authenticated owner/member, exact actor/net/weapon/life and accepted packet physicsPoints(ts,u). Sidecar schema is validated at native _tick before timeline watermark changes. Gear is adopted through the installed equipment path and a subsequent gear-key transition closes this channel.
3. First time-dt sets only the simulation origin. Subsequent serials and exact dt/time continuity are checked; duplicate frames require identical retained history. Every executed dt is charged cumulatively against receiver now-boundAt with a fixed origin. Future packet.u, repeated accepted ticks or arbitrary initial owner G.time cannot prepay resources. The actual accepted-ahead test executes no frames at receiver t0, at most0.5sec by receiver t0.5, then legally catches up by1.2sec.
4. Explicit actor/frame/byte/history/step/birth/checkpoint bounds prevent unbounded retained input or per-call execution. Missing-prefix births expire during idle advance, not only when another source frame arrives. One channel cannot restart itself after a witness/gap failure.

## FIFO, proof and lifecycle review

- Source rows capture beforeSeq before the native Actor update and a global source frame order. Receiver advances before a FIFO event only when row.beforeSeq < eventSeq and frame tick is not after the event; after playback it permits rows whose beforeSeq is already committed. Same-owner paint therefore plays before subsequent resource/swim frames. The real source feet-paint test confirms this; delayed-input birth pairing remains bounded and does not block normal playback.
- Launches are obtained only from a private actual Actor executing installed Physics/updateResources/final WeaponRunner and native launch calculations. Owner charge/ink/body/grounded scalars are witnesses, not assignments. Co-forged full claim cannot elevate a real minimum-charge shot. R cancellation, exact per-frame14/32/63F ink traces, gear, low-ink recovery, keep31F, air/landing/movement and native sub debit pass the source/replay suite.
- Launch receipts are WeakMap-branded. Peeking is non-consuming; successful commit removes the underlying pending launch. Multiple wrappers/copies cannot reuse it. Receiver commits a matched receipt once; later same-event commit fails. A request failing comparison does not itself commit the launch. Actual terrain/capsule contact remains required by the existing production finite-flight authority.
- Every read/commit checks owner, exact actor/net/weapon/life plus world/match/session identity. Source clear generations and receiver clear wrapper revoke both sides; leave/host handoff/dispose close channels. Actual dual-VM tests revoke a previously live receipt on life, owner, clear, leave and host change; direct replay additionally tests weapon and retirement.
- Mandatory damage gate is intentionally not connected to peek/commitReceiverChargerBirth. There is no new claim that a matched input receipt alone authorizes damage, paint or turf. Existing production ledger resource residual therefore remains a documented limitation.

## Quota and incomplete contracts

Normal8 dense actual inputs at30/60/120Hz each transport all4800 source frames over200 packets in10seconds; peak142835 bytes/sec, no disconnect. The32actor defensive stress hits the unchanged relay limit with explicit1008 close and bounded producer state. This demonstrates the intended normal8 quota; it does not promise unlimited simultaneous native actors.

Still required before mandatory admission: cross-owner historical paint/world order and rollback; validated inter-frame knockback and Match post-Actor pushes; trusted SuperJump destination/lifecycle; source-earned special/turf credit, activation/refill and deployed support effects; transient/conditional equipment transitions; late join/respawn/migration trusted checkpoints and recovery after a closed channel. Receiver currently fails closed on unsupported body/equipment/action transitions while normal production playback remains active. Same-owner FIFO tests do not prove cross-owner causal world reconstruction. Native1/65 is an unpublished foundation, not completion of all65 main owners or global authority issues.

Raw commands used:

```
node --max-old-space-size=384 --experimental-vm-modules --experimental-global-webcrypto --test --test-concurrency=1 patches/network-replication/tests/receiver-charger-input.test.mjs patches/network-replication/tests/native-charger-relay-quota.test.mjs
node --max-old-space-size=384 --experimental-vm-modules --experimental-global-webcrypto --test --test-concurrency=1 patches/network-replication/tests/native-charger-input.test.mjs patches/network-replication/tests/native-charger-replay.test.mjs
```

Original/current snapshots and full raw output are adjacent. Repository sources were only read.
