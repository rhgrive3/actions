# Charger lab full-network failure review and strict test migration drafts

Read-only source review of /workspace/scratch/actions-charger-replay-lab. Shared source/tests were not edited. New draft patches/probes/raw are confined to this /tmp directory. No GPU or remote/commit operations.

## Complete initial run

125network test files yield865 tests,839pass,26fail,0skip,873.429sec. All26 final failures are enumerated in classification.json, without double-counting the progress and final summary entries. Original run and first-failure TAP hashes are recorded there.

| Category | Tests | Paths |
| --- | ---: | --- |
| Current producer still expected26 fields |21| adoption-state2,armor-ready-flags4,issue-1062-remote-squidroll1,issue-1088-surge-presentation2,issue-1110-superjump-epoch1,issue-953-slam-adoption9,roller-presentation1,roller-vertical-state1 |
| Physical flight expected old displayY |3| issue-93-squidspawn-handoff,30/60/120Hz |
| New dependency/compiled anchor metadata migration |2| combat-pvp-cap-queue.metadata,hit-payload-prequeue.metadata |

These are initial failure classifications, not a claim that replacing widths alone makes the complete run pass. All gameplay assertions downstream must still execute after migration.

## Row migration criteria

- Current producer must be EXACTLY27, not >=26/27 or a variable bound. Retain exact22special counter,23adoption tag/life,24Surge-or-null,25hit-authority tag/life/revision/parent assertions.
- Add exact slot26 array length3/tag iw-input-body-1/rawbits/physicalY. Derive expected bits from actual fire/squid/sub/jump source intent (0..15), and expected physicalY from r3(actor.pos.y), not row2 or smooth/render Y. Do not relax typed validation to accommodate old fixtures.
- Keep legacy22,23,24,25 positive receive paths and ADD26 to the loop. For all22–26 rows missing slot26 retain row2 physical fallback; verify no invented raw input, no reset ink or native launch capability. Preserve adoption/hit fallback assertions. Existing legacy behavior must not be deleted merely because the producer is27.
- Malformed present slot26 remains rejecting: wrong/null/nonarray tag, length2/4, bits<0/>15/fraction/NaN, nonfinite/out-of-range physicalY or physical/display separation beyond the shared native step allowance. Reject before actor/simulation watermark, then same-ts valid correction must recover. Do not strip malformed slot26 and retry it as legacy.

## Squid Spawn flight evidence

The old assertion expects packet.slice(1,7), including r2 displayY. Actual adapter intentionally unpacks canonical r3 physicalY from slot26 and carries display offset separately. The /tmp canonical probe retains ALL original flight, destination, remaining clock, gauge, armor, invulnerability, duplicate-event and native touchdown assertions, changes only expected physicalY, and ADDS exact tag/rawbits/r3 actual source validation plus explicit legacy-display inequality.

All3 cadence lanes pass6.98sec. Every lane sourceY6.653127555043441 -> physical6.653, old display6.65; receiver.pos.y6.653 and receiver._netDisplayYOffset−.003. Therefore position plus cosmetic offset still yields6.65. The old3 failures are display/physical unit-contract confusion. Migration should additionally retain render-root continuity and canonical collision/hurtbox checks; it must not loosen position tolerance or weaken landing/armor ownership.

## Metadata drafts

Temporary rebased copies pass22/22 in0.56sec. By the final check the owner had already applied both drafts to the lab; reverse --check confirms they match. This reviewer did not apply them. The rebased copy paths are test-only adaptation for /tmp; patch files contain repository-relative changes and preserve normal module URLs.

combat-pvp-cap-queue: audit each new Charger authority/input import exactly once, retain the capability regex and hostile VM options. Extract ONLY the actual pure receiverChargerRequired selector between unique source anchors; audit its source and test native true/catalog false. Every new native capability helper has an explicit throwing stub and assert. The two unconditional observer hooks permit ONLY the actual production no-installed-G no-op branch; any supplied G throws and is individually tested. No contact/receipt/proof helper returns a permissive success or global false selector.

All original14 direct cap rows and5wrapper cases retain exact accepted/queue/proofUses/cap assertions. The unrelated-main161positive remains, with its fixture explicitly declared a synthetic equipped catalogue main so it does not purport to mint a native Charger proof. A new native161 route proves it reaches the rejecting contact stub. This is metadata-only, not a new native authority or gameplay-value claim.

hit-payload-prequeue: supply the unchanged actual final compiled Boss receipt prefix plus exact sendBossHit boundary instead of weakening adapter identity checks. Synthetic PLAYER={} supplies the newly passed installation symbol; native runtime is never evaluated. Preserve original14 payload cases, prequeue ordering, missing/duplicate native guard negatives. Add missing/duplicate Boss guard negatives. No production adapter/guard mutation or permissive regex replacement is proposed.

Exact commands/raw/declarations are adjacent. combat_authority owns lab-only application after parent coordination and must rerun focused suites, then any required complete run against the updated test snapshot. The mandatory native1/65 gate and other incomplete contracts remain outside this fixture-only migration.
