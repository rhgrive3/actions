/workspace/scratch/actions-node22/node-v22.23.4-linux-x64/bin/node --experimental-vm-modules --test --test-concurrency=2 \
  patches/splatoon3/tests/special-zipcaster-ink-screen-contact.test.mjs \
  patches/splatoon3/tests/special-missile-tracking-hook-range.test.mjs \
  patches/splatoon3/tests/sub-community-behavior.test.mjs \
  patches/splatoon3/tests/curling-community-fidelity.test.mjs \
  patches/splatoon3/tests/catalogue-integration.test.mjs \
  patches/splatoon3/tests/tacticooler-gauge-lock.test.mjs \
  patches/splatoon3/tests/kit-trizooka-geometry.test.mjs \
  patches/splatoon3/tests/kit-trizooka-native.test.mjs \
  patches/splatoon3/tests/trizooka-birth-swim.test.mjs \
  patches/splatoon3/tests/special-zipcaster-armor.test.mjs \
  patches/splatoon3/tests/deployed-special-gauge-lock.test.mjs \
  patches/splatoon3/tests/burst-contact-phases.test.mjs \
  patches/local-quality/tests/tenacity.test.mjs \
  patches/splatoon3/tests/triple-splashdown-presentation.test.mjs
