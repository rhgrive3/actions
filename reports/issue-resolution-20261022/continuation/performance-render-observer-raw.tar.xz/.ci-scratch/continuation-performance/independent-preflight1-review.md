# GPU observer preflight integration review 1

Frozen harness `caa150372562eae8344987f179be05a68efb0d640b38e941b2b82774b94363f2`, helper `30eb15833dfb793815a3e1887c321142aeb96da61f9c2e1d643b12027cd3ac2f`. Snapshot: `preflight1/snapshot.json`. Read-only, no GPU; helper unchanged from 4/4 CPU run, so no repeat unit run.

Two integration findings were sent to the author:

1. page.evaluate has no encompassing finally. Tracker uninstall and resource disposal occur only after every assertion/fault control succeeds. The main finally calls actual.stop before probe.stop without nesting, so a failure in the former skips the latter. Add ownership-scoped outer finally and nested stops, then tracker uninstall, then dispose.
2. State snapshot excludes DEPTH_WRITEMASK and all 10 enables readDepth changes; direct compare-mode restoration is also not asserted. Add these gates before reporting complete exact GL state restoration.

Positive controls: original module served bytes are manifest-verified; tracker installed before Renderer; exact native/observed/restored pixels; hostile pack/unpack PBO+offset state; separate compile/link/query/creation faults; live temporary resource tracking; exact pixels after each fault; normal depth/mip/fallback/buffer input completeness. Node finally closes browser/server even if inner controls fail. These observations do not substitute for the author GPU run or fill the explicit RBO/blit content limits.
