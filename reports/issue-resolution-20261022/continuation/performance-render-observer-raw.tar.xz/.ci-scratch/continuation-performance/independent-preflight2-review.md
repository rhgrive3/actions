# GPU observer preflight integration review 2

Frozen harness `e5c8abf9538effe96d4fcaf30c90438139e81e54032f37f1e3954b599625ad71`, helper `30eb15833dfb793815a3e1887c321142aeb96da61f9c2e1d643b12027cd3ac2f`. Snapshot `preflight2/`. No GPU run, source edit, or repeated unchanged CPU unit run.

**The previous two integration findings are resolved.** Main observer stops are nested; page evaluation ownership finally stops outstanding actual/frame observers, uninstalls tracker, disposes renderer and loses context. Fault instance overrides have a separate restoration finally. State comparison now includes depth write mask and all 10 modified enables. Native/observed/restored exact pixel and four fault gates remain intact.

The fixture now validates raw sampler2D depth with compareFunction null. **Nonzero TEXTURE_COMPARE_MODE/sampler2DShadow restoration remains unverified**, and the author was asked to persist that limitation in its report (the frozen report object currently has no limitations field). RBO and unsampled blit contents remain unobserved. This review does not independently attest the author's GPU result.

Minor: browser console has duplicate identical listeners, causing duplicated logs only. Renderer constructor/setSize precede ownership try; full evaluation failure is still followed by Node browser/server cleanup.
