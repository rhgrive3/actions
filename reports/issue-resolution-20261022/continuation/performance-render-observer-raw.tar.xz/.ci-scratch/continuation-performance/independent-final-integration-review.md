# Final GPU observer integration delta review

Two-context harness SHA `1bc500b09db0a74b8e5d619582efc2c13d37bde131e40431687a45277e051f4b`; preflight SHA `36aab340a573b40a1bd4a4b7f61e581e61745491c9ffdb4b18355bdb549bc1f6`; helper SHA `30eb15833dfb793815a3e1887c321142aeb96da61f9c2e1d643b12027cd3ac2f`. Exact snapshots in `two-context2/`.

The final delta is accepted for the author's bounded diagnostic probe. Browser-close/PID-check/final-save failures become failed cleanupError and exit1; HTTP server closes in the surrounding finally. Preflight duplicate logging is removed and raw-depth/nonzero-shadow limitation is persisted. All earlier observer source and primary integration fixes are retained.

No GPU/browser run, source edits, or repeated unchanged CPU tests by reviewer. The helper CPU unit result remains 4/4 at exact source bytes. Actual GL result is the author's separate evidence.

Narrow remaining limitation: initial report save at line260 still occurs before protected terminal cleanup, so the code does not guarantee cleanup for every disk-write exception. Do not broaden the failure guarantee beyond the protected close/PID/final-save block. Shadow compare mode, RBO and unsampled blit inputs remain unverified/unobserved as stated in receipts.
