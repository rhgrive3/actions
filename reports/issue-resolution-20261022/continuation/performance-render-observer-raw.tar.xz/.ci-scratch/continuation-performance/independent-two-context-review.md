# Two-context GPU observer harness independent integration review

Frozen harness SHA `bb1f0f4e4d619db026136fa38657fe8475cf492aa1798f67bfaf7dc71c87a82d`, helper `30eb1583…`, HEAD `73abe7a…`. Snapshot `two-context/`. Read-only; GPU not executed and unchanged CPU tests not repeated.

Main final-frame actual.stop → gpu.stop → tracker.uninstall ordering is correct and nested. Per-context finally removes tracker and closes context. Verified source/artifact bytes remain separate from evaluated observer bytes. Chromium major151, 180s boot predicate, natural complete activated PWA, exact pixels and explicitly diagnostic/non-performance result are retained. Owned descendant PID/startTicks terminal checking is present.

One remaining failure-cleanup hole was sent to the author: Node finally lines259–263 sequences save → browser.close → PID exit check → save → HTTP server.close. If an earlier step throws, server.close is skipped and the live HTTP server can hold the failed process open. Put terminal server.close in an unconditional nested finally and record failed cleanup if possible.

GPU JSON inputs are recorded; automatic comparability remains workload/state/pixel only. RBO/unsampled blit/stencil/unsupported allocations stay unobserved. Raw-depth preflight does not validate nonzero shadow compare restoration. No full GPU-input equality or timing acceptance is established by this review.
