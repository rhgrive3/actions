import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const root=process.cwd(),site=path.join(root,'_site'),m=JSON.parse(fs.readFileSync(path.join(site,'inkwave-build.json')));
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const namespaces={'upstream/':'inkwave-public/','patch/':'patches/splatoon3/','touch-layout/':'patches/touch-layout/','reliability/':'patches/reliability/','local-quality/':'patches/local-quality/','network-replication/':'patches/network-replication/','loading-cache/':'patches/loading-cache/','practice-range/':'patches/practice-range/','native-stages/':'patches/native-stages/','build-script/':'scripts/'};
const sha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const tree=new Map(execFileSync('git',['ls-tree','-r','-z',sha],{encoding:'utf8'}).split('\0').filter(Boolean).map(row=>{const [meta,name]=row.split('\t');return[name,meta.split(' ')[2]];}));
for(const [file,expected]of Object.entries(m.files)){
 const prefix=Object.keys(namespaces).find(k=>file.startsWith(k));assert.ok(prefix,file);
 const name=namespaces[prefix]+file.slice(prefix.length),body=fs.readFileSync(path.join(root,name));assert.equal(hash(body),expected,name);
 const blob=crypto.createHash('sha1').update(`blob ${body.length}\0`).update(body).digest('hex');assert.equal(blob,tree.get(name),name+' committed');
}
for(const[file,expected]of Object.entries(m.artifacts))assert.equal(hash(fs.readFileSync(path.join(site,file))),expected,file);
assert.equal(hash(JSON.stringify(m.artifacts)),m.contentHash);
console.log(JSON.stringify({sourceCommit:sha,contentHash:m.contentHash,revision:m.build.revision,inputs:Object.keys(m.files).length,artifacts:Object.keys(m.artifacts).length,status:'passed'},null,2));
