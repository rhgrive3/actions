/*
 * Multi-finger taps for ordinary buttons.
 *
 * Browsers only synthesize `click` for a lone finger: while one thumb rests on the movement stick, tapping a hotbar
 * slot, the inventory button or anything else with a second finger produces pointer events but no click. This helper
 * watches touch pointers and, whenever a tap ends while other fingers are still down, fires the click itself.
 * Single-finger taps, mouse and keyboard are left entirely to the browser.
 */
const TAPPABLE = 'button, [role="button"], a[href], label, summary, select, input[type="checkbox"], input[type="radio"], input[type="range"]';
const MAX_MOVE = 18;       // px a finger may drift and still count as a tap
const MAX_PRESS = 700;     // ms

interface Press { el: HTMLElement; x: number; y: number; at: number; }

export function installMultiTouchTaps(root: Window = window): () => void {
  const touches = new Set<number>();
  const presses = new Map<number, Press>();
  let synthetic: { el: HTMLElement; at: number } | null = null;

  const down = (e: PointerEvent) => {
    if (e.pointerType !== 'touch') return;
    touches.add(e.pointerId);
    const el = (e.target as Element | null)?.closest?.(TAPPABLE) as HTMLElement | null;
    if (el) presses.set(e.pointerId, { el, x: e.clientX, y: e.clientY, at: e.timeStamp });
  };
  const up = (e: PointerEvent) => {
    if (e.pointerType !== 'touch') return;
    const others = touches.size - (touches.has(e.pointerId) ? 1 : 0);
    touches.delete(e.pointerId);
    const press = presses.get(e.pointerId);
    presses.delete(e.pointerId);
    if (!press || e.type === 'pointercancel' || others < 1) return;          // alone on the screen: the native click handles it
    if (Math.hypot(e.clientX - press.x, e.clientY - press.y) > MAX_MOVE || e.timeStamp - press.at > MAX_PRESS) return;
    const el = press.el;
    if (!el.isConnected || (el as HTMLButtonElement).disabled) return;
    synthetic = { el, at: performance.now() };
    el.click();
  };
  // If a browser does deliver its own click for that tap after all, swallow it so the action does not run twice.
  const click = (e: MouseEvent) => {
    if (!e.isTrusted || !synthetic) return;
    const recent = performance.now() - synthetic.at < 500, same = (e.target as Element | null)?.closest?.(TAPPABLE) === synthetic.el;
    synthetic = null;
    if (recent && same) { e.stopPropagation(); e.preventDefault(); }
  };
  const blur = () => { touches.clear(); presses.clear(); };

  const opts = { capture: true, passive: true } as const;
  root.addEventListener('pointerdown', down, opts);
  root.addEventListener('pointerup', up, opts);
  root.addEventListener('pointercancel', up, opts);
  root.addEventListener('click', click, true);
  root.addEventListener('blur', blur);
  return () => {
    root.removeEventListener('pointerdown', down, opts);
    root.removeEventListener('pointerup', up, opts);
    root.removeEventListener('pointercancel', up, opts);
    root.removeEventListener('click', click, true);
    root.removeEventListener('blur', blur);
  };
}
