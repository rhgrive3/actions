import { resolve } from './data';
import type { Stack } from './types';

/*
 * Vanilla NBT bridge (Java Edition 1.20.4, DataVersion 3700 — the last version before item components).
 *
 * The engine keeps light-weight runtime stacks ({ name, count, durability, ench, label }). Everything that leaves the
 * runtime — item stacks inside block entities, the ender chest, shulker box items, minecart inventories, the server
 * side ender chest table — is written in the exact vanilla layout:
 *
 *   Item:        { Slot: <byte>, id: "minecraft:<name>", Count: <byte>, tag: { ... } }
 *   tag.Damage / tag.RepairCost / tag.Enchantments[{ id, lvl }] / tag.StoredEnchantments (enchanted books)
 *   tag.display.Name (JSON text component) / tag.display.color (leather armour, decimal RGB)
 *   tag.BlockEntityTag.Items (shulker boxes)
 */
export const DATA_VERSION = 3700;
export const NS = 'minecraft:';

export interface NbtEnchantment { id: string; lvl: number; }
export interface NbtItemTag {
  Damage?: number;
  RepairCost?: number;
  Enchantments?: NbtEnchantment[];
  StoredEnchantments?: NbtEnchantment[];
  display?: { Name?: string; color?: number };
  BlockEntityTag?: { id?: string; Items?: NbtItem[] };
  Charged?: boolean;
}
export interface NbtItem { Slot?: number; id: string; Count: number; tag?: NbtItemTag; }

/** Internal enchantment ids that differ from the vanilla registry names. */
const ENCH_TO_VANILLA: Record<string, string> = { curse_of_binding: 'binding_curse', curse_of_vanishing: 'vanishing_curse', sweeping_edge: 'sweeping' };
const ENCH_FROM_VANILLA: Record<string, string> = Object.fromEntries(Object.entries(ENCH_TO_VANILLA).map(([k, v]) => [v, k]));

export const nsId = (name: string) => (name.includes(':') ? name : NS + name);
export const stripNs = (id: string) => (id.startsWith(NS) ? id.slice(NS.length) : id);
const clone = <T>(v: T): T => (v === undefined ? v : JSON.parse(JSON.stringify(v)));

/** Runtime stack -> vanilla item compound. */
export function stackToNbt(stack: Stack, slot?: number): NbtItem {
  const def = resolve(stack.name), tag: NbtItemTag = clone(stack.tag ?? {});
  if (stack.durability !== undefined && def?.durability) tag.Damage = Math.max(0, def.durability - stack.durability);
  if (stack.ench && Object.keys(stack.ench).length) {
    const list = Object.entries(stack.ench).map(([id, lvl]) => ({ id: NS + (ENCH_TO_VANILLA[id] ?? id), lvl }));
    if (stack.name === 'enchanted_book') tag.StoredEnchantments = list; else tag.Enchantments = list;
  }
  if (stack.label) tag.display = { ...(tag.display ?? {}), Name: JSON.stringify({ text: stack.label }) };
  if (stack.loaded) tag.Charged = true;
  const out: NbtItem = { id: nsId(stack.name), Count: Math.max(1, Math.min(127, Math.floor(stack.count))) };
  if (slot !== undefined) out.Slot = slot;
  if (Object.keys(tag).length) out.tag = tag;
  return slot !== undefined ? { Slot: slot, id: out.id, Count: out.Count, ...(out.tag ? { tag: out.tag } : {}) } : out;
}

/** Vanilla item compound -> runtime stack. Unknown items are kept by name so nothing is lost on a round trip. */
export function stackFromNbt(nbt: NbtItem): Stack {
  const name = stripNs(nbt.id), def = resolve(name), src = nbt.tag ?? {};
  const stack: Stack = { name, count: nbt.Count };
  const keep: NbtItemTag = {};
  if (src.Damage !== undefined && def?.durability) stack.durability = Math.max(0, def.durability - src.Damage);
  const list = src.Enchantments ?? src.StoredEnchantments;
  if (list?.length) stack.ench = Object.fromEntries(list.map(e => { const id = stripNs(e.id); return [ENCH_FROM_VANILLA[id] ?? id, e.lvl]; }));
  if (src.display?.Name) {
    try { const parsed = JSON.parse(src.display.Name); stack.label = typeof parsed === 'string' ? parsed : String(parsed?.text ?? ''); }
    catch { stack.label = src.display.Name; }
  }
  if (src.Charged) stack.loaded = true;
  if (src.RepairCost) keep.RepairCost = src.RepairCost;
  if (src.display?.color !== undefined) keep.display = { color: src.display.color };
  if (src.BlockEntityTag) keep.BlockEntityTag = clone(src.BlockEntityTag);
  if (Object.keys(keep).length) stack.tag = keep;
  return stack;
}

/** Container slots -> vanilla `Items` list (only occupied slots, each with its `Slot` byte). */
export function itemsToNbt(slots: readonly (Stack | null)[]): NbtItem[] {
  const out: NbtItem[] = [];
  slots.forEach((s, i) => { if (s && s.count > 0) out.push(stackToNbt(s, i)); });
  return out;
}

/** Vanilla `Items` list -> fixed-size slot array. Entries with an out-of-range or duplicate Slot are dropped. */
export function itemsFromNbt(list: readonly NbtItem[] | undefined, size: number): (Stack | null)[] {
  const slots: (Stack | null)[] = Array(size).fill(null);
  for (const it of list ?? []) {
    const slot = it.Slot ?? -1;
    if (!Number.isInteger(slot) || slot < 0 || slot >= size || slots[slot] || !it.id || !(it.Count > 0)) continue;
    slots[slot] = stackFromNbt(it);
  }
  return slots;
}

/** Shulker box item that keeps its contents: `tag.BlockEntityTag.Items`, exactly like a mined vanilla shulker box. */
export function shulkerItem(slots: readonly (Stack | null)[] | undefined, name = 'shulker_box'): Stack {
  const Items = itemsToNbt(slots ?? []);
  const stack: Stack = { name, count: 1 };
  if (Items.length) stack.tag = { BlockEntityTag: { id: NS + 'shulker_box', Items } };
  return stack;
}
export function shulkerContents(stack: Stack | null | undefined, size = 27): (Stack | null)[] | null {
  const items = stack?.tag?.BlockEntityTag?.Items;
  return items?.length ? itemsFromNbt(items, size) : null;
}

/** Vanilla stores entity UUIDs as four signed 32-bit ints (most significant first). */
export function uuidToIntArray(uuid: string): [number, number, number, number] {
  const hex = uuid.replace(/-/g, '').padEnd(32, '0').slice(0, 32);
  return [0, 8, 16, 24].map(i => parseInt(hex.slice(i, i + 8), 16) | 0) as [number, number, number, number];
}
export function intArrayToUuid(ints: readonly number[]): string {
  const hex = ints.map(n => (n >>> 0).toString(16).padStart(8, '0')).join('');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
export const isUuid = (s: unknown): s is string => typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);

// ---- Anvil prior-work penalty ------------------------------------------------------------------------------------------
/** Penalty after `uses` anvil operations: 2^n - 1 (0, 1, 3, 7, 15, 31, ...). This is the value stored in `RepairCost`. */
export const priorWorkPenalty = (uses: number) => 2 ** Math.max(0, Math.floor(uses)) - 1;
export const repairCostOf = (s: Stack | null | undefined) => s?.tag?.RepairCost ?? 0;
/** Number of anvil operations an item has been through (inverse of priorWorkPenalty). */
export const anvilUses = (s: Stack | null | undefined) => Math.round(Math.log2(repairCostOf(s) + 1));
export const nextRepairCost = (cost: number) => cost * 2 + 1;
/** Survival anvils refuse any operation costing 40 levels or more ("Too Expensive!"). */
export const ANVIL_LEVEL_CAP = 40;

// ---- Leather dyeing ----------------------------------------------------------------------------------------------------
/** Vanilla DyeColor texture-diffuse colours (decimal RGB as stored in `display.color`). */
export const DYE_RGB: Record<string, number> = {
  white: 0xf9fffe, orange: 0xf9801d, magenta: 0xc74ebd, light_blue: 0x3ab3da, yellow: 0xfed83d, lime: 0x80c71f, pink: 0xf38baa, gray: 0x474f52,
  light_gray: 0x9d9d97, cyan: 0x169c9c, purple: 0x8932b8, blue: 0x3c44aa, brown: 0x835432, green: 0x5e7c16, red: 0xb02e26, black: 0x1d1d21,
};
/** DyeableItem.blendAndSetColor: averages the channels, then rescales to the average of the brightest channels. */
export function blendDyeColors(existing: number | undefined, dyes: readonly number[]): number {
  const sum = [0, 0, 0];
  let maxSum = 0, n = 0;
  const add = (rgb: number) => {
    const r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
    maxSum += Math.max(r, g, b); sum[0] += r; sum[1] += g; sum[2] += b; n++;
  };
  if (existing !== undefined) add(existing);
  for (const d of dyes) add(d);
  if (!n) return existing ?? 0;
  let r = Math.floor(sum[0] / n), g = Math.floor(sum[1] / n), b = Math.floor(sum[2] / n);
  const avgMax = maxSum / n, max = Math.max(r, g, b);
  if (max > 0) { r = Math.floor(r * avgMax / max); g = Math.floor(g * avgMax / max); b = Math.floor(b * avgMax / max); }
  return (r << 16) | (g << 8) | b;
}
