// Blocks and items for the 1.21 (Tricky Trials) update, archaeology, armor trims, beacons / conduits and the mob-behaviour pass.
// Registered from the *end* of content.ts (not as a side-effect import) so that every pre-existing block keeps its numeric id
// and old saves stay valid.
import { block, item } from './data';

export const SHERD_NAMES: [string, string][] = [
  ['angler', '釣り人'], ['archer', '射手'], ['arms_up', '両手上げ'], ['blade', '刃'], ['brewer', '醸造家'], ['burn', '炎'], ['danger', '危険'],
  ['explorer', '探検家'], ['flow', '流れ'], ['friend', '友達'], ['guster', '突風'], ['heart', 'ハート'], ['heartbreak', '失恋'], ['howl', '遠吠え'],
  ['miner', '鉱夫'], ['mourner', '哀悼者'], ['plenty', '豊穣'], ['prize', '褒美'], ['scrape', '削り'], ['sheaf', '束'], ['shelter', '避難所'],
  ['skull', '頭蓋骨'], ['snort', '鼻息'],
];
/** The 16 armor trim patterns (1.20 set). */
export const TRIM_PATTERN_NAMES: [string, string][] = [
  ['sentry', '歩哨'], ['dune', '砂丘'], ['coast', '沿岸'], ['wild', '野生'], ['ward', '監守'], ['eye', '目'], ['vex', 'ヴェックス'], ['tide', '潮流'],
  ['snout', '鼻'], ['rib', '肋骨'], ['spire', '尖塔'], ['wayfinder', '道探し'], ['shaper', '整形'], ['silence', '静寂'], ['raiser', '育成'], ['host', '主'],
];
export const templateItem = (pattern: string) => `${pattern}_armor_trim_smithing_template`;
export const sherdItem = (name: string) => `${name}_pottery_sherd`;
export const EXPLORER_MAP_ITEMS = ['ocean_explorer_map', 'woodland_explorer_map', 'buried_treasure_map', 'trial_explorer_map'];

let done = false;
export function registerContent121() {
  if (done) return;
  done = true;
  const pick = { tool: 'pickaxe', tier: 1 };

  // ---- Trial chambers palette: tuff + copper -------------------------------------------------------------------------
  block('tuff_bricks', '凝灰岩レンガ', '#6f7168', 'bricks', 1.5, pick);
  block('polished_tuff', '磨かれた凝灰岩', '#7b7d73', 'stone', 1.5, pick);
  block('chiseled_tuff', '模様入りの凝灰岩', '#676960', 'stone', 1.5, pick);
  block('chiseled_tuff_bricks', '模様入りの凝灰岩レンガ', '#74766c', 'bricks', 1.5, pick);
  block('chiseled_copper', '模様入りの銅', '#c06c4f', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('copper_grate', '銅の格子', '#c8714f', 'glass', 3, { tool: 'pickaxe', tier: 2, transparent: true });
  block('exposed_copper', '風化した銅', '#a17e68', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('weathered_copper', '錆びた銅', '#6c996f', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('oxidized_copper', '酸化した銅', '#52a384', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('oxidized_cut_copper', '酸化した切り込み入りの銅', '#4f997f', 'bricks', 3, { tool: 'pickaxe', tier: 2 });
  block('oxidized_chiseled_copper', '酸化した模様入りの銅', '#53a68a', 'metal', 3, { tool: 'pickaxe', tier: 2 });

  // ---- Trial spawner & vault (state lives in systems/trials.ts, the cell state is the visual phase) -------------------
  block('trial_spawner', 'トライアルスポナー', '#4a5d6a', 'deepslate', 50, { tool: 'pickaxe', tier: 1, light: 4, category: 'utility' });
  block('vault', '宝物庫', '#3f5560', 'deepslate', 50, { tool: 'pickaxe', tier: 1, light: 6, category: 'utility' });
  block('ominous_vault', '不吉な宝物庫', '#3f4f78', 'deepslate', 50, { tool: 'pickaxe', tier: 1, light: 6, category: 'utility' });

  // ---- Beacon / conduit ----------------------------------------------------------------------------------------------
  block('beacon', 'ビーコン', '#7fe3e0', 'glass', 3, { tool: 'pickaxe', transparent: true, light: 15, category: 'utility' });
  block('conduit', 'コンジット', '#a98f6a', 'prismarine', 3, { transparent: true, light: 15, category: 'utility' });

  // ---- Archaeology ---------------------------------------------------------------------------------------------------
  block('suspicious_sand', '怪しげな砂', '#d9cb92', 'sand', 0.25, { tool: 'shovel', drop: '', transparent: true, category: 'nature' });
  block('suspicious_gravel', '怪しげな砂利', '#948c85', 'gravel', 0.25, { tool: 'shovel', drop: '', transparent: true, category: 'nature' });
  block('decorated_pot', '飾り壺', '#8e4f3a', 'terracotta', 0, { tool: 'pickaxe', transparent: true, category: 'decorations' });

  // ---- Mob-behaviour blocks ------------------------------------------------------------------------------------------
  block('bee_nest', 'ミツバチの巣', '#d9b444', 'sponge', 0.3, { tool: 'axe', category: 'nature' });
  block('beehive', '養蜂箱', '#b8904f', 'planks', 0.6, { tool: 'axe', category: 'utility' });
  block('turtle_egg', 'カメの卵', '#e6e3cf', 'quartz', 0.5, { transparent: true, category: 'nature' });
  block('skeleton_skull', 'スケルトンの頭蓋骨', '#c9c9c0', 'wool', 1, { category: 'decorations' });
  block('zombie_head', 'ゾンビの頭', '#4f7a43', 'wool', 1, { category: 'decorations' });
  block('creeper_head', 'クリーパーの頭', '#5fae4f', 'wool', 1, { category: 'decorations' });
  block('wither_skeleton_skull', 'ウィザースケルトンの頭蓋骨', '#2f2f2f', 'wool', 1, { category: 'decorations' });
  block('piglin_head', 'ピグリンの頭', '#e0a07a', 'wool', 1, { category: 'decorations' });

  // ---- Items ---------------------------------------------------------------------------------------------------------
  item('trial_key', 'トライアルキー', '#c9834f', 'tool', { category: 'tools' });
  item('ominous_trial_key', '不吉なトライアルキー', '#4f6ac9', 'tool', { category: 'tools' });
  item('ominous_bottle', '不吉な瓶', '#3d4f8a', 'misc', { category: 'food' });
  item('brush', 'ブラシ', '#b88a5a', 'tool', { durability: 64, stack: 1, category: 'tools' });
  item('armadillo_scute', 'アルマジロの鱗甲', '#b07a6a', 'misc', { category: 'materials' });
  item('wolf_armor', 'オオカミの鎧', '#b88a7a', 'tool', { durability: 64, stack: 1, category: 'tools' });
  item('torchflower_seeds', 'トーチフラワーの種', '#d98a3a', 'misc', { category: 'materials' });
  item('pitcher_pod', 'ウツボカズラのさや', '#5a9a8a', 'misc', { category: 'materials' });
  item('ocean_explorer_map', '海洋探検家の地図', '#6fa8c9', 'misc', { stack: 1, category: 'tools' });
  item('woodland_explorer_map', '森林探検家の地図', '#7a9a5a', 'misc', { stack: 1, category: 'tools' });
  item('buried_treasure_map', '埋もれた宝の地図', '#d9c27a', 'misc', { stack: 1, category: 'tools' });
  item('trial_explorer_map', '試練の探検家の地図', '#c9834f', 'misc', { stack: 1, category: 'tools' });
  for (const [name, ja] of SHERD_NAMES) item(sherdItem(name), `${ja}の壺の欠片`, '#9a5a3f', 'misc', { category: 'materials' });
  for (const [name, ja] of TRIM_PATTERN_NAMES) item(templateItem(name), `鍛冶型（${ja}の装飾）`, '#7ad0c0', 'misc', { category: 'materials' });

  // ---- Record 018: Copper variants, Lightning Rod, Respawn Anchor, Lodestone, Amethyst Geode, Trapped Chest, Bundle, Goat Horn ----
  block('exposed_cut_copper', '風化した切り込み入りの銅', '#9c7b65', 'bricks', 3, { tool: 'pickaxe', tier: 2 });
  block('weathered_cut_copper', '錆びた切り込み入りの銅', '#68946b', 'bricks', 3, { tool: 'pickaxe', tier: 2 });
  block('exposed_chiseled_copper', '風化した模様入りの銅', '#a07d67', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('weathered_chiseled_copper', '錆びた模様入りの銅', '#6a976d', 'metal', 3, { tool: 'pickaxe', tier: 2 });
  block('lightning_rod', '避雷針', '#c46f4e', 'metal', 3, { tool: 'pickaxe', tier: 2, shape: 'end_rod', transparent: true, category: 'redstone' });
  block('respawn_anchor', 'リスポーンアンカー', '#2f2147', 'obsidian', 50, { tool: 'pickaxe', tier: 4, light: 7, category: 'utility' });
  block('lodestone', 'ロードストーン', '#7c7e82', 'stone', 3.5, { tool: 'pickaxe', tier: 1, category: 'utility' });
  block('budding_amethyst', '芽生えたアメジスト', '#8f68b5', 'amethyst', 1.5, { tool: 'pickaxe', drop: '', category: 'nature' });
  block('small_amethyst_bud', '小さなアメジストの芽', '#a67ff0', 'amethyst', 1.5, { tool: 'pickaxe', solid: false, transparent: true, shape: 'cross', light: 1, drop: '', category: 'nature' });
  block('medium_amethyst_bud', '中くらいのアメジストの芽', '#ad85f5', 'amethyst', 1.5, { tool: 'pickaxe', solid: false, transparent: true, shape: 'cross', light: 2, drop: '', category: 'nature' });
  block('large_amethyst_bud', '大きなアメジストの芽', '#b68dfa', 'amethyst', 1.5, { tool: 'pickaxe', solid: false, transparent: true, shape: 'cross', light: 4, drop: '', category: 'nature' });
  block('amethyst_cluster', 'アメジストの塊', '#c197ff', 'amethyst', 1.5, { tool: 'pickaxe', solid: false, transparent: true, shape: 'cross', light: 5, drop: 'amethyst_shard', category: 'nature' });
  block('trapped_chest', 'トラップチェスト', '#b8823c', 'chest', 2.5, { tool: 'axe', shape: 'chest', transparent: true, category: 'redstone' });
  block('carved_pumpkin', 'くり抜いたカボチャ', '#c97b28', 'bark', 1, { tool: 'axe', category: 'nature' });
  item('bundle', 'バンドル', '#a87045', 'misc', { stack: 1, category: 'tools' });
  item('goat_horn', 'ヤギの角笛', '#8c7d6a', 'tool', { stack: 1, category: 'tools' });
  item('quartz', 'ネザークォーツ', '#eae5de', 'gem', { category: 'materials' });
}
