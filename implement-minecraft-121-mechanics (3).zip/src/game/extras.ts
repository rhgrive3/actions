// Items / blocks added for the Java-Edition parity pass: glass bottle, dragon's breath, jukebox and the music discs.
import { block, item } from './data';

export const MUSIC_DISCS: { name: string; ja: string; color: string; label: string }[] = [
  { name: 'music_disc_13', ja: 'ミュージックディスク (13)', color: '#c9a63a', label: '13' },
  { name: 'music_disc_cat', ja: 'ミュージックディスク (cat)', color: '#4cae45', label: 'cat' },
  { name: 'music_disc_blocks', ja: 'ミュージックディスク (blocks)', color: '#d9622b', label: 'blocks' },
  { name: 'music_disc_chirp', ja: 'ミュージックディスク (chirp)', color: '#c8353b', label: 'chirp' },
  { name: 'music_disc_far', ja: 'ミュージックディスク (far)', color: '#8ad06a', label: 'far' },
  { name: 'music_disc_mall', ja: 'ミュージックディスク (mall)', color: '#6a63c9', label: 'mall' },
  { name: 'music_disc_mellohi', ja: 'ミュージックディスク (mellohi)', color: '#b03fa5', label: 'mellohi' },
  { name: 'music_disc_stal', ja: 'ミュージックディスク (stal)', color: '#3b3b3f', label: 'stal' },
  { name: 'music_disc_strad', ja: 'ミュージックディスク (strad)', color: '#e0e0e0', label: 'strad' },
  { name: 'music_disc_ward', ja: 'ミュージックディスク (ward)', color: '#2f8f6f', label: 'ward' },
  { name: 'music_disc_11', ja: 'ミュージックディスク (11)', color: '#1a1a1a', label: '11' },
  { name: 'music_disc_wait', ja: 'ミュージックディスク (wait)', color: '#4da6d9', label: 'wait' },
  { name: 'music_disc_pigstep', ja: 'ミュージックディスク (Pigstep)', color: '#e88aa0', label: 'Pigstep' },
];

export function registerExtras() {
item('glass_bottle', 'ガラス瓶', '#c9e4ea', 'glass', { category: 'materials', stack: 64 });
item('dragon_breath', 'ドラゴンブレス', '#c040e8', 'gem', { category: 'materials', stack: 64 });
for (const d of MUSIC_DISCS) item(d.name, d.ja, d.color, 'gem', { category: 'tools', stack: 1 });
block('jukebox', 'ジュークボックス', '#6b4a33', 'planks', 2, { tool: 'axe', category: 'utility' });
}
