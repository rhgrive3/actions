import { isUuid, type NbtItem } from './nbt';

/*
 * Ender chest persistence on the server. The 27 slots belong to the player (UUID), so the client only ever sends and
 * receives a vanilla `EnderItems` list for "this player in this world"; which ender chest block was opened is irrelevant.
 * The local world save carries the same list as a fallback, so the game stays playable offline.
 */
const KEY = 'voxel.player.uuid';
const OFFLINE = '00000000-0000-4000-8000-000000000000';
let serverSyncEnabled = true;

/** The browser-only distribution has no API server; its local EnderItems save remains authoritative. */
export function configureEnderSync(enabled: boolean) {
  serverSyncEnabled = enabled;
}

function randomUuid(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
  const hex = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16));
  hex[12] = '4'; hex[16] = ((parseInt(hex[16], 16) & 3) | 8).toString(16);
  const s = hex.join('');
  return `${s.slice(0, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}-${s.slice(16, 20)}-${s.slice(20)}`;
}

/** Stable per-browser player UUID (created on first use). */
export function playerUUID(): string {
  try {
    const saved = localStorage.getItem(KEY);
    if (isUuid(saved)) return saved.toLowerCase();
    const fresh = randomUuid();
    localStorage.setItem(KEY, fresh);
    return fresh;
  } catch {
    return OFFLINE;
  }
}

export async function pullEnderItems(uuid: string, world: string): Promise<{ EnderItems: NbtItem[]; updatedAt: number } | null> {
  if (!serverSyncEnabled || typeof fetch !== 'function' || uuid === OFFLINE) return null;
  try {
    const res = await fetch(`/api/ender-chest?player=${encodeURIComponent(uuid)}&world=${encodeURIComponent(world)}`, { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    return Array.isArray(data?.EnderItems) ? { EnderItems: data.EnderItems, updatedAt: Number(data.updatedAt) || 0 } : null;
  } catch {
    return null;
  }
}

/** Returns the server timestamp of the write, or 0 when it could not be stored (the caller retries on the next save). */
export async function pushEnderItems(uuid: string, world: string, EnderItems: NbtItem[]): Promise<number> {
  if (!serverSyncEnabled || typeof fetch !== 'function' || uuid === OFFLINE) return 0;
  try {
    const res = await fetch('/api/ender-chest', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ player: uuid, world, EnderItems }),
      keepalive: true,
    });
    if (!res.ok) return 0;
    const data = await res.json();
    return Number(data?.updatedAt) || Date.now();
  } catch {
    return 0;
  }
}
