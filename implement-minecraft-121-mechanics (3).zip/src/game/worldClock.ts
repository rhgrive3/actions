/*
 * Overworld clock and weather — Java Edition 1.21 ServerLevel.advanceWeatherCycle / sleeping.
 *
 * minecraft.wiki "Weather": two flags with their own timers. Rain stays on 12 000–24 000 ticks and off 12 000–180 000 ticks;
 * thunder stays on 3 600–15 600 ticks and off 12 000–180 000 ticks. It is a thunderstorm only while both are on. A third
 * "clear weather" timer is only set by /weather clear; while it runs both flags are kept off and their timers are pinned at 1,
 * so when it ends both flip on at once (a thunderstorm).
 * minecraft.wiki "/weather": default durations clear 12 000–180 000, rain 12 000–24 000, thunder 3 600–15 600.
 * minecraft.wiki "Bed": 100 ticks asleep, then the time jumps to 0 (sunrise) of the next day; in Java the weather cycle is only
 * reset when it is raining. Beds work 12 542–23 459 (clear), 12 010–23 991 (rain) or any time in a thunderstorm.
 * Moon phase = day number mod 8 (Level.getMoonPhase: dayTime / 24000 % 8).
 */

export const DAY_TICKS = 24000;
export const SECONDS_PER_DAY = 1200;
export type Range = readonly [number, number];
export const RAIN_DELAY: Range = [12000, 180000];
export const RAIN_DURATION: Range = [12000, 24000];
export const THUNDER_DELAY: Range = [12000, 180000];
export const THUNDER_DURATION: Range = [3600, 15600];
export const SLEEP_TICKS = 100;
export type WeatherKind = 'clear' | 'rain' | 'storm';

/** UniformInt.of(lo, hi).sample — both ends inclusive. */
export const uniformInt = (rng: () => number, r: Range) => r[0] + Math.floor(rng() * (r[1] - r[0] + 1));

export class WeatherCycle {
  clearTime = 0;
  rainTime = 0;
  thunderTime = 0;
  raining = false;
  thundering = false;

  get state(): WeatherKind { return !this.raining ? 'clear' : this.thundering ? 'storm' : 'rain'; }

  /** ServerLevel.advanceWeatherCycle, once per game tick. */
  tick(rng: () => number = Math.random) {
    let i = this.clearTime, j = this.thunderTime, k = this.rainTime, thunder = this.thundering, rain = this.raining;
    if (i > 0) {
      i--;
      j = thunder ? 0 : 1;
      k = rain ? 0 : 1;
      thunder = false;
      rain = false;
    } else {
      if (j > 0) { j--; if (j === 0) thunder = !thunder; } else j = uniformInt(rng, thunder ? THUNDER_DURATION : THUNDER_DELAY);
      if (k > 0) { k--; if (k === 0) rain = !rain; } else k = uniformInt(rng, rain ? RAIN_DURATION : RAIN_DELAY);
    }
    this.clearTime = i; this.thunderTime = j; this.rainTime = k; this.thundering = thunder; this.raining = rain;
  }

  /** /weather clear|rain|storm [duration] (ServerLevel.setWeatherParameters). */
  set(kind: WeatherKind, rng: () => number = Math.random, duration?: number) {
    if (kind === 'clear') {
      this.clearTime = duration ?? uniformInt(rng, RAIN_DELAY);
      this.rainTime = 0; this.thunderTime = 0; this.raining = false; this.thundering = false;
    } else {
      const d = duration ?? uniformInt(rng, kind === 'storm' ? THUNDER_DURATION : RAIN_DURATION);
      this.clearTime = 0; this.rainTime = d; this.thunderTime = d; this.raining = true; this.thundering = kind === 'storm';
    }
  }

  /** After the night was slept through: ServerLevel.resetWeatherCycle runs only while it rains. */
  sleptThrough() {
    if (!this.raining) return;
    this.rainTime = 0; this.raining = false; this.thunderTime = 0; this.thundering = false;
  }

  /** Seconds until the visible weather can change next. */
  secondsLeft(): number {
    if (this.clearTime > 0) return this.clearTime / 20;
    if (!this.raining) return this.rainTime / 20;
    return Math.min(this.rainTime, this.thunderTime > 0 ? this.thunderTime : this.rainTime) / 20;
  }
}

/** Java bed rule (not wired into the bed interaction, which is outside this work's scope — see the report). */
export function canSleepAt(time: number, weather: WeatherKind): boolean {
  if (weather === 'storm') return true;
  const t = (((time % 1) + 1) % 1) * DAY_TICKS;
  return weather === 'rain' ? t >= 12010 && t <= 23991 : t >= 12542 && t <= 23459;
}

/** Day counter stored on the world meta (`dayCount`, optional → old saves fall back to play time / 1200 s). */
export function dayOf(meta: { playTime: number }): number {
  const d = (meta as unknown as { dayCount?: number }).dayCount;
  return typeof d === 'number' && Number.isFinite(d) ? d : Math.floor(meta.playTime / SECONDS_PER_DAY);
}
export function setDay(meta: object, day: number) { (meta as unknown as { dayCount?: number }).dayCount = Math.max(0, Math.floor(day)); }
export const moonPhase = (day: number) => ((Math.floor(day) % 8) + 8) % 8;
/** Waking up: dayTime + 24000 rounded down to a whole day → time 0 (sunrise) of the next day. */
export const wakeUp = (day: number) => ({ time: 0, day: day + 1 });

export interface ClockState {
  acc: number;
  weather: WeatherCycle;
  /** The weather value this module last wrote into the engine (detects /weather and other outside changes). */
  applied: WeatherKind | null;
  sleepTicks: number;
}
const clocks = new WeakMap<object, ClockState>();
export function clockOf(owner: object): ClockState {
  let c = clocks.get(owner);
  if (!c) clocks.set(owner, c = { acc: 0, weather: new WeatherCycle(), applied: null, sleepTicks: 0 });
  return c;
}
/** Whole 20 Hz ticks for this frame (at most 10 are kept so a stalled tab does not fast-forward the weather). */
export function clockTicks(c: ClockState, dt: number): number {
  c.acc = Math.min(c.acc + Math.max(0, dt), 0.5);
  let n = 0;
  while (c.acc >= 0.05 - 1e-9) { c.acc -= 0.05; n++; }
  if (c.acc < 0) c.acc = 0;
  return n;
}
