/**
 * Gameplay → presentation contract for the 1.21 "Tricky Trials" systems.
 *
 * This file is the single hand-off point between the gameplay code (structures, trial spawners, vaults, mob AI, beacons,
 * archaeology) and the rendering / VFX code. Gameplay never draws anything itself: it only
 *   1. sets *flags* on entities (see `Mob` in entities/mobs.ts),
 *   2. writes the low 4 *state bits* of a block cell, and
 *   3. emits the *events* declared below through `engine.w121.events`.
 *
 * ── Entity flags (all optional fields on `Mob`) ───────────────────────────────────────────────────────────────────────
 *   charged        creeper struck by lightning → draw the blue aura
 *   carried        enderman: block id held between its hands (0 / undefined = empty)
 *   fx             active status effects on the mob: { wind_charged | infested | oozing | weaving: secondsLeft }
 *   nectar         bee carries pollen (draw pollen on its back / dripping particles)
 *   pollinating    bee is hovering on a flower
 *   inHive         > 0 while the bee is inside its hive (the group is hidden)
 *   pregnant       turtle is carrying eggs and walking home
 *   digging        turtle (laying) / sniffer (digging) is playing its dig animation
 *   wanted         allay: item name it has been asked to collect, `heldCount` = how many it carries
 *   wolfArmor      wolf: remaining wolf-armor durability (> 0 → draw the armor)
 *   trial          key of the trial spawner that summoned this mob, `ominous` = spawned by an ominous spawner
 *
 * ── Block cell states ────────────────────────────────────────────────────────────────────────────────────────────────
 *   trial_spawner     0 inactive · 1 waiting for players · 2 active · 3 ejecting reward · 4 cooldown   (+8 = ominous)
 *   vault / ominous_vault   0 inactive · 1 active (unrewarded player nearby) · 2 unlocking · 3 ejecting
 *   bee_nest / beehive      honey level 0‥5
 *   turtle_egg        bits 0-1 = eggs-1 (1‥4 eggs) · bits 2-3 = crack stage 0‥2
 *   suspicious_sand / suspicious_gravel   dusted stage 0‥3
 *   beacon            beam level 0‥4 (0 = no pyramid)
 *   conduit           0 inactive · 1 active · 2 active and hunting (full 42-block frame)
 */
export type SpawnerPhase = 'inactive' | 'waiting' | 'active' | 'ejecting' | 'cooldown';
export type VaultPhase = 'inactive' | 'active' | 'unlocking' | 'ejecting';
type At = { x: number; y: number; z: number };

export interface GameEvents {
  trial_spawner_state: At & { phase: SpawnerPhase; ominous: boolean; players: number };
  trial_spawner_spawn: At & { species: string; mobId: number; ominous: boolean };
  trial_spawner_eject: At & { item: string; count: number; ominous: boolean };
  vault_state: At & { phase: VaultPhase; ominous: boolean };
  vault_eject: At & { item: string; count: number; ominous: boolean };
  vault_denied: At & { reason: 'already' | 'wrong_key' | 'no_key' | 'busy'; player: string };
  /** A wind burst (mace enchantment, Wind Charged death, wind charge projectile). */
  wind_burst: At & { radius: number; source: 'mace' | 'wind_charged' | 'wind_charge' };
  mace_smash: At & { fall: number; damage: number; density: number; breach: number; windBurst: number };
  /** One of the four 1.21 effects fired. `entity` is 'player' or a mob id. */
  effect_trigger: At & { effect: 'wind_charged' | 'infested' | 'oozing' | 'weaving'; entity: 'player' | number; count: number };
  lightning: At & { channeling: boolean };
  creeper_charged: At & { mobId: number };
  mob_head_drop: At & { head: string; victim: string };
  enderman_block: At & { mobId: number; block: number; action: 'pick' | 'place' };
  enderman_teleport: At & { mobId: number; cause: 'water' | 'rain' | 'projectile' };
  turtle_lay: At & { eggs: number };
  turtle_hatch: At & { eggs: number };
  bee_pollinate: At & { mobId: number };
  bee_grow_crop: At & { mobId: number };
  hive_honey: At & { level: number };
  hive_harvest: At & { item: string; calm: boolean };
  allay_deliver: At & { mobId: number; item: string; count: number; to: 'player' | 'note_block' };
  sniffer_dig: At & { mobId: number; item: string };
  armadillo_scute: At & { mobId: number; brushed: boolean };
  beacon_state: At & { level: number; primary: string; secondary: string; range: number };
  conduit_state: At & { frame: number; active: boolean; range: number; hunting: boolean };
  conduit_attack: At & { mobId: number };
  brush_progress: At & { stage: number };
  archaeology_find: At & { item: string };
  explorer_map: { kind: string; status: 'searching' | 'found' | 'none'; x?: number; z?: number };
}

type Handler<T> = (payload: T) => void;

export class EventBus {
  private handlers = new Map<string, Set<Handler<never>>>();
  /** Ring buffer of the latest events — handy for debugging overlays and for the headless tests. */
  readonly recent: { type: keyof GameEvents; payload: unknown }[] = [];

  on<K extends keyof GameEvents>(type: K, fn: Handler<GameEvents[K]>): () => void {
    let set = this.handlers.get(type);
    if (!set) { set = new Set(); this.handlers.set(type, set); }
    set.add(fn as Handler<never>);
    return () => { set!.delete(fn as Handler<never>); };
  }

  emit<K extends keyof GameEvents>(type: K, payload: GameEvents[K]) {
    this.recent.push({ type, payload });
    if (this.recent.length > 96) this.recent.shift();
    const set = this.handlers.get(type);
    if (set) for (const fn of set) (fn as unknown as Handler<GameEvents[K]>)(payload);
  }

  count(type: keyof GameEvents) { return this.recent.filter(e => e.type === type).length; }
  last<K extends keyof GameEvents>(type: K): GameEvents[K] | undefined {
    for (let i = this.recent.length - 1; i >= 0; i--) if (this.recent[i].type === type) return this.recent[i].payload as GameEvents[K];
    return undefined;
  }
}
