import { DEFAULT_SETTINGS, type Settings, type WorldMeta, type WorldSave } from './types';
export function readLocal<T>(key:string,fallback:T):T{try{const value=localStorage.getItem(key);return value?JSON.parse(value):fallback;}catch{return fallback;}}
export function writeLocal(key:string,value:unknown){try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
export const loadSettings=():Settings=>({...DEFAULT_SETTINGS,...readLocal<Partial<Settings>>('voxel.settings',{})});
export const saveSettings=(s:Settings)=>writeLocal('voxel.settings',s);
export const loadWorlds=():WorldMeta[]=>readLocal<WorldMeta[]>('voxel.worlds',[]).sort((a,b)=>b.updated-a.updated);
export const loadSave=(id:string)=>readLocal<WorldSave|undefined>('voxel.save.'+id,undefined);
export function saveWorld(save:WorldSave){const ok=writeLocal('voxel.save.'+save.meta.id,save),worlds=loadWorlds(),i=worlds.findIndex(w=>w.id===save.meta.id);if(i>=0)worlds[i]=save.meta;else worlds.unshift(save.meta);writeLocal('voxel.worlds',worlds);return ok;}
export function deleteWorld(id:string){try{localStorage.removeItem('voxel.save.'+id);}catch{}return writeLocal('voxel.worlds',loadWorlds().filter(w=>w.id!==id));}
export function exportWorld(save:WorldSave){const url=URL.createObjectURL(new Blob([JSON.stringify(save)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=save.meta.name+'.voxel.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
