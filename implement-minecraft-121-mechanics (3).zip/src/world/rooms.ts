// Room variety for the big structures: woodland mansion (irregular rooms, randomly linked), ancient city (long deepslate-brick
// corridors, barracks, the redstone laboratory under the central frame) and the three bastion remnant types.
import { ID } from '../game/data';
import { makeCell } from '../game/blockState';
import type { Terrain } from './terrain';
import type { Put, Placed } from './structures';
import { markLoot } from './loot';

const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const cell = (name: string, state: number, fallback = 'stone') => makeCell(id(name, fallback), state);
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
const fill = (put: Put, x0: number, y0: number, z0: number, x1: number, y1: number, z1: number, block: number) => {
  for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) put(x, y, z, block, true);
};

// =========================================================================================================================
// Woodland mansion
// =========================================================================================================================
export const MANSION_ROOM_KINDS = ['library', 'storage', 'jail', 'cat_statue', 'flower_garden', 'bedroom', 'treasure', 'dining'] as const;
export type MansionRoomKind = typeof MANSION_ROOM_KINDS[number];
export interface MansionRoom {
  floor: number; side: -1 | 1;
  /** Cross walls stand at x0 and x1; the room interior is x0+1 … x1-1 by |z - p.z| = 3 … 9. */
  x0: number; x1: number; floorY: number;
  kind: MansionRoomKind;
  /** Door onto the central corridor / doorway through the wall at x1 into the next room. */
  corridorDoor: boolean; link: boolean;
}
/** Where the mansion's mobs stand (kept clear of walls and furniture): offsets from the site, see structureOccupants. */
const MANSION_KEEP_CLEAR: [number, number, number][] = [[-9, 0, -5], [7, 0, 5], [-1, 5, -5], [7, 10, 5], [-9, 5, 5], [7, 10, -5]];

/** Irregular room plan: every (floor, wing) strip is cut at random widths, rooms get a shuffled purpose and random connecting doors. */
export function mansionPlan(seed: number, p: { x: number; y: number; z: number }): MansionRoom[] {
  const s = seed + 7400, X0 = p.x - 15, rooms: MansionRoom[] = [], off = Math.floor(hash(p.x, p.z, s + 1) * 8);
  let ordinal = 0;
  for (let floor = 0; floor < 3; floor++) for (const side of [-1, 1] as const) {
    const cuts = [0];
    for (let pos = 0, n = 0; ; n++) {
      let next = pos + [5, 6, 8, 10][Math.floor(hash(side * 7 + floor, n, s + 11 + p.x) * 4)];
      while ([6, 14, 16, 17, 22].includes(next)) next++;               // keep doors and mob positions out of the walls
      if (next > 25) break;
      cuts.push(next); pos = next;
    }
    cuts.push(30);
    let prevLink = false;
    for (let i = 0; i + 1 < cuts.length; i++) {
      const last = i + 2 === cuts.length, link = !last && hash(cuts[i + 1] + side * 50, floor, s + 12) < 0.55;
      const secret = floor > 0 && prevLink && hash(cuts[i] + side * 50, floor, s + 13) < 0.3;
      rooms.push({ floor, side, x0: X0 + cuts[i], x1: X0 + cuts[i + 1], floorY: p.y - 1 + floor * 5, kind: MANSION_ROOM_KINDS[(ordinal++ * 3 + off) % 8], corridorDoor: !secret, link });
      prevLink = link;
    }
  }
  return rooms;
}

function furnishMansionRoom(put: Put, p: Placed, r: MansionRoom, s: number) {
  const fy = r.floorY, a = r.x0 + 1, b = r.x1 - 1, mid = (r.x0 + r.x1) >> 1, zi = (i: number) => p.z + r.side * i;
  const set = (x: number, dy: number, i: number, blk: number) => put(x, fy + dy, zi(i), blk, true);
  switch (r.kind) {
    case 'library':
      for (let x = a; x <= b; x++) for (let dy = 1; dy <= 3; dy++) set(x, dy, 9, id('bookshelf'));
      for (let x = a + 1; x < b; x += 2) { set(x, 1, 6, id('bookshelf')); set(x, 2, 6, id('bookshelf')); }
      break;
    case 'storage':                                                    // chest store room
      for (let x = a, n = 0; x <= b && n < 3; x += 2, n++) { set(x, 1, 9, id('chest')); markLoot(x, fy + 1, zi(9), 'mansion_storage'); }
      set(b, 1, 7, id('barrel', 'oak_planks')); set(b, 2, 7, id('barrel', 'oak_planks')); set(b, 1, 6, id('oak_planks'));
      break;
    case 'jail':                                                       // cell behind iron bars with an iron door
      for (let x = a; x <= b; x++) {
        for (let i = 7; i <= 9; i++) put(x, fy, zi(i), id('cobblestone'), true);
        for (let dy = 1; dy <= 4; dy++) set(x, dy, 6, id('iron_bars'));
      }
      set(mid, 1, 6, id('iron_door', 'oak_door')); set(mid, 2, 6, 0);
      break;
    case 'cat_statue': {                                               // black wool cat
      const wool = id('black_wool', 'white_wool');
      for (let i = 5; i <= 7; i++) set(mid, 2, i, wool);
      set(mid, 1, 5, wool); set(mid, 1, 7, wool); set(mid, 3, 5, wool); set(mid, 3, 8, wool); set(mid, 2, 8, wool);
      break;
    }
    case 'flower_garden': {
      const flowers = ['poppy', 'dandelion', 'allium', 'azure_bluet', 'red_tulip', 'oxeye_daisy', 'cornflower', 'white_tulip'];
      for (let x = a; x <= b; x++) for (let i = 4; i <= 8; i++) {
        put(x, fy, zi(i), id('grass_block'), true);
        const h = hash3(x, fy, zi(i), s + 20);
        if (h < 0.65 && !(x === mid && i === 4)) set(x, 1, i, id(flowers[Math.floor(h * 97) % flowers.length], 'poppy'));
      }
      set(a, 1, 9, id('oak_leaves')); set(b, 1, 9, id('oak_leaves'));
      break;
    }
    case 'bedroom':
      set(a, 1, 8, id('white_wool')); set(a, 1, 9, id('white_wool')); set(a + 1, 1, 9, id('red_carpet', 'white_carpet')); set(b, 1, 9, id('bookshelf'));
      break;
    case 'treasure':
      set(mid, 1, 6, id('chest')); set(mid, 1, 8, id('lapis_block', 'gold_block'));
      break;
    case 'dining':
      for (let x = Math.max(a, mid - 1); x <= Math.min(b, mid + 1); x++) { set(x, 1, 6, id('dark_oak_fence', 'oak_fence')); set(x, 2, 6, id('brown_carpet', 'white_carpet')); }
      break;
  }
  set(b, 1, 3, id('torch'));
}

export function mansion(t: Terrain, put: Put, p: Placed) {
  const cob = id('cobblestone'), plank = id('dark_oak_planks', 'oak_planks'), log = id('dark_oak_log', 'oak_log'), birch = id('birch_planks', 'oak_planks'), pane = id('glass_pane', 'glass'), carpet = id('red_carpet', 'air');
  const lantern = id('lantern', 'torch'), s = t.seed + 7400;
  const X0 = p.x - 15, X1 = p.x + 15, Z0 = p.z - 10, Z1 = p.z + 10, y = p.y;
  for (let z = Z0; z <= Z1; z++) for (let x = X0; x <= X1; x++) {
    for (let dy = 2; dy <= 8; dy++) put(x, y - dy, z, cob, true);
    const edgeX = x === X0 || x === X1, edgeZ = z === Z0 || z === Z1, dzc = z - p.z, dxc = x - X0;
    for (let k = 0; k < 3; k++) {
      const fy = y - 1 + k * 5;
      put(x, fy, z, k === 0 ? cob : plank, true);
      for (let dy = 1; dy <= 4; dy++) {
        let b = 0;
        if (edgeX || edgeZ) {
          const along = edgeX ? z - Z0 : dxc;
          b = (edgeX && edgeZ) || along % 5 === 0 ? log : (dy === 2 || dy === 3) && along % 5 !== 1 && along % 5 !== 4 ? pane : plank;
        } else if (Math.abs(dzc) === 2) b = birch;
        else if (dy === 1 && Math.abs(dzc) <= 1) b = dzc === 0 && dxc % 8 === 0 ? lantern : carpet;
        put(x, fy + dy, z, b, true);
      }
    }
    put(x, y + 14, z, plank, true);
  }
  for (let r = 0; r <= 11; r++) fill(put, X0 - 1, y + 15 + r, Z0 - 1 + r, X1 + 1, y + 15 + r, Z1 + 1 - r, r === 11 ? log : plank);
  // Rooms: cross walls, furnishing, then the doors that string them together.
  const rooms = mansionPlan(t.seed, p);
  for (const r of rooms) {
    if (r.x1 < X1) for (let i = 3; i <= 9; i++) for (let dy = 1; dy <= 4; dy++) put(r.x1, r.floorY + dy, p.z + r.side * i, birch, true);
    furnishMansionRoom(put, p, r, s);
  }
  for (const r of rooms) {
    const mid = (r.x0 + r.x1) >> 1;
    if (r.corridorDoor) for (let dy = 1; dy <= 2; dy++) { put(mid, r.floorY + dy, p.z + r.side * 2, 0, true); put(mid, r.floorY + dy, p.z + r.side * 3, 0, true); }
    if (r.link) { const i = 4 + Math.floor(hash(r.x1, r.floorY * 3 + r.side, s + 14) * 2); for (let dy = 1; dy <= 2; dy++) for (const dx of [-1, 0, 1]) put(r.x1 + dx, r.floorY + dy, p.z + r.side * i, 0, true); }
  }
  for (let dy = 0; dy <= 2; dy++) { put(p.x + 1, y + dy, Z0, 0, true); put(p.x + 2, y + dy, Z0, 0, true); put(p.x + 1, y + dy, Z0 + 1, 0, true); put(p.x + 2, y + dy, Z0 + 1, 0, true); }
  for (let dy = 0; dy <= 10; dy++) put(X1 - 1, y + dy, p.z + 1, id('ladder'), true);
  for (const [dx, dy, dz] of MANSION_KEEP_CLEAR) { put(p.x + dx, y + dy, p.z + dz, 0, true); put(p.x + dx, y + dy + 1, p.z + dz, 0, true); }
}

// =========================================================================================================================
// Ancient city
// =========================================================================================================================
export interface AncientCityParts {
  /** Roofed deepslate-brick galleries: [x0, x1] ranges along the main road (z = p.z ± 3 are the colonnades). */
  corridors: [number, number][];
  barracks: { x0: number; z0: number; x1: number; z1: number; door: [number, number, number]; chests: [number, number, number][] };
  lab: { x0: number; y0: number; z0: number; x1: number; y1: number; z1: number; stairTop: [number, number, number] };
  iceBoxChest: [number, number, number];
}
export function ancientCityParts(p: { x: number; y: number; z: number }): AncientCityParts {
  return {
    corridors: [[p.x - 30, p.x - 12], [p.x + 12, p.x + 30]],
    barracks: { x0: p.x - 7, z0: p.z + 14, x1: p.x + 7, z1: p.z + 22, door: [p.x, p.y, p.z + 14], chests: [[p.x - 6, p.y, p.z + 21], [p.x + 6, p.y, p.z + 21]] },
    lab: { x0: p.x - 6, y0: p.y - 8, z0: p.z - 14, x1: p.x + 6, y1: p.y - 3, z1: p.z - 6, stairTop: [p.x, p.y - 1, p.z - 5] },
    iceBoxChest: [p.x - 16, p.y + 1, p.z - 14],
  };
}
/** Added on top of the base city: long corridors, the barracks and the redstone laboratory beneath the central frame. */
export function ancientCityExtras(t: Terrain, put: Put, p: Placed) {
  const A = ancientCityParts(p), y = p.y, s = t.seed + 7650;
  const bricks = id('deepslate_bricks', 'deepslate'), tiles = id('deepslate_tiles', 'deepslate'), polished = id('polished_deepslate', 'deepslate'), cobbled = id('cobbled_deepslate', 'deepslate');
  const lantern = id('soul_lantern', 'lantern'), wool = id('gray_wool', 'white_wool'), carpet = id('gray_carpet', 'white_carpet'), dplank = id('dark_oak_planks', 'oak_planks');
  // ---- Long deepslate-brick corridors along the main road ------------------------------------------------------------------
  for (const [x0, x1] of A.corridors) for (let x = x0; x <= x1; x++) {
    const a = Math.abs(x - p.x), pillar = a % 4 === 0;
    for (const dz of [-3, 3]) for (let dy = 0; dy <= 3; dy++) put(x, y + dy, p.z + dz, pillar || dy === 3 ? (hash3(x, dy, dz, s) < 0.2 ? cobbled : bricks) : 0, true);
    for (let dz = -3; dz <= 3; dz++) if (hash(x, dz, s + 1) > 0.07) put(x, y + 4, p.z + dz, Math.abs(dz) === 3 ? polished : tiles, true);
    for (let dz = -2; dz <= 2; dz++) for (let dy = 0; dy <= 3; dy++) put(x, y + dy, p.z + dz, 0, true);
    if (a % 8 === 4) put(x, y + 3, p.z, lantern, true);
  }
  // ---- Barracks: bunks, chests, soul lanterns ---------------------------------------------------------------------------------
  const K = A.barracks;
  for (let z = K.z0; z <= K.z1; z++) for (let x = K.x0; x <= K.x1; x++) {
    const edge = x === K.x0 || x === K.x1 || z === K.z0 || z === K.z1;
    put(x, y - 1, z, tiles, true);
    for (let dy = 0; dy <= 3; dy++) put(x, y + dy, z, edge ? (dy === 0 ? cobbled : hash3(x, dy, z, s + 2) < 0.12 ? 0 : bricks) : 0, true);
    put(x, y + 4, z, hash(x, z, s + 3) < 0.06 ? 0 : tiles, true);
  }
  put(K.door[0], y, K.door[2], 0, true); put(K.door[0], y + 1, K.door[2], 0, true);
  for (const bz of [K.z0 + 2, K.z0 + 4, K.z0 + 6]) for (const sx of [-1, 1]) for (const off of [5, 6]) {
    put(p.x + sx * off, y, bz, wool, true);                                         // lower bunk
    put(p.x + sx * off, y + 2, bz, dplank, true); put(p.x + sx * off, y + 3, bz, carpet, true);   // upper bunk
  }
  for (const c of K.chests) put(c[0], c[1], c[2], id('chest'), true);
  put(p.x, y + 3, K.z0 + 4, lantern, true);
  for (let x = p.x - 1; x <= p.x + 1; x++) put(x, y, K.z0 + 4, polished, true);
  // ---- Redstone laboratory under the central frame ------------------------------------------------------------------------------
  const R = A.lab, fy = R.y0 + 1;
  for (let yy = R.y0; yy <= R.y1; yy++) for (let z = R.z0; z <= R.z1; z++) for (let x = R.x0; x <= R.x1; x++) {
    const shell = x === R.x0 || x === R.x1 || z === R.z0 || z === R.z1 || yy === R.y0 || yy === R.y1;
    put(x, yy, z, shell ? (yy === R.y0 ? tiles : bricks) : 0, true);
  }
  for (let i = 0; i <= 6; i++) {                                                    // staircase in front of the frame
    const sy = y - 1 - i, sz = p.z - 5 - i;
    for (let yy = fy; yy < sy; yy++) if (sz > R.z0 && sz < R.z1) put(p.x, yy, sz, bricks, true);
    put(p.x, sy, sz, cell('deepslate_stairs', 2, 'deepslate'), true);
    for (let dy = 1; dy <= 3; dy++) put(p.x, sy + dy, sz, 0, true);
  }
  const lab = (dx: number, dz: number, blk: number, dy = 0) => put(p.x + dx, fy + dy, p.z + dz, blk, true);
  for (let dx = 2; dx <= 5; dx++) lab(dx, -9, id('redstone_wire'));
  lab(3, -10, cell('repeater', 0)); lab(4, -10, cell('comparator', 0)); lab(2, -10, id('redstone_wire'));
  lab(4, -12, id('target')); lab(5, -12, id('note_block'));
  for (let dx = -5; dx <= -3; dx++) lab(dx, -13, id('unlit_redstone_lamp', 'redstone_lamp'), 2);
  lab(-4, -9, cell('piston', 4)); lab(-5, -9, cell('sticky_piston', 4)); lab(-3, -9, cell('lever', 0));
  lab(-2, -12, id('lectern', 'bookshelf'));
  lab(5, -8, wool); lab(5, -8, id('sculk_sensor', 'air'), 1);
  lab(-5, -12, lantern); lab(5, -11, lantern);
  // ---- Loot ---------------------------------------------------------------------------------------------------------------------
  markLoot(...A.iceBoxChest, 'ancient_city_ice_box');
}

// =========================================================================================================================
// Bastion remnant
// =========================================================================================================================
export const BASTION_TYPES = ['treasure', 'hoglin_stable', 'bridge'] as const;
export type BastionType = typeof BASTION_TYPES[number];
export const bastionType = (seed: number, p: { x: number; z: number }): BastionType => BASTION_TYPES[Math.floor(hash(p.x, p.z, seed + 7709) * 3)];
export interface BastionParts { type: BastionType; chests: [number, number, number][]; table: string }
export function bastionParts(seed: number, p: { x: number; y: number; z: number }): BastionParts {
  const type = bastionType(seed, p), y = p.y;
  if (type === 'bridge') return { type, table: 'bastion_bridge', chests: [[p.x + 1, y + 8, p.z], [p.x - 11, y, p.z - 1]] };
  if (type === 'hoglin_stable') return { type, table: 'bastion_hoglin_stable', chests: [[p.x - 9, y, p.z + 9], [p.x + 9, y, p.z - 9], [p.x - 9, y + 7, p.z - 9]] };
  return { type, table: 'bastion_treasure', chests: [[p.x + 6, y, p.z + 6], [p.x - 8, y, p.z + 8], [p.x - 9, y + 7, p.z - 9]] };
}

export function bastion(t: Terrain, put: Put, p: Placed) {
  const parts = bastionParts(t.seed, p);
  const bs = id('blackstone'), pbb = id('polished_blackstone_bricks', 'blackstone'), gilded = id('gilded_blackstone', 'blackstone'), gold = id('gold_block'), basalt = id('basalt', 'blackstone'), lava = id('lava');
  const chain = id('chain', 'air'), lantern = id('lantern', 'glowstone'), magma = id('magma_block', 'netherrack'), fence = id('nether_bricks_fence', 'iron_bars');
  const s = t.seed + 7700, y = p.y, H = 12, R = 12;
  if (parts.type === 'bridge') {
    // ---- Bridge: two piers joined by a ruined polished-blackstone deck over a lava moat ------------------------------------------
    for (let dz = -5; dz <= 5; dz++) for (let dx = -13; dx <= 13; dx++) {
      const x = p.x + dx, z = p.z + dz, pier = Math.abs(dx) >= 9, az = Math.abs(dz);
      for (let dy = 2; dy <= 6; dy++) put(x, y - dy, z, bs, true);
      put(x, y - 1, z, !pier && az <= 3 ? lava : hash(x, z, s + 1) < 0.1 ? gilded : bs, true);
      for (let dy = 0; dy <= 12; dy++) {
        let b = 0;
        const r = hash3(x, y + dy, z, s);
        if (pier && az <= 2) { if (dy <= 6 && (Math.abs(dx) === 9 || Math.abs(dx) === 13 || az === 2)) b = r < 0.08 ? gilded : r < 0.25 ? bs : pbb; }
        if (az <= 2 && dy === 7) b = !pier && r < 0.07 && dx !== 0 ? 0 : r < 0.1 ? gilded : pbb;                     // deck
        if (az === 2 && dy === 8 && (dx & 1) === 0) b = bs;                                                           // parapet
        put(x, y + dy, z, b, true);
      }
    }
    for (let i = 0; i <= 6; i++) for (const sx of [-1, 1]) {                           // stairs up each pier
      const x = p.x + sx * 11, z = p.z + 3 + (6 - i) - 4;
      put(x, y + i, z, pbb, true);
      for (let dy = 1; dy <= 3; dy++) put(x, y + i + dy, z, 0, true);
    }
    for (const sx of [-1, 1]) { put(p.x + sx * 11, y, p.z - 2, 0, true); put(p.x + sx * 11, y + 1, p.z - 2, 0, true); }
    put(p.x, y + 8, p.z, gold, true); put(p.x, y + 9, p.z, gold, true); put(p.x - 1, y + 8, p.z, gilded, true);
    for (const sx of [-1, 1]) { put(p.x + sx * 5, y + 8, p.z - 2, basalt, true); put(p.x + sx * 5, y + 9, p.z - 2, lantern, true); }
  } else {
    const stable = parts.type === 'hoglin_stable';
    for (let dz = -R; dz <= R; dz++) for (let dx = -R; dx <= R; dx++) {
      const x = p.x + dx, z = p.z + dz, ax = Math.abs(dx), az = Math.abs(dz), ring = Math.max(ax, az);
      for (let dy = 2; dy <= 7; dy++) put(x, y - dy, z, bs, true);
      const moat = !stable && ring >= 3 && ring <= 4 && dx !== 0 && dz !== 0;
      put(x, y - 1, z, moat ? lava : stable && az >= 5 && ring < R - 1 ? id('soul_soil', 'netherrack') : hash(x, z, s + 1) < 0.08 ? magma : hash(x, z, s + 2) < 0.1 ? gilded : bs, true);
      const gate = (ax <= 1 || az <= 1) && ring >= R - 1;
      for (let dy = 0; dy <= H + 5; dy++) {
        let b = 0;
        if (ax >= R - 1 && az >= R - 1) b = basalt;
        else if (ring >= R - 1) {
          const r = hash3(x, y + dy, z, s);
          if (dy <= H || (dy === H + 1 && ring === R && ((ax + az) & 1) === 0)) b = r < 0.06 ? gilded : r < 0.22 ? bs : pbb;
          if ((gate && dy <= 3) || (r > 0.975 && dy > 4 && dy < H)) b = 0;
        } else if (dy === 6 && ring >= R - 5) b = pbb;
        else if (stable) {
          // Hoglin stables: stalls on both sides of a central aisle, divided by blackstone-brick walls and fenced at the front.
          if (az >= 5 && ax % 4 === 0 && ax <= 8 && dy <= 2) b = pbb;
          else if (az === 4 && dy === 0 && ax % 4 !== 2 && ax <= 9) b = fence;
          else if (az === 9 && ax % 4 === 2 && dy === 0) b = id('hay_block', 'gold_block');
          else if (az <= 1 && ax % 6 === 3 && dy <= 4) b = basalt;
        } else {
          // Treasure room: gold piled on a blackstone dais inside the lava moat.
          if (ring <= 2 && dy === 0) b = bs;
          else if (ring <= 1 && dy === 1) b = gold;
          else if (ring === 0 && dy === 2) b = gold;
        }
        put(x, y + dy, z, b, true);
      }
    }
    for (let i = 0; i <= 5; i++) { put(p.x - 9 + i, y + i, p.z + R - 2, pbb, true); for (let dy = i + 1; dy <= i + 3; dy++) put(p.x - 9 + i, y + dy, p.z + R - 2, 0, true); }
    for (const [cx, cz] of [[7, 7], [-7, 7], [7, -7], [-7, -7]]) { put(p.x + cx, y + 5, p.z + cz, chain, true); put(p.x + cx, y + 4, p.z + cz, lantern, true); }
  }
  for (const c of parts.chests) { put(c[0], c[1] - 1, c[2], bs, false); put(c[0], c[1], c[2], id('chest'), true); put(c[0], c[1] + 1, c[2], 0, true); markLoot(c[0], c[1], c[2], parts.table); }
}
