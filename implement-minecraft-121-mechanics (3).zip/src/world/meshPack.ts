import type { MeshData } from './mesher';

/**
 * GPU vertex layout sent from the chunk workers to the main thread.
 *
 * The mesher keeps producing plain Float32 data (the test suites inspect it directly); the worker repacks it right before
 * the transfer: normals become signed-normalised bytes, colours / light / wind unsigned-normalised shorts, tile layers
 * integer shorts and indices 16-bit whenever they fit. That is ~40 % fewer bytes per vertex and 50 % fewer index bytes to
 * post, upload and fetch every frame — vertex bandwidth is what low-end mobile GPUs run out of first.
 *
 * Every conversion is range-checked per chunk: a value outside the representable range falls back to the original Float32
 * array for that attribute, so the rendered image cannot change. Normalised shorts carry 1/65535 precision (far below one
 * 8-bit output step) and the axis-aligned normals used by voxel faces stay exactly ±1 / 0 (WebGL2: c / 127).
 */
export interface PackedMesh {
  position: Float32Array;
  normal: Int8Array | Float32Array;
  uv: Float32Array;
  color: Uint16Array | Float32Array;
  tile: Uint16Array | Float32Array;
  wind: Uint16Array | Float32Array;
  light: Uint16Array | Float32Array;
  index: Uint16Array | Uint32Array;
}

export function packUnit(src: Float32Array): Uint16Array | Float32Array {
  const n = src.length;
  for (let i = 0; i < n; i++) {
    const v = src[i];
    if (!(v >= 0 && v <= 1)) return src;
  }
  const out = new Uint16Array(n);
  for (let i = 0; i < n; i++) out[i] = Math.round(src[i] * 65535);
  return out;
}

export function packNormal(src: Float32Array): Int8Array | Float32Array {
  const n = src.length;
  for (let i = 0; i < n; i++) {
    const v = src[i];
    if (!(v >= -1 && v <= 1)) return src;
  }
  const out = new Int8Array(n);
  for (let i = 0; i < n; i++) out[i] = Math.round(src[i] * 127);
  return out;
}

export function packTile(src: Float32Array): Uint16Array | Float32Array {
  const n = src.length;
  for (let i = 0; i < n; i++) {
    const v = src[i];
    if (!(v >= 0 && v <= 65535) || v !== Math.floor(v)) return src;
  }
  return Uint16Array.from(src);
}

export function packIndex(src: Uint32Array, vertexCount: number): Uint16Array | Uint32Array {
  return vertexCount <= 65536 ? Uint16Array.from(src) : src;
}

export function packMesh(m: MeshData): PackedMesh {
  return {
    position: m.position,
    normal: packNormal(m.normal),
    uv: m.uv,
    color: packUnit(m.color),
    tile: packTile(m.tile),
    wind: packUnit(m.wind),
    light: packUnit(m.light),
    index: packIndex(m.index, m.position.length / 3),
  };
}

export function emptyPackedMesh(): PackedMesh {
  return {
    position: new Float32Array(0),
    normal: new Int8Array(0),
    uv: new Float32Array(0),
    color: new Uint16Array(0),
    tile: new Uint16Array(0),
    wind: new Uint16Array(0),
    light: new Uint16Array(0),
    index: new Uint16Array(0),
  };
}

export const packedTransfers = (m: PackedMesh): ArrayBufferLike[] =>
  [m.position.buffer, m.normal.buffer, m.uv.buffer, m.color.buffer, m.tile.buffer, m.wind.buffer, m.light.buffer, m.index.buffer];
