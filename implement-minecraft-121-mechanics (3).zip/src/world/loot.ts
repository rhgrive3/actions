// Room-level loot tables (Minecraft Java Edition loot tables, per Minecraft Wiki) and the marker mechanism that ties a
// generated container to its table.
//
// Structure builders call `markLoot` / `markPreset` right where they place a chest, dispenser, brewing stand or item frame.
// During normal chunk generation the calls are no-ops; `collectMarks` re-runs the (pure, seed-deterministic) builders with a
// null `put` to recover "which table does the chest at (x, y, z) use", so the builder stays the single source of truth.

export type LootEntry = [name: string, min: number, max: number, weight: number];
export interface LootPool { rolls: [number, number]; items: LootEntry[]; /** Probability that the pool is rolled at all (default 1). */ chance?: number }
export interface RoomLoot { ja: string; pools: LootPool[] }
export interface LootStack { name: string; count: number }
export interface LootMark { table?: string; preset?: (readonly [string, number] | null)[] }

const one = (name: string, chance = 1): LootPool => ({ rolls: [1, 1], items: [[name, 1, 1, 1]], chance });
const trim = (pattern: string, chance: number) => one(pattern + '_armor_trim_smithing_template', chance);
const junk = (rolls: [number, number], ...names: string[]): LootPool => ({ rolls, items: names.map(n => [n, 1, 8, 10] as LootEntry) });
const IRON_GEAR: LootEntry[] = ['iron_pickaxe', 'iron_sword', 'iron_chestplate', 'iron_helmet', 'iron_leggings', 'iron_boots'].map(n => [n, 1, 1, 5] as LootEntry);

export const ROOM_LOOT: Record<string, RoomLoot> = {
  // ---- Stronghold ---------------------------------------------------------------------------------------------------
  stronghold_library: { ja: '要塞の図書館', pools: [
    { rolls: [2, 10], items: [['book', 1, 3, 20], ['paper', 2, 7, 20], ['map', 1, 1, 1], ['compass', 1, 1, 1], ['enchanted_book', 1, 1, 10]] },
    trim('eye', 1),
  ] },
  stronghold_corridor: { ja: '要塞の回廊（祭壇）', pools: [
    { rolls: [2, 3], items: [['ender_pearl', 1, 1, 10], ['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['redstone', 4, 9, 5], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ...IRON_GEAR,
      ['golden_apple', 1, 1, 1], ['saddle', 1, 1, 1], ['music_disc_otherside', 1, 1, 1], ['enchanted_book', 1, 1, 1]] },
    trim('eye', 0.1),
  ] },
  stronghold_crossing: { ja: '要塞の物置', pools: [
    { rolls: [1, 4], items: [['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['redstone', 4, 9, 5], ['coal', 3, 8, 10], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ['iron_pickaxe', 1, 1, 1], ['enchanted_book', 1, 1, 1]] },
  ] },
  // ---- Desert pyramid (TNT trap chamber) ----------------------------------------------------------------------------
  desert_pyramid: { ja: '砂漠の寺院（TNT地下室）', pools: [
    { rolls: [2, 4], items: [['diamond', 1, 3, 5], ['iron_ingot', 1, 5, 15], ['gold_ingot', 2, 7, 15], ['emerald', 1, 3, 15], ['bone', 4, 6, 25], ['spider_eye', 1, 3, 25], ['rotten_flesh', 3, 7, 25], ['saddle', 1, 1, 20],
      ['golden_apple', 1, 1, 20], ['enchanted_golden_apple', 1, 1, 2], ['enchanted_book', 1, 1, 20]] },
    junk([4, 4], 'bone', 'gunpowder', 'rotten_flesh', 'string', 'sand'),
    trim('dune', 1 / 7),
  ] },
  // ---- Jungle pyramid -----------------------------------------------------------------------------------------------
  jungle_temple: { ja: 'ジャングルの寺院', pools: [
    { rolls: [2, 6], items: [['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 2, 7, 15], ['bamboo', 1, 3, 15], ['emerald', 1, 3, 2], ['bone', 4, 6, 20], ['rotten_flesh', 3, 7, 16], ['saddle', 1, 1, 3], ['enchanted_book', 1, 1, 1]] },
    trim('wild', 1 / 3),
  ] },
  // ---- Igloo basement -----------------------------------------------------------------------------------------------
  igloo_chest: { ja: 'イグルーの地下室', pools: [
    { rolls: [2, 8], items: [['apple', 1, 3, 15], ['coal', 1, 4, 15], ['gold_nugget', 1, 3, 10], ['stone_axe', 1, 1, 2], ['rotten_flesh', 1, 1, 10], ['emerald', 1, 1, 1], ['wheat', 2, 3, 10]] },
    one('golden_apple'),
  ] },
  // ---- Villages -----------------------------------------------------------------------------------------------------
  village_weaponsmith: { ja: '村の武器鍛冶', pools: [
    { rolls: [3, 8], items: [['diamond', 1, 3, 3], ['iron_ingot', 1, 5, 10], ['gold_ingot', 1, 3, 5], ['bread', 1, 3, 15], ['apple', 1, 3, 15], ...IRON_GEAR, ['obsidian', 3, 7, 5], ['oak_sapling', 3, 7, 5], ['saddle', 1, 1, 3]] },
  ] },
  village_temple: { ja: '村の教会', pools: [
    { rolls: [3, 8], items: [['redstone', 1, 4, 2], ['bread', 1, 4, 7], ['rotten_flesh', 1, 4, 7], ['lapis_lazuli', 1, 4, 1], ['gold_ingot', 1, 4, 1], ['emerald', 1, 4, 1]] },
  ] },
  village_plains_house: { ja: '平原の村の民家', pools: [
    { rolls: [3, 8], items: [['gold_nugget', 1, 3, 1], ['dandelion', 1, 1, 2], ['poppy', 1, 1, 1], ['potato', 1, 7, 10], ['bread', 1, 4, 10], ['apple', 1, 5, 10], ['book', 1, 1, 1], ['feather', 1, 1, 1], ['emerald', 1, 4, 2], ['oak_sapling', 1, 2, 5]] },
  ] },
  village_desert_house: { ja: '砂漠の村の民家', pools: [
    { rolls: [3, 8], items: [['clay_ball', 1, 1, 1], ['cactus', 1, 4, 10], ['wheat', 1, 7, 10], ['bread', 1, 4, 10], ['book', 1, 1, 1], ['dead_bush', 1, 3, 2], ['emerald', 1, 3, 1]] },
  ] },
  // ---- Woodland mansion ---------------------------------------------------------------------------------------------
  mansion_storage: { ja: '森の洋館の倉庫', pools: [
    { rolls: [1, 3], items: [['lead', 1, 1, 20], ['golden_apple', 1, 1, 15], ['enchanted_golden_apple', 1, 1, 2], ['music_disc_13', 1, 1, 15], ['music_disc_cat', 1, 1, 15], ['name_tag', 1, 1, 20], ['chainmail_chestplate', 1, 1, 10],
      ['diamond_hoe', 1, 1, 15], ['diamond_chestplate', 1, 1, 5], ['enchanted_book', 1, 1, 10]] },
    { rolls: [1, 4], items: [['iron_ingot', 1, 4, 10], ['gold_ingot', 1, 4, 5], ['bread', 1, 1, 20], ['wheat', 1, 4, 20], ['bucket', 1, 1, 10], ['redstone', 1, 4, 15], ['coal', 1, 4, 15], ['melon_seeds', 2, 4, 10],
      ['pumpkin_seeds', 2, 4, 10], ['beetroot_seeds', 2, 4, 10]] },
    junk([3, 3], 'bone', 'gunpowder', 'rotten_flesh', 'string'),
    trim('vex', 0.5),
  ] },
  // ---- End city / end ship ------------------------------------------------------------------------------------------
  end_city_treasure: { ja: 'エンドシティの宝物', pools: [
    { rolls: [2, 6], items: [['diamond', 2, 7, 5], ['iron_ingot', 4, 8, 10], ['gold_ingot', 2, 7, 15], ['emerald', 2, 6, 2], ['beetroot_seeds', 1, 10, 5], ['saddle', 1, 1, 3],
      ...['diamond_sword', 'diamond_boots', 'diamond_chestplate', 'diamond_leggings', 'diamond_helmet', 'diamond_pickaxe', 'diamond_shovel', 'iron_sword', 'iron_boots', 'iron_chestplate', 'iron_leggings', 'iron_helmet',
        'iron_pickaxe', 'iron_shovel'].map(n => [n, 1, 1, 3] as LootEntry)] },
    trim('spire', 1 / 15),
  ] },
  // ---- Bastion remnant ----------------------------------------------------------------------------------------------
  bastion_treasure: { ja: '砦の遺跡（宝物庫）', pools: [
    { rolls: [3, 3], items: [['netherite_ingot', 1, 1, 15], ['ancient_debris', 1, 1, 10], ['netherite_scrap', 1, 1, 8], ['ancient_debris', 2, 2, 4], ['diamond_sword', 1, 1, 6], ['diamond_chestplate', 1, 1, 6], ['diamond_helmet', 1, 1, 6],
      ['diamond_leggings', 1, 1, 6], ['diamond_boots', 1, 1, 6], ['diamond', 2, 6, 5], ['enchanted_golden_apple', 1, 1, 2]] },
    { rolls: [3, 4], items: [['spectral_arrow', 12, 25, 1], ['gold_block', 2, 5, 1], ['iron_block', 2, 5, 1], ['gold_ingot', 3, 9, 1], ['iron_ingot', 3, 9, 1], ['crying_obsidian', 3, 5, 1], ['quartz', 8, 23, 1],
      ['gilded_blackstone', 5, 15, 1], ['magma_cream', 3, 8, 1]] },
    trim('snout', 1 / 12), one('netherite_upgrade'),
  ] },
  bastion_hoglin_stable: { ja: '砦の遺跡（ホグリンの厩舎）', pools: [
    { rolls: [1, 1], items: [['diamond_shovel', 1, 1, 15], ['diamond_pickaxe', 1, 1, 12], ['netherite_scrap', 1, 1, 8], ['ancient_debris', 1, 1, 12], ['ancient_debris', 2, 2, 5], ['saddle', 1, 1, 12], ['gold_block', 2, 4, 16],
      ['golden_carrot', 8, 17, 10], ['golden_apple', 1, 1, 10]] },
    { rolls: [3, 4], items: [['golden_axe', 1, 1, 1], ['crying_obsidian', 1, 5, 1], ['glowstone', 3, 6, 1], ['gilded_blackstone', 2, 5, 1], ['soul_sand', 2, 7, 1], ['crimson_nylium', 2, 7, 1], ['gold_nugget', 2, 8, 1],
      ['leather', 1, 3, 1], ['arrow', 5, 17, 1], ['string', 3, 8, 1], ['porkchop', 2, 5, 1], ['cooked_porkchop', 2, 5, 1], ['crimson_fungus', 2, 7, 1], ['crimson_roots', 2, 7, 1]] },
    trim('snout', 1 / 12), one('netherite_upgrade', 0.1),
  ] },
  bastion_bridge: { ja: '砦の遺跡（橋）', pools: [
    one('lodestone'),
    { rolls: [1, 2], items: [['crossbow', 1, 1, 1], ['spectral_arrow', 10, 28, 1], ['gilded_blackstone', 8, 12, 1], ['crying_obsidian', 3, 8, 1], ['gold_block', 1, 1, 1], ['gold_ingot', 4, 9, 1], ['iron_ingot', 4, 9, 1],
      ['golden_sword', 1, 1, 1], ['golden_chestplate', 1, 1, 1], ['golden_helmet', 1, 1, 1], ['golden_leggings', 1, 1, 1], ['golden_boots', 1, 1, 1], ['golden_axe', 1, 1, 1]] },
    { rolls: [2, 4], items: [['string', 1, 6, 1], ['leather', 1, 3, 1], ['arrow', 5, 17, 1], ['iron_nugget', 2, 6, 1], ['gold_nugget', 2, 6, 1]] },
    trim('snout', 1 / 12), one('netherite_upgrade', 0.1),
  ] },
  // ---- Ancient city -------------------------------------------------------------------------------------------------
  ancient_city_ice_box: { ja: '古代都市の氷室', pools: [
    { rolls: [4, 10], items: [['suspicious_stew', 2, 6, 1], ['golden_carrot', 1, 10, 5], ['baked_potato', 1, 10, 5], ['packed_ice', 2, 6, 2], ['snowball', 2, 6, 4]] },
  ] },
};

// ---- Deterministic rolling ----------------------------------------------------------------------------------------------
const mulberry = (seed: number) => () => {
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
export function lootSeed(table: string, x: number, y: number, z: number, worldSeed: number): number {
  let h = (Math.imul(x | 0, 73856093) ^ Math.imul(y | 0, 19349663) ^ Math.imul(z | 0, 83492791) ^ Math.imul(worldSeed | 0, 1274126177)) | 0;
  for (let i = 0; i < table.length; i++) h = Math.imul(h ^ table.charCodeAt(i), 16777619);
  return h | 0;
}
/** Rolls a 27-slot chest from a room table. `stackLimit` clamps counts (the engine passes the real per-item stack size). */
export function rollRoomLoot(table: string, seed: number, stackLimit: (name: string) => number = () => 64): (LootStack | null)[] {
  const slots: (LootStack | null)[] = Array(27).fill(null), def = ROOM_LOOT[table], r = mulberry(seed);
  if (!def) return slots;
  for (const pool of def.pools) {
    if (pool.chance !== undefined && r() >= pool.chance) continue;
    const rolls = pool.rolls[0] + Math.floor(r() * (pool.rolls[1] - pool.rolls[0] + 1)), total = pool.items.reduce((s, i) => s + i[3], 0);
    for (let n = 0; n < rolls; n++) {
      let w = r() * total;
      const it = pool.items.find(i => (w -= i[3]) <= 0) ?? pool.items[0];
      let slot = Math.floor(r() * 27), guard = 0;
      while (slots[slot] && guard++ < 27) slot = (slot + 1) % 27;
      if (slots[slot]) break;
      slots[slot] = { name: it[0], count: Math.max(1, Math.min(it[1] + Math.floor(r() * (it[2] - it[1] + 1)), stackLimit(it[0]))) };
    }
  }
  return slots;
}

// ---- Markers ------------------------------------------------------------------------------------------------------------
let sink: Map<string, LootMark> | null = null;
/** The chest at (x, y, z) is filled from `table` the first time it is opened. */
export function markLoot(x: number, y: number, z: number, table: string) { sink?.set(`${x},${y},${z}`, { table }); }
/** The container at (x, y, z) (dispenser, brewing stand, item frame …) starts with exactly these stacks. */
export function markPreset(x: number, y: number, z: number, preset: (readonly [string, number] | null)[]) { sink?.set(`${x},${y},${z}`, { preset }); }
/** Runs `build` (structure builders with a null `put`) and returns every marker they emitted. */
export function collectMarks(build: () => void): Map<string, LootMark> {
  const prev = sink, out = new Map<string, LootMark>();
  sink = out;
  try { build(); } finally { sink = prev; }
  return out;
}
