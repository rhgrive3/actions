// Structures that were missing: end ship, jungle temple and igloo (Minecraft Wiki: "End City#Ship", "Jungle Pyramid", "Igloo").
import { type Put, type StructHost, bid, cell, hash2, hash3, tag, bed, stairsUp, ladderOn, attachOn, rsFacing, stoneBrick, mossyCobble, PANE_X } from './common';

interface Site { x: number; y: number; z: number }

// ======================================================================================================================
// End ship – floats beside an end city. Dragon head on the bow, a brewing stand with two Instant Health II potions and,
// in the stern of the hold, two treasure chests flanking the item frame that holds the elytra.
// ======================================================================================================================
/** Offsets from the ship origin (x = centre line, y = keel, z = bow). */
export const END_SHIP = {
  length: 25,
  dragonHead: [0, 5, -2], brewingStand: [0, 1, 12], elytraFrame: [0, 2, 21], chests: [[-1, 1, 21], [1, 1, 21]], mastTop: [0, 17, 11],
} as const;
const shipHalfWidth = (dz: number) => (dz < 0 || dz > 24 ? -1 : dz === 0 ? 0 : dz === 1 || dz === 24 ? 1 : dz <= 3 || dz >= 22 ? 2 : 3);

export function endShip(t: StructHost, put: Put, x: number, y: number, z: number) {
  const P = (dx: number, dy: number, dz: number, b: number) => put(x + dx, y + dy, z + dz, b, true);
  const purpur = bid('purpur_block', 'end_stone'), pillar = bid('purpur_pillar', 'purpur_block'), bricks = bid('end_stone_bricks', 'end_stone'), slab = bid('purpur_slab', 'purpur_block');
  const glass = bid('magenta_stained_glass', 'glass'), rod = bid('end_rod', 'torch'), obsidian = bid('obsidian');
  for (let dz = 0; dz <= 24; dz++) {
    const hw = shipHalfWidth(dz), hold = dz >= 4 && dz <= 21;
    for (let dx = -hw; dx <= hw; dx++) {
      const side = Math.abs(dx) === hw;
      if (!side || hw === 0) P(dx, 0, dz, dx === 0 ? obsidian : purpur);                               // keel
      for (let dy = 1; dy <= 3; dy++) P(dx, dy, dz, side || !hold ? (side && dz % 4 === 0 ? pillar : purpur) : 0);   // hull + hold
      P(dx, 4, dz, purpur);                                                                             // deck
      for (let dy = 5; dy <= 12; dy++) P(dx, dy, dz, 0);
      if (side && dz >= 4 && dz <= 17) P(dx, 5, dz, slab);                                              // bulwark
      if (dz >= 18) {                                                                                   // stern cabin
        const wall = side || dz === 18 || dz === 24;
        for (let dy = 5; dy <= 7; dy++) P(dx, dy, dz, wall ? (dy === 6 && side && (dz === 20 || dz === 21) ? glass : dz === 18 && dx === 0 && dy <= 6 ? 0 : purpur) : 0);
        P(dx, 8, dz, purpur);
        if (side || dz === 24) P(dx, 9, dz, slab);
      }
    }
  }
  // Bowsprit with the dragon head looking ahead.
  P(0, 5, 0, bricks); P(0, 5, -1, bricks);
  P(0, 5, -2, cell('dragon_head', 2, 'obsidian'));
  // Mast, yard and crow's nest.
  for (let dy = 5; dy <= 16; dy++) P(0, dy, 11, pillar);
  for (let dx = -3; dx <= 3; dx++) if (dx) { P(dx, 12, 11, bricks); if (Math.abs(dx) === 3) P(dx, 11, 11, rod); }
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz) P(dx, 16, 11 + dz, slab);
  P(0, 17, 11, rod);
  // Hold: hatch ladder, brewing stand, treasure chests and the elytra frame on the stern bulkhead.
  for (let dy = 1; dy <= 4; dy++) P(2, dy, 4, cell('ladder', ladderOn(0)));
  const [bx, by, bz] = END_SHIP.brewingStand;
  P(bx, by - 1, bz, obsidian); P(bx, by, bz, bid('brewing_stand', 'obsidian')); tag(t, x + bx, y + by, z + bz, 'end_ship_brewing');
  for (const [cx, cy, cz] of END_SHIP.chests) { P(cx, cy, cz, bid('chest')); tag(t, x + cx, y + cy, z + cz, 'end_city_treasure'); }
  const [fx, fy, fz] = END_SHIP.elytraFrame;
  P(fx, fy, fz, cell('item_frame', ladderOn(2), 'ladder')); tag(t, x + fx, y + fy, z + fz, 'end_ship_elytra');
  for (const dz of [8, 16]) for (const dx of [-2, 2]) P(dx, 3, dz, rod);
  P(0, 7, 21, rod);
}

// ======================================================================================================================
// Jungle temple – 12×15 mossy cobblestone pyramid. The basement holds a tripwire that fires a hidden dispenser (arrows)
// in front of the first chest, and a three-lever combination lock: only lever 1 ON, lever 2 OFF, lever 3 ON switches the
// redstone line off, so the two sticky pistons pull the wall away from the hidden vault with the second chest.
// ======================================================================================================================
/** Lever states that open the vault (index 0 = the lever next to the stairs). */
export const JUNGLE_CODE: readonly boolean[] = [true, false, true];
export interface JungleTempleParts {
  levers: [number, number, number][]; supports: [number, number, number][]; torches: [number, number, number][]; dust: [number, number, number][];
  pistons: [number, number, number][]; heads: [number, number, number][]; door: [number, number, number][]; vault: [number, number, number];
  hooks: [number, number, number][]; strings: [number, number, number][]; trapDust: [number, number, number][]; dispenser: [number, number, number];
  chests: [number, number, number][]; corridor: [number, number, number];
}
/** World coordinates of the temple's mechanisms. Plan axes: a = along (world z, 0..14), b = across (world x, 0..11). */
export function jungleTempleParts(p: Site): JungleTempleParts {
  const f = p.y - 4, W = (a: number, yy: number, b: number): [number, number, number] => [p.x - 6 + b, yy, p.z - 7 + a];
  return {
    levers: [W(1, f + 1, 5), W(2, f + 1, 5), W(3, f + 1, 5)], supports: [W(1, f + 1, 4), W(2, f + 1, 4), W(3, f + 1, 4)],
    torches: [W(1, f + 1, 3), W(3, f + 1, 3)],
    dust: [W(2, f + 1, 3), W(2, f + 1, 2), W(3, f + 1, 2), W(4, f + 1, 2), W(5, f + 1, 2), W(5, f + 1, 3)],
    pistons: [W(5, f, 4), W(5, f + 1, 4)], heads: [W(6, f, 4), W(6, f + 1, 4)], door: [W(7, f, 4), W(7, f + 1, 4)], vault: W(8, f, 1),
    hooks: [W(10, f, 4), W(10, f, 7)], strings: [W(10, f, 5), W(10, f, 6)], trapDust: [W(11, f, 8), W(12, f, 8), W(12, f, 7)], dispenser: W(12, f, 6),
    chests: [W(11, f, 5), W(8, f, 1)], corridor: W(6, f, 5),
  };
}

export function jungleTemple(t: StructHost, put: Put, p: Site) {
  const Y = p.y, f = Y - 4, x0 = p.x - 6, z0 = p.z - 7, stone = mossyCobble(t.seed + 8100), s = t.seed + 8100;
  const Q = (a: number, yy: number, b: number, block: number) => put(x0 + b, yy, z0 + a, block, true);
  const M = (a: number, yy: number, b: number) => put(x0 + b, yy, z0 + a, stone(x0 + b, yy, z0 + a), true);
  const at = (c: [number, number, number], block: number) => put(c[0], c[1], c[2], block, true);
  // Solid base (the basement is carved out of it) and the two tiers above ground.
  for (let a = 0; a <= 14; a++) for (let b = 0; b <= 11; b++) {
    for (let yy = Y - 7; yy <= Y - 1; yy++) M(a, yy, b);
    const edge = a === 0 || a === 14 || b === 0 || b === 11;
    for (let yy = Y; yy <= Y + 4; yy++) if (edge) M(a, yy, b); else Q(a, yy, b, 0);
    M(a, Y + 5, b);
    const in2 = a >= 1 && a <= 13 && b >= 1 && b <= 10, edge2 = a === 1 || a === 13 || b === 1 || b === 10;
    for (let yy = Y + 6; yy <= Y + 8; yy++) if (in2 && edge2) M(a, yy, b); else Q(a, yy, b, 0);
    if (in2) M(a, Y + 9, b);
    if (a >= 4 && a <= 10 && b >= 4 && b <= 7) M(a, Y + 10, b);
  }
  for (const b of [5, 6]) for (let yy = Y; yy <= Y + 2; yy++) Q(14, yy, b, 0);                              // entrance
  for (const b of [0, 11]) { Q(7, Y + 1, b, 0); Q(7, Y + 2, b, 0); }                                         // windows
  for (const b of [1, 10]) Q(7, Y + 7, b, 0);
  Q(0, Y + 2, 5, bid('chiseled_stone_bricks', 'stone_bricks')); Q(0, Y + 2, 6, bid('chiseled_stone_bricks', 'stone_bricks'));
  for (let i = 0; i <= 5; i++) {                                                                             // stairs to the upper floor
    Q(10 - i, Y + i, 9, cell('cobblestone_stairs', stairsUp(0), 'cobblestone'));
    for (let yy = Y; yy < Y + i; yy++) M(10 - i, yy, 9);
    for (let yy = Y + i + 1; yy <= Y + i + 3; yy++) Q(10 - i, yy, 9, 0);
  }
  // Vines on the outer walls (only where nothing else was written).
  for (let a = -1; a <= 15; a++) for (let b = -1; b <= 12; b++) {
    if (a >= 0 && a <= 14 && b >= 0 && b <= 11) continue;
    if ((a < 0 || a > 14) && (b < 0 || b > 11)) continue;
    for (let yy = Y + 1; yy <= Y + 4; yy++) if (hash3(a, yy, b, s + 1) < 0.22 && !(a === 15 && (b === 5 || b === 6))) put(x0 + b, yy, z0 + a, bid('vine', 'air'), false);
  }

  // ---- Basement -----------------------------------------------------------------------------------------------------
  const J = jungleTempleParts(p);
  for (let a = 1; a <= 11; a++) for (const b of [5, 6]) for (let yy = f; yy <= f + 2; yy++) Q(a, yy, b, 0);   // trap corridor
  for (let i = 0; i <= 3; i++) {                                                                             // stairs down from the ground floor
    Q(1, Y - 1 - i, 10 - i, cell('cobblestone_stairs', stairsUp(1), 'cobblestone'));
    for (let yy = Y - i; yy <= Y + 2 - i; yy++) Q(1, yy, 10 - i, 0);
  }
  // Three levers → NOT / pass / NOT → one dust line → two sticky pistons holding the vault wall shut.
  J.levers.forEach(c => at(c, cell('lever', attachOn(3))));
  J.torches.forEach(c => at(c, cell('redstone_torch', attachOn(1), 'torch')));
  [15, 14, 15, 14, 13, 12].forEach((power, i) => at(J.dust[i], cell('redstone_wire', power, 'air')));
  J.pistons.forEach(c => at(c, cell('sticky_piston', rsFacing(2) | 8, 'piston')));
  J.heads.forEach(c => at(c, cell('piston_head', rsFacing(2) | 8, 'oak_planks')));
  J.door.forEach(c => at(c, bid('mossy_cobblestone', 'cobblestone')));
  for (let a = 7; a <= 8; a++) for (let b = 1; b <= 3; b++) for (let yy = f; yy <= f + 1; yy++) Q(a, yy, b, 0);   // hidden vault
  at(J.chests[1], bid('chest')); tag(t, ...J.chests[1], 'jungle_temple');
  // Arrow trap: tripwire across the corridor → hook → dust → dispenser at the end of the corridor.
  at(J.hooks[0], cell('tripwire_hook', attachOn(3), 'air')); at(J.hooks[1], cell('tripwire_hook', attachOn(1), 'air'));
  J.strings.forEach(c => at(c, cell('tripwire', 1, 'air')));
  J.trapDust.forEach(c => at(c, bid('redstone_wire', 'air')));
  at(J.dispenser, cell('dispenser', rsFacing(0), 'cobblestone')); tag(t, ...J.dispenser, 'jungle_temple_dispenser');
  at(J.chests[0], bid('chest')); tag(t, ...J.chests[0], 'jungle_temple');
}

// ======================================================================================================================
// Igloo – snow dome with bed, furnace and crafting table. Half of them hide a trapdoor under the carpet: a ladder leads
// down to a stone-brick laboratory with a brewing stand (Splash Potion of Weakness), a chest (golden apple) and two cells
// holding a villager and a zombie villager.
// ======================================================================================================================
export const IGLOO_DEPTH = 14;
export const iglooHasBasement = (seed: number, x: number, z: number) => hash2(x, z, seed + 8200) < 0.5;
export interface IglooParts {
  basement: boolean; carpet: [number, number, number]; trapdoor: [number, number, number]; ladderTop: [number, number, number];
  floorY: number; brewingStand: [number, number, number]; chest: [number, number, number]; cauldron: [number, number, number];
  villager: [number, number, number]; zombieVillager: [number, number, number];
}
export function iglooParts(seed: number, p: Site): IglooParts {
  const by = p.y - IGLOO_DEPTH;
  return {
    basement: iglooHasBasement(seed, p.x, p.z), carpet: [p.x, p.y, p.z - 2], trapdoor: [p.x, p.y - 1, p.z - 2], ladderTop: [p.x, p.y - 2, p.z - 2], floorY: by,
    brewingStand: [p.x + 2, by, p.z - 1], chest: [p.x - 2, by, p.z - 1], cauldron: [p.x + 2, by, p.z], villager: [p.x - 2, by, p.z + 3], zombieVillager: [p.x + 2, by, p.z + 3],
  };
}
const domeInside = (dx: number, dy: number, dz: number) => dy >= 0 && dx * dx + dz * dz + dy * dy * 1.44 <= 6.8;

export function igloo(t: StructHost, put: Put, p: Site) {
  const y = p.y, snow = bid('snow_block'), P = (dx: number, yy: number, dz: number, b: number) => put(p.x + dx, yy, p.z + dz, b, true);
  const G = iglooParts(t.seed, p), white = bid('white_carpet', 'air'), gray = bid('light_gray_carpet', 'white_carpet');
  for (let dz = -4; dz <= 4; dz++) for (let dx = -4; dx <= 4; dx++) {
    if (dx * dx + dz * dz <= 17) { P(dx, y - 1, dz, snow); P(dx, y - 2, dz, snow); }
    for (let dy = 0; dy <= 4; dy++) {
      if (domeInside(dx, dy, dz)) { P(dx, y + dy, dz, dy === 0 ? ((dx + dz) & 1 ? gray : white) : 0); continue; }
      const shellCell = [[1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1], [0, -1, 0]].some(([ax, ay, az]) => domeInside(dx + ax, dy + ay, dz + az));
      if (shellCell) P(dx, y + dy, dz, snow);
    }
  }
  // Entrance tunnel on the south side.
  for (let dz = 3; dz <= 5; dz++) {
    P(0, y, dz, 0); P(0, y + 1, dz, 0); P(0, y - 1, dz, snow);
    if (dz > 3) for (const dx of [-1, 1]) { P(dx, y - 1, dz, snow); P(dx, y, dz, snow); P(dx, y + 1, dz, snow); }
    for (let dx = -1; dx <= 1; dx++) P(dx, y + 2, dz, snow);
  }
  P(-3, y + 1, 0, bid('ice', 'glass')); P(3, y + 1, 0, bid('ice', 'glass'));
  bed(put, p.x - 2, y, p.z, 2);
  P(2, y, -1, bid('furnace')); P(2, y, 0, bid('crafting_table')); P(1, y, 2, bid('redstone_torch', 'torch'));
  if (!G.basement) return;
  // Hidden hatch: a trapdoor set into the floor with the carpet lying on top of it.
  P(0, y - 1, -2, cell('oak_trapdoor', 4, 'oak_planks'));
  P(0, y, -2, white);
  const by = G.floorY, brick = stoneBrick(t.seed + 8201), SB = (dx: number, yy: number, dz: number) => put(p.x + dx, yy, p.z + dz, brick(p.x + dx, yy, p.z + dz), true);
  for (let yy = by - 1; yy <= by + 3; yy++) for (let dz = -3; dz <= 5; dz++) for (let dx = -3; dx <= 3; dx++) {
    const edge = Math.abs(dx) === 3 || dz === -3 || dz === 5 || yy === by - 1 || yy === by + 3;
    if (edge) SB(dx, yy, dz); else P(dx, yy, dz, 0);
  }
  for (let yy = by + 4; yy <= y - 2; yy++) for (let dz = -3; dz <= -1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dz !== -2) SB(dx, yy, dz);
  for (let yy = by; yy <= y - 2; yy++) P(0, yy, -2, cell('ladder', ladderOn(0)));
  // Two cells behind iron bars.
  for (let yy = by; yy <= by + 2; yy++) {
    for (const dx of [-2, -1, 1, 2]) P(dx, yy, 2, cell('iron_bars', PANE_X, 'stone_bricks'));
    for (let dz = 2; dz <= 4; dz++) SB(0, yy, dz);
  }
  P(G.brewingStand[0] - p.x, by, G.brewingStand[2] - p.z, bid('brewing_stand', 'cauldron')); tag(t, ...G.brewingStand, 'igloo_brewing');
  P(G.cauldron[0] - p.x, by, G.cauldron[2] - p.z, bid('cauldron', 'stone_bricks'));
  P(G.chest[0] - p.x, by, G.chest[2] - p.z, bid('chest')); tag(t, ...G.chest, 'igloo_chest');
  P(-2, by + 1, 1, cell('torch', attachOn(3))); P(2, by + 1, 1, cell('torch', attachOn(1)));
  P(0, by, 0, bid('red_carpet', 'white_carpet')); P(0, by, 1, bid('red_carpet', 'white_carpet'));
  P(-2, by + 2, -2, bid('cobweb', 'air')); P(2, by + 2, -2, bid('cobweb', 'air'));
}
