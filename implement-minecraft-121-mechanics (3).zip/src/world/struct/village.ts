// Plains village (Minecraft Wiki "Village" – plains set): meeting point with a well and a bell, small houses, a temple
// (church tower, cleric's brewing stand), a weaponsmith (lava forge, grindstone, blast furnace), and terraced farm plots
// with a water channel and a composter. Every building adapts to the terrain: the floor sits on the highest ground of its
// footprint and the gap below is closed by a stone retaining wall (small height difference) or carried on log stilts with a
// plank boardwalk (large difference). Roads follow the slope one block at a time on stone causeways and bridge water with planks.
import { type Put, type StructHost, SEA, DX, DZ, bid as bidBase, cell as cellBase, hasBlock, hash2, tag, groundY, door, bed, stairsUp, ladderOn, attachOn, PANE_X, PANE_Z } from './common';


/** Biome variants of the village (building material and roof shape). The compact core and the jigsaw extension share them. */
export type VillageVariant = 'plains' | 'desert' | 'taiga' | 'savanna' | 'snowy';
const DESERT_MAP: Record<string, string> = {
  oak_planks: 'cut_sandstone', oak_log: 'smooth_sandstone', oak_fence: 'sandstone_fence', oak_stairs: 'sandstone_stairs', oak_slab: 'sandstone_slab', oak_door: 'acacia_door',
  cobblestone: 'sandstone', mossy_cobblestone: 'cut_sandstone', cobblestone_stairs: 'sandstone_stairs', cobblestone_slab: 'sandstone_slab', dirt_path: 'smooth_sandstone',
};
/** Name of a block in a village variant (`oak_*` becomes spruce / acacia, stone becomes sandstone in the desert). */
export function variantName(v: VillageVariant, n: string): string {
  if (v === 'plains') return n;
  if (v === 'desert') return DESERT_MAP[n] ?? n;
  const wood = v === 'savanna' ? 'acacia' : 'spruce';
  return n.startsWith('oak_') ? wood + n.slice(3) : n;
}
let mapName: ((n: string) => string) | null = null;
const resolve = (name: string) => { if (!mapName) return name; const m = mapName(name); return m !== name && hasBlock(m) ? m : name; };
const bid = (name: string, fallback = 'stone') => bidBase(resolve(name), fallback);
const cell = (name: string, state = 0, fallback = 'stone') => cellBase(resolve(name), state, fallback);

export type Foundation = 'flat' | 'stone_wall' | 'boardwalk';
export interface VillageBuilding {
  kind: 'house' | 'church' | 'smithy';
  x0: number; z0: number; x1: number; z1: number;
  /** Walking level of the ground floor (the floor block is floorY - 1). */
  floorY: number;
  minGround: number; maxGround: number;
  foundation: Foundation;
  /** Door cell and the direction it opens to (0 N, 1 E, 2 S, 3 W). */
  doorX: number; doorZ: number; doorDir: number;
}
export interface VillageLayout {
  cx: number; cz: number;
  buildings: VillageBuilding[];
  farm: { x0: number; z0: number; x1: number; z1: number; terraces: number[] };
  wellY: number;
  bell: [number, number, number];
  composter: [number, number, number];
}

const LAYOUTS = new WeakMap<object, Map<string, VillageLayout>>();
const TERRACE_DEPTH = 5, FARM_W = 11;

function measure(t: StructHost, kind: VillageBuilding['kind'], x0: number, z0: number, w: number, d: number, doorX: number, doorZ: number, doorDir: number): VillageBuilding {
  let lo = Infinity, hi = -Infinity;
  for (let z = z0; z < z0 + d; z++) for (let x = x0; x < x0 + w; x++) { const g = groundY(t, x, z); if (g < lo) lo = g; if (g > hi) hi = g; }
  if (hi <= SEA) hi = SEA;                       // never build a floor under water
  const diff = hi - lo;
  return { kind, x0, z0, x1: x0 + w - 1, z1: z0 + d - 1, floorY: hi + 1, minGround: lo, maxGround: hi, foundation: diff === 0 ? 'flat' : diff <= 2 ? 'stone_wall' : 'boardwalk', doorX, doorZ, doorDir };
}

/** Deterministic plan of the village centred on (cx, cz); cached per terrain. */
export function villageLayout(t: StructHost, cx: number, cz: number): VillageLayout {
  let m = LAYOUTS.get(t);
  if (!m) { m = new Map(); LAYOUTS.set(t, m); }
  const key = cx + ',' + cz, hit = m.get(key);
  if (hit) return hit;
  const buildings = [
    measure(t, 'house', cx - 10, cz - 8, 5, 5, cx - 8, cz - 4, 2),
    measure(t, 'house', cx + 5, cz - 6, 6, 5, cx + 8, cz - 2, 2),
    measure(t, 'house', cx - 7, cz + 6, 5, 6, cx - 5, cz + 11, 2),
    measure(t, 'church', cx - 3, cz - 24, 7, 11, cx, cz - 14, 2),
    measure(t, 'smithy', cx + 13, cz + 3, 9, 7, cx + 17, cz + 3, 0),
  ];
  // Terraced farm: three plots stepping with the slope (always at least one block per terrace, at most two).
  const fx0 = cx - 22, fz0 = cz + 3, g = [0, 1, 2].map(k => Math.max(SEA, groundY(t, fx0 + 5, fz0 + k * TERRACE_DEPTH + 2)));
  const dir = g[2] - g[0] >= 0 ? 1 : -1, terraces = [g[0]];
  for (let k = 1; k < 3; k++) terraces.push(terraces[k - 1] + dir * Math.max(1, Math.min(2, Math.abs(g[k] - terraces[k - 1]))));
  const layout: VillageLayout = {
    cx, cz, buildings,
    farm: { x0: fx0, z0: fz0, x1: fx0 + FARM_W - 1, z1: fz0 + 3 * TERRACE_DEPTH - 1, terraces },
    wellY: Math.max(SEA, groundY(t, cx, cz)) + 1,
    bell: [cx + 3, Math.max(SEA, groundY(t, cx + 3, cz - 3)) + 2, cz - 3],
    composter: [cx - 11, Math.max(SEA, groundY(t, cx - 11, cz + 5)) + 1, cz + 5],
  };
  m.set(key, layout);
  return layout;
}

export function plainsVillage(t: StructHost, put: Put, cx: number, cz: number, variant: VillageVariant = 'plains') {
  mapName = variant === 'plains' ? null : (n: string) => variantName(variant, n);
  try { plainsVillageBody(t, put, cx, cz); } finally { mapName = null; }
}
function plainsVillageBody(t: StructHost, put: Put, cx: number, cz: number) {
  const L = villageLayout(t, cx, cz), seed = t.seed + 4242;
  const P = (x: number, y: number, z: number, b: number) => put(x, y, z, b, true);
  const cob = bid('cobblestone'), mossy = bid('mossy_cobblestone', 'cobblestone'), planks = bid('oak_planks'), log = bid('oak_log'), fence = bid('oak_fence', 'oak_planks');
  const slab = bid('oak_slab', 'oak_planks'), torch = bid('torch'), pathId = bid('dirt_path', 'gravel');
  const wallStone = (x: number, y: number, z: number) => (hash2(x * 7 + y, z * 13 - y, seed) < 0.3 ? mossy : cob);
  const clear = (x: number, y0: number, y1: number, z: number) => { for (let y = y0; y <= y1; y++) P(x, y, z, 0); };

  // ---- Foundations ---------------------------------------------------------------------------------------------------
  /** Closes the gap between the floor (floorY - 1) and the ground: stone wall, or log stilts under a plank deck. */
  const foundation = (b: VillageBuilding) => {
    const wood = b.foundation === 'boardwalk';
    for (let z = b.z0; z <= b.z1; z++) for (let x = b.x0; x <= b.x1; x++) {
      const g = groundY(t, x, z), edge = x === b.x0 || x === b.x1 || z === b.z0 || z === b.z1;
      if (!wood) { for (let y = g + 1; y <= b.floorY - 2; y++) P(x, y, z, edge ? wallStone(x, y, z) : cob); continue; }
      const post = edge && (((x - b.x0) % 2 === 0 && (z - b.z0) % 2 === 0) || ((x === b.x0 || x === b.x1) && (z === b.z0 || z === b.z1)));
      if (post) for (let y = g + 1; y <= b.floorY - 2; y++) P(x, y, z, log);
    }
    if (wood) {
      // Boardwalk: a plank deck along the door side, carried by fence posts.
      const w = b.doorDir, along = w === 0 || w === 2;
      for (let i = (along ? b.x0 : b.z0) - 1; i <= (along ? b.x1 : b.z1) + 1; i++) {
        const x = along ? i : b.doorX + DX[w], z = along ? b.doorZ + DZ[w] : i, g = groundY(t, x, z);
        P(x, b.floorY - 1, z, planks);
        clear(x, b.floorY, b.floorY + 2, z);
        if ((i & 1) === 0) for (let y = g + 1; y <= b.floorY - 2; y++) P(x, y, z, fence);
      }
    }
  };
  /** Landing in front of the door and steps down to the ground. Returns the last cell and the level of its top block. */
  const approach = (b: VillageBuilding): [number, number, number] => {
    const w = b.doorDir, wood = b.foundation === 'boardwalk', stairs = cell(wood ? 'oak_stairs' : 'cobblestone_stairs', stairsUp((w + 2) & 3), wood ? 'oak_planks' : 'cobblestone');
    let x = b.doorX + DX[w], z = b.doorZ + DZ[w], level = b.floorY;
    const support = (y1: number) => { for (let y = groundY(t, x, z) + 1; y <= y1; y++) P(x, y, z, wood ? fence : wallStone(x, y, z)); };
    P(x, level - 1, z, groundY(t, x, z) >= level - 1 ? pathId : wood ? planks : cob);
    support(level - 2);
    clear(x, level, level + 2, z);
    for (let k = 0; k < 12; k++) {
      const nx = x + DX[w], nz = z + DZ[w];
      if (level - 1 <= Math.max(SEA, groundY(t, nx, nz))) break;
      x = nx; z = nz; level--;
      P(x, level, z, stairs);
      support(level - 1);
      clear(x, level + 1, level + 3, z);
    }
    return [x, z, level - 1];
  };
  /** Road cells in walking order; the surface never steps more than one block (stone causeway up, cutting down). */
  const road = (cells: [number, number][], prev: number | null = null) => {
    for (const [x, z] of cells) {
      const g = groundY(t, x, z);
      if (g < SEA) { P(x, SEA, z, planks); clear(x, SEA + 1, SEA + 3, z); prev = SEA; continue; }   // plank bridge over water
      const y = prev === null ? g : Math.max(prev - 1, Math.min(prev + 1, g));
      for (let yy = g + 1; yy < y; yy++) P(x, yy, z, wallStone(x, yy, z));
      P(x, y, z, pathId);
      if (y !== g) clear(x, y + 1, Math.max(y, g) + 3, z);
      prev = y;
    }
  };
  const line = (x0: number, z0: number, x1: number, z1: number): [number, number][] => {
    const out: [number, number][] = [], n = Math.max(Math.abs(x1 - x0), Math.abs(z1 - z0)), sx = Math.sign(x1 - x0), sz = Math.sign(z1 - z0);
    for (let i = 0; i <= n; i++) out.push([x0 + sx * i, z0 + sz * i]);
    return out;
  };

  // ---- Roads ---------------------------------------------------------------------------------------------------------
  road(line(cx + 2, cz, cx + 22, cz)); road(line(cx - 2, cz, cx - 22, cz));
  road(line(cx, cz - 2, cx, cz - 12)); road(line(cx, cz + 2, cx, cz + 14));
  for (const b of L.buildings) {
    foundation(b);
    const [ex, ez, ey] = approach(b), w = b.doorDir;
    let cells: [number, number][] = [];
    if (b.kind === 'house' && b.z0 > cz) cells = line(ex, ez + 1, ex, ez + 1).concat(line(ex + 1, ez + 1, cx, ez + 1));          // house south of the road: around to the Z road
    else if (w === 2) cells = ez + 1 <= cz - 1 ? line(ex, ez + 1, ex, cz - 1) : [];
    else if (w === 0) cells = ez - 1 >= cz + 1 ? line(ex, ez - 1, ex, cz + 1) : [];
    road(cells, ey);
  }

  // ---- Meeting point: well + bell ------------------------------------------------------------------------------------
  {
    const wy = L.wellY;
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      const x = cx + dx, z = cz + dz, corner = Math.abs(dx) === 1 && Math.abs(dz) === 1;
      for (let y = groundY(t, x, z) + 1; y < wy - 1; y++) P(x, y, z, mossy);
      P(x, wy - 1, z, mossy);
      P(x, wy, z, dx === 0 && dz === 0 ? bid('water') : mossy);
      P(x, wy + 1, z, corner ? fence : 0); P(x, wy + 2, z, corner ? fence : 0);
      P(x, wy + 3, z, corner || (dx === 0 && dz === 0) ? planks : slab);
    }
    const [bx, by, bz] = L.bell;
    for (const dx of [-1, 1]) {
      for (let y = groundY(t, bx + dx, bz) + 1; y < by - 1; y++) P(bx + dx, y, bz, cob);
      P(bx + dx, by - 1, bz, fence); P(bx + dx, by, bz, fence);
    }
    for (let dx = -1; dx <= 1; dx++) P(bx + dx, by + 1, bz, dx === 0 ? planks : slab);
    P(bx, by - 1, bz, 0);
    P(bx, by, bz, bid('bell', 'gold_block'));
    for (const [dx, dz] of [[5, 1], [-12, -1], [1, -12], [12, 1], [1, 12]]) {
      const x = cx + dx, z = cz + dz, y = Math.max(SEA, groundY(t, x, z)) + 1;
      P(x, y, z, fence); P(x, y + 1, z, fence); P(x, y + 2, z, bid('lantern', 'torch'));
    }
  }

  // ---- Buildings -----------------------------------------------------------------------------------------------------
  for (const b of L.buildings) {
    const y = b.floorY, w = b.x1 - b.x0 + 1, d = b.z1 - b.z0 + 1;
    const at = (lx: number, dy: number, lz: number, block: number) => P(b.x0 + lx, y + dy, b.z0 + lz, block);
    if (b.kind === 'house') {
      for (let lz = 0; lz < d; lz++) for (let lx = 0; lx < w; lx++) {
        const ex = lx === 0 || lx === w - 1, ez = lz === 0 || lz === d - 1;
        at(lx, -1, lz, cob);
        for (let dy = 0; dy < 3; dy++) {
          let id = ex && ez ? log : ex || ez ? planks : 0;
          if (dy === 1 && (ex !== ez)) {
            if (ez && (lx === 1 || lx === w - 2) && !(lz === d - 1 && lx === (w >> 1))) id = cell('glass_pane', PANE_X, 'glass');
            if (ex && (lz === 1 || lz === d - 2)) id = cell('glass_pane', PANE_Z, 'glass');
          }
          at(lx, dy, lz, id);
        }
      }
      for (let lz = -1; lz <= d; lz++) for (let lx = -1; lx <= w; lx++) at(lx, 3, lz, planks);
      for (let lz = 0; lz < d; lz++) for (let lx = 0; lx < w; lx++) at(lx, 4, lz, planks);
      for (let lz = 1; lz < d - 1; lz++) for (let lx = 1; lx < w - 1; lx++) at(lx, 5, lz, slab);
      const chimney = hash2(b.x0, b.z0, seed) < 0.5 ? 1 : w - 2;
      for (let dy = 4; dy <= 6; dy++) at(chimney, dy, 1, cob);
      door(put, b.doorX, y, b.doorZ, 'oak_door', 2);
      bed(put, b.x0 + 1, y, b.z0 + 1, 0);
      at(w - 2, 0, 1, bid('crafting_table'));
      at(w - 2, 0, d - 2, bid('chest'));
      tag(t, b.x0 + w - 2, y, b.z0 + d - 2, 'village_plains_house');
      at(w >> 1, 2, 1, cell('torch', attachOn(0)));
    } else if (b.kind === 'church') {
      // Nave (lz 4..10, five blocks high) with a 7×5 bell tower (lz 0..4, eleven blocks high) behind the altar.
      for (let lz = 0; lz <= 10; lz++) for (let lx = 0; lx <= 6; lx++) {
        const tower = lz <= 4, top = tower ? 10 : 4, ex = lx === 0 || lx === 6, ez = lz === 0 || lz === 10 || lz === 4;
        at(lx, -1, lz, cob);
        for (let dy = 0; dy <= top; dy++) {
          let id = ex || lz === 0 || lz === 10 || (lz === 4 && (dy > 4 || !(lx === 3 && dy <= 2))) ? wallStone(b.x0 + lx, y + dy, b.z0 + lz) : 0;
          if (lz === 4 && lx === 3 && dy <= 2) id = 0;                                                    // archway nave → tower
          if (!tower && ex && (lz === 6 || lz === 8) && (dy === 1 || dy === 2)) id = cell('glass_pane', PANE_Z, 'glass');
          if (tower && ex && lz === 2 && (dy === 7 || dy === 8)) id = cell('glass_pane', PANE_Z, 'glass');
          if (lz === 10 && lx === 3 && dy === 3) id = cell('glass_pane', PANE_X, 'glass');
          if (lz === 4 && lx === 3 && (dy === 7 || dy === 8)) id = cell('glass_pane', PANE_X, 'glass');
          void ez;
          at(lx, dy, lz, id);
        }
        if (!tower) { at(lx, 5, lz, cob); if (lx >= 1 && lx <= 5 && lz >= 6 && lz <= 9) at(lx, 6, lz, bid('cobblestone_slab', 'cobblestone')); }
        else {
          at(lx, 11, lz, cob);
          if ((ex || lz === 0 || lz === 4) && (lx + lz) % 2 === 0) at(lx, 12, lz, cob);                  // battlements
        }
      }
      for (let dy = 0; dy <= 11; dy++) at(3, dy, 1, cell('ladder', ladderOn(0)));                        // ladder up the tower
      door(put, b.doorX, y, b.doorZ, 'oak_door', 2);
      at(2, 0, 5, bid('brewing_stand'));                                                                  // cleric's job site
      at(4, 0, 5, bid('chest')); tag(t, b.x0 + 4, y, b.z0 + 5, 'village_temple');
      for (const lz of [7, 9]) for (const lx of [1, 2, 4, 5]) at(lx, 0, lz, cell('oak_stairs', stairsUp(2), 'oak_planks'));   // pews face the altar
      at(1, 3, 6, cell('torch', attachOn(3))); at(5, 3, 6, cell('torch', attachOn(1)));
      at(1, 3, 9, cell('torch', attachOn(3))); at(5, 3, 9, cell('torch', attachOn(1)));
      at(2, 4, 2, torch);
    } else {
      // Weaponsmith: open porch (lz 0..1) with the lava forge, closed workshop (lz 2..6) behind it.
      for (let lz = 0; lz <= 6; lz++) for (let lx = 0; lx <= 8; lx++) {
        at(lx, -1, lz, cob);
        const room = lz >= 2, ex = lx === 0 || lx === 8, ez = lz === 2 || lz === 6;
        for (let dy = 0; dy <= 3; dy++) {
          let id = 0;
          if (room && (ex || ez)) {
            id = ex && ez ? log : dy === 0 || (lz === 2 && lx >= 5) ? cob : planks;
            if (dy === 1 && lz === 6 && (lx === 3 || lx === 5)) id = cell('glass_pane', PANE_X, 'glass');
            if (dy === 1 && lx === 8 && lz === 4) id = cell('glass_pane', PANE_Z, 'glass');
          }
          at(lx, dy, lz, id);
        }
        at(lx, 4, lz, bid('cobblestone_slab', 'cobblestone'));
      }
      for (let dy = 0; dy <= 3; dy++) { at(0, dy, 0, fence); at(8, dy, 0, fence); }
      // Forge: two lava blocks walled in by cobblestone, iron bars towards the porch.
      at(5, 0, 1, cob); at(8, 0, 1, cob); at(5, 0, 0, cob); at(8, 0, 0, fence);
      at(6, 0, 1, bid('lava')); at(7, 0, 1, bid('lava'));
      at(6, 0, 0, cell('iron_bars', PANE_X, 'cobblestone')); at(7, 0, 0, cell('iron_bars', PANE_X, 'cobblestone'));
      at(4, 0, 1, bid('furnace'));
      at(1, 0, 1, bid('anvil', 'iron_block'));
      door(put, b.x0 + 2, y, b.z0 + 2, 'oak_door', 0);
      at(7, 0, 3, bid('blast_furnace', 'furnace'));
      at(7, 0, 5, bid('grindstone', 'cobblestone'));                                                       // weaponsmith's job site
      at(1, 0, 3, bid('smithing_table', 'crafting_table'));
      at(1, 0, 5, bid('chest')); tag(t, b.x0 + 1, y, b.z0 + 5, 'village_weaponsmith');
      at(4, 2, 5, cell('torch', attachOn(2)));
    }
  }

  // ---- Terraced farm -------------------------------------------------------------------------------------------------
  {
    const F = L.farm, crops = ['wheat_crop', 'carrots', 'potatoes'];
    for (let k = 0; k < 3; k++) {
      const Y = F.terraces[k], z0 = F.z0 + k * TERRACE_DEPTH;
      for (let lz = 0; lz < TERRACE_DEPTH; lz++) for (let lx = 0; lx < FARM_W; lx++) {
        const x = F.x0 + lx, z = z0 + lz, g = groundY(t, x, z), edge = lx === 0 || lx === FARM_W - 1 || lz === 0 || lz === TERRACE_DEPTH - 1;
        for (let y = Math.min(g, Y - 1) + 1; y < Y; y++) P(x, y, z, edge ? wallStone(x, y, z) : bid('dirt'));   // retaining wall + soil
        if (g < Y - 1 && g < SEA) for (let y = g + 1; y < Y; y++) P(x, y, z, edge ? wallStone(x, y, z) : bid('dirt'));
        clear(x, Y + 1, Math.max(Y, g) + 3, z);
        if (edge) { P(x, Y, z, log); continue; }
        if (lz === 2) { P(x, Y - 1, z, bid('dirt')); P(x, Y, z, bid('water')); continue; }                 // irrigation channel
        P(x, Y, z, bid('farmland_moist', 'farmland'));
        const age = k === 0 ? 2 + Math.floor(hash2(x, z, seed + 9) * 6) : Math.floor(hash2(x, z, seed + 9) * 4);
        P(x, Y + 1, z, cell(crops[k], age, 'wheat_crop'));
      }
    }
    const [qx, qy, qz] = L.composter;
    for (let y = groundY(t, qx, qz) + 1; y < qy; y++) P(qx, y, qz, cob);
    P(qx, qy, qz, bid('composter', 'oak_planks'));
    clear(qx, qy + 1, qy + 2, qz);
  }
}
