// Grand village (Minecraft Wiki "Village" – plains / desert / taiga / savanna / snowy sets, assembled like vanilla's jigsaw villages).
// The compact core (meeting point with well and bell, church, weaponsmith, three houses and the terraced farm of `village.ts`) stays
// the centre. Its three road ends are jigsaw connectors: the assembler (`jigsaw.ts`) grows 3-wide streets from them and hangs
// houses (small / medium / large), job-site buildings (library, butcher, cartographer, armorer, tannery, shepherd, fletcher, mason,
// toolsmith), a stable, terraced farms, animal pens and street lamps on the street sides – drawn by weight from the pools,
// rotated to face the street, collision-checked as strict AABBs (one free block between buildings).
//
// Terrain: every building's floor sits on the highest ground of its footprint, the gap below is closed by a (mossy) cobblestone
// foundation – or log stilts when it is more than three blocks deep –, the door is reached by 1–2 steps, streets follow the
// ground one block at a time with stairs, and cross water on plank bridges; steep streets become plank boardwalks on fences.
import { type Put, type StructHost, SEA, bid, cell, hash2, tag, groundY, door, bed, stairsUp, PANE_X, PANE_Z, hasBlock } from './common';
import { plainsVillage, villageLayout, variantName, type VillageLayout, type VillageVariant } from './village';
import { growJigsaw, rotSize, toWorld, toWorldXZ, worldDir, type Box, type Connector, type PieceDef, type Placed, type Pool } from './jigsaw';
import { chest, itemFrame, lantern, lectern, pottedPlant, carpet, barrel, facingState } from './decor';

export type { VillageVariant };
export type Role = 'home' | 'library' | 'butcher' | 'cartographer' | 'armorer' | 'tannery' | 'shepherd' | 'fletcher' | 'mason' | 'toolsmith' | 'stable';
export const VILLAGE_ROLE_TABLE: Record<Role, string> = {
  home: '', library: 'village_library', butcher: 'village_butcher', cartographer: 'village_cartographer', armorer: 'village_armorer', tannery: 'village_tannery',
  shepherd: 'village_shepherd', fletcher: 'village_fletcher', mason: 'village_mason', toolsmith: 'village_toolsmith', stable: 'village_stable',
};
export const VILLAGE_HOUSE_TABLE: Record<VillageVariant, string> = {
  plains: 'village_plains_house', desert: 'village_desert_house', taiga: 'village_taiga_house', savanna: 'village_savanna_house', snowy: 'village_snowy_house',
};

interface Pal {
  planks: number; log: number; fence: number; stairs: string; slab: string; doorName: string; path: number; glass: number;
  flat: boolean; wallA: number; wallB: number; trim: number; snow: boolean; wool: string; crop: string[];
}
const palette = (v: VillageVariant): Pal => {
  const n = (name: string) => variantName(v, name);
  return {
    planks: bid(n('oak_planks')), log: bid(n('oak_log')), fence: bid(n('oak_fence'), 'oak_planks'), stairs: n('oak_stairs'), slab: n('oak_slab'), doorName: n('oak_door'),
    path: bid(n('dirt_path'), 'gravel'), glass: bid('glass_pane', 'glass'), flat: v === 'desert' || v === 'savanna',
    wallA: bid(n('cobblestone')), wallB: bid(n('mossy_cobblestone'), 'cobblestone'),
    trim: v === 'desert' ? bid('orange_terracotta', 'terracotta') : v === 'savanna' ? bid('red_terracotta', 'terracotta') : bid(n('oak_log')),
    snow: v === 'snowy', wool: v === 'desert' ? 'orange' : v === 'savanna' ? 'yellow' : v === 'snowy' ? 'light_blue' : 'red',
    crop: v === 'desert' ? ['wheat_crop', 'carrots'] : v === 'snowy' ? ['potatoes', 'carrots'] : ['wheat_crop', 'carrots', 'potatoes'],
  };
};
export const villageVariantFor = (biome: string): VillageVariant =>
  biome === 'desert' ? 'desert' : /snow|frozen|ice|grove/.test(biome) ? 'snowy' : /savanna/.test(biome) ? 'savanna' : /taiga|pine|spruce/.test(biome) ? 'taiga' : 'plains';

// ---- Piece templates --------------------------------------------------------------------------------------------------
/** Local frame: the front (street side) is local north (-z); a building's door is on its first body row behind a 2-deep porch. */
const PORCH = 2;
const con = (x: number, z: number, dir: number, name: string, target: string, pool: string): Connector => ({ x, y: 0, z, dir, name, target, pool });
const streetDef = (len: number, branch = false): PieceDef => {
  const cs: Connector[] = [con(1, 0, 0, branch ? 'front' : 'street_end', branch ? 'side' : 'street_end', ''), con(1, len - 1, 2, 'street_end', 'street_end', 'streets')];
  for (let z = 2; z < len - 1; z += 4) { cs.push(con(0, z, 3, 'side', 'front', 'frontage'), con(2, z, 1, 'side', 'front', 'frontage')); }
  return { id: (branch ? 'branch_' : 'street_') + len, kind: 'street', size: [3, 1, len], connectors: cs, terrain: true };
};
const buildingDef = (id: string, kind: string, w: number, l: number, role: Role, max?: number): PieceDef => ({
  id, kind, size: [w, 12, l + PORCH], terrain: true, pad: 1, max,
  connectors: [con(w >> 1, 0, 0, 'front', 'side', ''), con(w >> 1, l + PORCH - 1, 2, 'rear', 'rear', 'backyard')],
  ...({ role } as object),
}) as PieceDef;
const roleOf = (d: PieceDef) => ((d as unknown as { role: Role }).role);
const plotDef = (id: string, kind: string, w: number, l: number, max: number): PieceDef => ({
  id, kind, size: [w, 4, l], terrain: true, pad: 1, max,
  connectors: [con(w >> 1, 0, 0, 'front', 'side', ''), con(w >> 1, 0, 0, 'rear', 'rear', '')],
});
const lampDef: PieceDef = { id: 'lamp', kind: 'lamp', size: [1, 5, 1], terrain: true, max: 18, connectors: [con(0, 0, 0, 'front', 'side', '')] };

const HOUSES = [buildingDef('house_small', 'house', 5, 5, 'home'), buildingDef('house_medium', 'house', 7, 6, 'home'), buildingDef('house_large', 'house', 9, 8, 'home', 6)];
const PROS: PieceDef[] = ([['library', 7, 6], ['butcher', 7, 6], ['cartographer', 5, 6], ['armorer', 7, 6], ['tannery', 7, 7], ['shepherd', 7, 6], ['fletcher', 5, 5], ['mason', 7, 6], ['toolsmith', 7, 6]] as [Role, number, number][])
  .map(([r, w, l]) => buildingDef('pro_' + r, 'pro', w, l, r, 1));
const STABLE = buildingDef('stable', 'stable', 9, 7, 'stable', 1);
const FARM = plotDef('farm', 'farm', 9, 11, 4), PEN = plotDef('pen', 'pen', 7, 7, 3);
const STREETS = [6, 9, 12, 15].map(l => streetDef(l)), BRANCHES = [9, 12].map(l => streetDef(l, true));
const POOLS: Record<string, Pool> = {
  streets: { entries: STREETS.map((d, i) => ({ def: d, weight: [3, 5, 4, 2][i] })), fallback: '' },
  frontage: {
    entries: [
      ...HOUSES.map((d, i) => ({ def: d, weight: [16, 11, 6][i] })), ...PROS.map(d => ({ def: d, weight: 4 })), { def: STABLE, weight: 3 },
      { def: FARM, weight: 6 }, { def: PEN, weight: 4 }, ...BRANCHES.map(d => ({ def: d, weight: 3 })),
    ],
    fallback: 'lamps',
  },
  backyard: { entries: [{ def: FARM, weight: 5 }, { def: PEN, weight: 5 }, { def: HOUSES[0], weight: 3 }], fallback: 'lamps' },
  lamps: { entries: [{ def: lampDef, weight: 1 }] },
};
// Pieces of the 'frontage' pool that connect to a street also need to accept being attached to a building's back yard ('rear').
for (const d of [HOUSES[0]]) d.connectors[0] = con(d.size[0] >> 1, 0, 0, 'front', 'side', '');
HOUSES[0].connectors.push(con(2, 0, 0, 'rear', 'rear', ''));

// ---- Layout -----------------------------------------------------------------------------------------------------------
export interface GrandVillageLayout {
  cx: number; cz: number; variant: VillageVariant; core: VillageLayout;
  pieces: Placed[];
  /** Pieces a villager can live or work in (houses, job sites, stable) plus farms and pens are listed separately. */
  buildings: Placed[];
  /** Total number of structures: core buildings + jigsaw buildings, farms and pens. */
  count: number;
  bounds: Box;
}
const RADIUS = 60;
const LAYOUTS = new Map<string, GrandVillageLayout>();
const gkey = (x: number, z: number) => x + ',' + z;

function attempt(t: StructHost, cx: number, cz: number, core: VillageLayout, variant: VillageVariant, seed: number): Placed[] {
  const road = (x: number, z: number) => Math.max(SEA, groundY(t, x, z));
  const occupied: Box[] = core.buildings.map(b => [b.x0 - 1, 0, b.z0 - 1, b.x1 + 1, 511, b.z1 + 1] as Box);
  occupied.push([core.farm.x0 - 1, 0, core.farm.z0 - 1, core.farm.x1 + 1, 511, core.farm.z1 + 1], [cx - 3, 0, cz - 4, cx + 5, 511, cz + 3], [cx - 12, 0, cz + 4, cx - 10, 511, cz + 6]);
  const roots = [
    { x: cx + 22, y: road(cx + 22, cz), z: cz, dir: 1, target: 'street_end', pool: 'streets' },
    { x: cx - 22, y: road(cx - 22, cz), z: cz, dir: 3, target: 'street_end', pool: 'streets' },
    { x: cx, y: road(cx, cz + 14), z: cz + 14, dir: 2, target: 'street_end', pool: 'streets' },
  ];
  const finalize = (p: Placed, _parent: Placed | null, at: { y: number }) => {
    const def = p.def, [W, L] = rotSize(def, p.rot);
    if (def.kind === 'street') {
      const ys = new Map<string, number>(), cs: number[] = [];
      let water = 0;
      for (let lz = 0; lz < def.size[2]; lz++) {
        const [x, z] = toWorldXZ(def, p.rot, p.bx, p.bz, 1, lz), g = groundY(t, x, z);
        if (g < SEA) water++;
        const y = Math.max(SEA, g);
        if (lz === 0 ? Math.abs(y - at.y) > 1 : Math.abs(y - cs[lz - 1]) > 1) return false;
        cs.push(y);
        for (let lx = 0; lx < 3; lx++) { const [wx, wz] = toWorldXZ(def, p.rot, p.bx, p.bz, lx, lz); ys.set(gkey(wx, wz), y); }
      }
      if (water > 3) return false;
      p.meta.ys = ys; p.meta.cs = cs; p.meta.wood = Math.max(...cs) - Math.min(...cs) >= 3;
      p.meta.surface = (x: number, z: number) => ys.get(gkey(x, z)) ?? at.y;
      return true;
    }
    let lo = Infinity, hi = -Infinity, wet = 0, n = 0;
    for (let z = p.bz; z < p.bz + L; z++) for (let x = p.bx; x < p.bx + W; x++) {
      const g = groundY(t, x, z); n++;
      if (g < SEA) wet++;
      if (g < lo) lo = g; if (g > hi) hi = g;
    }
    if (def.kind === 'lamp') { p.meta.floorY = Math.max(SEA, hi) + 1; return Math.abs(p.meta.floorY - 1 - at.y) <= 2; }
    if (wet > n * 0.25) return false;
    const walk = at.y + 1, floorY = Math.max(Math.max(SEA, hi) + 1, walk), diff = floorY - walk;
    if (diff > 2 || floorY - lo > 8) return false;
    Object.assign(p.meta, { floorY, lo, hi, diff, stilts: floorY - lo > 3 });
    p.meta.surface = () => floorY - 1;
    return true;
  };
  return growJigsaw({ seed, pools: POOLS, occupied, roots, maxDepth: 16, maxPieces: 150, bounds: { cx, cz, r: RADIUS }, finalize });
}

const isBuilding = (p: Placed) => p.def.kind === 'house' || p.def.kind === 'pro' || p.def.kind === 'stable';
/** Deterministic plan of the grand village around (cx, cz) – several seeds are tried and the one with the most buildings wins. */
export function grandVillageLayout(t: StructHost, cx: number, cz: number, variant: VillageVariant = 'plains'): GrandVillageLayout {
  const key = t.seed + ':' + cx + ',' + cz + ':' + variant, hit = LAYOUTS.get(key);
  if (hit) return hit;
  const core = villageLayout(t, cx, cz);
  let best: Placed[] = [], bestN = -1;
  for (let k = 0; k < 14; k++) {
    const pieces = attempt(t, cx, cz, core, variant, Math.imul(t.seed | 0, 2654435761) ^ Math.imul(cx, 40503) ^ Math.imul(cz, 65599) ^ (k * 7919));
    const n = core.buildings.length + pieces.filter(p => isBuilding(p) || p.def.kind === 'farm' || p.def.kind === 'pen').length;
    const roles = new Set(pieces.filter(p => p.def.kind === 'pro').map(p => roleOf(p.def))).size;
    const score = n + roles * 0.5;
    if (score > bestN) { best = pieces; bestN = score; }
    if (n >= 22 && roles >= 3) break;
  }
  const L: GrandVillageLayout = {
    cx, cz, variant, core, pieces: best, buildings: best.filter(isBuilding),
    count: core.buildings.length + best.filter(p => isBuilding(p) || p.def.kind === 'farm' || p.def.kind === 'pen').length,
    bounds: [cx - RADIUS, 0, cz - RADIUS, cx + RADIUS, 511, cz + RADIUS],
  };
  if (LAYOUTS.size > 12) LAYOUTS.clear();
  LAYOUTS.set(key, L);
  return L;
}

// ---- Building ---------------------------------------------------------------------------------------------------------
interface Ctx { t: StructHost; put: Put; p: Placed; pal: Pal; variant: VillageVariant; fy: number; P: (lx: number, ly: number, lz: number, id: number) => void; D: (d: number) => number; rnd: (lx: number, lz: number, s?: number) => number }
function makeCtx(t: StructHost, put: Put, p: Placed, pal: Pal, variant: VillageVariant): Ctx {
  const fy = (p.meta.floorY as number) ?? 0;
  return {
    t, put, p, pal, variant, fy,
    P: (lx, ly, lz, id) => { const [x, y, z] = toWorld(p, lx, fy + ly, lz); put(x, y, z, id, true); },
    D: d => worldDir(p, d),
    rnd: (lx, lz, s = 0) => { const [x, , z] = toWorld(p, lx, 0, lz); return hash2(x + s * 31, z - s * 17, t.seed + 5151); },
  };
}
const stone = (c: Ctx, x: number, y: number, z: number) => (hash2(x * 7 + y, z * 13 - y, c.t.seed + 4243) < 0.3 ? c.pal.wallB : c.pal.wallA);
/** Column from the ground up to `top` (inclusive) in foundation stone. */
function support(c: Ctx, x: number, z: number, top: number, wood = false) {
  for (let y = groundY(c.t, x, z) + 1; y <= top; y++) c.put(x, y, z, wood ? c.pal.log : stone(c, x, y, z), true);
}

function buildStreet(c: Ctx) {
  const { p, pal, put } = c, def = p.def, cs = p.meta.cs as number[], wood = p.meta.wood as boolean, len = def.size[2];
  const plank = pal.planks, stairs = (dir: number) => cell(pal.stairs, stairsUp(dir), 'cobblestone_stairs');
  for (let lz = 0; lz < len; lz++) {
    const y = cs[lz];
    for (let lx = 0; lx < 3; lx++) {
      const [x, , z] = toWorld(p, lx, 0, lz), g = groundY(c.t, x, z);
      const bridge = groundY(c.t, ...toWorldXZ(def, p.rot, p.bx, p.bz, 1, lz)) < SEA;
      if (bridge) {                                                        // plank bridge over water with fence rails
        put(x, SEA, z, plank, true);
        for (let h = 1; h <= 3; h++) put(x, SEA + h, z, lx === 1 || h > 1 ? 0 : pal.fence, true);
        if (lx !== 1 && lz % 3 === 0) for (let yy = Math.max(g, SEA - 6); yy < SEA; yy++) put(x, yy, z, pal.fence, true);
        continue;
      }
      for (let yy = g + 1; yy < y; yy++) put(x, yy, z, wood ? (lx === 1 ? 0 : pal.fence) : stone(c, x, yy, z), true);
      put(x, y, z, wood ? plank : pal.path, true);
      for (let yy = y + 1; yy <= Math.max(y, g) + 3; yy++) put(x, yy, z, 0, true);
      if (wood && lx !== 1 && lz % 2 === 0) put(x, y + 1, z, pal.fence, true);
    }
  }
  // Stairs on the one-block steps (the high side points up the slope).
  for (let lz = 1; lz < len; lz++) {
    const d = cs[lz] - cs[lz - 1];
    if (d === 0) continue;
    for (let lx = 0; lx < 3; lx++) {
      const [x, y, z] = toWorld(p, lx, d > 0 ? cs[lz] : cs[lz - 1], d > 0 ? lz : lz - 1);
      put(x, y, z, stairs(c.D(d > 0 ? 2 : 0)), true);
    }
  }
  // Street furniture: a lantern post on the lower-left edge of long streets.
  if (len >= 9) for (const lz of [len >> 1]) { const [x, y, z] = toWorld(p, 0, cs[lz] + 1, lz); put(x, y, z, pal.fence, true); put(x, y + 1, z, pal.fence, true); lantern(put, x, y + 2, z); }
}

function buildLamp(c: Ctx) {
  const { pal } = c, y = c.fy - 1, [x, , z] = toWorld(c.p, 0, 0, 0), g = groundY(c.t, x, z);
  for (let yy = g + 1; yy < y; yy++) c.put(x, yy, z, stone(c, x, yy, z), true);
  c.P(0, -1, 0, pal.wallA); c.P(0, 0, 0, pal.fence); c.P(0, 1, 0, pal.fence); c.P(0, 2, 0, pal.fence);
  const [lx, ly, lz] = toWorld(c.p, 0, c.fy + 3, 0); lantern(c.put, lx, ly, lz);
  for (let h = 4; h <= 4; h++) c.P(0, h, 0, 0);
}

function buildBuilding(c: Ctx) {
  const { p, pal, put, variant } = c, def = p.def, role = roleOf(def), [w, , len] = def.size, l = len - PORCH, diff = p.meta.diff as number, stilts = p.meta.stilts as boolean;
  const dx = w >> 1, back = len - 1, wallH = 4, front = PORCH;
  const gableH = pal.flat ? 1 : ((w + 1) >> 1);
  const paneAlongX = p.rot % 2 === 0 ? PANE_X : PANE_Z, paneAlongZ = p.rot % 2 === 0 ? PANE_Z : PANE_X;
  const floor = role === 'stable' ? bid('dirt') : pal.planks;
  const wd = c.D;
  // 1. Clear the volume, lay foundation + floor.
  for (let lz = 0; lz < len; lz++) for (let lx = 0; lx < w; lx++) for (let ly = 0; ly < wallH + gableH + 3; ly++) c.P(lx, ly, lz, 0);
  for (let lz = front; lz < len; lz++) for (let lx = 0; lx < w; lx++) {
    const [x, , z] = toWorld(p, lx, 0, lz), edge = lx === 0 || lx === w - 1 || lz === front || lz === back;
    const post = edge && (((lx % 2 === 0) && ((lz - front) % 2 === 0)) || ((lx === 0 || lx === w - 1) && (lz === front || lz === back)));
    if (stilts) { if (post) support(c, x, z, c.fy - 2, true); }
    else for (let y = groundY(c.t, x, z) + 1; y <= c.fy - 2; y++) put(x, y, z, edge ? stone(c, x, y, z) : pal.wallA, true);
    c.P(lx, -1, lz, floor);
  }
  // 2. Porch: steps from the street up to the door (diff 0–2).
  for (let lz = 0; lz < front; lz++) {
    const [x, , z] = toWorld(p, dx, 0, lz);
    const level = lz === 1 ? c.fy - 1 : c.fy - 1 - diff + (diff === 2 ? 0 : 0);
    const top = diff === 0 ? c.fy - 1 : lz === 1 ? c.fy - 1 : c.fy - 1 - (diff - 1);
    void level;
    support(c, x, z, top - 1, stilts);
    if (diff === 0) { put(x, c.fy - 1, z, stilts ? pal.planks : pal.wallA, true); }
    else if (diff === 1) put(x, top, z, lz === 0 ? cell(pal.stairs, stairsUp(wd(2)), 'cobblestone_stairs') : pal.planks, true);
    else put(x, top, z, cell(pal.stairs, stairsUp(wd(2)), 'cobblestone_stairs'), true);
  }
  // 3. Walls, windows, door.
  for (let ly = 0; ly < wallH; ly++) for (let lz = front; lz < len; lz++) for (let lx = 0; lx < w; lx++) {
    const edge = lx === 0 || lx === w - 1 || lz === front || lz === back;
    if (!edge) continue;
    const corner = (lx === 0 || lx === w - 1) && (lz === front || lz === back);
    let id = corner ? pal.log : pal.planks;
    if (!corner && ly >= 1 && ly <= 2) {
      const sideWin = (lx === 0 || lx === w - 1) && lz === front + 2 && l >= 5;
      const frontWin = lz === front && (lx === 1 || lx === w - 2) && lx !== dx;
      const backWin = lz === back && lx === dx && role !== 'cartographer' && role !== 'library';
      if (sideWin || backWin) id = cell('glass_pane', lz === back ? paneAlongX : paneAlongZ, 'glass');
      else if (frontWin) id = cell('glass_pane', paneAlongX, 'glass');
    }
    if (ly === wallH - 1 && !corner && pal.flat) id = pal.trim;
    c.P(lx, ly, lz, id);
  }
  door(put, ...toWorld(p, dx, c.fy, front), pal.doorName, wd(0));
  // 4. Ceiling and roof.
  for (let lz = front; lz < len; lz++) for (let lx = 0; lx < w; lx++) c.P(lx, wallH, lz, pal.planks);
  if (pal.flat) {
    for (let lz = front; lz < len; lz++) for (let lx = 0; lx < w; lx++) if (lx === 0 || lx === w - 1 || lz === front || lz === back) c.P(lx, wallH + 1, lz, cell(pal.slab, 0, 'oak_slab'));
    if (variant === 'savanna') for (let lx = 1; lx < w - 1; lx += 2) c.P(lx, wallH + 2, back, pal.fence);
  } else {
    for (let lz = front; lz < len; lz++) for (let lx = 0; lx < w; lx++) {
      const i = Math.min(lx, w - 1 - lx), mid = i === (w - 1) >> 1;
      if (mid) c.P(lx, wallH + i - 1 + 1, lz, pal.planks);
      else c.P(lx, wallH + i, lz, cell(pal.stairs, stairsUp(lx < dx ? wd(1) : wd(3)), 'oak_stairs'));
      if (pal.snow && mid) c.P(lx, wallH + i + 1, lz, bid('snow_layer', 'air'));
    }
    for (const lz of [front, back]) for (let lx = 1; lx < w - 1; lx++) { const i = Math.min(lx, w - 1 - lx); for (let y = wallH + 1; y < wallH + i; y++) c.P(lx, y, lz, pal.planks); }
  }
  // 5. Furnishing.
  const table = role === 'home' ? VILLAGE_HOUSE_TABLE[variant] : VILLAGE_ROLE_TABLE[role];
  const frontD = wd(0), headD = wd(2), room = (n: number) => front + 1 + n;     // room(0) = first interior row
  const at = (lx: number, lz: number) => toWorld(p, lx, c.fy, lz);
  const bedAt = (lx: number, lz: number) => { const [x, y, z] = at(lx, lz); bed(put, x, y, z, facingState(headD)); };
  const chestAt = (lx: number, lz: number, tb = table) => { const [x, y, z] = at(lx, lz); chest(put, c.t, x, y, z, frontD, tb); };
  const block = (lx: number, ly: number, lz: number, name: string, fb = 'crafting_table') => c.P(lx, ly, lz, bid(name, fb));
  const faced = (lx: number, lz: number, name: string, dir = frontD) => c.P(lx, 0, lz, cell(name, facingState(dir), 'furnace'));
  const lampAt = (lx: number, lz: number) => { c.P(lx, 0, lz, pal.fence); const [x, y, z] = at(lx, lz); lantern(put, x, y + 1, z); };
  const lastRow = back - 1, firstRow = front + 1;
  lampAt(1, firstRow);
  const potted = () => { const [x, y, z] = at(w - 2, firstRow); pottedPlant(put, x, y, z, Math.floor(c.rnd(w, len) * 7)); };
  potted();
  switch (role) {
    case 'home':
      bedAt(1, lastRow - 1); chestAt(w - 2, lastRow); block(w - 2, 0, lastRow - 2, 'crafting_table');
      if (w >= 7) { bedAt(w - 2, lastRow - 1 - 0 > firstRow ? lastRow - 1 : lastRow - 1); block(2, 0, lastRow, 'furnace'); }
      if (w >= 9) { for (let z = firstRow + 1; z < lastRow; z++) c.P(4, 0, z, z === dx ? 0 : bid('oak_planks')); faced(dx - 1, lastRow, 'barrel'); }
      for (let lx = 2; lx <= w - 3; lx++) { const [x, y, z] = at(lx, room(1)); carpet(put, x, y, z, pal.wool); }
      break;
    case 'library': {
      for (let lx = 1; lx <= w - 2; lx++) for (let ly = 0; ly < 3; ly++) c.P(lx, ly, lastRow, bid('bookshelf', 'oak_planks'));
      const [lxw, lyw, lzw] = at(dx, room(2)); lectern(put, lxw, lyw, lzw, frontD);
      { const [fx, fy2, fz] = toWorld(p, 1, c.fy + 1, room(2)); itemFrame(put, c.t, fx, fy2, fz, wd(3), 'village_book_frame'); }
      chestAt(w - 2, lastRow - 1); block(2, 0, lastRow - 1, 'crafting_table'); bedAt(1, lastRow - 2);
      break;
    }
    case 'butcher': faced(w - 2, lastRow - 1, 'smoker'); faced(w - 3, lastRow - 1, 'barrel'); chestAt(1, lastRow); c.P(2, 0, lastRow, bid('hay_block', 'oak_planks')); bedAt(w - 2, lastRow - 2); break;
    case 'cartographer': block(w - 2, 0, lastRow - 1, 'cartography_table'); chestAt(1, lastRow); bedAt(w - 2, lastRow - 3 >= firstRow ? lastRow - 3 : lastRow - 2); { const [fx, fy2, fz] = toWorld(p, dx, c.fy + 1, lastRow); itemFrame(put, c.t, fx, fy2, fz, headD, 'village_map_frame'); } break;
    case 'armorer': block(w - 2, 0, lastRow - 1, 'blast_furnace', 'furnace'); block(2, 0, lastRow, 'anvil', 'iron_block'); chestAt(w - 2, lastRow); c.P(1, 0, lastRow, bid('iron_block', 'cobblestone')); bedAt(1, lastRow - 2); break;
    case 'tannery': block(w - 2, 0, lastRow, 'cauldron', 'iron_block'); block(w - 3, 0, lastRow, 'cauldron', 'iron_block'); chestAt(1, lastRow); bedAt(w - 2, lastRow - 3 >= firstRow ? lastRow - 3 : lastRow - 2); break;
    case 'shepherd': block(w - 2, 0, lastRow, 'loom', 'crafting_table'); chestAt(1, lastRow); for (let lx = 2; lx <= w - 3; lx++) for (const lz of [firstRow + 1, firstRow + 2]) { const [x, y, z] = at(lx, lz); put(x, y, z, bid(['white', 'gray', 'brown', 'black'][(lx + lz) & 3] + '_wool', 'white_wool'), true); } bedAt(1, lastRow - 1); break;
    case 'fletcher': block(w - 2, 0, lastRow, 'fletching_table'); chestAt(1, lastRow); bedAt(w - 2, lastRow - 2); break;
    case 'mason': block(w - 2, 0, lastRow, 'stonecutter', 'crafting_table'); chestAt(1, lastRow); for (let z = firstRow + 1; z <= firstRow + 2; z++) c.P(w - 2, 0, z, bid('stone_bricks')); bedAt(w - 2, lastRow - 2); break;
    case 'toolsmith': block(w - 2, 0, lastRow, 'smithing_table', 'crafting_table'); block(w - 3, 0, lastRow, 'grindstone', 'cobblestone'); chestAt(1, lastRow); bedAt(1, lastRow - 2); break;
    case 'stable':
      for (let lz = firstRow + 1; lz <= lastRow; lz++) for (const lx of [3, 5]) c.P(lx, 0, lz, pal.fence);
      for (const lx of [2, 4, 6]) c.P(lx, 0, lastRow, bid('hay_block', 'oak_planks'));
      chestAt(1, lastRow); barrel(put, c.t, ...at(w - 2, lastRow), frontD); block(1, 0, firstRow + 2, 'composter', 'oak_planks');
      break;
  }
  // Roof-line trim for the desert: terracotta band along the front.
  if (variant === 'desert') for (let lx = 0; lx < w; lx++) c.P(lx, wallH - 1, front, pal.trim);
}

function buildFarm(c: Ctx) {
  const { p, pal, put } = c, [w, , l] = p.def.size, base = c.fy - 1;
  const crop = (k: number) => bid(pal.crop[k % pal.crop.length], 'wheat_crop');
  for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) for (let ly = 0; ly < 4; ly++) c.P(lx, ly, lz, 0);
  // Two terraces: the lower plot at base-1+... each plot is 5 deep; the second is one block higher.
  for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) {
    const [x, , z] = toWorld(p, lx, 0, lz), plot = lz < 5 ? 0 : 1, row = lz < 5 ? lz : lz - 5, y = base - 1 + plot + (lz === 5 ? 0 : 0);
    if (lz === 10) { support(c, x, z, y, false); c.P(lx, y - base, lz, stone(c, x, y, z)); continue; }
    support(c, x, z, y - 1, false);
    const edgeX = lx === 0 || lx === w - 1;
    if (row === 4 || edgeX) { put(x, y, z, edgeX ? stone(c, x, y, z) : pal.planks, true); if (row === 4 && plot === 0) put(x, y + 1, z, 0, true); continue; }
    if (row === 2) put(x, y, z, bid('water'), true);
    else { put(x, y, z, bid('farmland_moist', 'dirt'), true); put(x, y + 1, z, row === 0 && (lx === w >> 1) ? pal.fence : crop(lx + plot), true); }
    if (row === 0) put(x, y + 1, z, lx === w >> 1 ? 0 : crop((lx >> 1) + plot), true);
  }
  // Step between the terraces and fences on the open sides, a composter at the lower corner.
  c.P(w >> 1, 0 - 0, 4, cell(pal.stairs, stairsUp(c.D(2)), 'oak_stairs'));
  c.P(w - 2, 0, 0, bid('composter', 'oak_planks'));
  for (let lx = 1; lx < w - 1; lx++) if (lx !== w >> 1) c.P(lx, 1, l - 2, pal.fence);
  const [lx2, ly2, lz2] = toWorld(p, 1, base + 2, 0); lantern(put, lx2, ly2, lz2);
  put(lx2, ly2 - 1, lz2, pal.fence, true);
}

function buildPen(c: Ctx) {
  const { p, pal, put } = c, [w, , l] = p.def.size, y = c.fy - 1;
  for (let lz = 0; lz < l; lz++) for (let lx = 0; lx < w; lx++) {
    const [x, , z] = toWorld(p, lx, 0, lz), edge = lx === 0 || lx === w - 1 || lz === 0 || lz === l - 1;
    support(c, x, z, y - 1);
    for (let ly = 0; ly < 4; ly++) c.P(lx, ly, lz, 0);
    put(x, y, z, bid(edge ? 'coarse_dirt' : (c.rnd(lx, lz) < 0.3 ? 'coarse_dirt' : 'grass_block'), 'dirt'), true);
    if (edge && !(lz === 0 && lx === w >> 1)) { c.P(lx, 0, lz, pal.fence); if ((lx + lz) % 3 === 0) c.P(lx, 1, lz, pal.fence); }
  }
  c.P(1, 0, l - 2, bid('hay_block', 'oak_planks')); c.P(2, 0, l - 2, bid('hay_block', 'oak_planks')); c.P(w - 2, 0, l - 2, bid('cauldron', 'water'));
  c.P(w - 2, -1, l - 2, bid('stone_bricks'));
  const [x, yy, z] = toWorld(p, w >> 1, c.fy + 2, 0); lantern(put, x, yy, z); put(x, yy - 1, z, pal.fence, true); put(x, yy - 2, z, pal.fence, true);
}

/** Builds every jigsaw piece of the village that touches the chunk at (ox, oz) (all pieces when omitted). */
function buildPieces(t: StructHost, put: Put, L: GrandVillageLayout, ox?: number, oz?: number) {
  const pal = palette(L.variant);
  for (const p of L.pieces) {
    if (ox !== undefined && oz !== undefined && (p.box[3] < ox - 1 || p.box[0] > ox + 17 || p.box[5] < oz - 1 || p.box[2] > oz + 17)) continue;
    const c = makeCtx(t, put, p, pal, L.variant);
    switch (p.def.kind) {
      case 'street': buildStreet(c); break;
      case 'lamp': buildLamp(c); break;
      case 'farm': buildFarm(c); break;
      case 'pen': buildPen(c); break;
      default: buildBuilding(c);
    }
  }
  for (const p of L.pieces) {                                                // wall-mounted tags need nothing more; keep the loot tags of every container
    void p;
  }
  void tag; void hasBlock;
}

/** The whole village: compact core + jigsaw extension. With (ox, oz) only what touches that chunk is built. */
export function grandVillage(t: StructHost, put: Put, cx: number, cz: number, variant: VillageVariant = 'plains', ox?: number, oz?: number): GrandVillageLayout {
  const L = grandVillageLayout(t, cx, cz, variant);
  const coreNear = ox === undefined || oz === undefined || (cx - 26 <= ox + 17 && cx + 26 >= ox - 1 && cz - 28 <= oz + 17 && cz + 20 >= oz - 1);
  if (coreNear) plainsVillage(t, put, cx, cz, variant);
  buildPieces(t, put, L, ox, oz);
  return L;
}
