// Jigsaw-style structure assembly (Minecraft Wiki "Jigsaw block" / "Structure pool"): a piece is a template with connectors, a
// connector names the *pool* its neighbour is drawn from and the connector `name` the neighbour has to offer. The assembler
// walks the open connectors breadth-first, draws pieces from the pools by weight (with per-piece caps), rotates each candidate
// so the two connectors face each other, and keeps it only if its bounding box collides with nothing already placed.
//
// Pure and deterministic: the same seed always yields the same layout. Collision uses a 16-block bucket grid so a layout with
// hundreds of pieces stays cheap, and the finished layout is cached by the caller (one per structure).
import { DX, DZ, mulberry } from './common';

export type Box = [number, number, number, number, number, number];
/** Connector cell is *inside* the piece, on its boundary; `dir` points out of the piece (0 N, 1 E, 2 S, 3 W). */
export interface Connector { x: number; y: number; z: number; dir: number; name: string; target: string; pool: string }
export interface PieceDef {
  id: string; kind: string;
  /** Unrotated size: width (x), height (y), length (z). */
  size: [number, number, number];
  connectors: Connector[];
  /** Maximum number of this piece per layout (default unlimited). */
  max?: number;
  /** Free blocks kept around the piece (not applied against its parent). */
  pad?: number;
  /** Terrain pieces ignore the vertical axis while colliding (their floor is chosen from the ground afterwards). */
  terrain?: boolean;
}
export interface PoolEntry { def: PieceDef; weight: number }
export interface Pool { entries: PoolEntry[]; /** Pool tried when nothing of this one fits. */ fallback?: string }
export interface Placed {
  def: PieceDef; rot: number; depth: number; parent: number; entry: number;
  /** Connector of the parent (or index of the root connector when `parent` is -1) this piece hangs on. */
  parentConn: number;
  /** World minimum corner of the rotated bounding box. */
  bx: number; by: number; bz: number;
  box: Box;
  /** Free-form data written by the `finalize` hook (floor level, foundation type …). */
  meta: Record<string, any>;
}
export interface RootConnector { x: number; y: number; z: number; dir: number; target: string; pool: string }
export interface JigsawConfig {
  seed: number; pools: Record<string, Pool>;
  /** Boxes that are already occupied (the older part of the structure, terrain features …). */
  occupied: Box[]; roots: RootConnector[];
  maxDepth: number; maxPieces: number;
  /** Pieces must stay inside this square (centre ± r on X/Z); `y0`/`y1` additionally bound non-terrain pieces vertically. */
  bounds: { cx: number; cz: number; r: number; y0?: number; y1?: number };
  /** Terrain hook: may adjust `meta` or reject the candidate (return false). `parent` is null for root connectors. */
  finalize?: (p: Placed, parent: Placed | null, at: { x: number; y: number; z: number; dir: number }) => boolean;
}

const swap = (rot: number) => (rot & 1) === 1;
/** Rotated footprint (width along X, length along Z). */
export const rotSize = (def: PieceDef, rot: number): [number, number] => swap(rot) ? [def.size[2], def.size[0]] : [def.size[0], def.size[2]];
/** Local → world (x, z) for a piece with minimum corner (bx, bz). rot = quarter turns clockwise seen from above. */
export function toWorldXZ(def: PieceDef, rot: number, bx: number, bz: number, lx: number, lz: number): [number, number] {
  const [w, , l] = def.size;
  switch (rot & 3) {
    case 0: return [bx + lx, bz + lz];
    case 1: return [bx + (l - 1 - lz), bz + lx];
    case 2: return [bx + (w - 1 - lx), bz + (l - 1 - lz)];
    default: return [bx + lz, bz + (w - 1 - lx)];
  }
}
export const toWorld = (p: Placed, lx: number, ly: number, lz: number): [number, number, number] => {
  const [x, z] = toWorldXZ(p.def, p.rot, p.bx, p.bz, lx, lz);
  return [x, p.by + ly, z];
};
export const worldDir = (p: Placed, localDir: number) => (localDir + p.rot) & 3;
export const boxesOverlap = (a: Box, b: Box) => a[0] <= b[3] && a[3] >= b[0] && a[1] <= b[4] && a[4] >= b[1] && a[2] <= b[5] && a[5] >= b[2];

class Grid {
  private cells = new Map<number, number[]>();
  boxes: Box[] = [];
  private key = (gx: number, gz: number) => (gx + 4096) * 8192 + (gz + 4096);
  add(b: Box) {
    const i = this.boxes.push(b) - 1;
    for (let gz = b[2] >> 4; gz <= b[5] >> 4; gz++) for (let gx = b[0] >> 4; gx <= b[3] >> 4; gx++) {
      const k = this.key(gx, gz); let a = this.cells.get(k);
      if (!a) this.cells.set(k, a = []);
      a.push(i);
    }
    return i;
  }
  /** Index of the first box that collides with `b` (grown by `pad` in X/Z), skipping `ignore`; -1 if free. */
  hit(b: Box, pad: number, ignore: number): number {
    const q: Box = [b[0] - pad, b[1], b[2] - pad, b[3] + pad, b[4], b[5] + pad];
    for (let gz = q[2] >> 4; gz <= q[5] >> 4; gz++) for (let gx = q[0] >> 4; gx <= q[3] >> 4; gx++) {
      const a = this.cells.get(this.key(gx, gz));
      if (a) for (const i of a) if (i !== ignore && boxesOverlap(q, this.boxes[i])) return i;
    }
    return -1;
  }
}

export function growJigsaw(cfg: JigsawConfig): Placed[] {
  const rnd = mulberry(cfg.seed >>> 0), grid = new Grid(), placed: Placed[] = [], counts = new Map<string, number>();
  for (const b of cfg.occupied) grid.add(b);
  const nOcc = grid.boxes.length;                                     // grid index i >= nOcc  ⇒  placed[i - nOcc]
  interface Open { ci: number; parent: number; pool: string; target: string; wx: number; wy: number; wz: number; dir: number; depth: number }
  const queue: Open[] = cfg.roots.map((r, ci) => ({ ci, parent: -1, pool: r.pool, target: r.target, wx: r.x, wy: r.y, wz: r.z, dir: r.dir, depth: 0 }));

  const tryPool = (open: Open, poolName: string): Placed | null => {
    const pool = cfg.pools[poolName];
    if (!pool) return null;
    const target = open.target;
    const cand = pool.entries.filter(e => (e.def.max === undefined || (counts.get(e.def.id) ?? 0) < e.def.max) && e.def.connectors.some(c => c.name === target));
    const tx = open.wx + DX[open.dir], tz = open.wz + DZ[open.dir], ty = open.wy;
    for (let tries = 0; tries < 8 && cand.length; tries++) {
      let w = rnd() * cand.reduce((s, e) => s + e.weight, 0), i = 0;
      while (i < cand.length - 1 && (w -= cand[i].weight) > 0) i++;
      const def = cand.splice(i, 1)[0].def;
      const entries = def.connectors.map((_, k) => k).filter(k => def.connectors[k].name === target);
      for (let n = entries.length; n > 1; n--) { const j = Math.floor(rnd() * n); [entries[n - 1], entries[j]] = [entries[j], entries[n - 1]]; }
      for (const k of entries) {
        const c = def.connectors[k], rot = (open.dir + 2 - c.dir + 8) & 3;
        const [ox, oz] = toWorldXZ(def, rot, 0, 0, c.x, c.z), bx = tx - ox, bz = tz - oz, [W, L] = rotSize(def, rot);
        const by = def.terrain ? 0 : ty - c.y, H = def.size[1];
        const box: Box = def.terrain ? [bx, 0, bz, bx + W - 1, 511, bz + L - 1] : [bx, by, bz, bx + W - 1, by + H - 1, bz + L - 1];
        const bd = cfg.bounds;
        if (bx < bd.cx - bd.r || bx + W - 1 > bd.cx + bd.r || bz < bd.cz - bd.r || bz + L - 1 > bd.cz + bd.r) continue;
        if (!def.terrain && ((bd.y0 !== undefined && by < bd.y0) || (bd.y1 !== undefined && by + H - 1 > bd.y1))) continue;
        // Strict AABB test against everything but the parent (which the child touches face to face), then against the parent itself.
        const parentIdx = open.parent < 0 ? -1 : open.parent + nOcc;
        if (grid.hit(box, def.pad ?? 0, parentIdx) >= 0) continue;
        if (parentIdx >= 0 && boxesOverlap(box, grid.boxes[parentIdx])) continue;
        const p: Placed = { def, rot, depth: open.depth + 1, parent: open.parent, parentConn: open.ci, entry: k, bx, by, bz, box, meta: {} };
        if (cfg.finalize && !cfg.finalize(p, open.parent < 0 ? null : placed[open.parent], { x: open.wx, y: open.wy, z: open.wz, dir: open.dir })) continue;
        return p;
      }
    }
    return pool.fallback && pool.fallback !== poolName ? tryPool(open, pool.fallback) : null;
  };

  while (queue.length && placed.length < cfg.maxPieces) {
    const open = queue.shift()!;
    if (open.depth >= cfg.maxDepth) continue;
    const p = tryPool(open, open.pool);
    if (!p) continue;
    placed.push(p); grid.add(p.box);
    counts.set(p.def.id, (counts.get(p.def.id) ?? 0) + 1);
    const idx = placed.length - 1;
    p.def.connectors.forEach((c, k) => {
      if (k === p.entry) return;
      const [wx, wy, wz] = toWorld(p, c.x, c.y, c.z);
      const surf = p.meta.surface as ((x: number, z: number) => number) | undefined;
      queue.push({ ci: k, parent: idx, pool: c.pool, target: c.target, wx, wy: surf ? surf(wx, wz) : wy, wz, dir: worldDir(p, c.dir), depth: p.depth });
    });
  }
  return placed;
}
