// Interior-decoration helpers shared by every structure builder: chests with a real `facing`, item frames, lecterns, brewing
// stands, hanging lanterns, flower pots (a decorated pot with its plant on top – the registry has no vanilla flower pot) and
// carpets. Every helper writes through `put` and tags block entities with their room loot table.
import { type Put, type StructHost, bid, cell, tag, ladderOn } from './common';

/** Chest / barrel / furnace / lectern state whose front (opening) looks towards world direction `dir` (0 N, 1 E, 2 S, 3 W). */
export const facingState = (dir: number) => (dir + 2) & 3;

export function chest(put: Put, t: StructHost, x: number, y: number, z: number, dir: number, table: string) {
  put(x, y, z, cell('chest', facingState(dir)), true);
  tag(t, x, y, z, table);
}
export function barrel(put: Put, t: StructHost, x: number, y: number, z: number, dir: number, table?: string) {
  put(x, y, z, cell('barrel', facingState(dir), 'chest'), true);
  if (table) tag(t, x, y, z, table);
}
/** Item frame hanging on the block that lies in direction `onDir` from (x, y, z); `table` seeds its contents (FIXED_CONTENTS). */
export function itemFrame(put: Put, t: StructHost, x: number, y: number, z: number, onDir: number, table?: string) {
  put(x, y, z, cell('item_frame', ladderOn(onDir), 'ladder'), true);
  if (table) tag(t, x, y, z, table);
}
export const lectern = (put: Put, x: number, y: number, z: number, dir: number) => put(x, y, z, cell('lectern', facingState(dir), 'bookshelf'), true);
export function brewing(put: Put, t: StructHost, x: number, y: number, z: number, table?: string) {
  put(x, y, z, bid('brewing_stand', 'cauldron'), true);
  if (table) tag(t, x, y, z, table);
}
export const lantern = (put: Put, x: number, y: number, z: number, soul = false) => put(x, y, z, bid(soul ? 'soul_lantern' : 'lantern', 'torch'), true);
const FLOWERS = ['poppy', 'dandelion', 'azure_bluet', 'oxeye_daisy', 'red_tulip', 'allium', 'blue_orchid'];
/** Flower pot: decorated pot with a flower growing out of it. */
export function pottedPlant(put: Put, x: number, y: number, z: number, n = 0) {
  put(x, y, z, bid('decorated_pot', 'terracotta'), true);
  put(x, y + 1, z, bid(FLOWERS[Math.abs(n) % FLOWERS.length], 'dandelion'), true);
}
export const carpet = (put: Put, x: number, y: number, z: number, color = 'red') => put(x, y, z, bid(color + '_carpet', 'white_carpet'), true);
