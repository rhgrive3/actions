// Authentic Minecraft Java Edition world-generation features & tree placers.
// Every placer is strictly deterministic from world coordinates + world seed, so cross-chunk objects match seamlessly.

import { ID } from '../game/data';

export type PutBlock = (x: number, y: number, z: number, id: number, replace?: boolean) => void;

const B = ID as Record<string, number | undefined>;
const bid = (name: string, fallback = 'oak_leaves'): number => B[name] ?? B[fallback] ?? 0;

function h32(x: number, y: number, z: number, seed: number): number {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(y | 0, 1274126177) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 2246822519)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

function makeRng(x: number, z: number, seed: number) {
  let s = (Math.imul(x | 0, 73856093) ^ Math.imul(z | 0, 19349663) ^ Math.imul(seed | 0, 83492791)) >>> 0;
  if (s === 0) s = 0x6d2b79f5;
  return () => {
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Standard BlobFoliagePlacer used by Oak, Birch, Tall Birch, and standard Jungle trees. */
export function placeBlobTree(
  put: PutBlock, x: number, y: number, z: number, seed: number,
  logId: number, leafId: number, baseH: number, randH: number,
  opts?: { vines?: boolean; cocoa?: boolean; radius?: number },
) {
  const rng = makeRng(x, z, seed);
  const h = baseH + Math.floor(rng() * (randH + 1));
  const rad = opts?.radius ?? 2;
  put(x, y, z, ID.dirt, true);
  for (let dy = 1; dy <= h; dy++) put(x, y + dy, z, logId, true);

  // Vanilla BlobFoliagePlacer: 4 layers from h-2 to h+1 (radius 2, 2, 1, 1)
  for (let dy = -2; dy <= 1; dy++) {
    const r = dy >= 0 ? Math.max(1, rad - 1) : rad;
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) === r && Math.abs(dz) === r) {
          if (dy === 1 || (dy === 0 && r > 1) || rng() < 0.5) continue;
        }
        put(x + dx, y + h + dy, z + dz, leafId, false);
      }
    }
  }

  if (opts?.cocoa && B.cocoa !== undefined) {
    const dirs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (let dy = 2; dy <= Math.min(4, h - 2); dy++) {
      if (rng() < 0.32) {
        const [dx, dz] = dirs[Math.floor(rng() * 4)];
        put(x + dx, y + dy, z + dz, B.cocoa, false);
      }
    }
  }

  if (opts?.vines && B.vine !== undefined) {
    const vId = B.vine;
    // Trunk vines
    for (let dy = 1; dy < h; dy++) {
      for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
        if (rng() < 0.25) put(x + dx, y + dy, z + dz, vId, false);
      }
    }
    // Hanging perimeter vines from canopy bottom
    for (let dz = -rad; dz <= rad; dz++) {
      for (let dx = -rad; dx <= rad; dx++) {
        if (Math.abs(dx) === rad || Math.abs(dz) === rad) {
          if (rng() < 0.22) {
            const len = 1 + Math.floor(rng() * 3);
            for (let k = 1; k <= len; k++) put(x + dx, y + h - 2 - k, z + dz, vId, false);
          }
        }
      }
    }
  }
}

/** Vanilla Fancy Oak (Balloon/Branching Oak): tall trunk with angled branches and spherical foliage clusters. */
export function placeFancyOakTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 19);
  const totalH = 7 + Math.floor(rng() * 7); // 7..13
  const trunkH = Math.floor(totalH * 0.62);
  put(x, y, z, ID.dirt, true);
  for (let dy = 1; dy <= trunkH; dy++) put(x, y + dy, z, ID.oak_log, true);

  const placeSphere = (cx: number, cy: number, cz: number, r: number) => {
    for (let dy = -2; dy <= 2; dy++) {
      const rr = dy === -2 || dy === 2 ? r - 1 : r;
      for (let dz = -rr; dz <= rr; dz++) {
        for (let dx = -rr; dx <= rr; dx++) {
          if (dx * dx + dz * dz + dy * dy * 1.4 <= r * r + 0.8) {
            put(cx + dx, cy + dy, cz + dz, ID.oak_leaves, false);
          }
        }
      }
    }
  };

  // Crown cluster
  placeSphere(x, y + totalH - 1, z, 2);
  for (let dy = trunkH; dy < totalH - 1; dy++) put(x, y + dy, z, ID.oak_log, true);

  // Diagonal branches with leaf spheres
  const branchCount = 3 + Math.floor(rng() * 4);
  for (let b = 0; b < branchCount; b++) {
    const a = (b / branchCount) * Math.PI * 2 + rng() * 0.8;
    const len = 2 + Math.floor(rng() * 3);
    const startY = Math.max(3, Math.floor(totalH * (0.4 + rng() * 0.38)));
    const endY = Math.min(totalH - 1, startY + 1 + Math.floor(rng() * 2));
    const ex = Math.round(Math.cos(a) * len);
    const ez = Math.round(Math.sin(a) * len);
    const steps = Math.max(Math.abs(ex), Math.abs(ez), endY - startY, 1);
    for (let s = 1; s <= steps; s++) {
      const t = s / steps;
      put(x + Math.round(ex * t), y + Math.round(lerp(startY, endY, t)), z + Math.round(ez * t), ID.oak_log, true);
    }
    placeSphere(x + ex, y + endY, z + ez, 2);
  }
}

/** Vanilla Swamp Oak: medium oak with wider radius=3 canopy and hanging vines (often in shallow water). */
export function placeSwampOakTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  placeBlobTree(put, x, y, z, seed + 23, ID.oak_log, ID.oak_leaves, 5, 3, { vines: true, radius: 3 });
}

/** Vanilla Spruce (tiered conical) vs Pine (top-only cluster). */
export function placeSpruceOrPine(put: PutBlock, x: number, y: number, z: number, seed: number, pine: boolean) {
  const rng = makeRng(x, z, seed + 31);
  const h = (pine ? 7 : 6) + Math.floor(rng() * 4);
  const log = ID.spruce_log, leaf = ID.spruce_leaves;
  put(x, y, z, ID.dirt, true);
  for (let dy = 1; dy <= h; dy++) put(x, y + dy, z, log, true);

  if (pine) {
    // Pine: bare lower trunk, tight conical crown at top 4-5 layers
    const crownH = 3 + Math.floor(rng() * 2);
    let r = 0;
    for (let dy = h + 1; dy >= h + 1 - crownH; dy--) {
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (r >= 2 && Math.abs(dx) === r && Math.abs(dz) === r) continue;
          put(x + dx, y + dy, z + dz, leaf, false);
        }
      }
      r = Math.min(2, r + 1);
    }
  } else {
    // Spruce: alternating stepped tiers down to 2 blocks above ground
    const bare = 1 + Math.floor(rng() * 2);
    let curR = 0, maxR = 1, minR = 0;
    for (let dy = h + 1; dy >= bare + 1; dy--) {
      for (let dz = -curR; dz <= curR; dz++) {
        for (let dx = -curR; dx <= curR; dx++) {
          if (curR > 0 && Math.abs(dx) === curR && Math.abs(dz) === curR) continue;
          put(x + dx, y + dy, z + dz, leaf, false);
        }
      }
      if (curR >= maxR) {
        curR = minR;
        minR = 1;
        maxR = Math.min(3, maxR + 1);
      } else {
        curR++;
      }
    }
    put(x, y + h + 1, z, leaf, false);
  }
}

/** Vanilla 2x2 Mega Pine & Mega Spruce (Old Growth Taiga), with Podzol alter-ground patches. */
export function placeMegaTaigaTree(put: PutBlock, x: number, y: number, z: number, seed: number, isSpruce: boolean) {
  const rng = makeRng(x, z, seed + 47);
  const h = 14 + Math.floor(rng() * 14); // 14..27 blocks
  const log = ID.spruce_log, leaf = ID.spruce_leaves;

  for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
    put(x + dx, y, z + dz, ID.dirt, true);
    for (let dy = 1; dy <= h; dy++) put(x + dx, y + dy, z + dz, log, true);
  }

  // AlterGround: podzol ring around base
  const podzol = bid('podzol', 'dirt');
  for (let dz = -4; dz <= 5; dz++) for (let dx = -4; dx <= 5; dx++) {
    const d = Math.hypot(dx - 0.5, dz - 0.5);
    if (d <= 4.3 && (d <= 2.4 || rng() < 0.6)) put(x + dx, y, z + dz, podzol, true);
  }

  // MegaPineFoliagePlacer: crownHeight 3..7 (pine) or 13..17 (spruce)
  const crownH = isSpruce ? 12 + Math.floor(rng() * 6) : 4 + Math.floor(rng() * 4);
  let prevR = 0;
  for (let ly = h + 1; ly >= Math.max(3, h + 1 - crownH); ly--) {
    const distFromTop = h + 1 - ly;
    let r = distFromTop === 0 ? 1 : Math.min(3, 1 + Math.floor((distFromTop / crownH) * 2.7));
    if (isSpruce && distFromTop > 2) {
      r = distFromTop % 3 === 0 ? Math.max(1, prevR - 1) : Math.min(3, prevR + 1);
    }
    prevR = r;
    for (let dz = -r; dz <= r + 1; dz++) {
      for (let dx = -r; dx <= r + 1; dx++) {
        const d = Math.hypot(dx - 0.5, dz - 0.5);
        if (d <= r + 0.55) put(x + dx, y + ly, z + dz, leaf, false);
      }
    }
  }
}

/** Vanilla 2x2 Mega Jungle Tree: towering trunk, branches, multi-layered canopy & hanging vines. */
export function placeMegaJungleTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 61);
  const h = 15 + Math.floor(rng() * 14); // 15..28 blocks
  const log = ID.jungle_log, leaf = ID.jungle_leaves, vine = B.vine;

  for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
    put(x + dx, y, z + dz, ID.dirt, true);
    for (let dy = 1; dy <= h; dy++) put(x + dx, y + dy, z + dz, log, true);
  }

  const placeCrown = (cx: number, cy: number, cz: number, rad: number) => {
    for (let dy = -1; dy <= 1; dy++) {
      const r = dy === 1 ? Math.max(1, rad - 2) : rad - (dy === -1 ? 0 : 1);
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          if (dx * dx + dz * dz <= r * r + 1) put(cx + dx, cy + dy, cz + dz, leaf, false);
        }
      }
    }
  };

  placeCrown(x, y + h, z, 5);

  // Side branches halfway up and near crown
  for (let by = Math.floor(h * 0.45); by < h - 3; by += 3 + Math.floor(rng() * 2)) {
    const a = rng() * Math.PI * 2;
    const blen = 2 + Math.floor(rng() * 3);
    const bx = Math.round(Math.cos(a) * blen);
    const bz = Math.round(Math.sin(a) * blen);
    for (let s = 1; s <= blen; s++) {
      const t = s / blen;
      put(x + Math.round(bx * t), y + by + Math.floor(t), z + Math.round(bz * t), log, true);
    }
    placeCrown(x + bx, y + by + 1, z + bz, 3);
  }

  // Vines on 2x2 trunk & crown edges
  if (vine !== undefined) {
    for (let dy = 2; dy < h - 1; dy++) {
      if (rng() < 0.25) put(x - 1, y + dy, z, vine, false);
      if (rng() < 0.25) put(x + 2, y + dy, z + 1, vine, false);
      if (rng() < 0.25) put(x, y + dy, z - 1, vine, false);
      if (rng() < 0.25) put(x + 1, y + dy, z + 2, vine, false);
    }
    for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const d = Math.hypot(dx, dz);
      if (d >= 4 && d <= 5.2 && rng() < 0.25) {
        const len = 2 + Math.floor(rng() * 5);
        for (let k = 1; k <= len; k++) put(x + dx, y + h - 1 - k, z + dz, vine, false);
      }
    }
  }
}

/** Vanilla Jungle Bush: 1 jungle log surrounded by a low dome of oak leaves on the forest floor. */
export function placeJungleBush(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 67);
  put(x, y, z, ID.dirt, true);
  put(x, y + 1, z, ID.jungle_log, true);
  const leaf = ID.oak_leaves;
  for (let dy = 1; dy <= 2; dy++) {
    const r = dy === 1 ? 2 : 1;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (Math.abs(dx) === r && Math.abs(dz) === r && rng() < 0.5) continue;
      put(x + dx, y + dy, z + dz, leaf, false);
    }
  }
}

/** Vanilla Acacia: diagonal forking trunk with 1–2 flat two-layer umbrella canopies. */
export function placeAcaciaTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 73);
  const h = 5 + Math.floor(rng() * 4);
  const bendAt = 2 + Math.floor(rng() * 2);
  const dirs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  const mainD = Math.floor(rng() * 4);
  const [mdx, mdz] = dirs[mainD];
  const log = ID.acacia_log, leaf = ID.acacia_leaves;
  put(x, y, z, ID.dirt, true);

  let cx = x, cz = z;
  for (let dy = 1; dy <= h; dy++) {
    if (dy >= bendAt) { cx += mdx; cz += mdz; }
    put(cx, y + dy, cz, log, true);
  }

  const canopy = (tx: number, ty: number, tz: number) => {
    for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
      if (Math.abs(dx) === 2 && Math.abs(dz) === 2) continue;
      put(tx + dx, ty, tz + dz, leaf, false);
    }
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
      if (Math.abs(dx) === 1 && Math.abs(dz) === 1 && rng() < 0.4) continue;
      put(tx + dx, ty + 1, tz + dz, leaf, false);
    }
  };
  canopy(cx, y + h, cz);

  // Secondary fork in another direction (~65% chance)
  if (rng() < 0.65) {
    const [sdx, sdz] = dirs[(mainD + 1 + Math.floor(rng() * 3)) & 3];
    let bx = x, bz = z;
    const forkEnd = h - 1;
    for (let dy = bendAt; dy <= forkEnd; dy++) {
      bx += sdx; bz += sdz;
      put(bx, y + dy, bz, log, true);
    }
    canopy(bx, y + forkEnd, bz);
  }
}

/** Vanilla Dark Oak: 2x2 thick trunk, branching crown, wide dense dark-oak canopy. */
export function placeDarkOakTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 83);
  const h = 6 + Math.floor(rng() * 3);
  const log = ID.dark_oak_log, leaf = ID.dark_oak_leaves;
  const shiftX = rng() < 0.5 ? 1 : -1;
  const shiftZ = rng() < 0.5 ? 1 : -1;

  for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
    put(x + dx, y, z + dz, ID.dirt, true);
  }
  let cx = x, cz = z;
  for (let dy = 1; dy <= h; dy++) {
    if (dy === h - 2 && rng() < 0.7) { cx += shiftX; cz += shiftZ; }
    for (let dz = 0; dz <= 1; dz++) for (let dx = 0; dx <= 1; dx++) {
      put(cx + dx, y + dy, cz + dz, log, true);
    }
  }
  // Spread short top branches
  for (const [bx, bz] of [[-1, 0], [2, 0], [0, -1], [1, 2]] as const) {
    if (rng() < 0.65) put(cx + bx, y + h - 1, cz + bz, log, true);
  }
  // Wide dark oak roof canopy (layers at h-2..h+1)
  for (let dz = -2; dz <= 3; dz++) for (let dx = -2; dx <= 3; dx++) {
    const edge = dx === -2 || dx === 3 || dz === -2 || dz === 3;
    const corner = (dx === -2 || dx === 3) && (dz === -2 || dz === 3);
    if (!corner) put(cx + dx, y + h - 1, cz + dz, leaf, false);
    if (!edge || rng() < 0.65) put(cx + dx, y + h, cz + dz, leaf, false);
  }
  for (let dz = -1; dz <= 2; dz++) for (let dx = -1; dx <= 2; dx++) {
    if ((dx === -1 || dx === 2) && (dz === -1 || dz === 2) && rng() < 0.5) continue;
    put(cx + dx, y + h + 1, cz + dz, leaf, false);
  }
  for (let dz = -3; dz <= 4; dz++) for (let dx = -3; dx <= 4; dx++) {
    const d = Math.hypot(dx - 0.5, dz - 0.5);
    if (d <= 3.7 && rng() < 0.7) put(cx + dx, y + h - 2, cz + dz, leaf, false);
  }
}

/** Vanilla Cherry Tree (1.20): CherryTrunkPlacer + CherryFoliagePlacer with hanging pink blossom clusters. */
export function placeCherryTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 97);
  const h = 7 + (rng() < 0.5 ? 1 : 0);
  const log = ID.cherry_log, leaf = ID.cherry_leaves;
  put(x, y, z, ID.dirt, true);
  for (let dy = 1; dy <= h - 2; dy++) put(x, y + dy, z, log, true);

  const placeCherryCanopy = (cx: number, cy: number, cz: number) => {
    const rad = 4;
    for (let dy = -2; dy <= 2; dy++) {
      const r = dy === 2 ? 2 : dy === -2 ? 3 : rad;
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        const corner = Math.abs(dx) === r && Math.abs(dz) === r;
        if (corner && (dy >= 1 || rng() < 0.35)) continue;
        if (dx * dx + dz * dz <= r * r + 2) {
          put(cx + dx, cy + dy, cz + dz, leaf, false);
          // Characteristic hanging cherry leaf tips below lower rim
          if (dy === -2 && rng() < 0.24) {
            put(cx + dx, cy - 3, cz + dz, leaf, false);
            if (rng() < 0.33) put(cx + dx, cy - 4, cz + dz, leaf, false);
          }
        }
      }
    }
  };

  // 1 to 3 wide sweeping horizontal-then-upward branches
  const bCount = 1 + Math.floor(rng() * 3);
  const baseAngle = rng() * Math.PI * 2;
  for (let b = 0; b < bCount; b++) {
    const a = baseAngle + (b * Math.PI * 2) / bCount + (rng() - 0.5) * 0.5;
    const hLen = 2 + Math.floor(rng() * 3); // 2..4
    const startY = h - 4 + Math.floor(rng() * 2);
    const endY = h + (rng() < 0.5 ? 0 : -1);
    const dx = Math.cos(a), dz = Math.sin(a);
    for (let s = 1; s <= hLen; s++) {
      const lx = x + Math.round(dx * s), lz = z + Math.round(dz * s);
      const ly = startY + (s === hLen ? 1 : 0);
      put(lx, y + ly, lz, log, true);
      if (s === hLen) {
        for (let yy = ly; yy <= endY; yy++) put(lx, y + yy, lz, log, true);
        placeCherryCanopy(lx, y + endY, lz);
      }
    }
  }
  if (bCount === 1) placeCherryCanopy(x, y + h, z);
}

/** Vanilla Mangrove Tree: stilt arch roots, muddy roots in mud/water, branching trunk, mossy canopy & vines. */
export function placeMangroveTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 109);
  const trunkOffY = 2 + Math.floor(rng() * 2); // 2..3 blocks above ground on stilt roots
  const trunkH = 3 + Math.floor(rng() * 3);
  const log = ID.mangrove_log, leaf = ID.mangrove_leaves;
  const roots = bid('mangrove_roots', 'mangrove_log');
  const mossCarpet = B.moss_carpet;
  const vine = B.vine;

  const baseY = y + trunkOffY;
  // 4 arching root legs extending diagonally down to ground/mud
  for (const [rx, rz] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
    const span = 2 + Math.floor(rng() * 2);
    for (let s = 1; s <= span; s++) {
      const ry = baseY - Math.floor((s / span) * (trunkOffY + 1));
      const px = x + rx * s, pz = z + rz * s;
      put(px, ry, pz, roots, true);
      if (mossCarpet !== undefined && rng() < 0.45) put(px, ry + 1, pz, mossCarpet, false);
    }
    // Anchor down
    put(x + rx * span, y, z + rz * span, roots, true);
  }

  for (let dy = 0; dy <= trunkH; dy++) put(x, baseY + dy, z, log, true);
  // 1-2 upward branches
  for (let b = 0; b < 2; b++) {
    const bx = (b === 0 ? 1 : -1) * (1 + Math.floor(rng() * 2));
    const bz = (rng() < 0.5 ? 1 : -1);
    put(x + Math.sign(bx), baseY + trunkH - 1, z + bz, log, true);
    put(x + bx, baseY + trunkH, z + bz, log, true);
  }

  // Random-spread mangrove foliage (radius 3, height 2)
  const topY = baseY + trunkH;
  for (let dy = -1; dy <= 1; dy++) {
    const r = dy === 1 ? 2 : 3;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (dx * dx + dz * dz <= r * r + 1 && rng() < 0.88) {
        put(x + dx, topY + dy, z + dz, leaf, false);
        if (dy === -1 && vine !== undefined && Math.abs(dx) + Math.abs(dz) >= 3 && rng() < 0.25) {
          const len = 1 + Math.floor(rng() * 3);
          for (let k = 1; k <= len; k++) put(x + dx, topY - 1 - k, z + dz, vine, false);
        }
      }
    }
  }
}

/** Vanilla Azalea Tree (surface indicator above Lush Caves). */
export function placeAzaleaTree(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 127);
  const h = 4 + Math.floor(rng() * 2);
  const bendDirs = [[1, 0], [-1, 0], [0, 1], [0, -1]] as const;
  const bendDir = bendDirs[Math.floor(rng() * 4)];
  put(x, y, z, bid('rooted_dirt', 'dirt'), true);
  let cx = x, cz = z;
  for (let dy = 1; dy <= h; dy++) {
    if (dy >= h - 1) { cx += bendDir[0]; cz += bendDir[1]; }
    put(cx, y + dy, cz, ID.oak_log, true);
  }
  const az = bid('azalea_leaves', 'oak_leaves'), fl = bid('flowering_azalea_leaves', 'azalea_leaves');
  for (let dy = -1; dy <= 1; dy++) {
    const r = dy === 1 ? 2 : 3;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (dx * dx + dz * dz <= r * r + 1 && rng() < 0.85) {
        put(cx + dx, y + h + dy, cz + dz, rng() < 0.25 ? fl : az, false);
      }
    }
  }
}

/** Vanilla Huge Red Mushroom (hollow domed cap) & Huge Brown Mushroom (flat 7x7 cap with trimmed corners). */
export function placeHugeMushroom(put: PutBlock, x: number, y: number, z: number, seed: number, red: boolean) {
  const rng = makeRng(x, z, seed + 139);
  const tall = rng() < 1 / 12;
  const h = tall ? 9 + Math.floor(rng() * 5) : 5 + Math.floor(rng() * 3);
  const stem = bid('mushroom_stem', 'birch_log');
  for (let dy = 1; dy <= h; dy++) put(x, y + dy, z, stem, true);

  if (red) {
    const cap = ID.red_mushroom_block;
    // Top 3x3 cap at h+1
    for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) put(x + dx, y + h + 1, z + dz, cap, false);
    // Hollow 5x5 skirt (corners removed) for 3 layers h-2..h
    for (let dy = h - 2; dy <= h; dy++) {
      for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
        const ax = Math.abs(dx), az = Math.abs(dz);
        if ((ax === 2 && az < 2) || (az === 2 && ax < 2)) put(x + dx, y + dy, z + dz, cap, false);
      }
    }
  } else {
    const cap = ID.brown_mushroom_block;
    // Flat 7x7 cap (radius 3) with outer corners clipped at h+1
    for (let dz = -3; dz <= 3; dz++) for (let dx = -3; dx <= 3; dx++) {
      if (Math.abs(dx) === 3 && Math.abs(dz) === 3) continue;
      put(x + dx, y + h + 1, z + dz, cap, false);
    }
  }
}

/** Vanilla Warm Ocean Coral Reefs: Coral Tree, Coral Claw, and Coral Mushroom. */
export function placeCoralReef(put: PutBlock, x: number, y: number, z: number, seed: number, maxTopY: number) {
  const rng = makeRng(x, z, seed + 157);
  const kinds = ['tube', 'brain', 'bubble', 'fire', 'horn'] as const;
  const kind = kinds[Math.floor(rng() * 5)];
  const blockId = B[kind + '_coral_block'];
  const fanId = B[kind + '_coral'];
  if (blockId === undefined) return;
  const pickleId = B.sea_pickle;
  const placeCoral = (px: number, py: number, pz: number) => {
    if (py >= maxTopY) return;
    put(px, py, pz, blockId, true);
    if (fanId !== undefined && py + 1 < maxTopY && rng() < 0.35) put(px, py + 1, pz, fanId, false);
    else if (pickleId !== undefined && py + 1 < maxTopY && rng() < 0.08) put(px, py + 1, pz, pickleId, false);
  };

  const shape = Math.floor(rng() * 3);
  if (shape === 0) {
    // Coral Tree: central trunk + 2..4 upward spreading branches
    const trunkH = 2 + Math.floor(rng() * 3);
    for (let dy = 1; dy <= trunkH; dy++) placeCoral(x, y + dy, z);
    const branches = 2 + Math.floor(rng() * 3);
    for (let b = 0; b < branches; b++) {
      const a = (b / branches) * Math.PI * 2 + rng() * 0.6;
      const len = 2 + Math.floor(rng() * 3);
      let cx = x, cy = y + trunkH, cz = z;
      for (let s = 1; s <= len; s++) {
        if (s % 2 === 1) { cx += Math.round(Math.cos(a)); cz += Math.round(Math.sin(a)); }
        else cy++;
        placeCoral(cx, cy, cz);
      }
    }
  } else if (shape === 1) {
    // Coral Mushroom: dome cap 3..5 wide
    const rw = 2;
    const h = 2 + Math.floor(rng() * 2);
    for (let dy = 1; dy <= h; dy++) placeCoral(x, y + dy, z);
    for (let dz = -rw; dz <= rw; dz++) for (let dx = -rw; dx <= rw; dx++) {
      if (Math.abs(dx) === rw && Math.abs(dz) === rw) continue;
      placeCoral(x + dx, y + h, z + dz);
      if (Math.abs(dx) <= 1 && Math.abs(dz) <= 1) placeCoral(x + dx, y + h + 1, z + dz);
    }
  } else {
    // Coral Claw: horizontal curving arms
    placeCoral(x, y + 1, z);
    const arms = 2 + Math.floor(rng() * 2);
    for (let b = 0; b < arms; b++) {
      const a = (b / arms) * Math.PI * 2 + rng() * 0.4;
      const dx = Math.round(Math.cos(a)), dz = Math.round(Math.sin(a));
      for (let s = 1; s <= 3; s++) placeCoral(x + dx * s, y + 1 + (s >= 2 ? 1 : 0), z + dz * s);
    }
  }
}

/** Vanilla Ice Spike (short thick mounds 10–18 blocks OR towering narrow spires up to 44 blocks). */
export function placeIceSpike(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 173);
  const packed = ID.packed_ice, blue = B.blue_ice ?? packed;
  const tall = rng() < 0.2;
  const h = tall ? 22 + Math.floor(rng() * 22) : 9 + Math.floor(rng() * 9);
  const baseR = tall ? 2.2 : 2.6 + rng() * 1.2;

  for (let dy = -2; dy <= h; dy++) {
    const t = Math.max(0, dy) / h;
    const r = Math.max(0.4, baseR * (1 - t));
    const ri = Math.ceil(r);
    for (let dz = -ri; dz <= ri; dz++) for (let dx = -ri; dx <= ri; dx++) {
      const d = Math.hypot(dx, dz);
      if (d <= r + 0.15) put(x + dx, y + dy, z + dz, dy <= 0 && rng() < 0.35 ? blue : packed, true);
    }
  }
}

/** Vanilla Frozen Ocean Iceberg: blue/packed ice floating underwater and rising with snow cap. */
export function placeIceberg(put: PutBlock, x: number, ySurf: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 191);
  const packed = ID.packed_ice, blue = B.blue_ice ?? packed, snow = ID.snow_block;
  const rx = 3 + Math.floor(rng() * 4), rz = 3 + Math.floor(rng() * 4);
  const topH = 4 + Math.floor(rng() * 8), botH = 5 + Math.floor(rng() * 6);

  for (let dy = -botH; dy <= topH; dy++) {
    const frac = dy >= 0 ? 1 - dy / (topH + 1) : 1 + dy / (botH + 2);
    const scale = Math.max(0.2, Math.pow(frac, 0.72));
    const lx = Math.ceil(rx * scale), lz = Math.ceil(rz * scale);
    for (let dz = -lz; dz <= lz; dz++) for (let dx = -lx; dx <= lx; dx++) {
      const ell = (dx * dx) / Math.max(1, (rx * scale) ** 2) + (dz * dz) / Math.max(1, (rz * scale) ** 2);
      if (ell <= 1.0 + (h32(x + dx, dy, z + dz, seed) - 0.5) * 0.25) {
        const blk = dy >= topH - 1 ? snow : dy < -2 && rng() < 0.4 ? blue : packed;
        put(x + dx, ySurf + dy, z + dz, blk, true);
      }
    }
  }
}

/** Vanilla Mossy Cobblestone Boulder (Forest Rock) in Old Growth Taiga. */
export function placeForestRock(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 211);
  const mossy = ID.mossy_cobblestone ?? ID.cobblestone;
  const rx = 1 + Math.floor(rng() * 2), ry = 1 + Math.floor(rng() * 2), rz = 1 + Math.floor(rng() * 2);
  for (let dy = 0; dy <= ry; dy++) for (let dz = -rz; dz <= rz; dz++) for (let dx = -rx; dx <= rx; dx++) {
    if ((dx * dx) / (rx * rx + 0.5) + (dy * dy) / (ry * ry + 0.5) + (dz * dz) / (rz * rz + 0.5) <= 1.1) {
      put(x + dx, y + dy, z + dz, mossy, true);
    }
  }
}

/** Vanilla Desert Well: 5x5 sandstone platform, cross-shaped water basin, 4 pillars and slab roof. */
export function placeDesertWell(put: PutBlock, x: number, y: number, z: number) {
  const ss = ID.sandstone, slab = B.sandstone_slab ?? ss, w = ID.water;
  for (let dz = -2; dz <= 2; dz++) for (let dx = -2; dx <= 2; dx++) {
    put(x + dx, y - 1, z + dz, ss, true);
    put(x + dx, y, z + dz, ss, true);
    const cross = (Math.abs(dx) <= 1 && dz === 0) || (Math.abs(dz) <= 1 && dx === 0);
    if (cross) {
      put(x + dx, y, z + dz, w, true);
      put(x + dx, y + 1, z + dz, 0, true);
    } else if (Math.abs(dx) === 2 || Math.abs(dz) === 2) {
      put(x + dx, y + 1, z + dz, Math.abs(dx) === 0 || Math.abs(dz) === 0 ? slab : ss, true);
    } else {
      put(x + dx, y + 1, z + dz, ss, true);
      put(x + dx, y + 2, z + dz, ss, true);
      put(x + dx, y + 3, z + dz, ss, true);
    }
  }
  for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
    put(x + dx, y + 4, z + dz, dx === 0 && dz === 0 ? ss : slab, true);
  }
}

/** Vanilla Chorus Plant: recursive organic branching plant 5..20 blocks tall with Chorus Flowers at tips. */
export function placeChorusPlant(put: PutBlock, x: number, y: number, z: number, seed: number) {
  const rng = makeRng(x, z, seed + 313);
  const plant = ID.chorus_plant, flower = ID.chorus_flower;
  const grow = (cx: number, cy: number, cz: number, age: number, prevDx: number, prevDz: number) => {
    const segH = 1 + Math.floor(rng() * 3) + (age === 0 ? 1 : 0);
    for (let dy = 0; dy < segH; dy++) put(cx, cy + dy, cz, plant, true);
    const topY = cy + segH;
    if (age >= 4 || cy - y >= 16) {
      put(cx, topY, cz, flower, true);
      return;
    }
    const dirs: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    const branches = age === 0 ? 2 + Math.floor(rng() * 2) : 1 + Math.floor(rng() * 3);
    let grew = false;
    for (let b = 0; b < branches; b++) {
      const [dx, dz] = dirs[Math.floor(rng() * 4)];
      if (dx === -prevDx && dz === -prevDz) continue;
      put(cx + dx, topY - 1, cz + dz, plant, true);
      grow(cx + dx, topY, cz + dz, age + 1 + (rng() < 0.35 ? 1 : 0), dx, dz);
      grew = true;
    }
    if (!grew) put(cx, topY, cz, flower, true);
  };
  grow(x, y, z, 0, 0, 0);
}

/** Vanilla Nether Huge Crimson / Warped Fungus: 1x1 or thick 3x3-plus stem, layered wart cap, shroomlights & weeping vines. */
export function placeHugeFungus(put: PutBlock, x: number, y: number, z: number, seed: number, crimson: boolean, ceilY: number) {
  const rng = makeRng(x, z, seed + 613);
  const stem = crimson ? ID.crimson_log : ID.warped_log;
  const wart = crimson ? ID.crimson_leaves : ID.warped_leaves;
  const shroom = ID.shroomlight;
  const vines = B.weeping_vines;
  let h = 4 + Math.floor(rng() * 10);
  if (rng() < 1 / 12) h *= 2;
  h = Math.min(h, Math.max(4, ceilY - y - 4));
  if (h < 4) return;
  const thick = rng() < 0.45;

  for (let dy = 1; dy <= h; dy++) {
    put(x, y + dy, z, stem, true);
    if (thick) {
      put(x + 1, y + dy, z, stem, true);
      put(x - 1, y + dy, z, stem, true);
      put(x, y + dy, z + 1, stem, true);
      put(x, y + dy, z - 1, stem, true);
    }
  }

  const hatStart = Math.max(3, h - 4);
  const maxR = thick ? 3 : 2;
  for (let dy = hatStart; dy <= h + 1; dy++) {
    const r = dy >= h ? Math.max(1, maxR - 1) : maxR;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
      if (dy < h && Math.abs(dx) < r && Math.abs(dz) < r && !(dy === h && dx === 0 && dz === 0)) continue; // hollow inner skirt
      if (Math.abs(dx) === r && Math.abs(dz) === r && rng() < 0.5) continue;
      const blk = rng() < 0.06 ? shroom : wart;
      put(x + dx, y + dy, z + dz, blk, false);
      if (crimson && vines !== undefined && dy === hatStart && rng() < 0.14) {
        const len = 1 + Math.floor(rng() * 4);
        for (let k = 1; k <= len; k++) put(x + dx, y + dy - k, z + dz, vines, false);
      }
    }
  }
}

function lerp(a: number, b: number, t: number) { return a + (b - a) * t; }
