// Structure builders added with the dungeon pass: trial chambers (1.21), ruined portals, ocean ruins, buried treasure and trail ruins,
// plus the small "bee tree" feature. Like structures.ts every builder is a pure function of the world seed and writes through `put`,
// which clips to the chunk being generated — so the same code runs on the main thread (loot / spawner lookup) and in chunk workers.
import { ID } from '../game/data';
import type { Terrain } from './terrain';
import type { Put, Placed } from './structures';

const SEA = 62;
const B = ID as Record<string, number | undefined>;
const id = (name: string, fallback = 'stone'): number => B[name] ?? B[fallback] ?? 1;
const hash = (x: number, z: number, seed: number) => {
  let h = (Math.imul(x | 0, 374761393) ^ Math.imul(z | 0, 668265263) ^ Math.imul(seed | 0, 1274126177)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
const hash3 = (x: number, y: number, z: number, seed: number) => hash(x + y * 131, z - y * 71, seed);
function mulberry(seed: number) {
  let a = seed | 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ===== Trial chambers ===================================================================================================
// A buried maze of 11×11 tuff/copper rooms on a 5×5 grid (16-block pitch) joined by 5-block corridors. The layout is grown from the
// central atrium with a seeded random walk, so it is different for every site but identical on every thread.
export const CHAMBER_CELL = 16;
export const CHAMBER_GRID = 2;
export type SpawnerKind = 'melee' | 'small_melee' | 'ranged' | 'breeze';
export type RoomType = 'atrium' | 'spawner' | 'vault' | 'supply' | 'ominous';
export interface ChamberRoom { gx: number; gz: number; x: number; z: number; type: RoomType; /** bit 0 N(-z) · 1 E(+x) · 2 S(+z) · 3 W(-x) */ links: number }
export interface ChamberLayout {
  x: number; y: number; z: number;
  rooms: ChamberRoom[];
  spawners: { x: number; y: number; z: number; kind: SpawnerKind }[];
  vaults: { x: number; y: number; z: number; ominous: boolean }[];
  chests: [number, number, number][];
  pots: [number, number, number][];
}
const DIRS: [number, number][] = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const layouts = new Map<string, ChamberLayout>();

export function chamberLayout(seed: number, px: number, py: number, pz: number): ChamberLayout {
  const key = `${seed}:${px},${py},${pz}`, cached = layouts.get(key);
  if (cached) return cached;
  const rnd = mulberry(Math.imul(seed | 0, 31) ^ Math.imul(px | 0, 73856093) ^ Math.imul(pz | 0, 19349663));
  const rooms: ChamberRoom[] = [{ gx: 0, gz: 0, x: px, z: pz, type: 'atrium', links: 0 }];
  const at = (gx: number, gz: number) => rooms.find(r => r.gx === gx && r.gz === gz);
  const want = 9 + Math.floor(rnd() * 5);
  for (let guard = 0; rooms.length < want && guard < 600; guard++) {
    const from = rooms[Math.floor(rnd() * rooms.length)], d = Math.floor(rnd() * 4), gx = from.gx + DIRS[d][0], gz = from.gz + DIRS[d][1];
    if (Math.abs(gx) > CHAMBER_GRID || Math.abs(gz) > CHAMBER_GRID) continue;
    const existing = at(gx, gz);
    if (existing) {                                                    // occasionally close a loop between two existing rooms
      if (rnd() < 0.25) { from.links |= 1 << d; existing.links |= 1 << ((d + 2) % 4); }
      continue;
    }
    from.links |= 1 << d;
    rooms.push({ gx, gz, x: px + gx * CHAMBER_CELL, z: pz + gz * CHAMBER_CELL, type: 'spawner', links: 1 << ((d + 2) % 4) });
  }
  let far = rooms[rooms.length - 1], farD = -1;
  for (const r of rooms.slice(1)) { const d = Math.abs(r.gx) + Math.abs(r.gz); if (d > farD) { farD = d; far = r; } }
  const cycle: RoomType[] = ['spawner', 'vault', 'spawner', 'supply', 'spawner', 'vault', 'spawner', 'supply'];
  let n = 0;
  for (const r of rooms.slice(1)) r.type = r === far ? 'ominous' : cycle[n++ % cycle.length];

  const L: ChamberLayout = { x: px, y: py, z: pz, rooms, spawners: [], vaults: [], chests: [], pots: [] };
  const kinds: SpawnerKind[] = ['melee', 'ranged', 'small_melee', 'melee', 'ranged', 'breeze'];
  for (const r of rooms) {
    if (r.type === 'atrium') {
      L.spawners.push({ x: r.x - 3, y: py, z: r.z, kind: 'breeze' }, { x: r.x + 3, y: py, z: r.z, kind: 'breeze' });
      L.vaults.push({ x: r.x, y: py, z: r.z, ominous: false });
      L.chests.push([r.x + 3, py, r.z + 3]);
    } else if (r.type === 'spawner') {
      L.spawners.push({ x: r.x, y: py, z: r.z, kind: kinds[Math.floor(rnd() * kinds.length)] });
      L.pots.push([r.x - 3, py, r.z + 3]);
    } else if (r.type === 'vault') {
      L.vaults.push({ x: r.x, y: py, z: r.z, ominous: false });
      L.pots.push([r.x - 3, py, r.z - 3], [r.x + 3, py, r.z + 3]);
    } else if (r.type === 'supply') {
      L.chests.push([r.x - 3, py, r.z - 3]);
      L.pots.push([r.x + 3, py, r.z - 3], [r.x - 3, py, r.z + 3]);
    } else {
      L.vaults.push({ x: r.x, y: py + 1, z: r.z, ominous: true });
      L.spawners.push({ x: r.x - 3, y: py, z: r.z - 3, kind: 'melee' }, { x: r.x + 3, y: py, z: r.z + 3, kind: 'ranged' });
    }
  }
  if (layouts.size > 64) layouts.clear();
  layouts.set(key, L);
  return L;
}

export function trialChambers(t: Terrain, put: Put, p: Placed) {
  const L = chamberLayout(t.seed, p.x, p.y, p.z), s = t.seed + 7800, y = p.y;
  const bricks = id('tuff_bricks', 'tuff'), polished = id('polished_tuff', 'tuff'), chisT = id('chiseled_tuff', 'tuff'), chisTB = id('chiseled_tuff_bricks', 'tuff'), tuff = id('tuff');
  const copper = id('copper_block'), cut = id('cut_copper', 'copper_block'), chisC = id('chiseled_copper', 'copper_block'), ox = id('oxidized_copper', 'copper_block'), oxCut = id('oxidized_cut_copper', 'copper_block');
  const grate = id('copper_grate', 'copper_block'), bulb = id('copper_bulb_lit', 'glowstone');
  for (const r of L.rooms) {
    const H = r.type === 'atrium' || r.type === 'ominous' ? 7 : 5;
    for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {
      const x = r.x + dx, z = r.z + dz, ax = Math.abs(dx), az = Math.abs(dz), wall = ax === 5 || az === 5, n = hash(x, z, s);
      put(x, y - 2, z, tuff, true);
      put(x, y - 1, z, wall ? bricks : ax === 4 || az === 4 ? polished : ax <= 1 && az <= 1 ? (ax + az === 0 ? chisC : cut) : n < 0.05 ? oxCut : n < 0.12 ? cut : bricks, true);
      for (let dy = 0; dy < H; dy++) {
        let b = 0;
        if (wall) b = dy === 2 ? (((dx + dz) & 3) === 0 ? chisTB : n < 0.3 ? ox : copper) : dy === H - 1 ? polished : hash3(x, y + dy, z, s) < 0.08 ? tuff : bricks;
        else if (ax === 4 && az === 4) b = dy % 3 === 2 ? chisT : polished;                       // corner pillars
        put(x, y + dy, z, b, true);
      }
      put(x, y + H, z, ax === 2 && az === 2 ? bulb : wall ? bricks : ax === 3 && az === 3 ? grate : (ax + az) % 4 === 0 ? cut : polished, true);
    }
  }
  for (const r of L.rooms) for (let d = 0; d < 4; d++) {
    if (!(r.links & (1 << d))) continue;
    const [ux, uz] = DIRS[d];
    for (let w = -1; w <= 1; w++) for (let dy = 0; dy <= 2; dy++) put(r.x + ux * 5 + (uz ? w : 0), y + dy, r.z + uz * 5 + (ux ? w : 0), 0, true);   // doorway
    if (d !== 1 && d !== 2) continue;                                   // each corridor is built once, by its west / north room
    for (let i = 6; i <= 10; i++) for (let w = -2; w <= 2; w++) for (let dy = -1; dy <= 3; dy++) {
      const x = r.x + ux * i + (uz ? w : 0), z = r.z + uz * i + (ux ? w : 0), side = Math.abs(w) === 2;
      let b = 0;
      if (dy === -1) b = side ? bricks : w === 0 ? cut : polished;
      else if (dy === 3) b = w === 0 && i === 8 ? bulb : bricks;
      else if (side) b = dy === 1 && (i & 1) === 0 ? copper : bricks;
      put(x, y + dy, z, b, true);
    }
  }
  const spawner = id('trial_spawner', 'spawner'), vault = id('vault', 'chest'), oVault = id('ominous_vault', 'chest'), chest = id('chest'), pot = id('decorated_pot', 'air');
  for (const sp of L.spawners) put(sp.x, sp.y, sp.z, spawner, true);
  for (const v of L.vaults) { if (v.ominous) put(v.x, v.y - 1, v.z, chisC, true); put(v.x, v.y, v.z, v.ominous ? oVault : vault, true); }
  for (const [x, cy, z] of L.chests) put(x, cy, z, chest, true);
  for (const [x, cy, z] of L.pots) put(x, cy, z, pot, true);
}

// ===== Ruined portal ====================================================================================================
export function ruinedPortal(t: Terrain, put: Put, p: Placed) {
  const s = t.seed + 7900, y = p.y, nether = t.dimension === 'nether';
  const obs = id('obsidian'), cry = id('crying_obsidian', 'obsidian'), rack = id('netherrack'), magma = id('magma_block', 'netherrack'), lava = id('lava'), gold = id('gold_block'), chest = id('chest');
  const base = nether ? id('polished_blackstone_bricks', 'blackstone') : id('stone_bricks'), mossy = nether ? id('blackstone') : id('mossy_stone_bricks', 'stone_bricks'), cracked = nether ? id('gilded_blackstone', 'blackstone') : id('cracked_stone_bricks', 'stone_bricks');
  const alongX = hash(p.x, p.z, s) < 0.5;
  const at = (u: number, w: number): [number, number] => (alongX ? [p.x + u, p.z + w] : [p.x + w, p.z + u]);
  for (let dz = -5; dz <= 5; dz++) for (let dx = -5; dx <= 5; dx++) {                       // scorched netherrack patch
    const d = Math.hypot(dx, dz), x = p.x + dx, z = p.z + dz, n = hash(x, z, s + 1);
    if (d > 5.2 || n > 0.85 - d * 0.11) continue;
    put(x, y - 1, z, n < 0.07 ? magma : n < 0.11 && d < 3 && d > 1.5 && !nether ? lava : rack, true);
  }
  for (let u = -3; u <= 2; u++) for (let w = -1; w <= 1; w++) {                               // cracked stone footing
    const [x, z] = at(u, w), n = hash(x, z, s + 3);
    put(x, y - 1, z, n < 0.3 ? mossy : n < 0.5 ? cracked : base, true);
  }
  for (let u = -2; u <= 1; u++) for (let v = 0; v <= 4; v++) {                                // the broken 4×5 frame
    const [x, z] = at(u, 0), edge = u === -2 || u === 1 || v === 0 || v === 4, n = hash3(u, v, p.x ^ p.z, s + 2);
    if (!edge) { put(x, y + v, z, 0, true); continue; }
    const missing = v > 0 && (n < 0.1 || (v >= 3 && n < 0.38));
    put(x, y + v, z, missing ? 0 : n > 0.8 ? cry : obs, true);
  }
  const [gx, gz] = at(2, 1), [cx, cz] = at(-3, 1);
  put(gx, y, gz, gold, true);
  put(cx, y, cz, chest, true);
}

// ===== Ocean ruins ======================================================================================================
export function oceanRuin(t: Terrain, put: Put, p: Placed) {
  const s = t.seed + 8000, warm = /warm|lukewarm|desert/.test(t.biomeAt(p.x, p.z, p.y - 1)) || hash(p.x, p.z, s + 9) < 0.3;
  const walls = warm ? [id('sandstone'), id('cut_sandstone', 'sandstone'), id('chiseled_sandstone', 'sandstone'), id('smooth_sandstone', 'sandstone')]
    : [id('stone_bricks'), id('mossy_stone_bricks', 'stone_bricks'), id('cracked_stone_bricks', 'stone_bricks'), id('prismarine')];
  const floor = warm ? id('sand') : id('gravel'), sus = warm ? id('suspicious_sand', 'sand') : id('suspicious_gravel', 'gravel'), chest = id('chest'), lantern = id('sea_lantern', 'glowstone');
  const huts: [number, number, number][] = [[0, 0, 3]];
  for (let i = 0; i < 2; i++) huts.push([Math.round((hash(p.x + i, p.z, s + 20) - 0.5) * 16), Math.round((hash(p.x, p.z + i, s + 21) - 0.5) * 16), 2]);
  huts.forEach(([ox, oz, half], n) => {
    const cx = p.x + ox, cz = p.z + oz, h = t.height(cx, cz);
    if (h > SEA - 4 || (n > 0 && Math.max(Math.abs(ox), Math.abs(oz)) < 6)) return;
    const hy = h + 1;
    for (let dz = -half; dz <= half; dz++) for (let dx = -half; dx <= half; dx++) {
      const x = cx + dx, z = cz + dz, edge = Math.abs(dx) === half || Math.abs(dz) === half, r = hash(x, z, s + n);
      put(x, hy - 1, z, !edge && r < 0.16 ? sus : r < 0.55 ? floor : walls[Math.floor(r * 97) % walls.length], true);
      if (!edge || (dx === 0 && dz === half)) continue;
      const height = Math.floor(hash(x, z, s + 5 + n) * 5);
      for (let dy = 0; dy < height; dy++) put(x, hy + dy, z, walls[Math.floor(hash3(x, hy + dy, z, s) * walls.length)], true);
      if (height === 4 && r < 0.2) put(x, hy + 4, z, lantern, true);
    }
    if (n === 0) put(cx - 1, hy, cz - 1, chest, true);
    put(cx + half + 1, hy - 1, cz + 1, sus, true);
  });
}

// ===== Buried treasure ==================================================================================================
export function buriedTreasure(_t: Terrain, put: Put, p: Placed) {
  put(p.x, p.y - 1, p.z, id('sandstone'), true);
  put(p.x, p.y, p.z, id('chest'), true);
  put(p.x, p.y + 1, p.z, id('sand'), true);
}

// ===== Trail ruins ======================================================================================================
// A lost settlement that is almost entirely underground: only the top of the central tower pokes out of the forest floor.
export function trailRuins(t: Terrain, put: Put, p: Placed) {
  const s = t.seed + 8100, top = p.y, base = top - 7;
  const terr = ['white_terracotta', 'light_blue_terracotta', 'yellow_terracotta', 'orange_terracotta', 'red_terracotta', 'brown_terracotta', 'cyan_terracotta'].map(n => id(n, 'terracotta'));
  const mud = id('mud_bricks', 'bricks'), cobble = id('cobblestone'), mossy = id('mossy_cobblestone', 'cobblestone'), gravel = id('gravel'), coarse = id('coarse_dirt', 'dirt'), dirt = id('dirt'), sus = id('suspicious_gravel', 'gravel'), packed = id('packed_mud', 'dirt'), planks = id('spruce_planks', 'oak_planks');
  const fillAt = (x: number, yy: number, z: number) => {
    const r = hash3(x, yy, z, s + 4), deep = yy <= base + 1;
    return r < (deep ? 0.1 : 0.05) ? sus : r < 0.5 ? gravel : r < 0.75 ? dirt : coarse;
  };
  const room = (cx: number, cz: number, half: number, height: number, color: number) => {
    for (let dz = -half; dz <= half; dz++) for (let dx = -half; dx <= half; dx++) {
      const x = cx + dx, z = cz + dz, edge = Math.abs(dx) === half || Math.abs(dz) === half;
      put(x, base - 1, z, hash(x, z, s + 1) < 0.5 ? packed : mud, true);
      for (let dy = 0; dy < height; dy++) {
        const yy = base + dy, r = hash3(x, yy, z, s + 2);
        if (yy > top + 1) break;
        if (edge) put(x, yy, z, dy === 0 ? (r < 0.4 ? mossy : cobble) : dy === height - 1 ? mud : r < 0.12 ? fillAt(x, yy, z) : r < 0.3 ? mud : color, true);
        else if (yy < top) put(x, yy, z, dy === height - 1 && r < 0.5 ? planks : fillAt(x, yy, z), true);
      }
    }
  };
  for (let dx = -9; dx <= 9; dx++) for (let w = -1; w <= 1; w++) {                               // the buried road
    const x = p.x + dx, z = p.z + w;
    put(x, base - 1, z, Math.abs(w) === 1 ? mud : hash(x, z, s + 3) < 0.6 ? gravel : coarse, true);
    put(x, base, z, fillAt(x, base, z), true);
  }
  room(p.x, p.z, 2, 9, terr[Math.floor(hash(p.x, p.z, s) * terr.length)]);                       // tower: base … top+1
  const sites: [number, number][] = [[-6, -5], [6, -5], [5, 6], [-6, 6]];
  sites.forEach(([ox, oz], i) => {
    if (hash(p.x + ox, p.z + oz, s + 6) < 0.2) return;
    room(p.x + ox, p.z + oz, 2, 3 + Math.floor(hash(p.x + ox, p.z + oz, s + 7) * 2), terr[(i * 3 + Math.floor(hash(p.x, p.z, s + 8) * 7)) % terr.length]);
  });
}

// ===== Bee trees ========================================================================================================
/** A lone oak with a bee nest on its trunk and a few flowers at its foot, in roughly one out of 30 flowery chunks. */
export function placeBeeNests(t: Terrain, put: Put, ox: number, oz: number) {
  if (t.dimension !== 'overworld' || B.bee_nest === undefined) return;
  const cx = Math.floor(ox / 16), cz = Math.floor(oz / 16);
  if (hash(cx, cz, t.seed + 8200) > 0.035) return;
  const x = cx * 16 + 4 + Math.floor(hash(cx, cz, t.seed + 8201) * 8), z = cz * 16 + 4 + Math.floor(hash(cx, cz, t.seed + 8202) * 8), h = t.height(x, z);
  if (h < SEA + 1 || h > 125) return;
  const biome = t.biomeAt(x, z, h);
  if (!/plains|meadow|flower|forest|cherry/.test(biome) || /dark|taiga|snowy|pale|wooded_badlands/.test(biome)) return;
  const log = id('oak_log'), leaves = id('oak_leaves'), flowers = [id('poppy'), id('dandelion'), id('cornflower', 'poppy'), id('oxeye_daisy', 'dandelion')];
  for (let dy = 3; dy <= 6; dy++) {
    const r = dy >= 6 ? 1 : 2;
    for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) if (Math.abs(dx) + Math.abs(dz) < r * 2 || dy === 4) put(x + dx, h + dy, z + dz, leaves, false);
  }
  for (let dy = 1; dy <= 5; dy++) put(x, h + dy, z, log, true);
  put(x + 1, h + 3, z, id('bee_nest'), true);
  [[2, 1], [-1, 2], [1, -2], [-2, -1], [2, -2]].forEach(([dx, dz], i) => {
    if (t.height(x + dx, z + dz) === h) put(x + dx, h + 1, z + dz, flowers[i % flowers.length], false);
  });
}
