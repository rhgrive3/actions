// Overworld terrain + biome source, faithfully implementing Minecraft Java Edition (1.18–1.21) multi-noise generation.
//
// Five horizontal climate parameters are evaluated at each column (with domain warp matching Mojang's Shift noise):
//   C  continentalness  mushroom_fields → deep_ocean → ocean → coast → near/mid/far inland
//   E  erosion          0..6  mountainous (E0..E1) → plateaus/hills (E2..E4) → shattered (E5) → flat/swamps (E6)
//   W  weirdness        drives biome variants (W<0 vs W>=0) and folds into PV:
//   PV peaks & valleys  1 - |3|W| - 2|   Valleys (rivers) → Low → Mid → High → Peaks
//   T  temperature      5 levels (frozen, cold, temperate, warm, hot)
//   H  humidity         5 levels (arid .. lush)
//
// Biome placement uses the exact vanilla OverworldBiomeBuilder decision matrix over (C, E, PV, W, T, H),
// ensuring completely authentic biome borders (e.g. cold oceans never touch warm jungles, mountain peaks are
// cushioned by snowy slopes/groves, rivers never slice through steep mountain massifs in mid/far inland, etc.).

export interface NoiseLike {
  n2(x: number, z: number): number;
  fbm(x: number, z: number, octaves?: number): number;
}

/** Single source of truth: vanilla sea level 63 → topmost water block Y = 62 (see terrain.ts). */
export const SEA = 62;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const sstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

function spline(pts: readonly [number, number][], v: number): number {
  if (v <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (v <= pts[i][0]) {
      const a = pts[i - 1], b = pts[i];
      const t = (v - a[0]) / (b[0] - a[0]);
      // Smooth Hermite interpolation prevents artificial angular creases in terrain slopes
      const st = t * t * (3 - 2 * t);
      return a[1] + (b[1] - a[1]) * st;
    }
  }
  return pts[pts.length - 1][1];
}

// Vanilla Continentalness -> baseline elevation offset from sea level
const CONT_SPLINE: readonly [number, number][] = [
  [-1.12, 12.0],   // Mushroom Island peaks above deep ocean
  [-1.02, -33.0],  // Deep ocean dropoff
  [-0.51, -31.0],  // Deep ocean basin floor
  [-0.44, -18.0],  // Ocean slope
  [-0.19, -5.5],   // Coastal shelf
  [-0.15, 0.2],    // Shoreline transition
  [-0.11, 2.2],    // Coastal lowland
  [0.03, 5.2],     // Near-inland
  [0.30, 11.5],    // Mid-inland
  [0.65, 19.0],    // Far-inland plateau
  [1.00, 23.0],
];

// Vanilla parameter thresholds (Java Edition 1.18–1.21 OverworldBiomeBuilder)
const TEMP_BOUNDS = [-0.45, -0.15, 0.20, 0.55] as const;
const HUMID_BOUNDS = [-0.35, -0.10, 0.10, 0.30] as const;
const EROSION_BOUNDS = [-0.78, -0.375, -0.2225, 0.05, 0.45, 0.55] as const;

function levelOf(val: number, bounds: readonly number[]): number {
  for (let i = 0; i < bounds.length; i++) {
    if (val < bounds[i]) return i;
  }
  return bounds.length;
}

// Hoisted pure biome table helpers (zero closure allocations per biome lookup)
function biomeBeach(T: number): string {
  return T === 0 ? 'snowy_beach' : T === 4 ? 'desert' : 'beach';
}
function biomeBadlands(H: number, W: number): string {
  return H <= 1 ? (W < 0 ? 'badlands' : 'eroded_badlands') : H === 2 ? 'badlands' : 'wooded_badlands';
}
function biomeSlope(H: number): string {
  return H <= 1 ? 'snowy_slopes' : 'grove';
}
function biomePeak(T: number, H: number, W: number): string {
  return T === 4 ? biomeBadlands(H, W) : T === 3 ? 'stony_peaks' : W < 0 ? 'jagged_peaks' : 'frozen_peaks';
}
function biomeMiddle(T: number, H: number, W: number): string {
  if (T === 0) {
    if (H === 0) return W < 0 ? 'snowy_plains' : 'ice_spikes';
    if (H === 1) return 'snowy_plains';
    if (H === 2) return W < 0 ? 'snowy_plains' : 'snowy_taiga';
    if (H === 3) return 'snowy_taiga';
    return 'taiga';
  }
  if (T === 1) {
    if (H <= 1) return 'plains';
    if (H === 2) return 'forest';
    if (H === 3) return 'taiga';
    return W < 0 ? 'old_growth_spruce_taiga' : 'old_growth_pine_taiga';
  }
  if (T === 2) {
    if (H === 0) return W < 0 ? 'flower_forest' : 'sunflower_plains';
    if (H === 1) return 'plains';
    if (H === 2) return 'forest';
    if (H === 3) return W < 0 ? 'birch_forest' : 'old_growth_birch_forest';
    return 'dark_forest';
  }
  if (T === 3) {
    if (H <= 1) return 'savanna';
    if (H === 2) return W < 0 ? 'forest' : 'plains';
    if (H === 3) return W < 0 ? 'jungle' : 'sparse_jungle';
    return W < 0 ? 'jungle' : 'bamboo_jungle';
  }
  return 'desert';
}
function biomePlateau(T: number, H: number, W: number): string {
  if (T === 0) {
    if (H === 0) return W < 0 ? 'snowy_plains' : 'ice_spikes';
    if (H <= 2) return 'snowy_plains';
    return 'snowy_taiga';
  }
  if (T === 1) {
    if (H === 0) return W < 0 ? 'meadow' : 'cherry_grove';
    if (H === 1) return 'meadow';
    if (H === 2) return W < 0 ? 'forest' : 'meadow';
    if (H === 3) return W < 0 ? 'taiga' : 'meadow';
    return W < 0 ? 'old_growth_spruce_taiga' : 'old_growth_pine_taiga';
  }
  if (T === 2) {
    if (H <= 1) return W < 0 ? 'meadow' : 'cherry_grove';
    if (H === 2) return W < 0 ? 'meadow' : 'forest';
    if (H === 3) return W < 0 ? 'meadow' : 'birch_forest';
    return 'dark_forest';
  }
  if (T === 3) {
    if (H <= 1) return 'savanna_plateau';
    if (H <= 3) return 'forest';
    return 'jungle';
  }
  return biomeBadlands(H, W);
}
function biomeShattered(T: number, H: number, W: number): string {
  if (T <= 1) {
    if (H <= 1) return 'windswept_gravelly_hills';
    if (H === 2) return 'windswept_hills';
    return 'windswept_forest';
  }
  if (T === 2) {
    if (H <= 2) return 'windswept_hills';
    return biomeMiddle(T, H, W);
  }
  if (T === 3) {
    if (H <= 1) return 'savanna';
    if (H === 2) return W < 0 ? 'forest' : 'plains';
    if (H === 3) return W < 0 ? 'jungle' : 'sparse_jungle';
    return W < 0 ? 'jungle' : 'bamboo_jungle';
  }
  return 'desert';
}

/** Starter area coordinates (kept compatible with starter cabin/village & title camera). */
const SPAWN_X = -11, SPAWN_Z = 27;

export class Column {
  x = NaN; z = NaN;
  C = 0; E = 0; W = 0; T = 0; H = 0; pv = 0;
  /** Unrounded surface height (before local structure adaptation). */
  hf = SEA;
  /** Factor controlling steepness / cliff intensity (low in shattered terrain). */
  jagged = 0;
  shattered = 0;
  swampy = 0;
  river = 0;
  island = 0;
  high = 0;
  biome = '';
}

interface QuartEntry {
  qx: number;
  qz: number;
  jx0: number; jz0: number;
  jx1: number; jz1: number;
  jx2: number; jz2: number;
  jx3: number; jz3: number;
  b0: string; b1: string; b2: string; b3: string;
  uniform: boolean;
}

export class OverworldGen {
  private cache: Column[] = Array.from({ length: 8192 }, () => new Column());
  private quartCache: QuartEntry[] = Array.from({ length: 2048 }, () => ({
    qx: 0x7fffffff, qz: 0x7fffffff,
    jx0: 0, jz0: 0, jx1: 0, jz1: 0, jx2: 0, jz2: 0, jx3: 0, jz3: 0,
    b0: '', b1: '', b2: '', b3: '',
    uniform: false,
  }));
  private kC = 0;
  private kE = 0;
  private kW = 0;
  private kT = 0;
  private kH = 0;
  private shiftX = 0;
  private shiftZ = 0;
  private initialized = false;

  constructor(private n: NoiseLike) {}

  private ensureInit() {
    if (this.initialized) return;
    this.initialized = true;
    this.kC = this.normField((x, z) => this.rawC(x, z), 37.13, -81.71, 0.42);
    this.kE = this.normField((x, z) => this.rawE(x, z), -143.3, 59.9, 0.42);
    this.kW = this.normField((x, z) => this.rawW(x, z), 211.7, 97.3, 0.44);
    this.kT = this.normField((x, z) => this.rawT(x, z), -17.9, -263.1, 0.46);
    this.kH = this.normField((x, z) => this.rawH(x, z), 301.3, 9.1, 0.43);
    this.findSpawnOffset();
  }

  /**
   * Mojang-style natural spawn search: locates a genuine temperate inland lowland (forest/plains) in the pure
   * multi-noise field and translates the coordinate origin there, completely avoiding artificial circular island masks.
   */
  private findSpawnOffset() {
    let bestScore = -1e9, bx = 0, bz = 0;
    for (let r = 0; r <= 24; r++) {
      for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) {
        if (Math.abs(dx) !== r && Math.abs(dz) !== r) continue;
        const tx = dx * 180, tz = dz * 180;
        const C = this.rawC(tx, tz) * this.kC;
        if (C < 0.04 || C > 0.36) continue;
        const E = this.rawE(tx, tz) * this.kE;
        if (E < 0.05 || E > 0.42) continue;
        const T = this.rawT(tx, tz) * this.kT;
        if (T < -0.14 || T > 0.18) continue;
        const H = this.rawH(tx, tz) * this.kH;
        if (H < -0.10 || H > 0.28) continue;
        const W = this.rawW(tx, tz) * this.kW;
        const pv = 1 - Math.abs(3 * Math.abs(W) - 2);
        if (pv < -0.15) continue;
        const score = 1 - Math.abs(T - 0.02) * 3 - Math.abs(E - 0.22) * 2 - Math.abs(C - 0.18) * 2;
        if (score > bestScore) { bestScore = score; bx = tx; bz = tz; }
        if (bestScore > 0.72) { this.shiftX = bx - SPAWN_X; this.shiftZ = bz - SPAWN_Z; return; }
      }
    }
    this.shiftX = bx - SPAWN_X;
    this.shiftZ = bz - SPAWN_Z;
  }

  // Mojang-authentic multi-octave amplitude spectra (each octave k attenuates by 0.5^k, matching NormalNoise):
  private rawT(x: number, z: number): number {
    return 1.5 * this.n.n2(x * 0.00042 - 17.9, z * 0.00042 - 263.1) +
           0.35 * this.n.n2(x * 0.0014 + 51.2, z * 0.0014 + 118.4);
  }
  private rawH(x: number, z: number): number {
    return 1.0 * this.n.n2(x * 0.000976 + 301.3, z * 0.000976 + 9.1) +
           0.5 * this.n.n2(x * 0.001953 - 88.4, z * 0.001953 + 174.2);
  }
  private rawC(x: number, z: number): number {
    const s = 0.000488;
    return 1.00 * this.n.n2(x * s + 37.13, z * s - 81.71) +
           0.50 * this.n.n2(x * s * 2 - 19.4, z * s * 2 + 42.8) +
           0.50 * this.n.n2(x * s * 4 + 103.7, z * s * 4 - 66.1) +
           0.25 * this.n.n2(x * s * 8 - 55.2, z * s * 8 + 129.3) +
           0.125 * this.n.n2(x * s * 16 + 12.9, z * s * 16 - 33.7);
  }
  private rawE(x: number, z: number): number {
    const s = 0.000488;
    return 1.00 * this.n.n2(x * s - 143.3, z * s + 59.9) +
           0.50 * this.n.n2(x * s * 2 + 74.1, z * s * 2 - 91.5) +
           0.125 * this.n.n2(x * s * 8 - 11.8, z * s * 8 + 38.6) +
           0.0625 * this.n.n2(x * s * 16 + 61.3, z * s * 16 - 47.2);
  }
  private rawW(x: number, z: number): number {
    const s = 0.001953;
    return 1.00 * this.n.n2(x * s + 211.7, z * s + 97.3) +
           1.00 * this.n.n2(x * s * 2 - 44.6, z * s * 2 + 183.1) +
           0.25 * this.n.n2(x * s * 4 + 93.2, z * s * 4 - 28.9);
  }

  private normField(fn: (x: number, z: number) => number, ox: number, oz: number, targetStd: number): number {
    let sum = 0;
    const step = 757;
    for (let j = -16; j < 16; j++) {
      for (let i = -16; i < 16; i++) {
        const v = fn(ox * 120 + i * step, oz * 120 + j * step);
        sum += v * v;
      }
    }
    const rms = Math.sqrt(sum / 1024) || 1;
    return targetStd / rms;
  }

  column(x: number, z: number): Column {
    if (!this.initialized) this.ensureInit();
    x = Math.floor(x); z = Math.floor(z);
    const c = this.cache[(Math.imul(x, 73856093) ^ Math.imul(z, 19349663)) & 8191];
    if (c.x !== x || c.z !== z) this.compute(x, z, c);
    return c;
  }

  private compute(x: number, z: number, c: Column) {
    const n = this.n;
    const wx = x + this.shiftX, wz = z + this.shiftZ;
    const sx = (n.n2(wx * 0.0156 + 11.3, wz * 0.0156 - 7.7) + 0.5 * n.n2(wx * 0.0312 - 5.1, wz * 0.0312 + 14.3)) * 14;
    const sz = (n.n2(wx * 0.0156 - 31.9, wz * 0.0156 + 17.1) + 0.5 * n.n2(wx * 0.0312 + 22.7, wz * 0.0312 - 9.4)) * 14;
    const qx = wx + sx, qz = wz + sz;

    const C = clamp(this.rawC(qx, qz) * this.kC, -1.25, 1.15);
    const E = clamp(this.rawE(qx, qz) * this.kE, -1.10, 1.10);
    const W = clamp(this.rawW(qx, qz) * this.kW, -1.15, 1.15);
    const bx = qx + n.n2(wx * 0.045 + 3.9, wz * 0.045 - 14.2) * 7;
    const bz = qz + n.n2(wx * 0.045 - 23.7, wz * 0.045 + 5.8) * 7;
    const T = clamp(this.rawT(bx, bz) * this.kT, -1.15, 1.15);
    const H = clamp(this.rawH(bx, bz) * this.kH, -1.15, 1.15);
    const pv = 1 - Math.abs(3 * Math.abs(W) - 2);

    let off = spline(CONT_SPLINE, C);

    if (C < -0.17) {
      const seaFloor = n.fbm(wx * 0.008 + 5.5, wz * 0.008 - 9.5, 2) * 6.5;
      off += sstep(-0.17, -0.35, C) * seaFloor;
    }

    const island = sstep(-0.98, -1.07, C);
    if (island > 0) {
      const iShape = 5.5 + n.fbm(wx * 0.018 + 9.1, wz * 0.018 + 4.4, 2) * 5.0;
      off = lerp(off, iShape, island);
    }

    const inland = sstep(-0.19, -0.05, C);
    const mount = sstep(-0.15, -0.45, E) * sstep(-0.14, 0.02, C) * (1 + 0.30 * sstep(-0.45, -0.82, E));
    const plateau = sstep(0.05, -0.35, E) * sstep(0.22, 0.48, C) * (1 - sstep(-0.55, -0.82, E) * 0.3);
    const hills = sstep(0.45, -0.25, E);
    const swampy = sstep(0.48, 0.56, E) * sstep(-0.14, -0.05, C) * sstep(0.32, 0.14, pv);

    const canRiver = lerp(sstep(0.08, -0.12, C), 1.0, sstep(-0.34, -0.14, E));
    const river = sstep(-0.82, -0.94, pv) * sstep(-0.20, -0.11, C) * canRiver;

    const e5 = sstep(0.38, 0.47, E) * sstep(0.62, 0.53, E);
    const sC0 = sstep(-0.02, 0.16, C);
    const shattered = e5 * (sC0 + (1 - sC0) * sstep(-0.04, 0.10, W));

    const s = clamp((pv + 0.85) / 1.85, 0, 1);
    const ss = s * s * (3 - 2 * s);
    let high = 0;
    let jagged = 0;

    if (inland > 0) {
      const rolling = n.fbm(wx * 0.0085 + 71.3, wz * 0.0085 - 13.9, 3);
      const bumps = n.n2(wx * 0.034 - 5.1, wz * 0.034 + 44.7);
      let relief = (2.2 + 12.0 * hills) * ss + rolling * (3.5 + 7.5 * hills) * (0.35 + 0.65 * s) + bumps * 1.1;

      if (plateau > 0) {
        const platH = 34 * sstep(0.0, 0.65, s) + n.fbm(wx * 0.011 - 19.3, wz * 0.011 + 8.7, 2) * 4.5;
        relief += plateau * platH;
      }

      if (mount > 0) {
        high = mount * Math.pow(s, 1.35);
        const peakSharpness = W < 0 ? 1.14 : 0.88;
        relief += 116 * high * peakSharpness;

        if (s > 0.25) {
          const jagRaw = n.fbm(wx * 0.026 + 19.7, wz * 0.026 + 3.3, 3);
          const jagHalf = jagRaw >= 0 ? jagRaw : jagRaw * 0.5;
          const jagWeight = mount * sstep(0.25, 0.85, s) * (W < 0 ? 1.0 : 0.55);
          jagged = jagWeight;
          relief += jagWeight * (jagHalf * 16.0 + (1 - Math.abs(n.n2(wx * 0.018 - 40.4, wz * 0.018 + 21.2))) * 10.0);
        }
      }

      if (shattered > 0) {
        const shatNoise = n.fbm(wx * 0.018 + 52.1, wz * 0.018 - 61.8, 3);
        const crag = Math.max(0, shatNoise + 0.10);
        const stepped = Math.pow(crag, 1.3) * 52;
        relief += shattered * (stepped * (0.4 + 0.6 * s) + n.n2(wx * 0.04, wz * 0.04) * 3.0);
      }

      if (canRiver > 0 && off + relief > 3) {
        const valleyApproach = sstep(-0.22, -0.85, pv) * canRiver * inland;
        off = lerp(off, 1.6, valleyApproach);
        relief *= 1 - valleyApproach * 0.9;
      }

      off += inland * relief;

      const hotLevel = sstep(0.48, 0.60, T);
      if (hotLevel > 0 && C > -0.05) {
        const erodedMask = hotLevel * sstep(-0.04, -0.22, H) * sstep(-0.04, 0.14, W) * (1 - sstep(-0.22, -0.42, E));
        if (erodedMask > 0) {
          const hoodoo = n.n2(wx * 0.048 + 14.1, wz * 0.048 - 22.8);
          if (hoodoo > 0.14) {
            const spireH = sstep(0.14, 0.48, hoodoo) * 18;
            off += erodedMask * spireH;
          }
        }
        const badlandsTerrace = hotLevel * sstep(0.35, -0.15, E);
        if (badlandsTerrace > 0 && off > 5) {
          const stepH = 6.0;
          const t = off / stepH, f = Math.floor(t);
          off = lerp(off, (f + sstep(0.30, 0.70, t - f)) * stepH, badlandsTerrace * 0.8);
        }
      }

      if (swampy > 0 && pv > -0.86) {
        const pool = n.n2(wx * 0.048 + 3.3, wz * 0.048 - 8.8) * 1.9 + n.n2(wx * 0.021 - 1.4, wz * 0.021 + 6.2) * 1.2;
        off = lerp(off, -0.65 + pool, swampy * (1 - river));
      }

      if (river > 0) {
        // River bed Y 55‥59 (vanilla): the water surface is always the sea level, never a perched pool on a slope.
        const riverDepth = -4.5 + n.n2(wx * 0.04 + 12.1, wz * 0.04 - 5.4) * 2.0;
        off = lerp(off, riverDepth, river);
      }
    }

    c.x = x; c.z = z; c.C = C; c.E = E; c.W = W; c.T = T; c.H = H; c.pv = pv;
    c.hf = SEA + off + 0.5;
    c.jagged = jagged;
    c.shattered = shattered;
    c.swampy = swampy;
    c.river = river;
    c.island = island;
    c.high = high;
    c.biome = '';
  }

  /** Deterministic per-quart-cell jitter in [0,1) (stands in for Mojang's LinearCongruentialGenerator in the zoomer). */
  private fuzz(qx: number, qz: number, salt: number): number {
    let h = Math.imul(qx, 374761393) ^ Math.imul(qz, 668265263) ^ Math.imul(salt + 0x9e3779b1, 1274126177);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }

  /**
   * Biome at a block column, resolved like Java Edition's BiomeManager + FuzzyOffsetBiomeZoomer:
   * biomes live on a 4x4 "quart" grid, and each block takes the biome of the nearest *jittered* quart-cell centre.
   * Uses an O(1) quart-cell cache and uniform-cell fast path while remaining 100% bit-for-bit identical.
   */
  biomeAt(x: number, z: number, _h?: number): string {
    const ix = Math.floor(x) - 2, iz = Math.floor(z) - 2;
    const qx = ix >> 2, qz = iz >> 2;
    const qSlot = this.quartCache[(Math.imul(qx, 73856093) ^ Math.imul(qz, 19349663)) & 2047];
    if (qSlot.qx !== qx || qSlot.qz !== qz) {
      qSlot.qx = qx;
      qSlot.qz = qz;
      qSlot.jx0 = (this.fuzz(qx, qz, 1) - 0.5) * 0.9;
      qSlot.jz0 = (this.fuzz(qx, qz, 2) - 0.5) * 0.9;
      qSlot.jx1 = (this.fuzz(qx + 1, qz, 1) - 0.5) * 0.9;
      qSlot.jz1 = (this.fuzz(qx + 1, qz, 2) - 0.5) * 0.9;
      qSlot.jx2 = (this.fuzz(qx, qz + 1, 1) - 0.5) * 0.9;
      qSlot.jz2 = (this.fuzz(qx, qz + 1, 2) - 0.5) * 0.9;
      qSlot.jx3 = (this.fuzz(qx + 1, qz + 1, 1) - 0.5) * 0.9;
      qSlot.jz3 = (this.fuzz(qx + 1, qz + 1, 2) - 0.5) * 0.9;
      const b0 = this.cellBiome(qx * 4 + 2, qz * 4 + 2);
      const b1 = this.cellBiome((qx + 1) * 4 + 2, qz * 4 + 2);
      const b2 = this.cellBiome(qx * 4 + 2, (qz + 1) * 4 + 2);
      const b3 = this.cellBiome((qx + 1) * 4 + 2, (qz + 1) * 4 + 2);
      qSlot.b0 = b0; qSlot.b1 = b1; qSlot.b2 = b2; qSlot.b3 = b3;
      qSlot.uniform = b0 === b1 && b0 === b2 && b0 === b3;
    }
    if (qSlot.uniform) return qSlot.b0;

    const fx = (ix & 3) * 0.25, fz = (iz & 3) * 0.25;
    const d0x = fx + qSlot.jx0, d0z = fz + qSlot.jz0;
    let best = d0x * d0x + d0z * d0z;
    let bestB = qSlot.b0;

    const d1x = fx - 1 + qSlot.jx1, d1z = fz + qSlot.jz1;
    const d1 = d1x * d1x + d1z * d1z;
    if (d1 < best) { best = d1; bestB = qSlot.b1; }

    const d2x = fx + qSlot.jx2, d2z = fz - 1 + qSlot.jz2;
    const d2 = d2x * d2x + d2z * d2z;
    if (d2 < best) { best = d2; bestB = qSlot.b2; }

    const d3x = fx - 1 + qSlot.jx3, d3z = fz - 1 + qSlot.jz3;
    const d3 = d3x * d3x + d3z * d3z;
    if (d3 < best) bestB = qSlot.b3;

    return bestB;
  }

  /** Smooth (unzoomed) climate lookup at an exact column — used by the zoomer once the quart cell is chosen. */
  cellBiome(x: number, z: number): string {
    const c = this.column(x, z);
    return c.biome || (c.biome = this.computeBiome(c));
  }

  /**
   * Exact Java Edition 1.18–1.21 OverworldBiomeBuilder lookup from multi-noise parameters.
   * Deliberately independent of raw block height `h` so biome borders never flicker on small ponds or cliffs.
   */
  private computeBiome(c: Column): string {
    const { C, E, W, T: Tv, H: Hv, pv } = c;
    const T = levelOf(Tv, TEMP_BOUNDS);
    const H = levelOf(Hv, HUMID_BOUNDS);
    const EIdx = levelOf(E, EROSION_BOUNDS);

    // 1. Non-inland biomes (Mushroom Fields & 5-temperature Oceans / Deep Oceans)
    if (C < -1.05) return 'mushroom_fields';
    if (C < -0.455) {
      if (T === 0) return 'deep_frozen_ocean';
      if (T === 1) return 'deep_cold_ocean';
      if (T === 2) return 'deep_ocean';
      if (T === 3) return 'deep_lukewarm_ocean';
      return 'warm_ocean';
    }
    if (C < -0.19) {
      if (T === 0) return 'frozen_ocean';
      if (T === 1) return 'cold_ocean';
      if (T === 2) return 'ocean';
      if (T === 3) return 'lukewarm_ocean';
      return 'warm_ocean';
    }

    const cBand = C < -0.11 ? 0 : C < 0.03 ? 1 : C < 0.30 ? 2 : 3;
    const pvBand = pv < -0.85 ? 0 : pv < -0.20 ? 1 : pv < 0.20 ? 2 : pv < 0.70 ? 3 : 4;

    if (pvBand === 0) {
      // Valleys
      const riv = T === 0 ? 'frozen_river' : 'river';
      if (EIdx <= 1) return cBand <= 1 ? riv : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
      if (EIdx <= 5) return riv;
      return cBand === 0 || T === 0 ? riv : (T <= 2 ? 'swamp' : 'mangrove_swamp');
    }

    if (pvBand === 1) {
      // Low Slice
      if (EIdx <= 1) {
        if (cBand === 0) return 'stony_shore';
        if (cBand === 1) return T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W);
        return T === 0 ? biomeSlope(H) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
      }
      if (EIdx === 2) return cBand === 0 ? 'stony_shore' : cBand === 1 ? biomeMiddle(T, H, W) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
      if (EIdx === 3) return cBand === 0 ? biomeBeach(T) : cBand === 1 ? biomeMiddle(T, H, W) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
      if (EIdx === 4) return cBand === 0 ? biomeBeach(T) : biomeMiddle(T, H, W);
      if (EIdx === 5) {
        const ws = W > 0 && T >= 2 && H <= 3 ? 'windswept_savanna' : biomeMiddle(T, H, W);
        return cBand === 0 ? (W < 0 ? biomeBeach(T) : ws) : cBand === 1 ? ws : biomeMiddle(T, H, W);
      }
      return cBand === 0 ? biomeBeach(T) : (T === 0 ? biomeMiddle(T, H, W) : T <= 2 ? 'swamp' : 'mangrove_swamp');
    }

    if (pvBand === 2) {
      // Mid Slice
      if (EIdx === 0) {
        if (cBand === 0) return 'stony_shore';
        return T < 3 ? biomeSlope(H) : biomePlateau(T, H, W);
      }
      if (EIdx === 1) {
        if (cBand === 0) return 'stony_shore';
        if (cBand <= 2) return T === 0 ? biomeSlope(H) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
        return T === 0 ? biomeSlope(H) : biomePlateau(T, H, W);
      }
      if (EIdx === 2) {
        if (cBand === 0) return 'stony_shore';
        if (cBand === 1) return biomeMiddle(T, H, W);
        if (cBand === 2) return T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W);
        return biomePlateau(T, H, W);
      }
      if (EIdx === 3) return cBand <= 1 ? biomeMiddle(T, H, W) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
      if (EIdx === 4) return cBand === 0 && W < 0 ? biomeBeach(T) : biomeMiddle(T, H, W);
      if (EIdx === 5) {
        const ws = W > 0 && T >= 2 && H <= 3 ? 'windswept_savanna' : biomeMiddle(T, H, W);
        return cBand === 0 ? (W < 0 ? biomeBeach(T) : ws) : cBand === 1 ? ws : biomeShattered(T, H, W);
      }
      return cBand === 0 ? (W < 0 ? biomeBeach(T) : biomeMiddle(T, H, W)) : (T === 0 ? biomeMiddle(T, H, W) : T <= 2 ? 'swamp' : 'mangrove_swamp');
    }

    if (pvBand === 3) {
      // High Slice
      if (EIdx === 0) {
        if (cBand === 0) return biomeMiddle(T, H, W);
        if (cBand === 1) return T < 3 ? biomeSlope(H) : biomePlateau(T, H, W);
        return biomePeak(T, H, W);
      }
      if (EIdx === 1) {
        if (cBand === 0) return biomeMiddle(T, H, W);
        if (cBand === 1) return T === 0 ? biomeSlope(H) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W));
        return T < 3 ? biomeSlope(H) : biomePlateau(T, H, W);
      }
      if (EIdx === 2) return cBand <= 1 ? biomeMiddle(T, H, W) : biomePlateau(T, H, W);
      if (EIdx === 3) return cBand <= 1 ? biomeMiddle(T, H, W) : cBand === 2 ? (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W)) : biomePlateau(T, H, W);
      if (EIdx === 4) return biomeMiddle(T, H, W);
      if (EIdx === 5) return cBand <= 1 ? (W > 0 && T >= 2 && H <= 3 ? 'windswept_savanna' : biomeMiddle(T, H, W)) : biomeShattered(T, H, W);
      return biomeMiddle(T, H, W);
    }

    // pvBand === 4 (Peaks)
    if (EIdx === 0) return cBand === 0 ? (T === 0 ? biomeSlope(H) : biomeMiddle(T, H, W)) : biomePeak(T, H, W);
    if (EIdx === 1) return cBand <= 1 ? (T === 0 ? biomeSlope(H) : (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W))) : biomePeak(T, H, W);
    if (EIdx === 2) return cBand <= 1 ? biomeMiddle(T, H, W) : biomePlateau(T, H, W);
    if (EIdx === 3) return cBand <= 1 ? biomeMiddle(T, H, W) : cBand === 2 ? (T === 4 ? biomeBadlands(H, W) : biomeMiddle(T, H, W)) : biomePlateau(T, H, W);
    if (EIdx === 4) return biomeMiddle(T, H, W);
    if (EIdx === 5) return cBand <= 1 ? (W > 0 && T >= 2 && H <= 3 ? 'windswept_savanna' : biomeShattered(T, H, W)) : biomeShattered(T, H, W);
    return biomeMiddle(T, H, W);
  }
}
