/*
 * Natural mob spawning and despawning — a port of Java Edition's NaturalSpawner, Mob.checkDespawn, PhantomSpawner and PatrolSpawner.
 *
 * Verified against the Minecraft Wiki ("Mob spawning", "Spawn" light rules) and the Java classes:
 *   - Mob caps per category: monster 70, creature 10, ambient 15, axolotls 5, underground water creature 5, water creature 5,
 *     water ambient 20; scaled by (spawnable chunks ÷ 289). Persistent mobs (named, tamed, leashed, riding, raid members…) do not count.
 *   - One spawn cycle per game tick for every category, except creatures (animals): once every 400 ticks.
 *   - For every eligible chunk and category below its cap: a random column, a random Y between the world bottom and the
 *     heightmap + 1 (so low ceilings / perimeters raise the rates), abort if that block is an opaque full cube, then 3 pack attempts
 *     of up to ceil(rand·4) members, each offset by rand(6) − rand(6) on X and Z (triangular ±5).
 *   - A spawn needs: > 24 blocks from the player (and the world spawn), ≤ 128 blocks (fish 64), a valid floor (solid top face,
 *     light emission < 14, not glass / leaves / ice / bedrock…), a free non-fluid, non-rail, non-redstone cell, a collision-free box,
 *     and for monsters darkness: sky light must not exceed rand(32), block light must be 0 (1.18+; 15 allowed in the Nether),
 *     and the combined raw brightness (with thunder: sky darkening 10) must be ≤ rand(8).
 *   - Despawn: instantly beyond 128 blocks (fish 64); beyond 32 blocks a mob idle for more than 600 ticks has a 1/800 chance per
 *     tick; within 32 blocks the idle counter resets. Animals never despawn.
 */

export type MobCategory = 'monster' | 'creature' | 'ambient' | 'axolotls' | 'underground_water_creature' | 'water_creature' | 'water_ambient' | 'misc';
export const MOB_CAP: Record<MobCategory, number> = {
  monster: 70, creature: 10, ambient: 15, axolotls: 5, underground_water_creature: 5, water_creature: 5, water_ambient: 20, misc: -1,
};
/** Vanilla enum order — the order categories are processed for every chunk. */
export const SPAWN_CATEGORIES: readonly MobCategory[] = ['monster', 'creature', 'ambient', 'axolotls', 'underground_water_creature', 'water_creature', 'water_ambient'];
export const DESPAWN_DISTANCE: Record<MobCategory, number> = {
  monster: 128, creature: 128, ambient: 128, axolotls: 128, underground_water_creature: 128, water_creature: 128, water_ambient: 64, misc: 128,
};
export const NO_DESPAWN_DISTANCE = 32, MIN_SPAWN_DISTANCE = 24, CREATURE_INTERVAL = 400, CAP_CHUNKS = 289;

const MONSTERS = new Set([
  'zombie', 'skeleton', 'creeper', 'spider', 'cave_spider', 'enderman', 'witch', 'slime', 'zombie_villager', 'husk', 'stray', 'drowned',
  'phantom', 'blaze', 'ghast', 'magma_cube', 'wither_skeleton', 'piglin', 'piglin_brute', 'hoglin', 'zoglin', 'zombified_piglin',
  'pillager', 'vindicator', 'evoker', 'ravager', 'vex', 'guardian', 'elder_guardian', 'shulker', 'silverfish', 'endermite', 'warden',
  'wither', 'dragon', 'bogged', 'breeze', 'illusioner', 'giant',
]);
const WATER_AMBIENT = new Set(['fish', 'cod', 'salmon', 'pufferfish', 'tropical_fish']);
const MISC = new Set(['villager', 'iron_golem', 'snow_golem']);

export function categoryOf(species: string): MobCategory {
  if (MONSTERS.has(species)) return 'monster';
  if (species === 'bat') return 'ambient';
  if (species === 'axolotl') return 'axolotls';
  if (species === 'glow_squid') return 'underground_water_creature';
  if (species === 'squid' || species === 'dolphin') return 'water_creature';
  if (WATER_AMBIENT.has(species)) return 'water_ambient';
  if (MISC.has(species)) return 'misc';
  return 'creature';
}
/** Mob.removeWhenFarAway: animals stay forever, everything else can despawn. */
export function removesWhenFar(category: MobCategory): boolean { return category !== 'creature' && category !== 'misc'; }

/** Global cap for a category given the number of spawnable chunks around the player (17×17 = 289 at full range). */
export function mobCap(category: MobCategory, chunks: number, scale = 1): number {
  return Math.floor((MOB_CAP[category] * chunks) / CAP_CHUNKS * scale);
}

// ------------------------------------------------------------------------------------------------------------ despawning
export interface DespawnState { noActionTime: number }
/**
 * Mob.checkDespawn for one game tick. `distSq` is the squared distance to the nearest player. `extraIdle` adds the +2/tick that
 * monsters in bright light and illagers get. Returns true when the mob must be removed.
 */
export function despawnTick(s: DespawnState, category: MobCategory, distSq: number, rnd: () => number, persistent = false, extraIdle = 0): boolean {
  if (persistent || !removesWhenFar(category)) { s.noActionTime = 0; return false; }
  s.noActionTime += 1 + extraIdle;
  const far = DESPAWN_DISTANCE[category];
  if (distSq > far * far) return true;
  const near = NO_DESPAWN_DISTANCE * NO_DESPAWN_DISTANCE;
  if (s.noActionTime > 600 && Math.floor(rnd() * 800) === 0 && distSq > near) return true;
  if (distSq < near) s.noActionTime = 0;
  return false;
}

// ------------------------------------------------------------------------------------------------------------ light rules
export interface LightRule { blockLimit: number; test: (rnd: () => number) => number }
/** dimension_type: monster_spawn_block_light_limit / monster_spawn_light_level. */
export function lightRule(dimension: string): LightRule {
  if (dimension === 'nether') return { blockLimit: 15, test: () => 7 };
  return { blockLimit: 0, test: rnd => Math.floor(rnd() * 8) };
}
/** Monster.isDarkEnoughToSpawn. `skyDarken` is 0 at noon … 11 at midnight (10 is forced during thunderstorms). */
export function isDarkEnoughToSpawn(sky: number, blockLight: number | (() => number), skyDarken: number, thundering: boolean, dimension: string, rnd: () => number): boolean {
  if (sky > Math.floor(rnd() * 32)) return false;
  const rule = lightRule(dimension);
  // Raw brightness is at least the darkened sky light: when that alone exceeds the highest possible test value (7) the block
  // light does not need to be probed at all.
  if (sky - (thundering ? Math.max(skyDarken, 10) : skyDarken) > 7) return false;
  const block = typeof blockLight === 'function' ? blockLight() : blockLight;
  if (block > rule.blockLimit) return false;
  const raw = Math.max(block, sky - (thundering ? Math.max(skyDarken, 10) : skyDarken));
  return raw <= rule.test(rnd);
}
/** Sky darkening (0-11) from the daylight fraction (1 = noon, 0 = midnight), plus rain. */
export function skyDarkenOf(daylight: number, raining = false, thundering = false): number {
  let f = 1 - Math.max(0, Math.min(1, daylight));
  let b = 1 - f;
  if (raining) b *= 1 - 5 / 16;
  if (thundering) b *= 1 - 5 / 16;
  f = 1 - b;
  return Math.max(0, Math.min(11, Math.floor(f * 11)));
}

// ----------------------------------------------------------------------------------------------------------- slime chunks
/** Java's slime chunk test: new Random(seed + x²·4987142 + x·5947611 + z²·4392871 + z·389711 ^ 987234911).nextInt(10) == 0. */
export function isSlimeChunk(seed: number | bigint, cx: number, cz: number): boolean {
  const M = (1n << 48n) - 1n;
  const s = BigInt.asIntN(64, BigInt(seed) + BigInt(Math.imul(Math.imul(cx, cx), 4987142)) + BigInt(Math.imul(cx, 5947611))
    + BigInt(Math.imul(cz, cz)) * 4392871n + BigInt(Math.imul(cz, 389711))) ^ 987234911n;
  let state = (s ^ 0x5DEECE66Dn) & M;
  for (;;) {
    state = (state * 0x5DEECE66Dn + 0xBn) & M;
    const bits = Number(state >> 17n), val = bits % 10;
    if (bits - val + 9 < 2147483648) return val === 0;
  }
}

// ------------------------------------------------------------------------------------------------------------ spawn lists
export interface SpawnEntry { species: string; weight: number; min: number; max: number }
const E = (species: string, weight: number, min: number, max: number): SpawnEntry => ({ species, weight, min, max });
const FARM = [E('sheep', 12, 4, 4), E('pig', 10, 4, 4), E('chicken', 10, 4, 4), E('cow', 8, 4, 4)];
const MONSTERS_DEFAULT = [E('spider', 100, 4, 4), E('zombie', 95, 4, 4), E('zombie_villager', 5, 1, 1), E('skeleton', 100, 4, 4),
  E('creeper', 100, 4, 4), E('slime', 100, 4, 4), E('enderman', 10, 1, 4), E('witch', 5, 1, 1)];
const has = (b: string, ...k: string[]) => k.some(s => b.includes(s));

/** Biome spawn settings (BiomeDefaultFeatures / the wiki's per-biome tables). */
export function spawnList(category: MobCategory, biome: string, dimension: string): SpawnEntry[] {
  const b = biome;
  if (dimension === 'nether') {
    if (category === 'creature') return [E('strider', 60, 1, 2)];
    if (category !== 'monster') return [];
    if (has(b, 'soul_sand')) return [E('skeleton', 20, 5, 5), E('ghast', 50, 4, 4), E('enderman', 1, 4, 4)];
    if (has(b, 'crimson')) return [E('zombified_piglin', 1, 2, 4), E('hoglin', 9, 3, 4), E('piglin', 5, 3, 4)];
    if (has(b, 'warped')) return [E('enderman', 1, 4, 4)];
    if (has(b, 'basalt')) return [E('ghast', 40, 1, 1), E('magma_cube', 100, 2, 5)];
    return [E('ghast', 50, 4, 4), E('zombified_piglin', 100, 4, 4), E('magma_cube', 2, 4, 4), E('enderman', 1, 4, 4), E('piglin', 15, 4, 4)];
  }
  if (dimension === 'end') return category === 'monster' ? [E('enderman', 10, 4, 4)] : [];
  const ocean = has(b, 'ocean'), river = has(b, 'river');
  switch (category) {
    case 'monster': {
      if (has(b, 'mushroom', 'deep_dark')) return [];
      let list = MONSTERS_DEFAULT;
      if (has(b, 'desert')) list = list.filter(e => e.species !== 'zombie' && e.species !== 'zombie_villager').concat(E('zombie', 19, 4, 4), E('zombie_villager', 1, 1, 1), E('husk', 80, 4, 4));
      else if (has(b, 'snowy_plains', 'ice_spikes', 'frozen', 'snowy_taiga', 'snowy_slopes', 'snowy_beach')) list = list.filter(e => e.species !== 'skeleton').concat(E('skeleton', 20, 4, 4), E('stray', 80, 4, 4));
      else if (has(b, 'swamp')) list = list.concat(E('slime', 1, 1, 1), E('bogged', 50, 4, 4));
      if (ocean) list = list.concat(E('drowned', 5, 1, 1));
      else if (river) list = list.concat(E('drowned', 100, 1, 1));
      else if (has(b, 'dripstone')) list = list.concat(E('drowned', 95, 4, 4));
      return list;
    }
    case 'creature': {
      if (ocean || river || has(b, 'deep_dark', 'dripstone', 'lush', 'stony_shore', 'snowy_beach', 'pale_garden')) return [];
      if (has(b, 'mushroom')) return [E('mooshroom', 8, 4, 8)];
      if (has(b, 'beach')) return [E('turtle', 5, 2, 5)];
      if (has(b, 'badlands')) return [E('armadillo', 6, 1, 2)];
      if (has(b, 'desert')) return [E('rabbit', 12, 2, 3), E('camel', 1, 1, 1)];
      if (has(b, 'snowy_plains', 'ice_spikes')) return [E('rabbit', 10, 2, 3), E('polar_bear', 1, 1, 2)];
      if (has(b, 'frozen_peaks', 'jagged_peaks')) return [E('goat', 5, 1, 3)];
      if (has(b, 'snowy_slopes')) return [E('rabbit', 4, 2, 3), E('goat', 5, 1, 3)];
      if (has(b, 'grove')) return [E('wolf', 1, 1, 1), E('rabbit', 8, 2, 3), E('fox', 4, 2, 4)];
      if (has(b, 'meadow')) return [E('donkey', 1, 1, 2), E('rabbit', 2, 2, 6), E('sheep', 2, 2, 4)];
      if (has(b, 'cherry')) return [E('pig', 1, 1, 2), E('rabbit', 2, 2, 6), E('sheep', 2, 2, 4)];
      if (has(b, 'taiga')) return FARM.concat(E('wolf', 8, 4, 4), E('rabbit', 4, 2, 3), E('fox', 8, 2, 4));
      if (has(b, 'bamboo')) return FARM.concat(E('chicken', 10, 4, 4), E('parrot', 40, 1, 2), E('panda', 80, 1, 2), E('ocelot', 2, 1, 3));
      if (has(b, 'jungle')) return FARM.concat(E('chicken', 10, 4, 4), E('parrot', has(b, 'sparse') ? 10 : 40, 1, 2), E('panda', 1, 1, 2), E('ocelot', 2, 1, 3));
      if (has(b, 'savanna')) return FARM.concat(E('horse', 1, 2, 6), E('donkey', 1, 1, 1), E('armadillo', 10, 2, 3), ...(has(b, 'plateau', 'windswept') ? [E('llama', 8, 4, 4)] : []));
      if (has(b, 'windswept')) return FARM.concat(E('llama', 5, 4, 6));
      if (has(b, 'swamp')) return FARM.concat(E('frog', 10, 2, 5));
      if (has(b, 'plains')) return FARM.concat(E('horse', 5, 2, 6), E('donkey', 1, 1, 3));
      if (has(b, 'flower')) return FARM.concat(E('rabbit', 4, 2, 3));
      if (has(b, 'forest')) return FARM.concat(E('wolf', 5, 4, 4));
      return FARM;
    }
    case 'ambient': return [E('bat', 10, 8, 8)];
    case 'axolotls': return has(b, 'lush') ? [E('axolotl', 10, 4, 6)] : [];
    case 'underground_water_creature': return [E('glow_squid', 10, 4, 6)];
    case 'water_creature':
      if (river) return [E('squid', 2, 1, 4)];
      if (!ocean) return [];
      if (has(b, 'frozen', 'cold')) return [E('squid', has(b, 'cold') ? 3 : 1, 1, 4)];
      return [E('squid', has(b, 'warm') ? 10 : 1, 1, has(b, 'lukewarm') ? 2 : 4), E('dolphin', has(b, 'warm') ? 2 : 1, 1, 2)];
    case 'water_ambient':
      if (river) return [E('salmon', 5, 1, 5)];
      if (has(b, 'lush')) return [E('tropical_fish', 25, 8, 8)];
      if (!ocean) return [];
      if (has(b, 'lukewarm')) return [E('cod', 15, 3, 6), E('pufferfish', 5, 1, 3), E('tropical_fish', 25, 8, 8)];
      if (has(b, 'warm')) return [E('pufferfish', 15, 1, 3), E('tropical_fish', 25, 8, 8)];
      if (has(b, 'frozen')) return [E('salmon', 15, 1, 5)];
      if (has(b, 'cold')) return [E('cod', 15, 3, 6), E('salmon', 15, 1, 5)];
      return [E('cod', 10, 3, 6)];
    default: return [];
  }
}
export function pickWeighted(list: SpawnEntry[], rnd: () => number): SpawnEntry | null {
  let total = 0;
  for (const e of list) total += e.weight;
  if (total <= 0) return null;
  let r = Math.floor(rnd() * total);
  for (const e of list) { r -= e.weight; if (r < 0) return e; }
  return list[list.length - 1];
}

/** Collision box (width, height) checked before a mob is placed. */
export function spawnBox(species: string): [number, number] {
  switch (species) {
    case 'spider': return [1.4, 0.9]; case 'cave_spider': return [0.7, 0.5]; case 'enderman': return [0.6, 2.9];
    case 'slime': case 'magma_cube': return [2.04, 2.04]; case 'ghast': return [4, 4]; case 'ravager': return [1.95, 2.2];
    case 'creeper': return [0.6, 1.7]; case 'wither_skeleton': return [0.7, 2.4]; case 'hoglin': return [1.4, 1.4];
    case 'chicken': case 'rabbit': case 'bat': case 'parrot': return [0.5, 0.9]; case 'cow': case 'mooshroom': case 'pig': case 'sheep': return [0.9, 1.4];
    case 'horse': case 'donkey': case 'llama': case 'camel': case 'polar_bear': case 'panda': return [1.4, 1.6];
    default: return [0.6, 1.95];
  }
}
/** Mob.getMaxSpawnClusterSize */
export function maxCluster(species: string): number {
  if (species === 'wolf' || species === 'tropical_fish' || species === 'cod' || species === 'fish') return 8;
  if (species === 'horse' || species === 'donkey' || species === 'llama') return 6;
  if (species === 'ghast') return 1;
  return 4;
}

// -------------------------------------------------------------------------------------------------------------- the world
/** Cell flags returned by SpawnWorld.cell. */
export const CELL = {
  SOLID: 1,          // blocks movement
  FULL: 2,           // opaque full cube ("redstone conductor") — also means its top face is sturdy
  WATER: 4, LAVA: 8,
  NO_FLOOR: 16,      // never a valid spawn floor: glass, leaves, ice, bedrock, barrier, trapdoors, light emission ≥ 14 …
  NO_INSIDE: 32,     // mobs cannot spawn inside: rails, redstone components, fire, powder snow, sweet berries, wither roses …
  STURDY_TOP: 64,    // non-full block with a full top face (top slabs, upside-down stairs, soul sand, mud)
  UNLOADED: 128,
} as const;

export interface SpawnWorld {
  dimension: string;
  seaLevel: number;
  minY: number;
  seed?: number;
  rnd(): number;
  /** CELL flags of the block at integer coordinates. */
  cell(x: number, y: number, z: number): number;
  /** Block name at integer coordinates (species specific floors: grass_block, sand, clay, mycelium …). */
  name(x: number, y: number, z: number): string;
  /** Heightmap WORLD_SURFACE: Y of the highest non-air block in the column (minY − 1 when empty). */
  topY(x: number, z: number): number;
  biome(x: number, z: number): string;
  skyLight(x: number, y: number, z: number): number;
  blockLight(x: number, y: number, z: number): number;
  /** 0 (noon) … 11 (midnight). */
  skyDarken(): number;
  thundering?(): boolean;
  /** 0-1, full moon = 1 (swamp slimes). */
  moonBrightness?(): number;
  /** Species the game knows how to build (unknown ones are skipped). */
  supports?(species: string): boolean;
  /** Structure overrides (witch hut, monument, fortress, outpost): return a list to replace the biome list. */
  structureSpawns?(category: MobCategory, x: number, y: number, z: number): SpawnEntry[] | null;
  /** Creates the mob. Return false when it could not be placed. */
  spawn(species: string, x: number, y: number, z: number, category: MobCategory): boolean;
}
export interface SpawnContext {
  /** Player position (single player). */
  px: number; py: number; pz: number;
  /** World spawn point: nothing spawns within 24 blocks of it. */
  worldSpawn?: [number, number, number] | null;
  /** Game tick counter (creatures only spawn when tick % 400 == 0). */
  tick: number;
  /** Current number of non-persistent mobs per category (updated in place as mobs spawn). */
  counts: Record<MobCategory, number>;
  /** Radius, in chunks, of the loaded square around the player (≤ 8 is used for spawning). */
  chunkRadius: number;
  peaceful: boolean;
  /** Game rules doMobSpawning / spawnMonsters. */
  spawnMonsters?: boolean; spawnAnimals?: boolean;
  /** Cap multiplier (1 = vanilla). */
  capScale?: number;
}

const ANIMAL_FLOORS: Record<string, string[]> = {
  rabbit: ['grass_block', 'snow_block', 'snow', 'sand'], fox: ['grass_block', 'snow_block', 'snow', 'podzol', 'coarse_dirt'],
  wolf: ['grass_block', 'snow_block', 'snow', 'podzol', 'coarse_dirt'], goat: ['grass_block', 'stone', 'snow_block', 'snow', 'packed_ice', 'gravel'],
  polar_bear: ['ice', 'snow_block', 'grass_block'], mooshroom: ['mycelium'], turtle: ['sand'], camel: ['sand', 'red_sand', 'sandstone'],
  armadillo: ['grass_block', 'coarse_dirt', 'red_sand', 'terracotta'], frog: ['grass_block', 'mud', 'mangrove_roots'],
  parrot: ['grass_block', 'leaves', 'log'], ocelot: ['grass_block', 'leaves'], strider: [],
};

export class NaturalSpawner {
  /** Spawns made by the last tick, per category (diagnostics / tests). */
  last: Partial<Record<MobCategory, number>> = {};
  /** Total spawn attempts that reached the rule checks during the last tick. */
  attempts = 0;

  /** Number of chunks used for the cap formula. */
  static capChunks(chunkRadius: number): number { const r = Math.max(0, Math.min(8, Math.floor(chunkRadius))); return (2 * r + 1) ** 2; }

  validFloor(w: SpawnWorld, x: number, y: number, z: number): boolean {
    const c = w.cell(x, y, z);
    if (c & (CELL.NO_FLOOR | CELL.UNLOADED)) return false;
    return (c & (CELL.FULL | CELL.STURDY_TOP)) !== 0;
  }
  emptyForSpawn(w: SpawnWorld, x: number, y: number, z: number): boolean {
    return (w.cell(x, y, z) & (CELL.SOLID | CELL.FULL | CELL.WATER | CELL.LAVA | CELL.NO_INSIDE | CELL.UNLOADED)) === 0;
  }
  private boxFree(w: SpawnWorld, species: string, x: number, y: number, z: number, water: boolean): boolean {
    const [bw, bh] = spawnBox(species), r = bw / 2;
    for (let yy = y; yy <= Math.floor(y + bh - 1e-6); yy++)
      for (let zz = Math.floor(z + 0.5 - r); zz <= Math.floor(z + 0.5 + r - 1e-6); zz++)
        for (let xx = Math.floor(x + 0.5 - r); xx <= Math.floor(x + 0.5 + r - 1e-6); xx++) {
          const c = w.cell(xx, yy, zz);
          if (c & (CELL.SOLID | CELL.FULL | CELL.UNLOADED)) return false;
          if (!water && c & (CELL.WATER | CELL.LAVA)) return false;
        }
    return true;
  }

  /** SpawnPlacements + the species' own checkSpawnRules at an integer block position. */
  canSpawnAt(w: SpawnWorld, species: string, category: MobCategory, x: number, y: number, z: number, peaceful = false): boolean {
    const rnd = () => w.rnd();
    const here = w.cell(x, y, z);
    if (here & CELL.UNLOADED) return false;
    const inWater = category === 'water_creature' || category === 'water_ambient' || category === 'underground_water_creature' || category === 'axolotls'
      || species === 'drowned' || species === 'guardian';
    if (inWater) {
      if (!(here & CELL.WATER) || w.cell(x, y + 1, z) & CELL.FULL) return false;
      if (!this.boxFree(w, species, x, y, z, true)) return false;
      if (species === 'drowned') {
        if (peaceful || !isDarkEnoughToSpawn(w.skyLight(x, y, z), () => w.blockLight(x, y, z), w.skyDarken(), !!w.thundering?.(), w.dimension, rnd)) return false;
        const b = w.biome(x, z);
        return b.includes('river') ? Math.floor(rnd() * 15) === 0 : Math.floor(rnd() * 40) === 0 && y < w.seaLevel - 5;
      }
      if (species === 'guardian') return !peaceful && (Math.floor(rnd() * 20) === 0 || w.skyLight(x, y, z) === 0);
      if (category === 'underground_water_creature') return y <= w.seaLevel - 33 && Math.max(w.blockLight(x, y, z), w.skyLight(x, y, z) - w.skyDarken()) === 0;
      if (category === 'axolotls') return w.name(x, y - 1, z) === 'clay';
      if (species === 'tropical_fish' && w.biome(x, z).includes('lush')) return true;
      // WaterAnimal.checkSurfaceWaterAnimalSpawnRules: between sea level − 13 and sea level, water below and above.
      return y >= w.seaLevel - 13 && y <= w.seaLevel && (w.cell(x, y - 1, z) & CELL.WATER) !== 0 && (w.cell(x, y + 1, z) & CELL.WATER) !== 0;
    }
    if (species === 'strider') {                              // IN_LAVA placement: lava source with air above
      return (here & CELL.LAVA) !== 0 && (w.cell(x, y + 1, z) & (CELL.SOLID | CELL.LAVA | CELL.WATER)) === 0;
    }
    const flying = species === 'ghast' || species === 'phantom';
    if (!flying && !this.validFloor(w, x, y - 1, z)) return false;
    if (!this.emptyForSpawn(w, x, y, z) || !this.emptyForSpawn(w, x, y + 1, z)) return false;
    if (!this.boxFree(w, species, x, y, z, false)) return false;
    const sky = w.skyLight(x, y, z), darken = w.skyDarken();
    let blockCache = -1;
    const blockAt = () => (blockCache < 0 ? (blockCache = w.blockLight(x, y, z)) : blockCache);
    if (category === 'monster') {
      if (peaceful && species !== 'piglin' && species !== 'hoglin') return false;
      const floor = w.name(x, y - 1, z);
      if (species === 'ghast') return Math.floor(rnd() * 20) === 0;
      if (species === 'magma_cube') return true;
      if (species === 'zombified_piglin') return floor !== 'nether_wart_block';
      if (species === 'piglin') return floor !== 'nether_wart_block';
      if (species === 'hoglin') return floor !== 'nether_wart_block';
      if (species === 'slime') {
        const b = w.biome(x, z);
        if (b.includes('swamp') && y > 50 && y < 70 && rnd() < 0.5 && rnd() < (w.moonBrightness?.() ?? 0.5)
          && Math.max(blockAt(), sky - darken) <= Math.floor(rnd() * 8)) return true;
        return Math.floor(rnd() * 10) === 0 && isSlimeChunk(w.seed ?? 0, x >> 4, z >> 4) && y < 40;
      }
      if (!isDarkEnoughToSpawn(sky, blockAt, darken, !!w.thundering?.(), w.dimension, rnd)) return false;
      if (species === 'husk' || species === 'stray') return sky > 0;            // need to see the sky
      return true;
    }
    if (category === 'ambient') {                              // Bat.checkBatSpawnRules
      if (y >= w.seaLevel) return false;
      return Math.max(blockAt(), sky - darken) <= Math.floor(rnd() * 4);
    }
    // Animal.checkAnimalSpawnRules: the right floor and raw brightness > 8.
    const floor = w.name(x, y - 1, z);
    const allowed = ANIMAL_FLOORS[species];
    const okFloor = allowed ? allowed.some(a => floor === a || floor.endsWith(a)) : floor === 'grass_block';
    if (!okFloor) return false;
    if (species === 'turtle') return y < w.seaLevel + 4;
    return sky > 8 || blockAt() > 8;
  }

  /** NaturalSpawner.spawnCategoryForPosition */
  spawnForPosition(w: SpawnWorld, ctx: SpawnContext, category: MobCategory, sx: number, y: number, sz: number): number {
    if (w.cell(sx, y, sz) & (CELL.FULL | CELL.UNLOADED)) return 0;
    const rnd = () => w.rnd();
    let spawned = 0;
    for (let k = 0; k < 3; k++) {
      let x = sx, z = sz, entry: SpawnEntry | null = null, inGroup = 0;
      let n = Math.ceil(rnd() * 4);
      for (let p = 0; p < n; p++) {
        x += Math.floor(rnd() * 6) - Math.floor(rnd() * 6);
        z += Math.floor(rnd() * 6) - Math.floor(rnd() * 6);
        const dx = x + 0.5 - ctx.px, dy = y - ctx.py, dz = z + 0.5 - ctx.pz, distSq = dx * dx + dy * dy + dz * dz;
        if (distSq <= MIN_SPAWN_DISTANCE * MIN_SPAWN_DISTANCE) continue;
        const ws = ctx.worldSpawn;
        if (ws && (x + 0.5 - ws[0]) ** 2 + (y - ws[1]) ** 2 + (z + 0.5 - ws[2]) ** 2 < MIN_SPAWN_DISTANCE * MIN_SPAWN_DISTANCE) continue;
        if (!entry) {
          let list = w.structureSpawns?.(category, x, y, z) ?? spawnList(category, w.biome(x, z), w.dimension);
          if (w.supports) list = list.filter(e => w.supports!(e.species));
          entry = pickWeighted(list, rnd);
          if (!entry) break;
          n = entry.min + Math.floor(rnd() * (1 + entry.max - entry.min));
        }
        const far = DESPAWN_DISTANCE[category];
        if (distSq > far * far) continue;
        this.attempts++;
        if (!this.canSpawnAt(w, entry.species, category, x, y, z, ctx.peaceful)) continue;
        if (!w.spawn(entry.species, x + 0.5, y, z + 0.5, category)) continue;
        spawned++; inGroup++;
        ctx.counts[category]++;
        if (spawned >= maxCluster(entry.species)) return spawned;
        if (inGroup >= entry.max && entry.max < 4) break;
      }
    }
    return spawned;
  }

  /** One game tick of natural spawning around the player. Returns the number of mobs spawned. */
  tick(w: SpawnWorld, ctx: SpawnContext): number {
    this.last = {}; this.attempts = 0;
    const R = Math.max(0, Math.min(8, Math.floor(ctx.chunkRadius)));
    const chunks = NaturalSpawner.capChunks(R);
    const rare = ctx.tick % CREATURE_INTERVAL === 0;
    const cats = SPAWN_CATEGORIES.filter(c => {
      if (c === 'monster') return !ctx.peaceful && ctx.spawnMonsters !== false;
      if (ctx.spawnAnimals === false) return false;
      return c !== 'creature' || rare;
    });
    if (!cats.length) return 0;
    const pcx = Math.floor(ctx.px) >> 4, pcz = Math.floor(ctx.pz) >> 4;
    let total = 0;
    for (let cz = pcz - R; cz <= pcz + R; cz++) for (let cx = pcx - R; cx <= pcx + R; cx++) {
      // Only chunks whose centre is within 128 blocks (horizontally) of the player are eligible.
      const ddx = cx * 16 + 8 - ctx.px, ddz = cz * 16 + 8 - ctx.pz;
      if (ddx * ddx + ddz * ddz >= 128 * 128) continue;
      let x = 0, z = 0, top = NaN;
      for (const c of cats) {
        if (ctx.counts[c] >= mobCap(c, chunks, ctx.capScale ?? 1)) continue;
        if (Number.isNaN(top)) {
          // One random column per chunk and tick, shared by the categories (the heightmap lookup is the costly part); Y is rolled
          // independently per category between the world bottom and the heightmap + 1, exactly as getRandomPosWithin does.
          x = cx * 16 + Math.floor(w.rnd() * 16); z = cz * 16 + Math.floor(w.rnd() * 16);
          top = w.topY(x, z) + 1;
        }
        const y = w.minY + Math.floor(w.rnd() * (top - w.minY + 1));
        if (y < w.minY + 1) continue;
        const n = this.spawnForPosition(w, ctx, c, x, y, z);
        if (n) { total += n; this.last[c] = (this.last[c] ?? 0) + n; }
      }
    }
    return total;
  }
}

// ------------------------------------------------------------------------------------------------------ special spawners
/** PhantomSpawner: every 60-120 s, for a player who has not slept for 3 days (72 000 ticks), above sea level under open sky. */
export class PhantomSpawner {
  nextTick = 0;
  /** Returns how many phantoms to spawn 20-34 blocks above the player this tick. */
  tick(o: { rnd(): number; ticksSinceRest: number; seesSky: boolean; y: number; seaLevel: number; night: boolean; difficulty: string | undefined; dimension: string }): number {
    if (--this.nextTick > 0) return 0;
    this.nextTick = (60 + Math.floor(o.rnd() * 60)) * 20;
    if (o.dimension !== 'overworld' || !o.night || !o.seesSky || o.y < o.seaLevel) return 0;
    if (o.difficulty === 'peaceful') return 0;
    const t = Math.max(1, Math.min(2147483647, Math.floor(o.ticksSinceRest)));
    if (Math.floor(o.rnd() * t) < 72000) return 0;
    const id = o.difficulty === 'easy' ? 1 : o.difficulty === 'hard' ? 3 : 2;
    return 1 + Math.floor(o.rnd() * (id + 1));
  }
}
/** PatrolSpawner: from day 5 on, every 12 000 + rand(1200) ticks, a 1-in-5 chance during the day, 24-48 blocks away, never in a village. */
export class PatrolSpawner {
  nextTick = 12000;
  tick(o: { rnd(): number; day: number; daytime: boolean; dimension: string; nearVillage: boolean; peaceful: boolean }): { dx: number; dz: number; size: number } | null {
    if (--this.nextTick > 0) return null;
    this.nextTick += 12000 + Math.floor(o.rnd() * 1200);
    if (o.peaceful || o.dimension !== 'overworld' || o.day < 5 || !o.daytime) return null;
    if (Math.floor(o.rnd() * 5) !== 0 || o.nearVillage) return null;
    const dx = (24 + Math.floor(o.rnd() * 24)) * (o.rnd() < 0.5 ? -1 : 1), dz = (24 + Math.floor(o.rnd() * 24)) * (o.rnd() < 0.5 ? -1 : 1);
    return { dx, dz, size: 2 + Math.floor(o.rnd() * 4) };
  }
}
