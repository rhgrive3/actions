/*
 * Static mob tables (Record 014 Perfected):
 *  - 48 additional species (bringing total from 31 to 79 species)
 *  - Breeding foods (25 species), taming tables, rideable stats, villager professions & trade tables,
 *    piglin bartering, and raid wave definitions.
 */

export type BodyPlan = 'biped' | 'quad' | 'spider' | 'fish' | 'bird' | 'blob' | 'flyer' | 'strider';

export interface SpeciesInfo {
  plan: BodyPlan;
  skin: string;
  shirt: string;
  pants: string;
  scale: number;
  hp: number;
  speed: number;
  passive: boolean;
  drop: [string, number];
  ja: string;
  fireproof?: boolean;
  burnsInSun?: boolean;
  effect?: [string, number];
}

export const NEW_SPECIES: Record<string, SpeciesInfo> = {
  // Nether
  piglin:           { plan: 'biped', skin: '#e8a893', shirt: '#c98a6a', pants: '#5a3d2e', scale: 1,    hp: 16, speed: 1.6, passive: false, drop: ['gold_nugget', 1], ja: 'ピグリン' },
  piglin_brute:     { plan: 'biped', skin: '#e8a893', shirt: '#3b2a24', pants: '#2b1e1a', scale: 1.08, hp: 50, speed: 1.5, passive: false, drop: ['golden_axe', 1], ja: 'ピグリンブルート' },
  zombified_piglin: { plan: 'biped', skin: '#c99a7a', shirt: '#6a7a4a', pants: '#4a3a2e', scale: 1,    hp: 20, speed: 1.6, passive: false, drop: ['rotten_flesh', 1], ja: 'ゾンビピグリン', fireproof: true },
  hoglin:           { plan: 'quad',  skin: '#b8785a', shirt: '#9a5c42', pants: '#6a3e2a', scale: 1.25, hp: 40, speed: 1.8, passive: false, drop: ['porkchop', 3], ja: 'ホグリン' },
  zoglin:           { plan: 'quad',  skin: '#c88a8a', shirt: '#9a5c5c', pants: '#6a3e3e', scale: 1.25, hp: 40, speed: 1.8, passive: false, drop: ['rotten_flesh', 2], ja: 'ゾグリン', fireproof: true },
  strider:          { plan: 'strider', skin: '#a53a3a', shirt: '#8a2a2a', pants: '#5a1a1a', scale: 1,  hp: 20, speed: 1.3, passive: true,  drop: ['string', 2], ja: 'ストライダー', fireproof: true },
  wither_skeleton:  { plan: 'biped', skin: '#2a2a2a', shirt: '#1e1e1e', pants: '#262626', scale: 1.18, hp: 20, speed: 1.6, passive: false, drop: ['coal', 1], ja: 'ウィザースケルトン', fireproof: true, effect: ['wither', 8] },
  // Illagers & Raids
  vindicator:       { plan: 'biped', skin: '#ba9472', shirt: '#3b4a4a', pants: '#2a2a2a', scale: 1,    hp: 24, speed: 1.9, passive: false, drop: ['emerald', 1], ja: 'ヴィンディケーター' },
  evoker:           { plan: 'biped', skin: '#ba9472', shirt: '#2a2a2a', pants: '#1a1a1a', scale: 1,    hp: 24, speed: 1.2, passive: false, drop: ['totem_of_undying', 1], ja: 'エヴォーカー' },
  vex:              { plan: 'flyer', skin: '#8fa3c6', shirt: '#6f8ab2', pants: '#5a6d8a', scale: 0.5,  hp: 14, speed: 3.2, passive: false, drop: ['string', 0], ja: 'ヴェックス' },
  ravager:          { plan: 'quad',  skin: '#55606a', shirt: '#3e464e', pants: '#2b3137', scale: 1.9,  hp: 100, speed: 2.0, passive: false, drop: ['saddle', 1], ja: 'ラヴェジャー' },
  // Undead variants
  drowned:          { plan: 'biped', skin: '#6c9c8c', shirt: '#4a7a7a', pants: '#355a66', scale: 1,    hp: 20, speed: 1.5, passive: false, drop: ['rotten_flesh', 1], ja: 'ドラウンド', burnsInSun: true },
  husk:             { plan: 'biped', skin: '#b8a070', shirt: '#8a7a50', pants: '#6a5a40', scale: 1,    hp: 20, speed: 1.5, passive: false, drop: ['rotten_flesh', 1], ja: 'ハスク', effect: ['hunger', 14] },
  zombie_villager:  { plan: 'biped', skin: '#5a8a4a', shirt: '#6a4a32', pants: '#4a3a2a', scale: 1,    hp: 20, speed: 1.4, passive: false, drop: ['rotten_flesh', 2], ja: '村人ゾンビ', burnsInSun: true },
  stray:            { plan: 'biped', skin: '#c8d4d8', shirt: '#6b7f88', pants: '#56666d', scale: 1,    hp: 20, speed: 1.4, passive: false, drop: ['arrow', 2], ja: 'ストレイ', burnsInSun: true, effect: ['slowness', 15] },
  bogged:           { plan: 'biped', skin: '#9aa88a', shirt: '#5a6a4a', pants: '#6a7a5a', scale: 1,    hp: 16, speed: 1.3, passive: false, drop: ['arrow', 2], ja: 'ボグド', burnsInSun: true, effect: ['poison', 5] },
  phantom:          { plan: 'flyer', skin: '#4c5a8a', shirt: '#3b4675', pants: '#2b3356', scale: 1,    hp: 20, speed: 5.0, passive: false, drop: ['phantom_membrane', 1], ja: 'ファントム', burnsInSun: true },
  // Arthropods & Trial Chambers
  cave_spider:      { plan: 'spider', skin: '#1f3a4a', shirt: '#163040', pants: '#102430', scale: 0.7, hp: 12, speed: 2.6, passive: false, drop: ['string', 1], ja: '洞窟グモ', effect: ['poison', 7] },
  silverfish:       { plan: 'blob',  skin: '#8a8f94', shirt: '#6a6f74', pants: '#55595d', scale: 0.4,  hp: 8,  speed: 2.4, passive: false, drop: ['string', 0], ja: 'シルバーフィッシュ' },
  endermite:        { plan: 'blob',  skin: '#3d2e4a', shirt: '#2a1f35', pants: '#1a1222', scale: 0.35, hp: 8,  speed: 2.0, passive: false, drop: ['string', 0], ja: 'エンダーマイト' },
  breeze:           { plan: 'flyer', skin: '#9ab8e8', shirt: '#c9d8f2', pants: '#7a98c8', scale: 0.95, hp: 30, speed: 2.2, passive: false, drop: ['wind_charge', 2], ja: 'ブリーズ' },
  // Aquatic
  guardian:         { plan: 'fish',  skin: '#5f8a7e', shirt: '#d4703a', pants: '#3f665c', scale: 1.2,  hp: 30, speed: 1.4, passive: false, drop: ['prismarine_shard', 2], ja: 'ガーディアン' },
  elder_guardian:   { plan: 'fish',  skin: '#a9b6a8', shirt: '#d4703a', pants: '#7f8f7e', scale: 2.3,  hp: 80, speed: 1.0, passive: false, drop: ['wet_sponge', 1], ja: 'エルダーガーディアン' },
  salmon:           { plan: 'fish',  skin: '#b84a3a', shirt: '#7a8a5a', pants: '#983a2a', scale: 0.65, hp: 3,  speed: 1.5, passive: true,  drop: ['salmon', 1], ja: 'サケ' },
  tropical_fish:    { plan: 'fish',  skin: '#e87a32', shirt: '#f2f2ea', pants: '#e87a32', scale: 0.5,  hp: 3,  speed: 1.4, passive: true,  drop: ['tropical_fish', 1], ja: '熱帯魚' },
  pufferfish:       { plan: 'fish',  skin: '#e8c832', shirt: '#f2e68a', pants: '#c9a82a', scale: 0.55, hp: 3,  speed: 1.0, passive: true,  drop: ['pufferfish', 1], ja: 'フグ' },
  glow_squid:       { plan: 'fish',  skin: '#2fa5a0', shirt: '#4fd0c8', pants: '#1f7570', scale: 1,    hp: 10, speed: 0.7, passive: true,  drop: ['glow_ink_sac', 2], ja: '発光するイカ' },
  axolotl:          { plan: 'fish',  skin: '#f0a1c8', shirt: '#e889b8', pants: '#d070a0', scale: 0.6,  hp: 14, speed: 1.1, passive: true,  drop: ['string', 0], ja: 'ウーパールーパー' },
  tadpole:          { plan: 'fish',  skin: '#4a3a2a', shirt: '#3a2e22', pants: '#2a2018', scale: 0.35, hp: 6,  speed: 1.2, passive: true,  drop: ['slime_ball', 0], ja: 'オタマジャクシ' },
  // Land Animals & Companions
  panda:            { plan: 'quad',  skin: '#efefef', shirt: '#1e1e1e', pants: '#1e1e1e', scale: 1.2,  hp: 20, speed: 0.9, passive: true,  drop: ['bamboo', 1], ja: 'パンダ' },
  polar_bear:       { plan: 'quad',  skin: '#f1f1ec', shirt: '#e4e4dc', pants: '#d4d4cc', scale: 1.35, hp: 30, speed: 1.5, passive: true,  drop: ['cod', 1], ja: 'シロクマ' },
  llama:            { plan: 'quad',  skin: '#d8c9a8', shirt: '#b94a4a', pants: '#b5a689', scale: 1.15, hp: 22, speed: 1.3, passive: true,  drop: ['leather', 1], ja: 'ラマ' },
  parrot:           { plan: 'bird',  skin: '#d9342b', shirt: '#2f6bd2', pants: '#e8c14a', scale: 0.55, hp: 6,  speed: 1.2, passive: true,  drop: ['feather', 1], ja: 'オウム' },
  goat:             { plan: 'quad',  skin: '#d9d3c4', shirt: '#b7b0a1', pants: '#8f887a', scale: 0.95, hp: 10, speed: 1.5, passive: true,  drop: ['mutton', 1], ja: 'ヤギ' },
  frog:             { plan: 'blob',  skin: '#d58a4a', shirt: '#b87239', pants: '#8f5a2c', scale: 0.4,  hp: 10, speed: 1.0, passive: true,  drop: ['slime_ball', 0], ja: 'カエル' },
  camel:            { plan: 'quad',  skin: '#d8b27a', shirt: '#c49c62', pants: '#a9844f', scale: 1.7,  hp: 32, speed: 1.6, passive: true,  drop: ['leather', 1], ja: 'ラクダ' },
  donkey:           { plan: 'quad',  skin: '#8b7b6a', shirt: '#7a6a5a', pants: '#5a4a3a', scale: 1.0,  hp: 24, speed: 2.1, passive: true,  drop: ['leather', 1], ja: 'ロバ' },
  mule:             { plan: 'quad',  skin: '#4a3222', shirt: '#3a261a', pants: '#2e2016', scale: 1.05, hp: 24, speed: 2.2, passive: true,  drop: ['leather', 1], ja: 'ラバ' },
  skeleton_horse:   { plan: 'quad',  skin: '#d8d6c8', shirt: '#c4c2b4', pants: '#b0aea0', scale: 1.1,  hp: 15, speed: 2.6, passive: true,  drop: ['bone', 2], ja: 'スケルトンホース' },
  zombie_horse:     { plan: 'quad',  skin: '#4a7a4a', shirt: '#3a5a3a', pants: '#2a4a2a', scale: 1.1,  hp: 15, speed: 2.3, passive: true,  drop: ['rotten_flesh', 2], ja: 'ゾンビホース' },
  mooshroom:        { plan: 'quad',  skin: '#a8302a', shirt: '#b83a30', pants: '#514638', scale: 1,    hp: 10, speed: 1.1, passive: true,  drop: ['raw_beef', 2], ja: 'ムーシュルーム' },
  armadillo:        { plan: 'quad',  skin: '#b07a6a', shirt: '#c9948a', pants: '#8a5a4e', scale: 0.55, hp: 12, speed: 1.0, passive: true,  drop: ['scute', 1], ja: 'アルマジロ' },
  sniffer:          { plan: 'quad',  skin: '#8a3f3a', shirt: '#5c8a3a', pants: '#6a4a3a', scale: 1.8,  hp: 14, speed: 0.7, passive: true,  drop: ['torchflower_seeds', 1], ja: 'スニッファー' },
  ocelot:           { plan: 'quad',  skin: '#e8c66a', shirt: '#d9b35a', pants: '#b9944a', scale: 0.6,  hp: 10, speed: 2.2, passive: true,  drop: ['string', 0], ja: 'ヤマネコ' },
  snow_golem:       { plan: 'biped', skin: '#f2f6f8', shirt: '#e8842a', pants: '#e4edf0', scale: 1,    hp: 4,  speed: 1.2, passive: true,  drop: ['snowball', 4], ja: 'スノーゴーレム' },
  wandering_trader: { plan: 'biped', skin: '#ba9472', shirt: '#3a62b8', pants: '#2a3a6a', scale: 1,    hp: 20, speed: 1.1, passive: true,  drop: ['emerald', 1], ja: '行商人' },
  allay:            { plan: 'flyer', skin: '#8fd0f0', shirt: '#5fb0e8', pants: '#3f90c8', scale: 0.45, hp: 20, speed: 2.5, passive: true,  drop: ['string', 0], ja: 'アレイ' },
  bat:              { plan: 'flyer', skin: '#3a2e26', shirt: '#4a3a30', pants: '#2a1e18', scale: 0.4,  hp: 6,  speed: 2.2, passive: true,  drop: ['string', 0], ja: 'コウモリ' },
};

export const RAIDERS = new Set(['pillager', 'vindicator', 'evoker', 'ravager', 'vex', 'witch']);

export const BREED_FOOD: Record<string, string[]> = {
  cow: ['wheat'], mooshroom: ['wheat'], sheep: ['wheat'], goat: ['wheat'],
  pig: ['carrot', 'potato', 'beetroot'],
  chicken: ['wheat_seeds', 'beetroot_seeds', 'melon_seeds', 'pumpkin_seeds'],
  parrot: [],
  wolf: ['raw_beef', 'porkchop', 'mutton', 'rabbit', 'chicken', 'cooked_beef', 'cooked_porkchop', 'cooked_mutton', 'cooked_rabbit', 'rotten_flesh', 'cooked_chicken'],
  cat: ['cod', 'salmon'], ocelot: ['cod', 'salmon'],
  horse: ['golden_apple', 'golden_carrot', 'enchanted_golden_apple', 'apple', 'wheat', 'sugar'],
  donkey: ['golden_apple', 'golden_carrot', 'apple', 'wheat', 'sugar'],
  mule: ['golden_apple', 'golden_carrot', 'apple'],
  rabbit: ['carrot', 'golden_carrot', 'dandelion'],
  llama: ['hay_block'], camel: ['cactus'],
  fox: ['sweet_berries', 'glow_berries'],
  panda: ['bamboo'], turtle: ['seagrass'],
  frog: ['slime_ball'], axolotl: ['tropical_fish'],
  hoglin: ['crimson_fungus'], strider: ['warped_fungus'],
  armadillo: ['spider_eye'],
  bee: ['dandelion', 'poppy', 'allium', 'azure_bluet', 'blue_orchid', 'cornflower', 'oxeye_daisy', 'lily_of_the_valley', 'sunflower'],
  sniffer: ['torchflower_seeds', 'wheat_seeds'],
};

export const TAME_FOOD: Record<string, { items: string[]; chance: number }> = {
  wolf: { items: ['bone'], chance: 1 / 3 },
  cat: { items: ['cod', 'salmon'], chance: 1 / 3 },
  ocelot: { items: ['cod', 'salmon'], chance: 1 / 3 },
  parrot: { items: ['wheat_seeds', 'melon_seeds', 'pumpkin_seeds', 'beetroot_seeds'], chance: 1 / 3 },
};

export const RIDE_TAME = new Set(['horse', 'donkey', 'mule', 'skeleton_horse', 'zombie_horse', 'llama', 'camel']);
export const SADDLEABLE = new Set(['horse', 'donkey', 'mule', 'skeleton_horse', 'zombie_horse', 'pig', 'strider', 'camel']);
export const LEASHABLE = new Set([
  'cow', 'pig', 'sheep', 'chicken', 'wolf', 'cat', 'horse', 'donkey', 'mule', 'skeleton_horse', 'zombie_horse',
  'llama', 'camel', 'goat', 'fox', 'rabbit', 'bee', 'parrot', 'polar_bear', 'panda', 'mooshroom', 'strider',
  'hoglin', 'dolphin', 'axolotl', 'frog', 'ocelot', 'sniffer', 'allay', 'armadillo', 'snow_golem', 'iron_golem', 'squid', 'glow_squid',
]);
export const RIDE: Record<string, { seat: number; speed: number; jump: number }> = {
  horse: { seat: 1.5, speed: 9, jump: 1.9 },
  donkey: { seat: 1.3, speed: 6.5, jump: 1.2 },
  mule: { seat: 1.35, speed: 7.2, jump: 1.4 },
  skeleton_horse: { seat: 1.5, speed: 8.5, jump: 1.8 },
  zombie_horse: { seat: 1.5, speed: 8.0, jump: 1.6 },
  pig: { seat: 0.95, speed: 3.8, jump: 0 },
  strider: { seat: 1.7, speed: 4.5, jump: 0 },
  camel: { seat: 2.1, speed: 6.0, jump: 1.5 },
  llama: { seat: 1.5, speed: 0, jump: 0 },
};

// ------------------------------------------------------------------ villagers

export type Profession =
  | 'none'
  | 'unemployed'
  | 'farmer'
  | 'librarian'
  | 'armorer'
  | 'toolsmith'
  | 'weaponsmith'
  | 'cleric'
  | 'butcher'
  | 'cartographer'
  | 'fletcher'
  | 'shepherd'
  | 'mason'
  | 'leatherworker'
  | 'fisherman'
  | 'nitwit';

export const JOB_SITES: Record<string, Profession> = {
  composter: 'farmer',
  lectern: 'librarian',
  blast_furnace: 'armorer',
  smithing_table: 'toolsmith',
  grindstone: 'weaponsmith',
  brewing_stand: 'cleric',
  smoker: 'butcher',
  cartography_table: 'cartographer',
  fletching_table: 'fletcher',
  loom: 'shepherd',
  stonecutter: 'mason',
  cauldron: 'leatherworker',
  barrel: 'fisherman',
};

export const PROFESSION_JA: Record<Profession, string> = {
  none: '無職',
  unemployed: '無職',
  farmer: '農民',
  librarian: '司書',
  armorer: '防具鍛冶',
  toolsmith: '道具鍛冶',
  weaponsmith: '武器鍛冶',
  cleric: '聖職者',
  butcher: '肉屋',
  cartographer: '製図家',
  fletcher: '矢師',
  shepherd: '羊飼い',
  mason: '石工',
  leatherworker: '革細工師',
  fisherman: '漁師',
  nitwit: '無能',
};

export const LEVEL_NAMES = ['', 'Novice', 'Apprentice', 'Journeyman', 'Expert', 'Master'];
export const LEVEL_JA = ['', '新米', '見習い', '一人前', '熟練者', '達人'];
export const LEVEL_XP = [0, 0, 10, 70, 150, 250];

export interface Offer {
  id: string;
  give: string;
  n: number;
  cost: number;
  get: string;
  result: string;
  count: number;
  xp: number;
  level: number;
  maxUses: number;
  ench?: Record<string, number>;
  /** Explorer map trades: the located target, or `pending` while the background structure search is still running. */
  map?: { kind: string; x: number; z: number; icon: string };
  pending?: boolean;
}
const o = (give: string, n: number, get: string, count: number, xp: number, level: number, ench?: Record<string, number>): Offer => ({
  id: `${give}_${n}_${get}_${level}`,
  give,
  n,
  cost: n,
  get,
  result: get,
  count,
  xp,
  level,
  maxUses: 12,
  ench,
});

export const TRADES: Record<Profession, Offer[]> = {
  none: [],
  unemployed: [],
  nitwit: [],
  farmer: [
    o('wheat', 20, 'emerald', 1, 2, 1), o('potato', 26, 'emerald', 1, 2, 1), o('carrot', 22, 'emerald', 1, 2, 1), o('emerald', 1, 'bread', 6, 1, 1),
    o('pumpkin_block', 6, 'emerald', 1, 10, 2), o('emerald', 1, 'pumpkin_pie', 4, 5, 2), o('emerald', 1, 'apple', 4, 5, 2),
    o('emerald', 3, 'cookie', 18, 20, 3), o('melon_block', 4, 'emerald', 1, 20, 3),
    o('emerald', 1, 'cake', 1, 15, 4),
    o('emerald', 3, 'golden_carrot', 3, 15, 5), o('emerald', 4, 'glistering_melon_slice', 3, 30, 5),
  ],
  librarian: [
    o('paper', 24, 'emerald', 1, 2, 1), o('emerald', 9, 'bookshelf', 1, 1, 1), o('emerald', 5, 'enchanted_book', 1, 1, 1, { mending: 1 }),
    o('book', 4, 'emerald', 1, 10, 2), o('emerald', 1, 'lantern', 1, 5, 2),
    o('ink_sac', 5, 'emerald', 1, 20, 3), o('emerald', 1, 'glass', 4, 10, 3),
    o('book_and_quill', 2, 'emerald', 1, 30, 4), o('emerald', 5, 'clock', 1, 15, 4),
    o('emerald', 20, 'name_tag', 1, 30, 5),
  ],
  armorer: [
    o('coal', 15, 'emerald', 1, 2, 1), o('emerald', 5, 'iron_helmet', 1, 1, 1), o('emerald', 9, 'iron_chestplate', 1, 1, 1),
    o('iron_ingot', 4, 'emerald', 1, 10, 2), o('emerald', 36, 'bell', 1, 5, 2), o('emerald', 1, 'chainmail_boots', 1, 5, 2),
    o('lava_bucket', 1, 'emerald', 1, 20, 3), o('diamond', 1, 'emerald', 1, 20, 3), o('emerald', 4, 'shield', 1, 10, 3),
    o('emerald', 19, 'diamond_leggings', 1, 15, 4, { protection: 2 }), o('emerald', 13, 'diamond_boots', 1, 15, 4, { feather_falling: 2 }),
    o('emerald', 21, 'diamond_chestplate', 1, 30, 5, { protection: 3 }), o('emerald', 13, 'diamond_helmet', 1, 30, 5, { protection: 3 }),
  ],
  toolsmith: [
    o('coal', 15, 'emerald', 1, 2, 1), o('emerald', 1, 'stone_axe', 1, 1, 1), o('emerald', 1, 'stone_pickaxe', 1, 1, 1),
    o('iron_ingot', 4, 'emerald', 1, 10, 2), o('emerald', 36, 'bell', 1, 5, 2),
    o('flint', 30, 'emerald', 1, 20, 3), o('emerald', 7, 'iron_pickaxe', 1, 10, 3, { efficiency: 2 }),
    o('diamond', 1, 'emerald', 1, 30, 4), o('emerald', 12, 'diamond_axe', 1, 15, 4, { efficiency: 3 }),
    o('emerald', 13, 'diamond_pickaxe', 1, 30, 5, { efficiency: 3, unbreaking: 2 }),
  ],
  weaponsmith: [
    o('coal', 15, 'emerald', 1, 2, 1), o('emerald', 3, 'iron_axe', 1, 1, 1), o('emerald', 7, 'iron_sword', 1, 1, 1, { sharpness: 1 }),
    o('iron_ingot', 4, 'emerald', 1, 10, 2), o('emerald', 36, 'bell', 1, 5, 2),
    o('flint', 24, 'emerald', 1, 20, 3),
    o('diamond', 1, 'emerald', 1, 30, 4), o('emerald', 12, 'diamond_axe', 1, 15, 4, { sharpness: 2 }),
    o('emerald', 13, 'diamond_sword', 1, 30, 5, { sharpness: 3 }),
  ],
  cleric: [
    o('rotten_flesh', 32, 'emerald', 1, 2, 1), o('emerald', 1, 'redstone', 2, 1, 1),
    o('gold_ingot', 3, 'emerald', 1, 10, 2), o('emerald', 1, 'lapis_lazuli', 1, 5, 2),
    o('rabbit_foot', 2, 'emerald', 1, 20, 3), o('emerald', 4, 'glowstone', 1, 10, 3),
    o('scute', 4, 'emerald', 1, 30, 4), o('glass_bottle', 9, 'emerald', 1, 30, 4), o('emerald', 5, 'ender_pearl', 1, 15, 4),
    o('nether_wart', 22, 'emerald', 1, 30, 5), o('emerald', 3, 'experience_bottle', 1, 30, 5),
  ],
  butcher: [
    o('chicken', 14, 'emerald', 1, 2, 1), o('porkchop', 7, 'emerald', 1, 2, 1), o('rabbit', 4, 'emerald', 1, 2, 1), o('emerald', 1, 'rabbit_stew', 1, 1, 1),
    o('coal', 15, 'emerald', 1, 2, 2), o('emerald', 1, 'cooked_porkchop', 5, 5, 2), o('emerald', 1, 'cooked_chicken', 8, 5, 2),
    o('mutton', 7, 'emerald', 1, 20, 3), o('raw_beef', 10, 'emerald', 1, 20, 3),
    o('dried_kelp_block', 10, 'emerald', 1, 30, 4),
    o('sweet_berries', 10, 'emerald', 1, 30, 5),
  ],
  cartographer: [
    o('paper', 24, 'emerald', 1, 2, 1), o('emerald', 7, 'map', 1, 1, 1),
    o('glass_pane', 11, 'emerald', 1, 10, 2), o('emerald', 13, 'filled_map', 1, 5, 2),
    o('compass', 1, 'emerald', 1, 20, 3), o('emerald', 7, 'item_frame', 1, 10, 3),
    o('emerald', 3, 'white_banner', 1, 15, 4),
    o('emerald', 8, 'globe_banner_pattern', 1, 30, 5),
  ],
  fletcher: [
    o('stick', 32, 'emerald', 1, 2, 1), o('emerald', 1, 'arrow', 16, 1, 1), o('gravel', 10, 'emerald', 1, 1, 1),
    o('flint', 26, 'emerald', 1, 10, 2), o('emerald', 2, 'bow', 1, 5, 2),
    o('string', 14, 'emerald', 1, 20, 3), o('emerald', 3, 'crossbow', 1, 10, 3),
    o('feather', 24, 'emerald', 1, 30, 4),
    o('tripwire_hook', 8, 'emerald', 1, 30, 5),
  ],
  shepherd: [
    o('white_wool', 18, 'emerald', 1, 2, 1), o('emerald', 2, 'shears', 1, 1, 1),
    o('white_dye', 12, 'emerald', 1, 10, 2), o('emerald', 1, 'white_wool', 1, 5, 2),
    o('emerald', 3, 'white_bed', 1, 10, 3),
    o('emerald', 3, 'white_banner', 1, 15, 4),
    o('emerald', 2, 'painting', 3, 30, 5),
  ],
  mason: [
    o('clay_ball', 10, 'emerald', 1, 2, 1), o('emerald', 1, 'bricks', 10, 1, 1),
    o('stone', 20, 'emerald', 1, 10, 2), o('emerald', 1, 'chiseled_stone_bricks', 4, 5, 2),
    o('granite', 16, 'emerald', 1, 20, 3), o('emerald', 1, 'polished_andesite', 4, 10, 3),
    o('quartz', 12, 'emerald', 1, 30, 4), o('emerald', 1, 'terracotta', 1, 15, 4),
    o('emerald', 1, 'quartz_pillar', 1, 30, 5), o('emerald', 1, 'quartz_block', 1, 30, 5),
  ],
  leatherworker: [
    o('leather', 6, 'emerald', 1, 2, 1), o('emerald', 3, 'leather_leggings', 1, 1, 1),
    o('flint', 26, 'emerald', 1, 10, 2), o('emerald', 7, 'leather_chestplate', 1, 5, 2),
    o('rabbit_hide', 9, 'emerald', 1, 20, 3), o('emerald', 4, 'leather_helmet', 1, 10, 3),
    o('scute', 4, 'emerald', 1, 30, 4),
    o('emerald', 6, 'saddle', 1, 30, 5),
  ],
  fisherman: [
    o('string', 20, 'emerald', 1, 2, 1), o('coal', 10, 'emerald', 1, 2, 1), o('emerald', 1, 'cooked_cod', 6, 1, 1),
    o('cod', 15, 'emerald', 1, 10, 2), o('emerald', 2, 'campfire', 1, 5, 2),
    o('salmon', 13, 'emerald', 1, 20, 3), o('emerald', 8, 'fishing_rod', 1, 10, 3, { luck_of_the_sea: 2, lure: 2 }),
    o('tropical_fish', 6, 'emerald', 1, 30, 4),
    o('pufferfish', 4, 'emerald', 1, 30, 5), o('emerald', 1, 'boat', 1, 30, 5),
  ],
};

export const TRADER_OFFERS: Offer[] = [
  o('emerald', 1, 'oak_sapling', 1, 1, 1), o('emerald', 1, 'red_sand', 4, 1, 1),
  o('emerald', 5, 'slime_ball', 1, 1, 1), o('emerald', 2, 'kelp', 3, 1, 1),
  o('emerald', 3, 'cactus', 1, 1, 1), o('emerald', 6, 'blue_ice', 1, 1, 1),
  o('emerald', 1, 'fern', 1, 1, 1), o('emerald', 5, 'nautilus_shell', 1, 1, 1),
];

export const BARTER: [string, number][] = [
  ['enchanted_book', 5], ['iron_boots', 8], ['splash_potion', 8], ['potion', 8],
  ['iron_nugget', 10], ['ender_pearl', 10], ['string', 20], ['quartz', 20],
  ['obsidian', 40], ['crying_obsidian', 40], ['fire_charge', 40], ['leather', 40],
  ['soul_sand', 40], ['nether_brick', 40], ['spectral_arrow', 40], ['gravel', 40], ['blackstone', 40],
];

export const RAID_WAVES: Record<string, number>[] = [
  { pillager: 4, vindicator: 1 },
  { pillager: 3, vindicator: 2, ravager: 1 },
  { pillager: 3, vindicator: 2, witch: 1 },
  { pillager: 4, vindicator: 3, evoker: 1, ravager: 1 },
  { pillager: 5, vindicator: 4, evoker: 2, witch: 2, ravager: 2 },
];
