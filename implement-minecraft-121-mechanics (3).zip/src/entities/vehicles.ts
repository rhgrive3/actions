import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import { itemsFromNbt, itemsToNbt, type NbtItem } from '../game/nbt';
import type { Stack } from '../game/types';
import {
  BOAT, boatControl, boatFloat, boatSeatOffset, boatSplashY, canBoardBoat, minecartCollide, newBoatState, pushApart,
  type BoatState, type BoatStatus, type CartBody,
} from './physics';

/*
 * Unified Vehicles System: Minecarts & Boats (Record 014 Perfected).
 *
 * Combines:
 *  - Minecart rail graph following (rail, powered_rail, detector_rail, activator_rail), slopes, corners, buffer stops
 *  - Detector rail activation while a minecart stands on it (implement)
 *  - Activator rail rider dismount on powered activator rails (vanilla)
 *  - Player collision nudge and minecart-to-minecart momentum transfer (implement + vanilla)
 *  - Boat water buoyancy, oar paddling animation, and Vanilla Ice Boat Highway physics (ice / packed_ice / blue_ice)
 *  - Per-dimension vehicle save & load persistence (implement + simplify)
 */

export type VehicleKind = 'minecart' | 'boat' | 'chest_minecart' | 'hopper_minecart' | 'tnt_minecart' | 'furnace_minecart';
const CART_KINDS: readonly string[] = ['minecart', 'chest_minecart', 'hopper_minecart', 'tnt_minecart', 'furnace_minecart'];
export const isCartKind = (k: string): k is VehicleKind => CART_KINDS.includes(k);
/** Furnace minecart: one coal burns 3600 ticks (capped at 32000) and pushes at 0.2 blocks/tick. TNT minecart fuse: 80 ticks. */
export const FURNACE_FUEL_PER_COAL = 3600, FURNACE_FUEL_MAX = 32000, FURNACE_CART_SPEED = 4, TNT_CART_FUSE = 80;
export interface VehicleSave {
  kind: VehicleKind;
  position?: [number, number, number];
  p?: [number, number, number];
  yaw: number;
  /** Vanilla entity NBT of the minecart variants. */
  id?: string; Items?: NbtItem[]; Fuel?: number; PushX?: number; PushZ?: number; TNTFuse?: number; Enabled?: boolean;
}
export interface Vehicle {
  id: number;
  kind: VehicleKind;
  group: THREE.Group;
  pos: THREE.Vector3;
  yaw: number;
  speed: number;
  dx: number;
  dz: number;
  onRail: boolean;
  from: THREE.Vector3;
  to: THREE.Vector3;
  vel: THREE.Vector3;
  hp: number;
  detector: [number, number, number] | null;
  oars?: THREE.Object3D[];
  /** Chest (27) / hopper (5) minecart inventory. */
  items?: (Stack | null)[];
  /** Furnace minecart: ticks of fuel left and the direction it pushes in. */
  fuel: number; pushX: number; pushZ: number;
  /** TNT minecart: ticks until it explodes, -1 = not primed. */
  fuse: number;
  /** Hopper minecart: false while it stands on a powered activator rail. */
  enabled: boolean;
  /** Boat: Java Boat state (per-tick velocity, turning speed, status), 20 Hz accumulator and mob passengers (max 2 riders in total). */
  boat?: BoatState;
  boatAcc?: number;
  passengers?: number[];
  /** Seat index the player took when boarding (0 = front = the one who steers). */
  playerSeat?: number;
}
/** A mob as seen by the vehicles (boarding boats, being pushed). */
export interface VehicleMob { id: number; x: number; y: number; z: number; width: number; aquatic: boolean; riding: boolean }
export interface VehicleHost {
  getCell(x: number, y: number, z: number): number;
  getBlock?(x: number, y: number, z: number): number;
  setBlock?(x: number, y: number, z: number, id: number, state?: number): boolean;
  drop?(x: number, y: number, z: number, name: string, count: number): void;
  sound?(k: string, p?: { x: number; y: number; z: number }): void;
  dropStack?(x: number, y: number, z: number, stack: Stack): void;
  containerAt?(x: number, y: number, z: number): (Stack | null)[] | null;
  /** Removes and returns one dropped item stack lying near the position. */
  takeDrop?(x: number, y: number, z: number): Stack | null;
  explode?(x: number, y: number, z: number, power: number): void;
  emit?(type: string, detail: Record<string, unknown>): void;
  /** Mobs near vehicles: boats pick them up (Boat.tick) and carry them. */
  mobs?(): VehicleMob[];
  setRider?(mobId: number, vehicleId: number | null): boolean;
  /** Puts a riding mob on its seat; false once the mob is dead or gone. */
  placeRider?(mobId: number, x: number, y: number, z: number, yaw: number): boolean;
}
export interface DriveInput {
  move?: { x: number; z: number };
  forward?: number;
  strafe?: number;
  yaw: number;
  run?: boolean;
  ascend?: boolean;
}
export type Control = DriveInput;

const idOf = (c: number) => (c < 0 ? -1 : c & 4095);
const stOf = (c: number) => (c < 0 ? 0 : (c >>> 12) & 15);
export const isRail = (id: number) => id > 0 && (id === ID.rail || id === ID.powered_rail || id === ID.detector_rail || id === ID.activator_rail);
const isIce = (id: number) => id > 0 && (id === ID.ice || id === ID.packed_ice || id === ID.blue_ice || id === ID.frosted_ice);
const solid = (id: number) => id > 0 && !!BLOCKS[id]?.solid && BLOCKS[id]?.shape !== 'cross';
const DIRS: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
export const MAX_CART_SPEED = 8;

export class VehicleManager {
  vehicles: Vehicle[] = [];
  riding: Vehicle | null = null;
  private nextId = 1;
  private time = 0;
  private tickAcc = 0;
  private box = new THREE.BoxGeometry(1, 1, 1);
  private mats = new Map<string, THREE.MeshLambertMaterial>();
  private _seat = new THREE.Vector3();
  private tmp = new THREE.Vector3();

  constructor(public scene: THREE.Scene, public host: VehicleHost) {}

  get list() { return this.vehicles; }
  set list(v: Vehicle[]) { this.vehicles = v; }

  private blockAt(x: number, y: number, z: number): number {
    if (this.host.getBlock) return this.host.getBlock(Math.floor(x), Math.floor(y), Math.floor(z));
    return idOf(this.host.getCell(Math.floor(x), Math.floor(y), Math.floor(z)));
  }

  private mat(c: string) {
    let m = this.mats.get(c);
    if (!m) { m = new THREE.MeshLambertMaterial({ color: c }); this.mats.set(c, m); }
    return m;
  }
  private part(g: THREE.Object3D, c: string, x: number, y: number, z: number, w: number, h: number, d: number) {
    const m = new THREE.Mesh(this.box, this.mat(c));
    m.position.set(x, y, z);
    m.scale.set(w, h, d);
    m.castShadow = true;
    g.add(m);
    return m;
  }

  private model(kind: VehicleKind): { g: THREE.Group; oars: THREE.Object3D[] } {
    const g = new THREE.Group(), oars: THREE.Object3D[] = [];
    if (isCartKind(kind)) {
      this.part(g, '#6d6f72', 0, 0.12, 0, 0.98, 0.1, 0.78);
      this.part(g, '#8a8d90', 0, 0.42, -0.35, 0.98, 0.5, 0.08);
      this.part(g, '#8a8d90', 0, 0.42, 0.35, 0.98, 0.5, 0.08);
      this.part(g, '#8a8d90', -0.45, 0.42, 0, 0.08, 0.5, 0.78);
      this.part(g, '#8a8d90', 0.45, 0.42, 0, 0.08, 0.5, 0.78);
      for (const sx of [-0.3, 0.3]) for (const sz of [-0.28, 0.28]) this.part(g, '#2b2b2b', sx, 0.1, sz, 0.18, 0.2, 0.06);
      const payload: Partial<Record<VehicleKind, string>> = { chest_minecart: '#b3833e', hopper_minecart: '#555d59', tnt_minecart: '#bd5540', furnace_minecart: '#777c76' };
      if (payload[kind]) this.part(g, payload[kind]!, 0, 0.62, 0, 0.74, 0.6, 0.6);
    } else {
      const wood = '#a3783f', dark = '#7d5a2c';
      this.part(g, dark, 0, 0.12, 0, 1.3, 0.1, 0.7);
      this.part(g, wood, 0, 0.3, -0.33, 1.3, 0.3, 0.06);
      this.part(g, wood, 0, 0.3, 0.33, 1.3, 0.3, 0.06);
      this.part(g, wood, -0.63, 0.3, 0, 0.06, 0.3, 0.7);
      this.part(g, wood, 0.63, 0.3, 0, 0.06, 0.3, 0.7);
      this.part(g, '#6b4b22', -0.2, 0.3, 0, 0.1, 0.3, 0.66);
      for (const s of [-1, 1]) {
        const oar = this.part(g, '#8f6a35', 0.05, 0.42, s * 0.5, 0.08, 0.06, 1.1);
        oar.rotation.x = s * 0.4;
        oars.push(oar);
      }
    }
    return { g, oars };
  }

  spawn(kind: VehicleKind, x: number, y: number, z: number, yaw = 0): Vehicle {
    const { g, oars } = this.model(kind);
    const pos = new THREE.Vector3(x, y, z);
    g.position.copy(pos);
    g.rotation.y = yaw;
    this.scene.add(g);
    const v: Vehicle = {
      id: this.nextId++,
      kind,
      group: g,
      pos,
      yaw,
      speed: 0,
      dx: 0,
      dz: 0,
      onRail: isCartKind(kind) && isRail(this.blockAt(x, y, z)),
      from: new THREE.Vector3(Math.floor(x) + 0.5, Math.round(y), Math.floor(z) + 0.5),
      to: new THREE.Vector3(Math.floor(x) + 0.5, Math.round(y), Math.floor(z) + 0.5),
      vel: new THREE.Vector3(),
      hp: 6,
      detector: null,
      oars,
      items: kind === 'chest_minecart' ? Array(27).fill(null) : kind === 'hopper_minecart' ? Array(5).fill(null) : undefined,
      fuel: 0, pushX: 0, pushZ: 0, fuse: -1, enabled: true,
    };
    this.vehicles.push(v);
    return v;
  }

  /** Place a minecart on a rail or a boat on water/ice/ground. Returns true when consumed. */
  place(kind: VehicleKind, x: number, y: number, z: number): boolean {
    if (isCartKind(kind)) {
      let ry = NaN;
      for (const dy of [0, 1, -1]) {
        if (isRail(this.blockAt(x, y + dy, z))) { ry = y + dy; break; }
      }
      if (Number.isNaN(ry)) return false;
      this.spawn(kind, x + 0.5, ry, z + 0.5, 0);
      this.host.sound?.('place', { x, y: ry, z });
      return true;
    }
    let wy = NaN;
    for (const dy of [0, -1, 1]) {
      const bid = this.blockAt(x, y + dy, z);
      if (bid === ID.water || isIce(bid)) { wy = y + dy; break; }
    }
    if (Number.isNaN(wy)) {
      if (solid(this.blockAt(x, y - 1, z)) && this.blockAt(x, y, z) === 0) wy = y - 0.85;
      else return false;
    }
    this.spawn('boat', x + 0.5, wy + 0.85, z + 0.5, 0);
    this.host.sound?.('water', { x, y: wy, z });
    return true;
  }

  pick(origin: THREE.Vector3, dir: THREE.Vector3, reach = 4.5): Vehicle | null {
    let best: Vehicle | null = null, bestD = reach;
    for (const v of this.vehicles) {
      if (v === this.riding) continue;
      this.tmp.copy(v.pos).sub(origin);
      this.tmp.y += 0.3;
      const d = this.tmp.length();
      if (d > bestD) continue;
      if (this.tmp.normalize().dot(dir) < 0.86) continue;
      best = v;
      bestD = d;
    }
    return best;
  }

  mount(v: Vehicle): boolean {
    if (v.kind === 'boat' && (v.passengers?.length ?? 0) >= BOAT.maxPassengers) return false;   // both seats are taken by mobs
    this.riding = v;
    // Seats fill in boarding order: whoever sits in front steers — a player who boards after a mob rides in the back (as in Java).
    v.playerSeat = v.kind === 'boat' ? (v.passengers?.length ?? 0) : 0;
    this.host.sound?.('wood', v.pos);
    return true;
  }

  dismount(): THREE.Vector3 | null {
    const v = this.riding;
    if (!v) return null;
    this.riding = null;
    const out = v.pos.clone();
    out.x += Math.cos(v.yaw) * 1.1;
    out.z -= Math.sin(v.yaw) * 1.1;
    if (solid(this.blockAt(out.x, out.y + 0.5, out.z))) {
      out.x = v.pos.x;
      out.z = v.pos.z;
      out.y += 1;
    }
    return out;
  }

  seat(v: Vehicle, out = new THREE.Vector3()) {
    return out.set(v.pos.x, v.pos.y + (v.kind === 'boat' ? -0.25 : -0.1), v.pos.z);
  }

  hit(v: Vehicle) {
    v.hp -= 2.5;
    v.group.position.y += 0.05;
    if (v.hp <= 0) this.destroy(v, true);
  }

  remove(v: Vehicle) { this.destroy(v, false); }

  destroy(v: Vehicle, drop: boolean) {
    if (this.riding === v) this.riding = null;
    for (const id of v.passengers ?? []) this.host.setRider?.(id, null);
    v.passengers = [];
    this.releaseDetector(v);
    this.scene.remove(v.group);
    const idx = this.vehicles.indexOf(v);
    if (idx >= 0) this.vehicles.splice(idx, 1);
    if (drop) {
      this.host.drop?.(v.pos.x, v.pos.y + 0.3, v.pos.z, v.kind, 1);
      for (const s of v.items ?? []) if (s) { if (this.host.dropStack) this.host.dropStack(v.pos.x, v.pos.y + 0.3, v.pos.z, s); else this.host.drop?.(v.pos.x, v.pos.y + 0.3, v.pos.z, s.name, s.count); }
    }
  }

  clear() {
    for (const v of [...this.vehicles]) this.releaseDetector(v);
    for (const v of this.vehicles) this.scene.remove(v.group);
    this.vehicles = [];
    this.riding = null;
  }

  save(): VehicleSave[] {
    return this.vehicles.map(v => ({
      kind: v.kind,
      id: 'minecraft:' + v.kind,
      position: [v.pos.x, v.pos.y, v.pos.z],
      p: [v.pos.x, v.pos.y, v.pos.z],
      yaw: v.yaw,
      ...(v.items ? { Items: itemsToNbt(v.items) } : {}),
      ...(v.kind === 'furnace_minecart' ? { Fuel: v.fuel, PushX: v.pushX, PushZ: v.pushZ } : {}),
      ...(v.kind === 'tnt_minecart' ? { TNTFuse: v.fuse } : {}),
      ...(v.kind === 'hopper_minecart' ? { Enabled: v.enabled } : {}),
    }));
  }

  load(list: VehicleSave[] | undefined) {
    this.clear();
    for (const s of list ?? []) {
      const coords = s?.position ?? s?.p;
      if (coords && (s.kind === 'boat' || isCartKind(s.kind))) {
        const v = this.spawn(s.kind, coords[0], coords[1], coords[2], s.yaw ?? 0);
        if (v.items && s.Items) v.items = itemsFromNbt(s.Items, v.items.length);
        v.fuel = s.Fuel ?? 0; v.pushX = s.PushX ?? 0; v.pushZ = s.PushZ ?? 0;
        v.fuse = s.TNTFuse ?? -1; v.enabled = s.Enabled ?? true;
      }
    }
  }

  connections(cx: number, ry: number, cz: number): { dx: number; dz: number; dy: number }[] {
    const out: { dx: number; dz: number; dy: number }[] = [];
    for (const [dx, dz] of DIRS) {
      if (isRail(this.blockAt(cx + dx, ry, cz + dz))) out.push({ dx, dz, dy: 0 });
      else if (isRail(this.blockAt(cx + dx, ry + 1, cz + dz)) && !solid(this.blockAt(cx, ry + 1, cz))) out.push({ dx, dz, dy: 1 });
      else if (isRail(this.blockAt(cx + dx, ry - 1, cz + dz)) && !solid(this.blockAt(cx + dx, ry, cz + dz))) out.push({ dx, dz, dy: -1 });
    }
    return out;
  }

  private releaseDetector(v: Vehicle) {
    if (!v.detector || !this.host.setBlock) return;
    const [x, y, z] = v.detector, cell = this.host.getCell(x, y, z);
    if (idOf(cell) === ID.detector_rail && (stOf(cell) & 9)) {
      this.host.setBlock(x, y, z, ID.detector_rail, stOf(cell) & 6);
    }
    v.detector = null;
  }

  /** Pushes stopped minecarts the player walks into, and resolves cart-to-cart collisions. */
  nudge(player: THREE.Vector3) {
    for (const v of this.vehicles) {
      if (!isCartKind(v.kind) || v === this.riding || v.speed > 0.5) continue;
      const dx = v.pos.x - player.x, dz = v.pos.z - player.z, dy = v.pos.y - player.y;
      if (dx * dx + dz * dz > 0.75 || dy < -1 || dy > 1.2) continue;
      const cx = Math.floor(v.pos.x), cy = Math.round(v.pos.y), cz = Math.floor(v.pos.z);
      const next = this.nextRail(cx, cy, cz, null, Math.atan2(dx, dz));
      if (next) {
        v.from.set(cx + 0.5, cy, cz + 0.5);
        v.to.copy(next);
        v.dx = Math.sign(next.x - v.from.x);
        v.dz = Math.sign(next.z - v.from.z);
        v.speed = 1.6;
      }
    }
  }

  update(dt: number, input: DriveInput | null): THREE.Vector3 | null {
    this.time += dt;
    // Minecart variants run on game ticks (20 Hz): hopper suction, furnace fuel, TNT fuse.
    this.tickAcc += dt;
    let ticks = 0;
    while (this.tickAcc >= 0.05 && ticks < 4) { this.tickAcc -= 0.05; ticks++; }
    if (this.tickAcc > 0.2) this.tickAcc = 0;
    for (let i = 0; i < ticks; i++) for (const v of [...this.vehicles]) if (v.kind !== 'minecart' && v.kind !== 'boat') this.tickVariant(v);
    for (const v of [...this.vehicles]) {
      if (isCartKind(v.kind)) this.updateMinecart(v, dt, v === this.riding ? input : null);
      else this.updateBoat(v, dt, v === this.riding ? input : null);
      v.group.position.copy(v.pos);
      v.group.rotation.y = v.yaw;
    }
    // AbstractMinecart.push, once per game tick: touching carts end up near their average velocity and are pushed apart
    // (0.05 blocks/tick); a furnace cart keeps 20 % of its own speed and hands the rest of the train its push.
    for (let t = 0; t < ticks; t++) {
      for (let i = 0; i < this.vehicles.length; i++) {
        for (let j = i + 1; j < this.vehicles.length; j++) {
          const a = this.vehicles[i], b = this.vehicles[j];
          if (!isCartKind(a.kind) || !isCartKind(b.kind) || Math.abs(a.pos.y - b.pos.y) > 0.9) continue;
          const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z;
          if (dx * dx + dz * dz >= 0.98 * 0.98) continue;
          const A = this.cartBody(a), B = this.cartBody(b);
          if (minecartCollide(A, B)) { this.applyCartBody(a, A); this.applyCartBody(b, B); }
        }
      }
    }
    if (!this.riding) return null;
    const v = this.riding;
    if (v.kind === 'boat') {
      const f = boatSeatOffset(v.playerSeat ?? 0, 1 + (v.passengers?.length ?? 0));
      this._seat.set(v.pos.x - Math.sin(v.yaw) * f, v.pos.y - 0.25, v.pos.z - Math.cos(v.yaw) * f);
    } else this._seat.set(v.pos.x, v.pos.y - 0.1, v.pos.z);
    return this._seat;
  }

  /** A cart as a point mass in blocks/tick along its rail segment. */
  private cartBody(v: Vehicle): CartBody {
    return { x: v.pos.x, z: v.pos.z, vx: (v.dx * v.speed) / 20, vz: (v.dz * v.speed) / 20, furnace: v.kind === 'furnace_minecart' && v.fuel > 0 };
  }
  /** Projects the post-collision velocity back onto the rail: carts only ever move along their track. */
  private applyCartBody(v: Vehicle, body: CartBody) {
    let ax = v.dx, az = v.dz;
    if (!ax && !az) {
      // Standing cart: pick the rail direction closest to the push.
      const cx = Math.floor(v.pos.x), cy = Math.round(v.pos.y), cz = Math.floor(v.pos.z);
      const next = this.nextRail(cx, cy, cz, null, Math.atan2(body.vx, body.vz));
      if (!next) return;
      v.from.set(cx + 0.5, cy, cz + 0.5);
      v.to.copy(next);
      ax = v.dx = Math.sign(next.x - v.from.x); az = v.dz = Math.sign(next.z - v.from.z);
    }
    const len = Math.hypot(ax, az) || 1;
    let sp = ((body.vx * ax + body.vz * az) / len) * 20;
    if (sp < 0) {                                           // knocked backwards: travel the segment the other way
      const tmp = v.from.clone(); v.from.copy(v.to); v.to.copy(tmp);
      v.dx = -v.dx; v.dz = -v.dz; sp = -sp;
    }
    v.speed = Math.min(MAX_CART_SPEED, sp);
  }

  /** True while the cart stands on a powered activator rail. */
  private onPoweredActivator(v: Vehicle): boolean {
    const cx = Math.floor(v.pos.x), cz = Math.floor(v.pos.z), ry = this.railAt(cx, Math.round(v.pos.y), cz);
    if (Number.isNaN(ry)) return false;
    const cell = this.host.getCell(cx, ry, cz);
    return idOf(cell) === ID.activator_rail && (stOf(cell) & 9) !== 0;
  }

  /** One game tick of a chest / hopper / TNT / furnace minecart. */
  tickVariant(v: Vehicle) {
    const powered = this.onPoweredActivator(v);
    if (v.kind === 'hopper_minecart') {
      v.enabled = !powered;                                   // a powered activator rail switches the hopper off
      if (v.enabled) this.hopperPull(v);
    } else if (v.kind === 'tnt_minecart') {
      if (powered && v.fuse < 0) this.prime(v);
      if (v.fuse >= 0 && --v.fuse <= 0) this.explodeCart(v, v.speed);
    } else if (v.kind === 'furnace_minecart' && v.fuel > 0) {
      v.fuel--;
      const cx = Math.floor(v.pos.x), cz = Math.floor(v.pos.z), ry = this.railAt(cx, Math.round(v.pos.y), cz);
      if (!Number.isNaN(ry)) {
        if (v.speed < 0.05 && (v.to.equals(v.from) || v.to.distanceToSquared(v.pos) < 0.002)) {
          const next = this.nextRail(cx, ry, cz, null, Math.atan2(v.pushX, v.pushZ));
          if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); v.dx = Math.sign(next.x - v.from.x); v.dz = Math.sign(next.z - v.from.z); v.speed = 1; }
        } else if (v.speed < FURNACE_CART_SPEED) v.speed = Math.min(FURNACE_CART_SPEED, v.speed + 0.3);
      }
      if (v.fuel % 4 === 0) this.host.emit?.('furnace_minecart_smoke', { id: v.id, x: v.pos.x, y: v.pos.y + 0.9, z: v.pos.z, fuel: v.fuel });
    }
  }

  /**
   * Hopper minecart suction. Unlike the hopper block (one item per 8 ticks) it has no cooldown: one item per tick from the
   * container directly above the rail, or a whole dropped stack lying on / next to the track.
   */
  private hopperPull(v: Vehicle): boolean {
    const items = v.items;
    if (!items) return false;
    const x = Math.floor(v.pos.x), y = Math.round(v.pos.y), z = Math.floor(v.pos.z);
    const insert = (s: Stack): number => {
      let left = s.count;
      const plain = !s.ench && !s.label && s.durability === undefined && !s.tag;
      if (plain) for (const slot of items) { if (left <= 0) break; if (slot && slot.name === s.name && slot.count < 64 && !slot.ench && !slot.tag && slot.durability === undefined) { const n = Math.min(64 - slot.count, left); slot.count += n; left -= n; } }
      for (let i = 0; i < items.length && left > 0; i++) if (!items[i]) { items[i] = { ...s, count: left }; left = 0; }
      return left;
    };
    const source = this.host.containerAt?.(x, y + 1, z);
    if (source) {
      for (let i = 0; i < source.length; i++) {
        const s = source[i];
        if (!s) continue;
        if (insert({ ...s, count: 1 }) > 0) continue;
        s.count--;
        if (s.count <= 0) source[i] = null;
        this.host.emit?.('hopper_minecart_pull', { id: v.id, item: s.name, from: 'container', x, y: y + 1, z });
        return true;
      }
      return false;
    }
    if (items.every(s => s && s.count >= 64)) return false;
    const drop = this.host.takeDrop?.(v.pos.x, v.pos.y, v.pos.z);
    if (!drop) return false;
    const left = insert(drop);
    if (left > 0) this.host.drop?.(v.pos.x, v.pos.y + 0.6, v.pos.z, drop.name, left);
    this.host.emit?.('hopper_minecart_pull', { id: v.id, item: drop.name, from: 'item', x: v.pos.x, y: v.pos.y, z: v.pos.z });
    return left < drop.count;
  }

  /** Furnace minecart: burn one coal / charcoal. It pushes away from whoever fed it. */
  addFuel(v: Vehicle, fromX: number, fromZ: number): boolean {
    if (v.kind !== 'furnace_minecart' || v.fuel + FURNACE_FUEL_PER_COAL > FURNACE_FUEL_MAX) return false;
    v.fuel += FURNACE_FUEL_PER_COAL;
    const dx = v.pos.x - fromX, dz = v.pos.z - fromZ;
    if (Math.abs(dx) >= Math.abs(dz)) { v.pushX = Math.sign(dx) || 1; v.pushZ = 0; } else { v.pushX = 0; v.pushZ = Math.sign(dz) || 1; }
    return true;
  }

  /** TNT minecart: light the fuse (activator rail, flint and steel). */
  prime(v: Vehicle, fuse = TNT_CART_FUSE): boolean {
    if (v.kind !== 'tnt_minecart' || v.fuse >= 0) return false;
    v.fuse = fuse;
    this.host.sound?.('fuse', v.pos);
    this.host.emit?.('tnt_minecart_primed', { id: v.id, x: v.pos.x, y: v.pos.y, z: v.pos.z, fuse });
    return true;
  }

  /** Vanilla: power 4 + random * 1.5 * min(5, speed in blocks/tick). */
  explodeCart(v: Vehicle, speed = 0) {
    if (!this.vehicles.includes(v)) return;
    const x = v.pos.x, y = v.pos.y + 0.3, z = v.pos.z, power = 4 + Math.random() * 1.5 * Math.min(5, speed / 20);
    this.destroy(v, false);
    this.host.emit?.('tnt_minecart_explode', { x, y, z, power });
    this.host.explode?.(x, y, z, power);
  }

  private railAt(x: number, y: number, z: number): number {
    for (const dy of [0, 1, -1]) if (isRail(this.blockAt(x, y + dy, z))) return y + dy;
    return NaN;
  }

  private updateMinecart(v: Vehicle, dt: number, input: DriveInput | null) {
    const cx = Math.floor(v.pos.x), cz = Math.floor(v.pos.z), cy = Math.round(v.pos.y);
    const ry = this.railAt(cx, cy, cz);
    if (Number.isNaN(ry)) {
      v.onRail = false;
      this.releaseDetector(v);
      const gy = this.groundY(v.pos.x, v.pos.y, v.pos.z);
      v.pos.y += (gy - v.pos.y) * Math.min(1, dt * 8);
      v.speed = Math.max(0, v.speed - 10 * dt);
      return;
    }
    v.onRail = true;
    const cell = this.host.getCell(cx, ry, cz), id = idOf(cell), st = stOf(cell);

    // Detector rail powers on while a cart stands on it
    if (id === ID.detector_rail && this.host.setBlock) {
      if (!v.detector || v.detector[0] !== cx || v.detector[1] !== ry || v.detector[2] !== cz) {
        this.releaseDetector(v);
        v.detector = [cx, ry, cz];
      }
      if ((st & 9) !== 9) this.host.setBlock(cx, ry, cz, id, st | 9);
    } else {
      this.releaseDetector(v);
    }

    // Powered activator rail dismounts the rider
    if (id === ID.activator_rail && (st & 9) && this.riding === v) {
      this.dismount();
    }

    const atTarget = v.to.distanceToSquared(v.pos) < 0.002 || v.to.equals(v.from);
    const fwd = input
      ? input.forward !== undefined
        ? input.forward
        : input.move
        ? -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw))
        : 0
      : 0;

    if (input && Math.abs(fwd) > 0.2) {
      const fx = -Math.sin(input.yaw) * fwd, fz = -Math.cos(input.yaw) * fwd;
      if (v.speed < 0.05 && atTarget) {
        const next = this.nextRail(cx, ry, cz, null, Math.atan2(fx, fz));
        if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); v.speed = 1.2; }
      } else {
        this.tmp.copy(v.to).sub(v.from).normalize();
        const along = this.tmp.x * fx + this.tmp.z * fz;
        v.speed = Math.min(6, v.speed + along * 2.5 * dt);
      }
    }
    if (v.to.equals(v.from) && (v.dx !== 0 || v.dz !== 0)) {
      const next = this.nextRail(cx, ry, cz, null, Math.atan2(v.dx, v.dz));
      if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); }
    }
    if (id === ID.powered_rail) {
      if (st & 9) v.speed = Math.min(8, v.speed + 10 * dt);
      else v.speed = Math.max(0, v.speed - 16 * dt);
      if ((st & 9) && v.speed < 0.3 && atTarget) {
        for (const [dx, dz] of DIRS) {
          if (solid(this.blockAt(cx + dx, ry, cz + dz))) {
            const next = this.nextRail(cx, ry, cz, null, Math.atan2(-dx, -dz));
            if (next) { v.from.set(cx + 0.5, ry, cz + 0.5); v.to.copy(next); v.speed = 1.8; break; }
          }
        }
        if (v.speed < 0.3) {
          const conns = this.connections(cx, ry, cz);
          if (conns.length) {
            const c = conns[0];
            v.from.set(cx + 0.5, ry, cz + 0.5);
            v.to.set(cx + c.dx + 0.5, ry + c.dy, cz + c.dz + 0.5);
            v.speed = 1.5;
          }
        }
      }
    } else {
      v.speed = Math.max(0, v.speed - 0.35 * dt - v.speed * 0.08 * dt);
    }

    const dy = v.to.y - v.from.y;
    if (dy > 0) v.speed -= 5 * dt;
    else if (dy < 0) v.speed = Math.min(8, v.speed + 5 * dt);
    if (v.speed < 0) {
      const t = v.from.clone(); v.from.copy(v.to); v.to.copy(t); v.speed = -v.speed;
    }
    if (v.speed <= 0.001) return;

    let remaining = v.speed * dt;
    for (let guard = 0; guard < 4 && remaining > 0; guard++) {
      this.tmp.copy(v.to).sub(v.pos);
      const dist = this.tmp.length();
      if (dist <= remaining || dist < 1e-4) {
        v.pos.copy(v.to);
        remaining -= dist;
        const tx = Math.floor(v.to.x), ty = Math.round(v.to.y), tz = Math.floor(v.to.z);
        const heading = Math.atan2(v.to.x - v.from.x, v.to.z - v.from.z);
        const next = this.nextRail(tx, ty, tz, v.from, heading);
        if (!next) {
          // A TNT minecart that runs into the end of the line at 0.1 blocks/tick or faster goes off on impact.
          if (v.kind === 'tnt_minecart' && v.speed >= 2) { this.explodeCart(v, v.speed); return; }
          v.speed *= 0.2;
          const t = v.from.clone(); v.from.copy(v.to); v.to.copy(t);
          v.speed = Math.min(v.speed, 0.4);
          break;
        }
        v.from.copy(v.to);
        v.to.copy(next);
      } else {
        this.tmp.normalize();
        v.pos.addScaledVector(this.tmp, remaining);
        remaining = 0;
      }
    }
    this.tmp.copy(v.to).sub(v.from);
    if (this.tmp.lengthSq() > 1e-6) {
      v.dx = Math.sign(this.tmp.x);
      v.dz = Math.sign(this.tmp.z);
      v.yaw = Math.atan2(this.tmp.x, this.tmp.z) + Math.PI / 2;
    }
  }

  private nextRail(x: number, y: number, z: number, from: THREE.Vector3 | null, heading: number): THREE.Vector3 | null {
    const hx = Math.round(Math.sin(heading)), hz = Math.round(Math.cos(heading));
    const order: [number, number][] = [[hx, hz], [hz, -hx], [-hz, hx], [-hx, -hz]];
    for (const [dx, dz] of order) {
      if (dx === 0 && dz === 0) continue;
      const ry = this.railAt(x + dx, y, z + dz);
      if (Number.isNaN(ry)) continue;
      if (ry > y && solid(this.blockAt(x + dx, y + 1, z + dz)) && !isRail(this.blockAt(x + dx, y + 1, z + dz))) continue;
      if (from && Math.floor(from.x) === x + dx && Math.floor(from.z) === z + dz && Math.round(from.y) === ry) continue;
      return new THREE.Vector3(x + dx + 0.5, ry, z + dz + 0.5);
    }
    return null;
  }

  private groundY(x: number, y: number, z: number) {
    for (let yy = Math.floor(y); yy > Math.floor(y) - 6; yy--) {
      if (solid(this.blockAt(x, yy, z))) return yy + 1;
    }
    return y - 0.5;
  }

  /** Water surface height of a cell (NaN when it holds no water): sources and falling water 8/9, flowing (8 − level)/9, 1 under more water. */
  private waterTop(bx: number, by: number, bz: number): number {
    const c = this.host.getCell(bx, by, bz);
    if (c < 0 || (c & 4095) !== ID.water) return NaN;
    if (this.blockAt(bx, by + 1, bz) === ID.water) return by + 1;
    const st = (c >>> 12) & 15;
    return by + (st === 0 || st & 8 ? 8 / 9 : (8 - (st & 7)) / 9);
  }

  /** Boat.getStatus: under (flowing) water, in water, on land (with the floor's slipperiness) or in the air. */
  boatStatus(v: Vehicle): { status: BoatStatus; waterLevel: number; friction: number } {
    const y = v.pos.y, r = BOAT.width / 2 - 0.08;
    const pts: [number, number][] = [[0, 0], [r, r], [r, -r], [-r, r], [-r, -r]];
    // Submerged? (water still above the top of the hull)
    const topY = y + BOAT.height, tx = Math.floor(v.pos.x), tz = Math.floor(v.pos.z), tby = Math.floor(topY);
    const over = this.waterTop(tx, tby, tz);
    if (!Number.isNaN(over) && topY < over) {
      const st = (this.host.getCell(tx, tby, tz) >>> 12) & 15;
      return { status: st === 0 ? 'under_water' : 'under_flowing_water', waterLevel: over, friction: 0.9 };
    }
    let level = -Infinity;
    for (const [ox, oz] of pts) {
      const bx = Math.floor(v.pos.x + ox), bz = Math.floor(v.pos.z + oz);
      for (const by of [Math.floor(y), Math.floor(y + BOAT.height * 0.5)]) {
        const top = this.waterTop(bx, by, bz);
        if (!Number.isNaN(top) && y < top) level = Math.max(level, top);
      }
    }
    if (level > -Infinity) return { status: 'in_water', waterLevel: level, friction: 0.9 };
    // Boat.getGroundFriction: the average slipperiness of the blocks under the hull (ice 0.98, blue ice 0.989, slime 0.8, others 0.6).
    let sum = 0, n = 0;
    for (const [ox, oz] of pts) {
      const id = this.blockAt(v.pos.x + ox, y - 0.001, v.pos.z + oz);
      if (!solid(id)) continue;
      sum += id === ID.blue_ice ? 0.989 : isIce(id) ? 0.98 : id === ID.slime_block ? 0.8 : BOAT.defaultFriction;
      n++;
    }
    if (n) return { status: 'on_land', waterLevel: y, friction: sum / n };
    return { status: 'in_air', waterLevel: y, friction: 0.9 };
  }

  /** One game tick of Boat.tick: status, floatBoat, controlBoat, then picking up / shoving nearby mobs. */
  private boatTick(v: Vehicle, b: BoatState, input: DriveInput | null) {
    const st = this.boatStatus(v), wasAir = b.status === 'in_air';
    boatFloat(b, st.status, v.pos.y, st.waterLevel, st.friction);
    if (wasAir && st.status !== 'in_air' && st.status !== 'on_land') v.pos.y = Math.max(v.pos.y, boatSplashY(st.waterLevel));
    const steering = input && this.riding === v && (v.playerSeat ?? 0) === 0;
    if (input && steering) {
      const fwd = input.forward !== undefined ? input.forward : input.move ? -(input.move.x * Math.sin(input.yaw) + input.move.z * Math.cos(input.yaw)) : 0;
      const strafe = input.strafe !== undefined ? input.strafe : input.move ? input.move.x * Math.cos(input.yaw) - input.move.z * Math.sin(input.yaw) : 0;
      boatControl(b, { left: strafe < -0.3, right: strafe > 0.3, up: fwd > 0.3, down: fwd < -0.3 }, -Math.sin(v.yaw), -Math.cos(v.yaw));
      if (v.oars && v.oars.length) {
        const paddle = Math.abs(fwd) > 0.3 || Math.abs(strafe) > 0.3;
        v.oars.forEach((oar, idx) => { oar.rotation.z = paddle ? Math.sin(this.time * 8 + idx * Math.PI) * 0.45 : 0; });
      }
    }
    // Mobs touching the hull climb in while nobody steers (two seats in total); everything else gets shoved aside.
    const mobs = this.host.mobs?.();
    if (!mobs) return;
    const pass = v.passengers ?? (v.passengers = []);
    for (const m of mobs) {
      if (m.riding) continue;
      const reach = BOAT.width / 2 + 0.2 + m.width / 2;
      if (Math.abs(m.x - v.pos.x) >= reach || Math.abs(m.z - v.pos.z) >= reach || m.y > v.pos.y + BOAT.height - 0.01 || m.y + 1 < v.pos.y + 0.01) continue;
      const riders = pass.length + (this.riding === v ? 1 : 0);
      if (canBoardBoat({ passengers: riders, playerControlled: this.riding === v && (v.playerSeat ?? 0) === 0, width: m.width, aquatic: m.aquatic, alreadyRiding: false })) {
        if (this.host.setRider?.(m.id, v.id)) { pass.push(m.id); this.host.sound?.('wood', v.pos); }
      } else {
        const push = pushApart(v.pos.x, v.pos.z, m.x, m.z);
        if (push) { b.vx -= push.x; b.vz -= push.z; }
      }
    }
  }

  private updateBoat(v: Vehicle, dt: number, input: DriveInput | null) {
    const b = v.boat ?? (v.boat = newBoatState());
    const pass = v.passengers ?? (v.passengers = []);
    v.boatAcc = Math.min((v.boatAcc ?? 0) + dt, 0.25);
    while (v.boatAcc >= 0.05) { v.boatAcc -= 0.05; this.boatTick(v, b, input); }

    // Between ticks the hull keeps moving with its per-tick velocity (blocks/tick × 20 = blocks/second).
    const k = dt * 20;
    v.yaw -= (b.deltaRotation * Math.PI) / 180 * k;
    v.vel.set(b.vx * 20, b.vy * 20, b.vz * 20);
    v.speed = Math.hypot(v.vel.x, v.vel.z);
    for (const axis of ['x', 'z'] as const) {
      const prev = v.pos[axis];
      v.pos[axis] += v.vel[axis] * dt;
      const edge = 0.45 * Math.sign(v.vel[axis] || 1);
      const px = axis === 'x' ? v.pos.x + edge : v.pos.x, pz = axis === 'z' ? v.pos.z + edge : v.pos.z;
      if (solid(this.blockAt(px, v.pos.y + 0.2, pz))) { v.pos[axis] = prev; if (axis === 'x') b.vx = 0; else b.vz = 0; }
    }
    v.pos.y += b.vy * k;
    if (b.vy <= 0 && solid(this.blockAt(v.pos.x, v.pos.y, v.pos.z))) { v.pos.y = Math.floor(v.pos.y) + 1; b.vy = 0; }
    else if (b.vy > 0 && solid(this.blockAt(v.pos.x, v.pos.y + BOAT.height, v.pos.z))) b.vy = 0;

    // Passengers: one rider sits in the middle; two sit at +0.2 (front) and −0.6 (back) along the hull.
    if (pass.length) {
      const playerHere = this.riding === v, count = pass.length + (playerHere ? 1 : 0);
      const fx = -Math.sin(v.yaw), fz = -Math.cos(v.yaw);
      for (let i = pass.length - 1; i >= 0; i--) {
        const seat = playerHere && (v.playerSeat ?? 0) <= i ? i + 1 : i;
        const f = boatSeatOffset(seat, count, true);
        if (this.host.placeRider && !this.host.placeRider(pass[i], v.pos.x + fx * f, v.pos.y + 0.15, v.pos.z + fz * f, v.yaw)) pass.splice(i, 1);
      }
    }
  }

  /** Lets every mob out of a boat (e.g. when it is pulled out with a lead or the boat is broken). */
  ejectPassengers(v: Vehicle) {
    for (const id of v.passengers ?? []) this.host.setRider?.(id, null);
    v.passengers = [];
  }

  dispose() {
    this.clear();
    this.box.dispose();
    for (const m of this.mats.values()) m.dispose();
  }
}

export { VehicleManager as Vehicles };
