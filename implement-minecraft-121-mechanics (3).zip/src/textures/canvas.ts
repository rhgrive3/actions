// Canvas creation is independent of the atlas to keep content registration acyclic.
export type DrawCanvas = HTMLCanvasElement | OffscreenCanvas;
export type Context2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;

function parseCssColor(s: string, globalAlpha = 1): [number, number, number, number] {
  let r = 128, g = 128, b = 128, a = Math.round(globalAlpha * 255);
  const str = String(s || '').trim();
  if (str.startsWith('#')) {
    if (str.length >= 7) {
      r = parseInt(str.slice(1, 3), 16) || 0;
      g = parseInt(str.slice(3, 5), 16) || 0;
      b = parseInt(str.slice(5, 7), 16) || 0;
    } else if (str.length === 4) {
      r = (parseInt(str[1], 16) || 0) * 17;
      g = (parseInt(str[2], 16) || 0) * 17;
      b = (parseInt(str[3], 16) || 0) * 17;
    }
  } else if (str.startsWith('rgb')) {
    const m = str.match(/[\d.]+/g);
    if (m && m.length >= 3) {
      r = Math.round(Number(m[0]));
      g = Math.round(Number(m[1]));
      b = Math.round(Number(m[2]));
      if (m.length >= 4) a = Math.round(Number(m[3]) * globalAlpha * 255);
    }
  }
  return [
    Math.max(0, Math.min(255, r)),
    Math.max(0, Math.min(255, g)),
    Math.max(0, Math.min(255, b)),
    Math.max(0, Math.min(255, a)),
  ];
}

function blendPixel(buf: Uint8ClampedArray, idx: number, r: number, g: number, b: number, a: number) {
  if (a <= 0) return;
  if (a >= 255 || buf[idx + 3] === 0) {
    buf[idx] = r; buf[idx + 1] = g; buf[idx + 2] = b; buf[idx + 3] = a;
    return;
  }
  const sa = a / 255, da = buf[idx + 3] / 255;
  const outA = sa + da * (1 - sa);
  if (outA <= 0) return;
  buf[idx] = Math.round((r * sa + buf[idx] * da * (1 - sa)) / outA);
  buf[idx + 1] = Math.round((g * sa + buf[idx + 1] * da * (1 - sa)) / outA);
  buf[idx + 2] = Math.round((b * sa + buf[idx + 2] * da * (1 - sa)) / outA);
  buf[idx + 3] = Math.round(outA * 255);
}

export function canvas(w: number, h = w): DrawCanvas {
  if (typeof document !== 'undefined') {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    c.getContext('2d', { willReadFrequently: true });
    return c;
  }
  if (typeof OffscreenCanvas !== 'undefined') {
    const c = new OffscreenCanvas(w, h);
    c.getContext('2d', { willReadFrequently: true });
    return c;
  }
  const buf = new Uint8ClampedArray(w * h * 4);
  let m: [number, number, number, number, number, number] = [1, 0, 0, 1, 0, 0];
  const stack: { m: [number, number, number, number, number, number]; fillStyle: string; strokeStyle: string; globalAlpha: number }[] = [];
  let pathPts: [number, number][] = [];

  const ctx: any = {
    fillStyle: '#000000',
    strokeStyle: '#000000',
    lineWidth: 1,
    globalAlpha: 1,
    imageSmoothingEnabled: false,
    save() {
      stack.push({ m: [...m] as [number, number, number, number, number, number], fillStyle: this.fillStyle, strokeStyle: this.strokeStyle, globalAlpha: this.globalAlpha });
    },
    restore() {
      const s = stack.pop();
      if (s) { m = s.m; this.fillStyle = s.fillStyle; this.strokeStyle = s.strokeStyle; this.globalAlpha = s.globalAlpha; }
    },
    setTransform(a: number, b: number, c: number, d: number, e: number, f: number) {
      m = [a, b, c, d, e, f];
    },
    translate(tx: number, ty: number) {
      m = [m[0], m[1], m[2], m[3], m[0] * tx + m[2] * ty + m[4], m[1] * tx + m[3] * ty + m[5]];
    },
    scale(sx: number, sy: number) {
      m = [m[0] * sx, m[1] * sx, m[2] * sy, m[3] * sy, m[4], m[5]];
    },
    fillRect(x: number, y: number, rw: number, rh: number) {
      const [r, g, b, a] = parseCssColor(this.fillStyle, this.globalAlpha ?? 1);
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          blendPixel(buf, (py * w + px) * 4, r, g, b, a);
        }
      }
    },
    strokeRect(x: number, y: number, rw: number, rh: number) {
      const prev = this.fillStyle;
      this.fillStyle = this.strokeStyle;
      this.fillRect(x, y, rw, 1);
      this.fillRect(x, y + rh - 1, rw, 1);
      this.fillRect(x, y, 1, rh);
      this.fillRect(x + rw - 1, y, 1, rh);
      this.fillStyle = prev;
    },
    clearRect(x: number, y: number, rw: number, rh: number) {
      const x0 = Math.max(0, Math.floor(x)), y0 = Math.max(0, Math.floor(y));
      const x1 = Math.min(w, Math.floor(x + rw)), y1 = Math.min(h, Math.floor(y + rh));
      for (let py = y0; py < y1; py++) {
        for (let px = x0; px < x1; px++) {
          const idx = (py * w + px) * 4;
          buf[idx] = 0; buf[idx + 1] = 0; buf[idx + 2] = 0; buf[idx + 3] = 0;
        }
      }
    },
    createImageData(iw: number, ih: number) { return { data: new Uint8ClampedArray(iw * ih * 4), width: iw, height: ih }; },
    putImageData(img: { data: Uint8ClampedArray }, dx: number, dy: number) {
      if (dx === 0 && dy === 0 && img.data.length === buf.length) buf.set(img.data);
    },
    getImageData(sx = 0, sy = 0, sw = w, sh = h) {
      if (sx === 0 && sy === 0 && sw === w && sh === h) return { data: new Uint8ClampedArray(buf), width: sw, height: sh };
      const out = new Uint8ClampedArray(sw * sh * 4);
      for (let py = 0; py < sh; py++) {
        for (let px = 0; px < sw; px++) {
          const si = ((sy + py) * w + (sx + px)) * 4;
          const di = (py * sw + px) * 4;
          out[di] = buf[si]; out[di + 1] = buf[si + 1]; out[di + 2] = buf[si + 2]; out[di + 3] = buf[si + 3];
        }
      }
      return { data: out, width: sw, height: sh };
    },
    drawImage(src: any, a1 = 0, a2 = 0, a3?: number, a4?: number, a5?: number, a6?: number, a7?: number, a8?: number) {
      if (!src || typeof src.getContext !== 'function') return;
      const sctx = src.getContext('2d');
      const sw0 = src.width || 16, sh0 = src.height || 16;
      const sData = sctx.getImageData(0, 0, sw0, sh0).data;
      let sx = 0, sy = 0, sw = sw0, sh = sh0, dx = a1, dy = a2, dw = sw0, dh = sh0;
      if (a7 !== undefined && a8 !== undefined) {
        sx = a1; sy = a2; sw = a3!; sh = a4!; dx = a5!; dy = a6!; dw = a7; dh = a8;
      } else if (a3 !== undefined && a4 !== undefined) {
        dx = a1; dy = a2; dw = a3; dh = a4;
      }
      if (sw <= 0 || sh <= 0 || dw <= 0 || dh <= 0) return;
      const [ma, mb, mc, md, me, mf] = m;
      const det = ma * md - mb * mc;
      if (Math.abs(det) < 1e-8) return;
      const corners: [number, number][] = [
        [dx, dy], [dx + dw, dy], [dx + dw, dy + dh], [dx, dy + dh],
      ].map(([ lx, ly ]) => [ma * lx + mc * ly + me, mb * lx + md * ly + mf]);
      const minX = Math.max(0, Math.floor(Math.min(...corners.map(p => p[0])))), maxX = Math.min(w - 1, Math.ceil(Math.max(...corners.map(p => p[0]))));
      const minY = Math.max(0, Math.floor(Math.min(...corners.map(p => p[1])))), maxY = Math.min(h - 1, Math.ceil(Math.max(...corners.map(p => p[1]))));
      for (let py = minY; py <= maxY; py++) {
        for (let px = minX; px <= maxX; px++) {
          const rx = px + 0.5 - me, ry = py + 0.5 - mf;
          const lx = (md * rx - mc * ry) / det;
          const ly = (-mb * rx + ma * ry) / det;
          if (lx < dx || lx >= dx + dw || ly < dy || ly >= dy + dh) continue;
          const tx = Math.min(sw0 - 1, Math.max(0, Math.floor(sx + ((lx - dx) / dw) * sw)));
          const ty = Math.min(sh0 - 1, Math.max(0, Math.floor(sy + ((ly - dy) / dh) * sh)));
          const si = (ty * sw0 + tx) * 4;
          blendPixel(buf, (py * w + px) * 4, sData[si], sData[si + 1], sData[si + 2], Math.round(sData[si + 3] * (this.globalAlpha ?? 1)));
        }
      }
    },
    beginPath() { pathPts = []; },
    closePath() {},
    moveTo(x: number, y: number) { pathPts = [[x, y]]; },
    lineTo(x: number, y: number) { pathPts.push([x, y]); },
    bezierCurveTo() {},
    stroke() {
      if (pathPts.length < 2) return;
      const [r, g, b, a] = parseCssColor(this.strokeStyle, this.globalAlpha ?? 1);
      for (let i = 0; i < pathPts.length - 1; i++) {
        const [x0, y0] = pathPts[i], [x1, y1] = pathPts[i + 1];
        const steps = Math.max(1, Math.ceil(Math.hypot(x1 - x0, y1 - y0)));
        for (let s = 0; s <= steps; s++) {
          const px = Math.floor(x0 + ((x1 - x0) * s) / steps);
          const py = Math.floor(y0 + ((y1 - y0) * s) / steps);
          if (px >= 0 && px < w && py >= 0 && py < h) blendPixel(buf, (py * w + px) * 4, r, g, b, a);
        }
      }
    },
    arc() {},
    fill() {
      if (pathPts.length < 3) return;
      const [r, g, b, a] = parseCssColor(this.fillStyle, this.globalAlpha ?? 1);
      const minY = Math.max(0, Math.floor(Math.min(...pathPts.map(p => p[1]))));
      const maxY = Math.min(h - 1, Math.ceil(Math.max(...pathPts.map(p => p[1]))));
      for (let py = minY; py <= maxY; py++) {
        const y = py + 0.5;
        const xs: number[] = [];
        for (let i = 0; i < pathPts.length; i++) {
          const [x1, y1] = pathPts[i], [x2, y2] = pathPts[(i + 1) % pathPts.length];
          if ((y1 <= y && y2 > y) || (y2 <= y && y1 > y)) {
            xs.push(x1 + ((y - y1) * (x2 - x1)) / (y2 - y1));
          }
        }
        xs.sort((u, v) => u - v);
        for (let k = 0; k + 1 < xs.length; k += 2) {
          const xStart = Math.max(0, Math.floor(xs[k])), xEnd = Math.min(w - 1, Math.floor(xs[k + 1]));
          for (let px = xStart; px <= xEnd; px++) blendPixel(buf, (py * w + px) * 4, r, g, b, a);
        }
      }
    },
    fillText() {},
    createLinearGradient() { return { addColorStop() {} }; },
    createRadialGradient() { return { addColorStop() {} }; },
    globalCompositeOperation: 'source-over',
    font: '9px monospace',
    textAlign: 'left',
  };
  return {
    width: w,
    height: h,
    getContext: () => ctx,
    toDataURL: () => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  } as unknown as DrawCanvas;
}
