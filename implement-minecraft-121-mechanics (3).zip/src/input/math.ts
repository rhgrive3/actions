export const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
export function stick(dx: number, dy: number, radius = 48) {
  const length = Math.hypot(dx, dy), scale = length > radius ? radius / length : 1;
  return { x: dx * scale / radius, forward: -dy * scale / radius };
}
export function movement(x: number, forward: number, yaw: number) {
  return { x: x * Math.cos(yaw) - forward * Math.sin(yaw), z: -x * Math.sin(yaw) - forward * Math.cos(yaw) };
}
export function look(yaw: number, pitch: number, dx: number, dy: number, sensitivity = 0.0025, invertX = false, invertY = false) {
  return { yaw: yaw - dx * sensitivity * (invertX ? -1 : 1), pitch: clamp(pitch - dy * sensitivity * (invertY ? -1 : 1), -89 * Math.PI / 180, 89 * Math.PI / 180) };
}
export function hashSeed(text: string) {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return h >>> 0;
}
export function random(seed: number) {
  let a = seed | 0;
  return () => { a += 0x6D2B79F5; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
}
