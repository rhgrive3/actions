import type { Settings } from '../game/types';

/** Voice profile of a mob: base pitch, waveform, pitch glide (start→end multiplier), duration, noise mix and loudness. */
interface Voice { f: number; wave: OscillatorType; glide: [number, number]; dur: number; noise?: number; vol: number; vib?: number; pulses?: number; filter?: number }

const V: Record<string, Voice> = {
  cow: { f: 108, wave: 'sawtooth', glide: [1.15, 0.78], dur: 0.8, vol: 0.2, vib: 5, filter: 700 },
  mooshroom: { f: 112, wave: 'sawtooth', glide: [1.15, 0.78], dur: 0.8, vol: 0.2, vib: 5, filter: 700 },
  pig: { f: 175, wave: 'square', glide: [1.2, 0.8], dur: 0.16, vol: 0.14, pulses: 2, filter: 900 },
  sheep: { f: 320, wave: 'sawtooth', glide: [1, 0.9], dur: 0.7, vol: 0.14, vib: 24, filter: 1500 },
  chicken: { f: 720, wave: 'square', glide: [1.1, 0.85], dur: 0.07, vol: 0.09, pulses: 3, filter: 2400 },
  zombie: { f: 92, wave: 'sawtooth', glide: [1.1, 0.75], dur: 0.9, noise: 0.25, vol: 0.2, vib: 6, filter: 500 },
  husk: { f: 100, wave: 'sawtooth', glide: [1.05, 0.7], dur: 0.9, noise: 0.35, vol: 0.2, vib: 5, filter: 520 },
  drowned: { f: 85, wave: 'sawtooth', glide: [1.1, 0.7], dur: 1.0, noise: 0.3, vol: 0.19, vib: 9, filter: 380 },
  zombie_villager: { f: 130, wave: 'sawtooth', glide: [1.2, 0.8], dur: 0.9, noise: 0.2, vol: 0.19, vib: 6, filter: 600 },
  skeleton: { f: 1800, wave: 'square', glide: [1, 0.6], dur: 0.04, vol: 0.12, pulses: 4, noise: 0.8, filter: 2600 },
  stray: { f: 1500, wave: 'square', glide: [1, 0.6], dur: 0.05, vol: 0.12, pulses: 4, noise: 0.8, filter: 2200 },
  bogged: { f: 1300, wave: 'square', glide: [1, 0.55], dur: 0.05, vol: 0.12, pulses: 4, noise: 0.8, filter: 2000 },
  wither_skeleton: { f: 1000, wave: 'square', glide: [1, 0.5], dur: 0.06, vol: 0.14, pulses: 3, noise: 0.8, filter: 1500 },
  creeper: { f: 3000, wave: 'sawtooth', glide: [1, 0.5], dur: 0.5, noise: 1, vol: 0.13, filter: 3500 },
  spider: { f: 900, wave: 'sawtooth', glide: [1.1, 0.9], dur: 0.35, noise: 0.9, vol: 0.14, vib: 30, filter: 2200 },
  cave_spider: { f: 1100, wave: 'sawtooth', glide: [1.1, 0.9], dur: 0.3, noise: 0.9, vol: 0.12, vib: 34, filter: 2600 },
  enderman: { f: 300, wave: 'sine', glide: [0.5, 1.8], dur: 0.7, vol: 0.18, vib: 40, filter: 1800 },
  endermite: { f: 700, wave: 'square', glide: [1, 0.8], dur: 0.06, vol: 0.09, pulses: 3, filter: 2500 },
  villager: { f: 215, wave: 'triangle', glide: [0.9, 1.15], dur: 0.45, vol: 0.2, vib: 7, pulses: 2, filter: 1200 },
  wandering_trader: { f: 190, wave: 'triangle', glide: [0.9, 1.1], dur: 0.5, vol: 0.2, vib: 6, pulses: 2, filter: 1100 },
  wolf: { f: 270, wave: 'sawtooth', glide: [1.25, 0.6], dur: 0.35, vol: 0.18, noise: 0.2, filter: 1100 },
  cat: { f: 620, wave: 'sine', glide: [0.8, 1.5], dur: 0.7, vol: 0.16, vib: 8, filter: 2400 },
  ocelot: { f: 700, wave: 'sine', glide: [0.9, 1.4], dur: 0.5, vol: 0.14, vib: 6, filter: 2600 },
  horse: { f: 440, wave: 'sawtooth', glide: [1.25, 0.65], dur: 0.9, vol: 0.18, vib: 14, filter: 1400 },
  donkey: { f: 330, wave: 'sawtooth', glide: [1.4, 0.7], dur: 0.8, vol: 0.18, vib: 10, filter: 1300 },
  mule: { f: 300, wave: 'sawtooth', glide: [1.4, 0.7], dur: 0.8, vol: 0.18, vib: 10, filter: 1300 },
  llama: { f: 260, wave: 'sawtooth', glide: [1, 1.3], dur: 0.6, vol: 0.15, vib: 8, filter: 900 },
  camel: { f: 150, wave: 'sawtooth', glide: [1.2, 0.8], dur: 0.9, vol: 0.17, vib: 6, filter: 700 },
  goat: { f: 380, wave: 'sawtooth', glide: [1, 0.85], dur: 0.7, vol: 0.15, vib: 28, filter: 1600 },
  iron_golem: { f: 70, wave: 'square', glide: [1, 0.8], dur: 0.35, vol: 0.22, noise: 0.5, filter: 600 },
  snow_golem: { f: 500, wave: 'triangle', glide: [1, 0.9], dur: 0.2, vol: 0.1, noise: 0.5, filter: 1800 },
  fish: { f: 450, wave: 'sine', glide: [0.8, 1.8], dur: 0.08, vol: 0.1, filter: 2200 },
  salmon: { f: 430, wave: 'sine', glide: [0.8, 1.8], dur: 0.08, vol: 0.1, filter: 2200 },
  tropical_fish: { f: 520, wave: 'sine', glide: [0.8, 1.8], dur: 0.08, vol: 0.1, filter: 2200 },
  pufferfish: { f: 380, wave: 'sine', glide: [0.7, 1.7], dur: 0.12, vol: 0.12, filter: 2000 },
  squid: { f: 260, wave: 'sine', glide: [0.7, 1.3], dur: 0.25, noise: 0.6, vol: 0.12, filter: 900 },
  glow_squid: { f: 280, wave: 'sine', glide: [0.7, 1.3], dur: 0.25, noise: 0.6, vol: 0.12, filter: 900 },
  dolphin: { f: 2100, wave: 'sine', glide: [1.2, 0.7], dur: 0.35, vol: 0.12, vib: 36, pulses: 2, filter: 4000 },
  guardian: { f: 150, wave: 'sine', glide: [1.2, 0.8], dur: 0.9, vol: 0.18, vib: 3, filter: 600 },
  elder_guardian: { f: 62, wave: 'sawtooth', glide: [1.2, 0.7], dur: 1.6, noise: 0.25, vol: 0.26, vib: 2, filter: 380 },
  blaze: { f: 210, wave: 'sawtooth', glide: [1, 0.9], dur: 0.7, noise: 0.9, vol: 0.14, vib: 16, filter: 900 },
  ghast: { f: 640, wave: 'sine', glide: [1.1, 0.45], dur: 1.3, vol: 0.2, vib: 10, filter: 1800 },
  slime: { f: 150, wave: 'sine', glide: [1.3, 0.55], dur: 0.25, noise: 0.3, vol: 0.18, filter: 600 },
  magma_cube: { f: 120, wave: 'square', glide: [1.3, 0.5], dur: 0.25, noise: 0.4, vol: 0.17, filter: 500 },
  witch: { f: 520, wave: 'sawtooth', glide: [1, 1.2], dur: 0.9, vol: 0.14, vib: 36, filter: 1800 },
  bee: { f: 185, wave: 'sawtooth', glide: [1, 1], dur: 0.8, vol: 0.06, vib: 90, filter: 800 },
  fox: { f: 880, wave: 'triangle', glide: [1.1, 0.75], dur: 0.25, vol: 0.12, vib: 16, filter: 2800 },
  rabbit: { f: 1250, wave: 'sine', glide: [1, 0.9], dur: 0.05, vol: 0.07, pulses: 2, filter: 3000 },
  parrot: { f: 1000, wave: 'square', glide: [1.3, 0.7], dur: 0.1, vol: 0.09, pulses: 3, vib: 22, filter: 3200 },
  frog: { f: 130, wave: 'square', glide: [1.1, 0.8], dur: 0.14, vol: 0.14, pulses: 2, filter: 600 },
  tadpole: { f: 600, wave: 'sine', glide: [0.8, 1.6], dur: 0.06, vol: 0.07, filter: 2000 },
  axolotl: { f: 900, wave: 'sine', glide: [1, 1.4], dur: 0.2, vol: 0.09, vib: 20, filter: 2600 },
  turtle: { f: 160, wave: 'sine', glide: [1, 0.7], dur: 0.35, vol: 0.1, filter: 500 },
  armadillo: { f: 400, wave: 'triangle', glide: [1, 0.8], dur: 0.12, vol: 0.08, filter: 1500 },
  panda: { f: 330, wave: 'triangle', glide: [1, 0.8], dur: 0.5, vol: 0.14, vib: 5, filter: 1000 },
  polar_bear: { f: 105, wave: 'sawtooth', glide: [1, 0.7], dur: 0.8, noise: 0.2, vol: 0.19, vib: 4, filter: 500 },
  sniffer: { f: 90, wave: 'sawtooth', glide: [1, 0.7], dur: 0.9, noise: 0.4, vol: 0.17, filter: 450 },
  piglin: { f: 160, wave: 'square', glide: [1.3, 0.8], dur: 0.2, vol: 0.14, pulses: 2, noise: 0.2, filter: 800 },
  piglin_brute: { f: 120, wave: 'square', glide: [1.3, 0.8], dur: 0.25, vol: 0.16, pulses: 2, noise: 0.2, filter: 700 },
  zombified_piglin: { f: 130, wave: 'square', glide: [1.2, 0.7], dur: 0.35, vol: 0.15, noise: 0.35, filter: 700 },
  hoglin: { f: 80, wave: 'sawtooth', glide: [1.3, 0.7], dur: 0.45, vol: 0.18, noise: 0.3, filter: 450 },
  zoglin: { f: 70, wave: 'sawtooth', glide: [1.3, 0.7], dur: 0.45, vol: 0.18, noise: 0.5, filter: 420 },
  strider: { f: 520, wave: 'triangle', glide: [1.2, 0.8], dur: 0.2, vol: 0.1, vib: 12, filter: 1800 },
  pillager: { f: 140, wave: 'triangle', glide: [1, 0.8], dur: 0.5, vol: 0.18, vib: 5, noise: 0.15, filter: 700 },
  vindicator: { f: 120, wave: 'triangle', glide: [1.1, 0.7], dur: 0.55, vol: 0.2, vib: 5, noise: 0.2, filter: 650 },
  evoker: { f: 170, wave: 'triangle', glide: [0.9, 1.2], dur: 0.7, vol: 0.18, vib: 8, filter: 800 },
  vex: { f: 1200, wave: 'sawtooth', glide: [1.1, 0.8], dur: 0.25, vol: 0.1, vib: 50, filter: 3000 },
  ravager: { f: 65, wave: 'sawtooth', glide: [1.2, 0.7], dur: 0.9, noise: 0.3, vol: 0.22, filter: 380 },
  phantom: { f: 720, wave: 'triangle', glide: [1.2, 0.35], dur: 0.9, vol: 0.14, vib: 14, filter: 2000 },
  silverfish: { f: 1600, wave: 'square', glide: [1, 0.8], dur: 0.04, vol: 0.08, pulses: 3, filter: 3000 },
  shulker: { f: 400, wave: 'triangle', glide: [1, 0.7], dur: 0.2, vol: 0.1, filter: 1500 },
  warden: { f: 42, wave: 'sawtooth', glide: [1.2, 0.7], dur: 1.8, noise: 0.35, vol: 0.28, vib: 3, filter: 300 },
  wither: { f: 55, wave: 'sawtooth', glide: [1.4, 0.6], dur: 1.4, noise: 0.3, vol: 0.26, vib: 4, filter: 420 },
  dragon: { f: 58, wave: 'sawtooth', glide: [1.6, 0.6], dur: 1.6, noise: 0.35, vol: 0.28, vib: 5, filter: 520 },
  allay: { f: 1400, wave: 'sine', glide: [1, 1.25], dur: 0.2, vol: 0.09, pulses: 2, filter: 4000 },
  bat: { f: 3200, wave: 'square', glide: [1, 0.7], dur: 0.04, vol: 0.06, pulses: 3, filter: 5000 },
  breeze: { f: 480, wave: 'sine', glide: [0.7, 1.4], dur: 0.5, noise: 0.8, vol: 0.12, filter: 1400 },
};
const DEFAULT_VOICE: Voice = { f: 240, wave: 'triangle', glide: [1, 0.85], dur: 0.35, vol: 0.14, filter: 1200 };

/** Original procedural tunes for the music discs (tempo, key, instrument colour). */
const DISC_STYLE: Record<string, { bpm: number; root: number; scale: number[]; wave: OscillatorType; bass: OscillatorType; seed: number; perc?: boolean }> = {
  music_disc_13: { bpm: 84, root: 261.63, scale: [0, 2, 3, 5, 7, 8, 10], wave: 'sine', bass: 'triangle', seed: 13 },
  music_disc_cat: { bpm: 96, root: 293.66, scale: [0, 2, 4, 7, 9], wave: 'triangle', bass: 'sine', seed: 31 },
  music_disc_blocks: { bpm: 126, root: 220, scale: [0, 3, 5, 7, 10], wave: 'square', bass: 'sawtooth', seed: 47, perc: true },
  music_disc_chirp: { bpm: 140, root: 329.63, scale: [0, 2, 4, 5, 7, 9, 11], wave: 'square', bass: 'triangle', seed: 59, perc: true },
  music_disc_far: { bpm: 72, root: 246.94, scale: [0, 2, 4, 7, 9], wave: 'sine', bass: 'sine', seed: 61 },
  music_disc_mall: { bpm: 100, root: 261.63, scale: [0, 2, 4, 6, 7, 9, 11], wave: 'triangle', bass: 'triangle', seed: 73 },
  music_disc_mellohi: { bpm: 88, root: 196, scale: [0, 2, 3, 5, 7, 9, 10], wave: 'triangle', bass: 'sine', seed: 83 },
  music_disc_stal: { bpm: 78, root: 277.18, scale: [0, 3, 5, 6, 7, 10], wave: 'sine', bass: 'triangle', seed: 97 },
  music_disc_strad: { bpm: 112, root: 311.13, scale: [0, 2, 4, 5, 7, 9, 11], wave: 'sawtooth', bass: 'triangle', seed: 101, perc: true },
  music_disc_ward: { bpm: 66, root: 220, scale: [0, 1, 4, 5, 7, 8, 11], wave: 'sawtooth', bass: 'sine', seed: 109 },
  music_disc_11: { bpm: 54, root: 174.61, scale: [0, 1, 5, 6, 10], wave: 'square', bass: 'sine', seed: 11 },
  music_disc_wait: { bpm: 104, root: 349.23, scale: [0, 2, 4, 7, 9], wave: 'triangle', bass: 'triangle', seed: 127 },
  music_disc_pigstep: { bpm: 118, root: 164.81, scale: [0, 3, 5, 7, 10], wave: 'sawtooth', bass: 'square', seed: 139, perc: true },
};

export class ProceduralAudio {
  context: AudioContext | null = null;
  master: GainNode | null = null;
  delay: DelayNode | null = null;
  delayGain: GainNode | null = null;
  noise: AudioBuffer | null = null;
  musicTimer: ReturnType<typeof setInterval> | null = null;
  settings: Settings;
  step = 0;
  private ear = { x: 0, y: 0, z: 0 };
  private discs = new Map<string, { timer: ReturnType<typeof setInterval>; name: string; pos: { x: number; y: number; z: number }; n: number }>();
  private amb: Record<string, number> = {};
  private lastVoice = new Map<string, number>();

  constructor(settings: Settings) {
    this.settings = settings;
  }

  resume() {
    try {
      if (!this.context) {
        this.context = new AudioContext();
        this.master = this.context.createGain();
        this.master.connect(this.context.destination);

        // Soft ambient echo bus for music & chimes
        this.delay = this.context.createDelay(1.0);
        this.delay.delayTime.value = 0.36;
        this.delayGain = this.context.createGain();
        this.delayGain.gain.value = 0.28;
        this.delay.connect(this.delayGain);
        this.delayGain.connect(this.delay);
        this.delayGain.connect(this.master);

        const length = this.context.sampleRate * 2;
        this.noise = this.context.createBuffer(1, length, this.context.sampleRate);
        const data = this.noise.getChannelData(0);
        let brown = 0;
        for (let i = 0; i < length; i++) {
          brown = (brown + Math.random() * 0.04 - 0.02) / 1.02;
          data[i] = brown * 3 + (Math.random() * 2 - 1) * 0.25;
        }
        this.configure(this.settings);
        this.musicTimer = setInterval(() => {
          if (this.settings.music && !this.settings.muted && this.context?.state === 'running' && this.discs.size === 0) {
            this.chord();
          }
        }, 7200);
      }
      if (this.context.state === 'suspended') this.context.resume().catch(() => {});
    } catch {}
  }

  configure(s: Settings) {
    this.settings = s;
    if (this.master && this.context) {
      this.master.gain.setTargetAtTime(s.muted ? 0 : s.volume * 0.52, this.context.currentTime, 0.08);
    }
  }

  private tone(freq: number, dur: number, vol: number, type: OscillatorType = 'sine', endFreq?: number, useDelay = false, delaySec = 0) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;
    const now = c.currentTime + delaySec;
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) osc.frequency.exponentialRampToValueAtTime(Math.max(30, endFreq), now + dur);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.linearRampToValueAtTime(vol, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.connect(g);
    g.connect(this.master);
    if (useDelay && this.delay) g.connect(this.delay);
    osc.start(now);
    osc.stop(now + dur + 0.02);
    osc.onended = () => { osc.disconnect(); g.disconnect(); };
  }

  /** Routes `node` to the master bus, positioned in 3D when a position is given. */
  private route(node: AudioNode, position?: { x: number; y: number; z: number }): PannerNode | null {
    const c = this.context!;
    if (!position) { node.connect(this.master!); return null; }
    const panner = c.createPanner();
    panner.panningModel = 'HRTF';
    panner.distanceModel = 'inverse';
    panner.refDistance = 3;
    panner.maxDistance = 42;
    panner.positionX.value = position.x; panner.positionY.value = position.y; panner.positionZ.value = position.z;
    node.connect(panner); panner.connect(this.master!);
    return panner;
  }

  /** Species-specific mob sound: say (ambient), hurt, death or snore. */
  mobVoice(species: string, type: 'say' | 'hurt' | 'death' | 'snore', position?: { x: number; y: number; z: number }) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;
    // Rate limit per species so a herd never produces a wall of noise
    const key = species + type, now = c.currentTime;
    if (now - (this.lastVoice.get(key) ?? -9) < (type === 'say' ? 0.35 : 0.12)) return;
    this.lastVoice.set(key, now);
    const v = V[species] ?? DEFAULT_VOICE;
    const dur = v.dur * (type === 'hurt' ? 0.55 : type === 'death' ? 1.5 : type === 'snore' ? 2.4 : 1);
    const g0 = type === 'hurt' ? [v.glide[0] * 1.35, v.glide[1] * 1.15] : type === 'death' ? [v.glide[0], v.glide[1] * 0.45] : type === 'snore' ? [1, 0.8] : v.glide;
    const pitch = type === 'snore' ? 0.55 : 1;
    const vol = v.vol * (type === 'snore' ? 0.5 : type === 'hurt' ? 1.15 : 1) * 1.3;
    const pulses = type === 'say' || type === 'snore' ? (v.pulses ?? 1) : Math.min(2, v.pulses ?? 1);
    const out = c.createGain(); out.gain.value = 1;
    const filter = c.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = (v.filter ?? 1500) * (type === 'hurt' ? 1.4 : 1); filter.Q.value = 1.1;
    filter.connect(out);
    const pan = this.route(out, position);
    const cleanup: AudioNode[] = [out, filter];
    for (let k = 0; k < pulses; k++) {
      const t0 = now + k * (dur * 1.15) + 0.005;
      const f0 = v.f * pitch * (1 + (Math.random() - 0.5) * 0.06);
      const osc = c.createOscillator(), g = c.createGain();
      osc.type = type === 'snore' ? 'sine' : v.wave;
      osc.frequency.setValueAtTime(f0 * g0[0], t0);
      osc.frequency.exponentialRampToValueAtTime(Math.max(25, f0 * g0[1]), t0 + dur);
      if (v.vib && type !== 'hurt') {
        const lfo = c.createOscillator(), lg = c.createGain();
        lfo.frequency.value = v.vib; lg.gain.value = f0 * 0.04;
        lfo.connect(lg); lg.connect(osc.frequency); lfo.start(t0); lfo.stop(t0 + dur + 0.05);
        lfo.onended = () => { lfo.disconnect(); lg.disconnect(); };
      }
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.linearRampToValueAtTime(vol, t0 + Math.min(0.06, dur * 0.2));
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      osc.connect(g); g.connect(filter);
      osc.start(t0); osc.stop(t0 + dur + 0.03);
      osc.onended = () => { osc.disconnect(); g.disconnect(); };
      if (v.noise && this.noise) {
        const src = c.createBufferSource(), ng = c.createGain(), nf = c.createBiquadFilter();
        src.buffer = this.noise; src.playbackRate.value = 0.8 + Math.random() * 0.5;
        nf.type = v.f > 1500 ? 'highpass' : 'bandpass'; nf.frequency.value = Math.max(200, v.f * 2); nf.Q.value = 0.8;
        ng.gain.setValueAtTime(0.0001, t0); ng.gain.linearRampToValueAtTime(vol * v.noise * 1.4, t0 + 0.03); ng.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
        src.connect(nf); nf.connect(ng); ng.connect(out);
        src.start(t0, Math.random() * 0.5); src.stop(t0 + dur + 0.03);
        src.onended = () => { src.disconnect(); nf.disconnect(); ng.disconnect(); };
      }
    }
    setTimeout(() => { for (const n of cleanup) n.disconnect(); pan?.disconnect(); }, (dur * (pulses + 1) + 0.4) * 1000);
  }

  play(kind: string, position?: { x: number; y: number; z: number }) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;

    const colon = kind.indexOf(':');
    if (colon > 0) {
      const head = kind.slice(0, colon), species = kind.slice(colon + 1);
      if (head === 'say' || head === 'hurt' || head === 'death' || head === 'snore') { this.mobVoice(species, head, position); return; }
    }

    if (kind === 'xp') {
      const pitch = 680 + Math.random() * 240;
      this.tone(pitch, 0.14, 0.14, 'sine', pitch * 1.25, true);
      return;
    }
    if (kind === 'levelup') {
      this.tone(523.25, 0.22, 0.16, 'triangle', undefined, true, 0);
      this.tone(659.25, 0.22, 0.16, 'triangle', undefined, true, 0.09);
      this.tone(783.99, 0.28, 0.18, 'triangle', undefined, true, 0.18);
      this.tone(1046.5, 0.45, 0.20, 'triangle', undefined, true, 0.27);
      return;
    }
    if (kind === 'glass') {
      this.tone(2400 + Math.random() * 600, 0.12, 0.18, 'triangle', 1200);
      this.tone(3100 + Math.random() * 700, 0.09, 0.14, 'sine', 1800, false, 0.02);
      return;
    }
    if (kind === 'bow') {
      this.tone(420, 0.14, 0.18, 'triangle', 160);
      return;
    }
    if (kind === 'critical') {
      this.tone(520, 0.11, 0.22, 'sawtooth', 880);
      return;
    }
    if (kind === 'portal') {
      this.tone(220, 0.9, 0.12, 'sine', 330, true);
      this.tone(330, 0.9, 0.1, 'triangle', 495, true, 0.12);
      return;
    }
    if (kind === 'chest' || kind === 'door') {
      this.tone(kind === 'chest' ? 160 : 240, 0.12, 0.15, 'triangle', kind === 'chest' ? 210 : 180);
      return;
    }
    if (kind === 'eat') {
      for (let i = 0; i < 3; i++) this.tone(240 + Math.random() * 90, 0.06, 0.12, 'sawtooth', 140, false, i * 0.06);
      return;
    }
    if (kind === 'drink') {
      for (let i = 0; i < 3; i++) this.tone(340 + i * 70 + Math.random() * 40, 0.07, 0.12, 'sine', 520 + i * 80, false, i * 0.06);
      return;
    }
    if (kind === 'brush') {
      this.tone(1100 + Math.random() * 350, 0.08, 0.08, 'triangle', 650);
      kind = 'sand';
    }
    if (kind === 'beacon') {
      this.tone(196, 0.65, 0.14, 'sine', 392, true, 0);
      this.tone(293.66, 0.65, 0.11, 'triangle', 587.33, true, 0.08);
      return;
    }
    if (kind === 'fuse') {
      this.tone(1800, 0.4, 0.09, 'sawtooth', 2600);
      return;
    }
    if (kind === 'equip') { this.tone(900, 0.07, 0.14, 'square', 600); this.tone(1400, 0.06, 0.1, 'triangle', 900, false, 0.05); return; }
    if (kind === 'golem_summon') { this.tone(70, 0.6, 0.22, 'square', 140, true); this.tone(420, 0.5, 0.1, 'triangle', 840, true, 0.12); return; }
    if (kind === 'bottle_fill') { for (let i = 0; i < 4; i++) this.tone(420 + i * 130, 0.09, 0.12, 'sine', 700 + i * 160, false, i * 0.06); return; }
    if (kind === 'dragon_breath') { this.tone(70, 1.1, 0.26, 'sawtooth', 38, true); this.tone(150, 0.9, 0.12, 'sawtooth', 60, false, 0.1); return; }
    if (kind === 'jukebox_insert') { this.tone(300, 0.12, 0.16, 'triangle', 180); this.tone(600, 0.1, 0.1, 'sine', 400, false, 0.07); return; }
    if (kind === 'thunder') {
      kind = 'explosion';
    }

    const now = c.currentTime;
    const source = c.createBufferSource();
    const filter = c.createBiquadFilter();
    const gain = c.createGain();
    source.buffer = this.noise;
    source.playbackRate.value = 0.8 + Math.random() * 0.4;

    let duration = 0.13, volume = 0.35, freq = 900;
    if (kind === 'grass' || kind === 'step') { duration = 0.11; volume = 0.24; freq = 650 + Math.random() * 580; filter.type = 'lowpass'; }
    else if (kind === 'sand') { duration = 0.12; volume = 0.22; freq = 1400 + Math.random() * 400; filter.type = 'highpass'; }
    else if (kind === 'stone' || kind === 'mine') { duration = 0.1; volume = 0.46; freq = 1850; filter.type = 'bandpass'; }
    else if (kind === 'wood' || kind === 'place') { duration = 0.14; volume = 0.42; freq = 480; filter.type = 'lowpass'; }
    else if (kind === 'water') { duration = 0.42; volume = 0.32; freq = 2200; filter.type = 'bandpass'; }
    else if (kind === 'fizz') { duration = 0.55; volume = 0.3; freq = 5200; filter.type = 'highpass'; }
    else if (kind === 'explosion') { duration = 1.35; volume = 0.88; freq = 155; filter.type = 'lowpass'; }
    else if (kind === 'click') { duration = 0.05; volume = 0.2; freq = 1400; filter.type = 'bandpass'; }
    else if (kind === 'hurt') { duration = 0.2; volume = 0.42; freq = 360; filter.type = 'lowpass'; }
    else { duration = 0.22; volume = 0.22; freq = 750; filter.type = 'bandpass'; }

    filter.frequency.setValueAtTime(freq, now);
    filter.frequency.exponentialRampToValueAtTime(Math.max(60, freq * 0.35), now + duration);
    filter.Q.value = 0.7;
    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(volume, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    source.connect(filter);
    filter.connect(gain);

    let panner: PannerNode | null = null;
    if (position) {
      panner = c.createPanner();
      panner.panningModel = 'HRTF';
      panner.distanceModel = 'inverse';
      panner.refDistance = 3;
      panner.maxDistance = 42;
      panner.positionX.value = position.x;
      panner.positionY.value = position.y;
      panner.positionZ.value = position.z;
      gain.connect(panner);
      panner.connect(this.master);
    } else {
      gain.connect(this.master);
    }

    source.start(now, Math.random() * 0.5);
    source.stop(now + duration + 0.03);
    source.onended = () => {
      source.disconnect();
      filter.disconnect();
      gain.disconnect();
      panner?.disconnect();
    };

    if (kind === 'wood' || kind === 'place' || kind === 'stone') {
      for (let i = 0; i < 2; i++) {
        const click = c.createBufferSource();
        const g = c.createGain();
        click.buffer = this.noise;
        g.gain.setValueAtTime(volume * 0.2, now + i * 0.025);
        g.gain.exponentialRampToValueAtTime(0.001, now + i * 0.025 + 0.024);
        click.connect(g);
        g.connect(this.master);
        click.start(now + i * 0.025, 0.7);
        click.stop(now + i * 0.025 + 0.03);
        click.onended = () => { click.disconnect(); g.disconnect(); };
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ ambience
  /**
   * Environmental sound: birds by day, cave drips / rumbles underground, biome specific layers (swamp frogs, ocean bubbles,
   * nether drones, end whooshes, deep dark heartbeat). Called every frame; each layer rate-limits itself.
   */
  ambient(env: { dim: string; biome: string; y: number; surface: number; cave: string | null; night: boolean; underwater: boolean; raining: boolean }) {
    const c = this.context;
    if (!c || !this.master || this.settings.muted || c.state !== 'running') return;
    const t = c.currentTime, due = (k: string, min: number, max: number) => {
      const next = this.amb[k] ?? t + min + Math.random() * (max - min);
      if (t < next) { this.amb[k] = next; return false; }
      this.amb[k] = t + min + Math.random() * (max - min);
      return true;
    };
    const pos = (r = 8) => ({ x: this.ear.x + (Math.random() - 0.5) * r * 2, y: this.ear.y + (Math.random() - 0.3) * 4, z: this.ear.z + (Math.random() - 0.5) * r * 2 });
    const underground = env.dim === 'overworld' && env.y < env.surface - 8;
    if (env.underwater) {
      if (due('bub', 1.5, 4)) for (let i = 0; i < 3; i++) this.tone(300 + Math.random() * 300, 0.07, 0.07, 'sine', 700 + Math.random() * 400, false, i * 0.08);
      return;
    }
    if (env.dim === 'nether') {
      if (due('neth', 9, 22)) { const f = env.biome === 'soul_sand_valley' ? 180 : env.biome === 'warped_forest' ? 130 : 90; this.tone(f, 2.4, 0.07, 'sine', f * 0.7, true); }
      if (env.biome === 'basalt_deltas' && due('crk', 0.8, 2.5)) this.play('stone', pos(10));
      if (due('lavapop', 4, 10)) this.play('water', pos(12));
      return;
    }
    if (env.dim === 'end') { if (due('void', 10, 24)) this.tone(55, 3.5, 0.08, 'sawtooth', 40, true); return; }
    if (underground) {
      if (due('cave', 14, 40)) {
        const r = Math.random();
        if (r < 0.4) this.tone(70 + Math.random() * 40, 1.6, 0.09, 'sine', 45, true);
        else if (r < 0.7) { this.tone(180, 0.5, 0.06, 'triangle', 90, true); this.tone(150, 0.6, 0.05, 'sine', 70, true, 0.4); }
        else this.play('stone', pos(14));
      }
      if (env.cave === 'dripstone_caves' && due('drip', 1.2, 4)) { const f = 900 + Math.random() * 700; this.tone(f, 0.09, 0.09, 'sine', f * 0.55); }
      else if (env.cave === 'lush_caves' && due('lush', 3, 9)) { this.tone(1500 + Math.random() * 600, 0.07, 0.05, 'sine', 2300, true); this.tone(900, 0.2, 0.04, 'sine', 700, true, 0.1); }
      else if (env.cave === 'deep_dark') {
        if (due('dd', 7, 16)) this.tone(48, 3.2, 0.12, 'sine', 36, true);
        if (due('beat', 2.2, 2.6)) { this.tone(55, 0.18, 0.12, 'sine', 40); this.tone(50, 0.2, 0.1, 'sine', 38, false, 0.28); }
      } else if (due('drop', 4, 12)) { const f = 700 + Math.random() * 500; this.tone(f, 0.08, 0.06, 'sine', f * 0.6); }
      return;
    }
    const b = env.biome;
    if (env.night) {
      if ((b === 'swamp' || b === 'mangrove_swamp') && due('frog', 2, 6)) for (let i = 0; i < 2; i++) this.tone(120 + Math.random() * 30, 0.12, 0.07, 'square', 90, false, i * 0.18);
      if (!b.includes('desert') && !b.includes('ocean') && !b.includes('snow') && due('cric', 0.4, 1.4)) { const f = 4300 + Math.random() * 400; for (let i = 0; i < 3; i++) this.tone(f, 0.03, 0.025, 'square', f * 0.97, false, i * 0.05); }
      if (due('wind_n', 12, 30)) this.play('sand', pos(10));
      return;
    }
    if (env.raining) { if (due('rain', 0.6, 1.6)) this.play('grass', pos(12)); return; }
    if (b.includes('ocean') || b === 'beach' || b === 'river') { if (due('wave', 6, 14)) this.play('water', pos(14)); if (due('gull', 12, 30)) this.tone(1800, 0.25, 0.05, 'triangle', 1300, true); return; }
    if (b.includes('desert') || b.includes('badlands')) { if (due('wind', 8, 22)) this.play('sand', pos(10)); return; }
    if (b.includes('snow') || b.includes('frozen') || b.includes('peaks') || b === 'grove' || b === 'ice_spikes') { if (due('wind_s', 6, 18)) this.play('sand', pos(10)); return; }
    if (b === 'swamp' || b === 'mangrove_swamp') { if (due('frog_d', 5, 12)) this.tone(130, 0.14, 0.06, 'square', 95); return; }
    if (b.includes('jungle') && due('jbird', 1.5, 4)) { const f = 1500 + Math.random() * 900; this.tone(f, 0.08, 0.05, 'square', f * 1.3); this.tone(f * 1.2, 0.07, 0.04, 'square', f, false, 0.1); return; }
    if (due('bird', 4, 14)) {
      const f = 2000 + Math.random() * 1400, n = 2 + Math.floor(Math.random() * 3);
      for (let i = 0; i < n; i++) this.tone(f * (1 + i * 0.06), 0.06, 0.04, 'sine', f * (1.2 + i * 0.05), false, i * 0.09);
    }
  }

  // ------------------------------------------------------------------------------------------------ jukebox
  /** Starts a looping procedural tune (one per jukebox key). Volume falls off with the distance to the jukebox. */
  playDisc(key: string, disc: string, pos: { x: number; y: number; z: number }) {
    this.stopDisc(key);
    const style = DISC_STYLE[disc];
    if (!style || !this.context) return;
    const stepMs = (60 / style.bpm / 2) * 1000;
    const rec = { timer: 0 as unknown as ReturnType<typeof setInterval>, name: disc, pos, n: 0 };
    const hash = (i: number, s: number) => { let h = Math.imul(i + 1, 374761393) ^ Math.imul(style.seed + s, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
    rec.timer = setInterval(() => {
      const c = this.context;
      if (!c || c.state !== 'running' || this.settings.muted || !this.settings.music && false) return;
      const dist = Math.hypot(pos.x - this.ear.x, pos.y - this.ear.y, pos.z - this.ear.z), falloff = Math.max(0, 1 - dist / 56);
      const n = rec.n++, bar = Math.floor(n / 16), step = n % 16;
      if (falloff <= 0.02) return;
      const vol = 0.2 * falloff * falloff;
      // 8-bar form: A A B A with a seeded melodic contour that walks through the scale
      const section = bar % 4 === 2 ? 1 : 0;
      const scale = style.scale;
      const walk = (i: number) => { let deg = 0; for (let k = 0; k <= i; k++) deg += Math.floor(hash(k + section * 97, 1) * 5) - 2; return deg; };
      const note = (deg: number) => { const len = scale.length, oct = Math.floor(deg / len), idx = ((deg % len) + len) % len; return style.root * Math.pow(2, (scale[idx] + 12 * oct) / 12); };
      const base = 2 + (section ? 2 : 0);
      if (hash(step + section * 31, 2) > (step % 4 === 0 ? 0.08 : 0.38)) {
        const deg = base + (((walk(step) % 8) + 8) % 8) + (hash(step, 3) > 0.8 ? 5 : 0);
        this.tone(note(deg), 60 / style.bpm * (hash(step, 4) > 0.6 ? 0.9 : 0.4), vol * 0.7, style.wave, undefined, true);
      }
      if (step % 4 === 0) {
        const root = note(((bar % 4) * 2) % scale.length - scale.length);
        this.tone(root, 60 / style.bpm * 1.6, vol * 0.9, style.bass);
      }
      if (style.perc && step % 2 === 0 && this.noise) {
        const src = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
        src.buffer = this.noise; f.type = step % 4 === 0 ? 'lowpass' : 'highpass'; f.frequency.value = step % 4 === 0 ? 220 : 6000;
        g.gain.setValueAtTime(vol * 0.9, c.currentTime); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + 0.07);
        src.connect(f); f.connect(g); g.connect(this.master!); src.start(c.currentTime, Math.random()); src.stop(c.currentTime + 0.08);
        src.onended = () => { src.disconnect(); f.disconnect(); g.disconnect(); };
      }
    }, stepMs);
    this.discs.set(key, rec);
  }

  stopDisc(key: string) {
    const d = this.discs.get(key);
    if (!d) return;
    clearInterval(d.timer);
    this.discs.delete(key);
  }

  isDiscPlaying(key: string) { return this.discs.has(key); }
  stopAllDiscs() { for (const k of [...this.discs.keys()]) this.stopDisc(k); }

  chord() {
    const c = this.context;
    if (!c || !this.master) return;
    // C418-inspired warm suspended & major7 ambient voicings
    const progressions = [
      [130.81, 196.0, 246.94, 329.63], // Cmaj7
      [110.0, 164.81, 220.0, 293.66],  // Am11
      [87.31, 130.81, 174.61, 261.63], // Fmaj7
      [98.0, 146.83, 196.0, 293.66],   // Gsus4
      [146.83, 220.0, 261.63, 392.0],  // Dm11
      [130.81, 164.81, 246.94, 392.0], // Cmaj9
    ];
    const notes = progressions[this.step++ % progressions.length];
    notes.forEach((freq, i) => {
      const osc = c.createOscillator();
      const gain = c.createGain();
      const filter = c.createBiquadFilter();
      osc.type = i === 0 ? 'sine' : 'triangle';
      osc.frequency.value = freq;
      osc.detune.value = i % 2 ? 3 : -3;
      filter.type = 'lowpass';
      filter.frequency.value = 620;
      const start = c.currentTime + i * 0.55;
      gain.gain.setValueAtTime(0, start);
      gain.gain.linearRampToValueAtTime(0.022, start + 1.4);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 6.2);
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(this.master!);
      if (this.delay && i > 0) gain.connect(this.delay);
      osc.start(start);
      osc.stop(start + 6.3);
      osc.onended = () => { osc.disconnect(); filter.disconnect(); gain.disconnect(); };
    });
  }

  listener(x: number, y: number, z: number, yaw: number) {
    this.ear.x = x; this.ear.y = y; this.ear.z = z;
    const l = this.context?.listener;
    if (!l) return;
    if (l.positionX) {
      l.positionX.value = x;
      l.positionY.value = y;
      l.positionZ.value = z;
      l.forwardX.value = -Math.sin(yaw);
      l.forwardY.value = 0;
      l.forwardZ.value = -Math.cos(yaw);
      l.upX.value = 0;
      l.upY.value = 1;
      l.upZ.value = 0;
    }
  }

  dispose() {
    if (this.musicTimer) clearInterval(this.musicTimer);
    this.stopAllDiscs();
    this.context?.close().catch(() => {});
    this.context = null;
  }
}
