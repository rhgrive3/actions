// Smithing-table armor trims: 16 templates × 10 materials = 160 smithing recipes, the template duplication crafting recipes and the
// other crafting recipes that came with the 1.21 / archaeology / mob-behaviour pass.
import { TRIM_PATTERN_NAMES, templateItem } from '../game/content121';
import type { Stack } from '../game/types';

export const TRIM_PATTERNS = TRIM_PATTERN_NAMES.map(([name]) => name);
export interface TrimMaterial { id: string; item: string; ja: string; color: string }
export const TRIM_MATERIALS: TrimMaterial[] = [
  { id: 'iron', item: 'iron_ingot', ja: '鉄', color: '#ececec' },
  { id: 'copper', item: 'copper_ingot', ja: '銅', color: '#b4684d' },
  { id: 'gold', item: 'gold_ingot', ja: '金', color: '#deb12d' },
  { id: 'lapis', item: 'lapis_lazuli', ja: 'ラピスラズリ', color: '#416e97' },
  { id: 'emerald', item: 'emerald', ja: 'エメラルド', color: '#11a036' },
  { id: 'diamond', item: 'diamond', ja: 'ダイヤモンド', color: '#6eecd2' },
  { id: 'netherite', item: 'netherite_ingot', ja: 'ネザライト', color: '#625859' },
  { id: 'redstone', item: 'redstone', ja: 'レッドストーン', color: '#971607' },
  { id: 'amethyst', item: 'amethyst_shard', ja: 'アメジスト', color: '#9a5cc6' },
  { id: 'quartz', item: 'quartz', ja: 'クォーツ', color: '#e3d4c4' },
];
export interface TrimRecipe { template: string; addition: string; pattern: string; material: string }
/** Every template × material combination; each applies to any armor piece. */
export const TRIM_RECIPES: TrimRecipe[] = TRIM_PATTERNS.flatMap(pattern => TRIM_MATERIALS.map(m => ({ template: templateItem(pattern), addition: m.item, pattern, material: m.id })));
export const isTrimmable = (name: string) => /_(helmet|chestplate|leggings|boots)$/.test(name);
export const trimLabel = (trim: { pattern: string; material: string }) => {
  const p = TRIM_PATTERN_NAMES.find(([n]) => n === trim.pattern)?.[1] ?? trim.pattern, m = TRIM_MATERIALS.find(x => x.id === trim.material)?.ja ?? trim.material;
  return `${p}の装飾（${m}）`;
};

/** Result of template + armor + material on the smithing table, or null when the combination is invalid / would change nothing. */
export function trimPreview(template: Stack | null, base: Stack | null, addition: Stack | null): Stack | null {
  if (!template || !base || !addition || !isTrimmable(base.name)) return null;
  const r = TRIM_RECIPES.find(x => x.template === template.name && x.addition === addition.name);
  if (!r || (base.trim?.pattern === r.pattern && base.trim.material === r.material)) return null;
  return { ...base, count: 1, trim: { pattern: r.pattern, material: r.material } };
}

/** Template duplication: 7 diamonds + the template + its signature block → 2 templates. */
export const TEMPLATE_COPY_BLOCK: Record<string, string> = {
  netherite_upgrade: 'netherrack',
  [templateItem('sentry')]: 'cobblestone', [templateItem('dune')]: 'sandstone', [templateItem('coast')]: 'cobblestone', [templateItem('wild')]: 'mossy_cobblestone',
  [templateItem('ward')]: 'cobbled_deepslate', [templateItem('eye')]: 'end_stone', [templateItem('vex')]: 'cobblestone', [templateItem('tide')]: 'prismarine',
  [templateItem('snout')]: 'blackstone', [templateItem('rib')]: 'netherrack', [templateItem('spire')]: 'purpur_block', [templateItem('wayfinder')]: 'terracotta',
  [templateItem('shaper')]: 'terracotta', [templateItem('silence')]: 'cobbled_deepslate', [templateItem('raiser')]: 'terracotta', [templateItem('host')]: 'terracotta',
};

type AddRecipe = (id: string, result: string, count: number, rows: string[], key: Record<string, string>, station?: 'inventory' | 'crafting_table', category?: string) => void;
export function registerRecipes121(recipe: AddRecipe, has: (id: string) => boolean) {
  const add: AddRecipe = (id, ...rest) => { if (!has(id)) recipe(id, ...rest); };
  for (const [template, blockName] of Object.entries(TEMPLATE_COPY_BLOCK)) add('copy_' + template, template, 2, ['DTD', 'DBD', 'DDD'], { D: 'diamond', T: template, B: blockName }, 'crafting_table', 'materials');
  add('brush', 'brush', 1, ['F', 'C', 'S'], { F: 'feather', C: 'copper_ingot', S: 'stick' }, 'crafting_table', 'tools');
  add('wolf_armor', 'wolf_armor', 1, ['S  ', 'SSS', 'S S'], { S: 'armadillo_scute' }, 'crafting_table', 'tools');
  add('mace', 'mace', 1, ['H', 'R'], { H: 'heavy_core', R: 'breeze_rod' }, 'crafting_table', 'tools');
  add('wind_charge', 'wind_charge', 4, ['R'], { R: 'breeze_rod' }, 'inventory', 'tools');
  add('beacon', 'beacon', 1, ['GGG', 'GNG', 'OOO'], { G: 'glass', N: 'nether_star', O: 'obsidian' }, 'crafting_table', 'utility');
  add('conduit', 'conduit', 1, ['NNN', 'NHN', 'NNN'], { N: 'nautilus_shell', H: 'heart_of_the_sea' }, 'crafting_table', 'utility');
  add('beehive', 'beehive', 1, ['PPP', 'HHH', 'PPP'], { P: 'oak_planks', H: 'honeycomb' }, 'crafting_table', 'utility');
  add('decorated_pot', 'decorated_pot', 1, [' B ', 'B B', ' B '], { B: 'brick' }, 'crafting_table', 'decorations');
  add('polished_tuff', 'polished_tuff', 4, ['TT', 'TT'], { T: 'tuff' }, 'inventory', 'building');
  add('tuff_bricks', 'tuff_bricks', 4, ['TT', 'TT'], { T: 'polished_tuff' }, 'inventory', 'building');
  add('chiseled_tuff', 'chiseled_tuff', 2, ['T', 'T'], { T: 'tuff_bricks' }, 'inventory', 'building');
  add('chiseled_copper', 'chiseled_copper', 2, ['C', 'C'], { C: 'cut_copper' }, 'inventory', 'building');
  add('copper_grate', 'copper_grate', 4, [' C ', 'C C', ' C '], { C: 'copper_block' }, 'crafting_table', 'building');
}
