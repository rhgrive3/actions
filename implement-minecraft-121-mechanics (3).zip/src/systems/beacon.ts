// Beacons (1–4 tier mineral pyramid, 3D vertical light beams, and GUI powers) and Conduits (16–42 block prismarine frame in water).
import * as THREE from 'three';
import { BLOCKS, ID } from '../game/data';
import type { GameEvents } from '../game/events';

type Get = (x: number, y: number, z: number) => number;
const ids = (list: string[]) => new Set(list.map(n => (ID as Record<string, number | undefined>)[n]).filter((v): v is number => v !== undefined));

// ---- Beacon -------------------------------------------------------------------------------------------------------------
export const BEACON_BASE_LIST = ['iron_block', 'gold_block', 'diamond_block', 'emerald_block', 'netherite_block'];
export const BEACON_BASE_BLOCKS = new Set(BEACON_BASE_LIST);
export const BEACON_PAYMENT = ['iron_ingot', 'gold_ingot', 'diamond', 'emerald', 'netherite_ingot'];
export const BEACON_PAYMENT_ITEMS = new Set(BEACON_PAYMENT);
export const isBeaconPayment = (name: string): boolean => BEACON_PAYMENT_ITEMS.has(name);
export const BEACON_INTERVAL = 4;

export interface BeaconPowerDef { id: string; ja: string; en: string; minTier: number }
export const BEACON_PRIMARY_POWERS: BeaconPowerDef[] = [
  { id: 'speed', ja: '移動速度上昇', en: 'Speed', minTier: 1 },
  { id: 'haste', ja: '採掘速度上昇', en: 'Haste', minTier: 1 },
  { id: 'resistance', ja: '耐性', en: 'Resistance', minTier: 2 },
  { id: 'jump_boost', ja: '跳躍力上昇', en: 'Jump Boost', minTier: 2 },
  { id: 'strength', ja: '攻撃力上昇', en: 'Strength', minTier: 3 },
];

export interface BeaconConfig { primary: string; secondary?: 'regeneration' | 'level2' | string }

let baseIds: Set<number> | null = null;
/** Number of complete pyramid layers under the beacon (0‥4): layer n is a (2n+1)² square n blocks below it. */
export function beaconLevel(get: Get, x: number, y: number, z: number): number {
  const base = (baseIds ??= ids(BEACON_BASE_LIST));
  let level = 0;
  for (let l = 1; l <= 4; l++) {
    for (let dz = -l; dz <= l; dz++) for (let dx = -l; dx <= l; dx++) if (!base.has(get(x + dx, y - l, z + dz))) return level;
    level = l;
  }
  return level;
}

/**
 * Computes the valid pyramid tier (0..4) under a beacon at (bx, by, bz).
 * Requires unobstructed sky above (transparent blocks and bedrock are allowed per Java Edition).
 */
export function beaconPyramidTier(getBlock: Get, bx: number, by: number, bz: number): number {
  for (let y = by + 1; y < by + 64; y++) {
    const id = getBlock(bx, y, bz);
    if (id <= 0) continue;
    const def = BLOCKS[id];
    if (def && def.solid && !def.transparent && def.name !== 'bedrock') return 0;
  }
  return beaconLevel(getBlock, bx, by, bz);
}

/** Range in blocks of a beacon with pyramid tier 1..4 (Java: 20, 30, 40, 50 blocks). */
export const beaconRange = (tier: number): number => (tier <= 0 ? 0 : 10 + tier * 10);
/** Effect duration in seconds applied every 4 seconds by an active beacon (Java: 9 + 2 * tier). */
export const beaconDuration = (tier: number): number => (tier <= 0 ? 0 : 9 + tier * 2);

const POWERS = [[], ['speed', 'haste'], ['speed', 'haste', 'resistance', 'jump_boost'], ['speed', 'haste', 'resistance', 'jump_boost', 'strength'], ['speed', 'haste', 'resistance', 'jump_boost', 'strength']];
export const beaconPowers = (level: number): string[] => POWERS[Math.max(0, Math.min(4, level))];

/** Effects granted to players in range: the primary power, raised to level II or joined by Regeneration on a full pyramid. */
export function beaconEffects(level: number, primary: string, secondary: string): [string, number, number][] {
  if (level <= 0 || !beaconPowers(level).includes(primary)) return [];
  const sec = beaconDuration(level), out: [string, number, number][] = [[primary, sec, level >= 4 && (secondary === primary || secondary === 'level2') ? 1 : 0]];
  if (level >= 4 && secondary === 'regeneration') out.push(['regeneration', sec, 0]);
  return out;
}

// ---- Conduit ------------------------------------------------------------------------------------------------------------
export const CONDUIT_FRAME_BLOCKS = ['prismarine', 'prismarine_bricks', 'dark_prismarine', 'sea_lantern'];
export const CONDUIT_MIN_FRAME = 16;
export const CONDUIT_MAX_FRAME = 42;
export const CONDUIT_INTERVAL = 2;
export const CONDUIT_ATTACK_RANGE = 8;
export const CONDUIT_ATTACK_DAMAGE = 4;
/** The 42 frame cells: three 5×5 square rings (one per axis plane) centred on the conduit. */
export const CONDUIT_FRAME_POSITIONS: [number, number, number][] = (() => {
  const seen = new Map<string, [number, number, number]>();
  for (let a = -2; a <= 2; a++) for (let b = -2; b <= 2; b++) {
    if (Math.max(Math.abs(a), Math.abs(b)) !== 2) continue;
    for (const p of [[a, b, 0], [a, 0, b], [0, a, b]] as [number, number, number][]) seen.set(p.join(','), p);
  }
  return [...seen.values()];
})();
let frameIds: Set<number> | null = null;
export function conduitFrame(get: Get, x: number, y: number, z: number): number {
  const frame = (frameIds ??= ids(CONDUIT_FRAME_BLOCKS));
  let n = 0;
  for (const [dx, dy, dz] of CONDUIT_FRAME_POSITIONS) if (frame.has(get(x + dx, y + dy, z + dz))) n++;
  return n;
}
/** A conduit only works inside a 3×3×3 volume of water. */
export function conduitInWater(get: Get, x: number, y: number, z: number): boolean {
  const water = ID.water;
  for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if ((dx || dy || dz) && get(x + dx, y + dy, z + dz) !== water) return false;
  return true;
}
export function conduitStatus(get: Get, x: number, y: number, z: number) {
  const frame = conduitFrame(get, x, y, z), active = frame >= CONDUIT_MIN_FRAME && conduitInWater(get, x, y, z);
  return { frame, active, range: active ? Math.floor(frame / 7) * 16 : 0, hunting: active && frame >= CONDUIT_MAX_FRAME };
}

// ---- Runtime ------------------------------------------------------------------------------------------------------------
export interface BeaconData { x: number; y: number; z: number; primary: string; secondary: string; level: number }
export interface ConduitData { x: number; y: number; z: number; frame: number; active: boolean; range: number; hunting: boolean }
export interface BeaconPlayer { id: string; x: number; y: number; z: number; /** in water or standing in rain */ wet: boolean }
export interface BeaconHost {
  getBlock: Get;
  setState(x: number, y: number, z: number, state: number): void;
  /** Whether nothing opaque sits above the beacon (the beam needs open sky). */
  skyClear?(x: number, y: number, z: number): boolean;
  players(): BeaconPlayer[];
  addEffect(player: string, id: string, sec: number, amp: number): void;
  hostilesInWater(x: number, y: number, z: number, r: number): number[];
  damageMob(id: number, damage: number): void;
  emit?<K extends keyof GameEvents>(type: K, payload: GameEvents[K]): void;
}
export interface BeaconSave { beacons: BeaconData[]; conduits: [number, number, number][] }
const keyOf = (x: number, y: number, z: number) => `${x},${y},${z}`;

export class BeaconSystem {
  beacons = new Map<string, BeaconData>();
  conduits = new Map<string, ConduitData>();
  private bAcc = BEACON_INTERVAL;
  private cAcc = CONDUIT_INTERVAL;

  constructor(public host: BeaconHost) {}

  addBeacon(x: number, y: number, z: number) { const k = keyOf(x, y, z); if (!this.beacons.has(k)) this.beacons.set(k, { x, y, z, primary: 'speed', secondary: '', level: 0 }); this.bAcc = BEACON_INTERVAL; return this.beacons.get(k)!; }
  addConduit(x: number, y: number, z: number) { const k = keyOf(x, y, z); if (!this.conduits.has(k)) this.conduits.set(k, { x, y, z, frame: 0, active: false, range: 0, hunting: false }); this.cAcc = CONDUIT_INTERVAL; return this.conduits.get(k)!; }
  remove(x: number, y: number, z: number) { const k = keyOf(x, y, z); this.beacons.delete(k); this.conduits.delete(k); }

  /** Re-validates one beacon's pyramid right now (also used when the player clicks it). */
  refreshBeacon(b: BeaconData): number {
    const level = this.host.skyClear?.(b.x, b.y, b.z) === false ? 0 : beaconLevel(this.host.getBlock, b.x, b.y, b.z);
    if (level !== b.level) {
      b.level = level;
      if (!beaconPowers(level).includes(b.primary)) b.primary = 'speed';
      if (level < 4) b.secondary = '';
      this.host.setState(b.x, b.y, b.z, level);
      this.host.emit?.('beacon_state', { x: b.x, y: b.y, z: b.z, level, primary: b.primary, secondary: b.secondary, range: beaconRange(level) });
    }
    return level;
  }
  /** Cycles the primary power (or the secondary one on a tier-4 pyramid). Returns false when the pyramid offers no choice. */
  cyclePower(b: BeaconData, secondary = false): boolean {
    const level = this.refreshBeacon(b), list = beaconPowers(level);
    if (!list.length) return false;
    if (secondary) {
      if (level < 4) return false;
      b.secondary = b.secondary === '' ? 'regeneration' : b.secondary === 'regeneration' ? b.primary : '';
    } else {
      const was = b.secondary === b.primary;
      b.primary = list[(list.indexOf(b.primary) + 1) % list.length];
      if (was) b.secondary = b.primary;
    }
    this.host.emit?.('beacon_state', { x: b.x, y: b.y, z: b.z, level, primary: b.primary, secondary: b.secondary, range: beaconRange(level) });
    this.bAcc = BEACON_INTERVAL;
    return true;
  }

  update(dt: number) {
    this.bAcc += dt; this.cAcc += dt;
    if (this.bAcc >= BEACON_INTERVAL && this.beacons.size) {
      this.bAcc = 0;
      const players = this.host.players();
      for (const b of this.beacons.values()) {
        if (this.host.getBlock(b.x, b.y, b.z) !== ID.beacon) continue;
        const level = this.refreshBeacon(b), range = beaconRange(level), fx = beaconEffects(level, b.primary, b.secondary);
        if (!fx.length) continue;
        for (const p of players) {
          if (Math.abs(p.x - (b.x + 0.5)) > range || Math.abs(p.z - (b.z + 0.5)) > range || p.y < b.y - range) continue;
          for (const [id, sec, amp] of fx) this.host.addEffect(p.id, id, sec, amp);
        }
      }
    } else if (this.bAcc >= BEACON_INTERVAL) this.bAcc = 0;
    if (this.cAcc >= CONDUIT_INTERVAL && this.conduits.size) {
      this.cAcc = 0;
      const players = this.host.players();
      for (const c of this.conduits.values()) {
        if (this.host.getBlock(c.x, c.y, c.z) !== ID.conduit) continue;
        const st = conduitStatus(this.host.getBlock, c.x, c.y, c.z);
        if (st.frame !== c.frame || st.active !== c.active) {
          Object.assign(c, st);
          this.host.setState(c.x, c.y, c.z, st.hunting ? 2 : st.active ? 1 : 0);
          this.host.emit?.('conduit_state', { x: c.x, y: c.y, z: c.z, ...st });
        }
        if (!st.active) continue;
        for (const p of players) {
          if (!p.wet || Math.hypot(p.x - (c.x + 0.5), p.y - (c.y + 0.5), p.z - (c.z + 0.5)) > st.range) continue;
          this.host.addEffect(p.id, 'conduit_power', 13, 0);
          this.host.addEffect(p.id, 'water_breathing', 13, 0);
          this.host.addEffect(p.id, 'night_vision', 13, 0);
          this.host.addEffect(p.id, 'haste', 13, 0);
        }
        if (st.hunting) for (const id of this.host.hostilesInWater(c.x + 0.5, c.y + 0.5, c.z + 0.5, CONDUIT_ATTACK_RANGE)) {
          this.host.damageMob(id, CONDUIT_ATTACK_DAMAGE);
          this.host.emit?.('conduit_attack', { x: c.x, y: c.y, z: c.z, mobId: id });
        }
      }
    } else if (this.cAcc >= CONDUIT_INTERVAL) this.cAcc = 0;
  }

  save(): BeaconSave { return { beacons: [...this.beacons.values()].map(b => ({ ...b })), conduits: [...this.conduits.values()].map(c => [c.x, c.y, c.z]) }; }
  load(data?: BeaconSave | null) {
    this.beacons.clear(); this.conduits.clear();
    for (const b of data?.beacons ?? []) this.beacons.set(keyOf(b.x, b.y, b.z), { ...b, level: 0 });
    for (const [x, y, z] of data?.conduits ?? []) this.addConduit(x, y, z);
    this.bAcc = BEACON_INTERVAL; this.cAcc = CONDUIT_INTERVAL;
  }
}

/** 3D vertical light beams for active beacons in the world. */
export class BeaconBeams {
  private beams = new Map<string, THREE.Group>();
  private coreGeo = new THREE.BoxGeometry(0.32, 220, 0.32);
  private glowGeo = new THREE.BoxGeometry(0.58, 220, 0.58);
  constructor(private scene: THREE.Scene) {}

  set(key: string, x: number, y: number, z: number, color = '#e8f8ff') {
    let g = this.beams.get(key);
    const hex = color.startsWith('#') ? color : '#e8f8ff';
    if (!g) {
      g = new THREE.Group();
      const core = new THREE.Mesh(this.coreGeo, new THREE.MeshBasicMaterial({ color: hex, transparent: true, opacity: 0.9 }));
      const glow = new THREE.Mesh(this.glowGeo, new THREE.MeshBasicMaterial({ color: hex, transparent: true, opacity: 0.32 }));
      g.add(core); g.add(glow);
      this.scene.add(g);
      this.beams.set(key, g);
    }
    g.position.set(x + 0.5, y + 110.5, z + 0.5);
  }

  update(elapsed: number) {
    for (const g of this.beams.values()) {
      g.rotation.y = elapsed * 1.4;
    }
  }

  remove(key: string) {
    const g = this.beams.get(key);
    if (!g) return;
    this.scene.remove(g);
    this.beams.delete(key);
  }

  clear() { for (const k of [...this.beams.keys()]) this.remove(k); }
  get size() { return this.beams.size; }
}
