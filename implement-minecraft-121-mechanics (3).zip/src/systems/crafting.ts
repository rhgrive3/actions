import { DYES } from '../game/content';
import { TRIM_PATTERNS } from './trims';
import type { Stack } from '../game/types';

export interface Recipe {
  id: string;
  result: string;
  count: number;
  ingredients: Record<string, number>;
  grid: (string | null)[][];
  station: 'inventory' | 'crafting_table';
  category: string;
}

export const RECIPES: Recipe[] = [];

function recipe(
  id: string,
  result: string,
  count: number,
  rows: string[],
  key: Record<string, string>,
  station: 'inventory' | 'crafting_table' = 'inventory',
  category = 'building',
) {
  const ingredients: Record<string, number> = {};
  const grid = rows.map(r =>
    [...r].map(c => {
      if (c === ' ' || c === '.') return null;
      const name = key[c];
      if (!name) throw new Error('Unknown recipe key ' + c);
      ingredients[name] = (ingredients[name] || 0) + 1;
      return name;
    }),
  );
  RECIPES.push({ id, result, count, ingredients, grid, station, category });
}

recipe('oak_planks', 'oak_planks', 4, ['L'], { L: 'oak_log' });
recipe('birch_planks', 'birch_planks', 4, ['L'], { L: 'birch_log' });
for (const wood of ['spruce', 'jungle', 'acacia', 'dark_oak', 'cherry', 'mangrove', 'pale_oak', 'crimson', 'warped', 'poplar']) {
  recipe(wood + '_planks', wood + '_planks', 4, ['L'], { L: wood + '_log' });
}

recipe('stick', 'stick', 4, ['P', 'P'], { P: 'oak_planks' });
recipe('crafting_table', 'crafting_table', 1, ['PP', 'PP'], { P: 'oak_planks' }, 'inventory', 'utility');
recipe('furnace', 'furnace', 1, ['CCC', 'C C', 'CCC'], { C: 'cobblestone' }, 'crafting_table', 'utility');
recipe('chest', 'chest', 1, ['PPP', 'P P', 'PPP'], { P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('barrel', 'barrel', 1, ['PSP', 'P P', 'PSP'], { P: 'oak_planks', S: 'oak_slab' }, 'crafting_table', 'utility');
recipe('bed', 'bed', 1, ['WWW', 'PPP'], { W: 'white_wool', P: 'oak_planks' }, 'crafting_table', 'utility');
recipe('torch', 'torch', 4, ['C', 'S'], { C: 'coal', S: 'stick' }, 'inventory', 'utility');
recipe('torch_charcoal', 'torch', 4, ['C', 'S'], { C: 'charcoal', S: 'stick' }, 'inventory', 'utility');
recipe('lantern', 'lantern', 1, ['III', 'ITI', 'III'], { I: 'iron_ingot', T: 'torch' }, 'crafting_table', 'utility');
recipe('ladder', 'ladder', 3, ['S S', 'SSS', 'S S'], { S: 'stick' }, 'crafting_table', 'utility');
recipe('oak_door', 'oak_door', 3, ['PP', 'PP', 'PP'], { P: 'oak_planks' }, 'crafting_table', 'building');
recipe('stone_bricks', 'stone_bricks', 4, ['SS', 'SS'], { S: 'stone' });
recipe('sandstone', 'sandstone', 1, ['SS', 'SS'], { S: 'sand' });
recipe('cut_sandstone', 'cut_sandstone', 4, ['SS', 'SS'], { S: 'sandstone' });
recipe('end_stone_bricks', 'end_stone_bricks', 4, ['EE', 'EE'], { E: 'end_stone' });
recipe('purpur_block', 'purpur_block', 4, ['CC', 'CC'], { C: 'popped_chorus_fruit' });
recipe('end_rod', 'end_rod', 4, ['B', 'C'], { B: 'blaze_rod', C: 'popped_chorus_fruit' }, 'inventory', 'utility');
recipe('glass_pane', 'glass_pane', 16, ['GGG', 'GGG'], { G: 'glass' }, 'crafting_table');
recipe('iron_bars', 'iron_bars', 16, ['III', 'III'], { I: 'iron_ingot' }, 'crafting_table');
recipe('bookshelf', 'bookshelf', 1, ['PPP', 'BBB', 'PPP'], { P: 'oak_planks', B: 'book' }, 'crafting_table', 'utility');
recipe('enchanting_table', 'enchanting_table', 1, [' B ', 'DOD', 'OOO'], { B: 'book', D: 'diamond', O: 'obsidian' }, 'crafting_table', 'utility');
recipe('anvil', 'anvil', 1, ['III', ' I ', 'III'], { I: 'iron_ingot' }, 'crafting_table', 'utility');
recipe('paper', 'paper', 3, ['SSS'], { S: 'sugar_cane' }, 'crafting_table', 'materials');
recipe('book', 'book', 1, ['PP', 'PL'], { P: 'paper', L: 'leather' }, 'inventory', 'materials');
recipe('bread', 'bread', 1, ['WWW'], { W: 'wheat' }, 'crafting_table', 'food');
recipe('golden_apple', 'golden_apple', 1, ['GGG', 'GAG', 'GGG'], { G: 'gold_ingot', A: 'apple' }, 'crafting_table', 'food');
recipe('cookie', 'cookie', 8, ['WCW'], { W: 'wheat', C: 'coal' }, 'crafting_table', 'food');

// Tools, weapons, utility gear & Progression to Nether / The End / End City
recipe('flint_and_steel', 'flint_and_steel', 1, ['I ', ' F'], { I: 'iron_ingot', F: 'flint' }, 'inventory', 'tools');
recipe('bucket', 'bucket', 1, ['I I', ' I '], { I: 'iron_ingot' }, 'crafting_table', 'tools');
recipe('shears', 'shears', 1, [' I', 'I '], { I: 'iron_ingot' }, 'inventory', 'tools');
recipe('bow', 'bow', 1, [' ST', 'S T', ' ST'], { S: 'stick', T: 'string' }, 'crafting_table', 'tools');
recipe('arrow', 'arrow', 4, ['F', 'S', 'E'], { F: 'flint', S: 'stick', E: 'feather' }, 'crafting_table', 'tools');
recipe('compass', 'compass', 1, [' I ', 'IRI', ' I '], { I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('clock', 'clock', 1, [' G ', 'GRG', ' G '], { G: 'gold_ingot', R: 'redstone' }, 'crafting_table', 'tools');
recipe('blaze_powder', 'blaze_powder', 2, ['B'], { B: 'blaze_rod' }, 'inventory', 'materials');
recipe('ender_eye', 'ender_eye', 1, ['PB'], { P: 'ender_pearl', B: 'blaze_powder' }, 'inventory', 'tools');
recipe('end_crystal', 'end_crystal', 1, ['GGG', 'GEG', 'GTG'], { G: 'glass', E: 'ender_eye', T: 'ghast_tear' }, 'crafting_table', 'tools');
recipe('shulker_box', 'shulker_box', 1, ['S', 'C', 'S'], { S: 'shulker_shell', C: 'chest' }, 'crafting_table', 'utility');
recipe('firework_rocket', 'firework_rocket', 3, ['P', 'G'], { P: 'paper', G: 'gunpowder' }, 'inventory', 'tools');
recipe('netherite_ingot', 'netherite_ingot', 1, ['SSS', 'SGG', 'GG '], { S: 'netherite_scrap', G: 'gold_ingot' }, 'crafting_table', 'materials');

// Redstone
recipe('lever', 'lever', 1, ['S', 'C'], { S: 'stick', C: 'cobblestone' }, 'inventory', 'redstone');
recipe('tnt', 'tnt', 1, ['GSG', 'SGS', 'GSG'], { G: 'gunpowder', S: 'sand' }, 'crafting_table', 'redstone');
recipe('redstone_lamp', 'redstone_lamp', 1, [' R ', 'RGR', ' R '], { R: 'redstone', G: 'glowstone' }, 'crafting_table', 'redstone');
recipe('piston', 'piston', 1, ['PPP', 'CIC', 'CRC'], { P: 'oak_planks', C: 'cobblestone', I: 'iron_ingot', R: 'redstone' }, 'crafting_table', 'redstone');
recipe('sticky_piston', 'sticky_piston', 1, ['S', 'P'], { S: 'slime_ball', P: 'piston' }, 'inventory', 'redstone');
recipe('note_block', 'note_block', 1, ['PPP', 'PRP', 'PPP'], { P: 'oak_planks', R: 'redstone' }, 'crafting_table', 'redstone');

for (const wood of ['oak', 'spruce', 'birch', 'jungle', 'acacia', 'dark_oak', 'cherry']) {
  const material = wood + '_planks';
  recipe(wood + '_slab', wood + '_slab', 6, ['MMM'], { M: material }, 'crafting_table');
  recipe(wood + '_stairs', wood + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: material }, 'crafting_table');
}
for (const color of Object.keys(DYES)) {
  for (const material of ['wool', 'concrete']) {
    const base = color + '_' + material;
    recipe(base + '_slab', base + '_slab', 6, ['MMM'], { M: base }, 'crafting_table');
    recipe(base + '_stairs', base + '_stairs', 4, ['M  ', 'MM ', 'MMM'], { M: base }, 'crafting_table');
  }
}

const tiers: Record<string, string> = {
  wooden: 'oak_planks',
  stone: 'cobblestone',
  iron: 'iron_ingot',
  golden: 'gold_ingot',
  diamond: 'diamond',
};

for (const [tier, mat] of Object.entries(tiers)) {
  const k = { M: mat, S: 'stick' };
  recipe(tier + '_pickaxe', tier + '_pickaxe', 1, ['MMM', ' S ', ' S '], k, 'crafting_table', 'tools');
  recipe(tier + '_axe', tier + '_axe', 1, ['MM', 'MS', ' S'], k, 'crafting_table', 'tools');
  recipe(tier + '_shovel', tier + '_shovel', 1, ['M', 'S', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_sword', tier + '_sword', 1, ['M', 'M', 'S'], k, 'crafting_table', 'tools');
  recipe(tier + '_hoe', tier + '_hoe', 1, ['MM', ' S', ' S'], k, 'crafting_table', 'tools');
}

for (const [tier, mat] of Object.entries({ iron: 'iron_ingot', golden: 'gold_ingot', diamond: 'diamond' })) {
  const k = { M: mat };
  recipe(tier + '_helmet', tier + '_helmet', 1, ['MMM', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_chestplate', tier + '_chestplate', 1, ['M M', 'MMM', 'MMM'], k, 'crafting_table', 'tools');
  recipe(tier + '_leggings', tier + '_leggings', 1, ['MMM', 'M M', 'M M'], k, 'crafting_table', 'tools');
  recipe(tier + '_boots', tier + '_boots', 1, ['M M', 'M M'], k, 'crafting_table', 'tools');
}

for (const type of ['pickaxe', 'axe', 'shovel', 'sword', 'helmet', 'chestplate', 'leggings', 'boots']) {
  recipe('netherite_' + type, 'netherite_' + type, 1, ['DN'], { D: 'diamond_' + type, N: 'netherite_ingot' }, 'crafting_table', 'tools');
}

export const SMELTING: Record<string, { result: string; time: number }> = {
  iron_ore: { result: 'iron_ingot', time: 10 },
  deepslate_iron_ore: { result: 'iron_ingot', time: 10 },
  raw_iron: { result: 'iron_ingot', time: 10 },
  copper_ore: { result: 'copper_ingot', time: 10 },
  deepslate_copper_ore: { result: 'copper_ingot', time: 10 },
  raw_copper: { result: 'copper_ingot', time: 10 },
  gold_ore: { result: 'gold_ingot', time: 10 },
  deepslate_gold_ore: { result: 'gold_ingot', time: 10 },
  nether_gold_ore: { result: 'gold_ingot', time: 10 },
  raw_gold: { result: 'gold_ingot', time: 10 },
  diamond_ore: { result: 'diamond', time: 10 },
  deepslate_diamond_ore: { result: 'diamond', time: 10 },
  emerald_ore: { result: 'emerald', time: 10 },
  deepslate_emerald_ore: { result: 'emerald', time: 10 },
  coal_ore: { result: 'coal', time: 10 },
  deepslate_coal_ore: { result: 'coal', time: 10 },
  lapis_ore: { result: 'lapis_lazuli', time: 10 },
  deepslate_lapis_ore: { result: 'lapis_lazuli', time: 10 },
  redstone_ore: { result: 'redstone', time: 10 },
  deepslate_redstone_ore: { result: 'redstone', time: 10 },
  nether_quartz_ore: { result: 'quartz', time: 10 },
  ancient_debris: { result: 'netherite_scrap', time: 10 },
  sand: { result: 'glass', time: 10 },
  red_sand: { result: 'glass', time: 10 },
  cobblestone: { result: 'stone', time: 10 },
  stone: { result: 'smooth_stone', time: 10 },
  cobbled_deepslate: { result: 'deepslate', time: 10 },
  sandstone: { result: 'smooth_sandstone', time: 10 },
  quartz_block: { result: 'smooth_quartz', time: 10 },
  clay_ball: { result: 'brick', time: 10 },
  clay: { result: 'terracotta', time: 10 },
  netherrack: { result: 'nether_brick', time: 10 },
  wet_sponge: { result: 'sponge', time: 10 },
  chorus_fruit: { result: 'popped_chorus_fruit', time: 10 },
  kelp: { result: 'dried_kelp', time: 10 },
  raw_beef: { result: 'cooked_beef', time: 10 },
  porkchop: { result: 'cooked_porkchop', time: 10 },
  mutton: { result: 'cooked_mutton', time: 10 },
  chicken: { result: 'cooked_chicken', time: 10 },
  rabbit: { result: 'cooked_rabbit', time: 10 },
  potato: { result: 'baked_potato', time: 10 },
  cod: { result: 'cooked_cod', time: 10 },
  salmon: { result: 'cooked_salmon', time: 10 },
  oak_log: { result: 'charcoal', time: 10 },
  birch_log: { result: 'charcoal', time: 10 },
  spruce_log: { result: 'charcoal', time: 10 },
  jungle_log: { result: 'charcoal', time: 10 },
  acacia_log: { result: 'charcoal', time: 10 },
  dark_oak_log: { result: 'charcoal', time: 10 },
  cherry_log: { result: 'charcoal', time: 10 },
  mangrove_log: { result: 'charcoal', time: 10 },
  pale_oak_log: { result: 'charcoal', time: 10 },
  poplar_log: { result: 'charcoal', time: 10 },
};

export const FUEL: Record<string, number> = {
  lava_bucket: 1000,
  coal_block: 800,
  dried_kelp_block: 200,
  blaze_rod: 120,
  coal: 80,
  charcoal: 80,
  oak_planks: 15, birch_planks: 15, spruce_planks: 15, jungle_planks: 15, acacia_planks: 15, dark_oak_planks: 15, cherry_planks: 15, mangrove_planks: 15, pale_oak_planks: 15, poplar_planks: 15,
  oak_log: 15, birch_log: 15, spruce_log: 15, jungle_log: 15, acacia_log: 15, dark_oak_log: 15, cherry_log: 15, mangrove_log: 15, pale_oak_log: 15, poplar_log: 15,
  crafting_table: 15, chest: 15, trapped_chest: 15, barrel: 15, bookshelf: 15, lectern: 15, composter: 15, note_block: 15, jukebox: 15, ladder: 15, bow: 15, crossbow: 15, fishing_rod: 15,
  wooden_pickaxe: 10, wooden_axe: 10, wooden_shovel: 10, wooden_sword: 10, wooden_hoe: 10, bowl: 10, sign: 10, oak_door: 10, birch_door: 10, spruce_door: 10, jungle_door: 10, acacia_door: 10, dark_oak_door: 10, cherry_door: 10,
  oak_slab: 7.5, birch_slab: 7.5, spruce_slab: 7.5, jungle_slab: 7.5, acacia_slab: 7.5, dark_oak_slab: 7.5, cherry_slab: 7.5,
  stick: 5, oak_sapling: 5, birch_sapling: 5, spruce_sapling: 5, jungle_sapling: 5, acacia_sapling: 5, dark_oak_sapling: 5, cherry_sapling: 5, dead_bush: 5,
  bamboo: 2.5, scaffolding: 2.5,
};

export function recipeCounts(stacks: ( { name: string; count: number } | null )[]) {
  const counts: Record<string, number> = {};
  for (const s of stacks) if (s) counts[s.name] = (counts[s.name] || 0) + s.count;
  return counts;
}

export function canCraft(recipe: Recipe, counts: Record<string, number>, creative: boolean, workbench: boolean) {
  if (!workbench && recipe.station === 'crafting_table' && !creative) return false;
  if (creative) return true;
  return Object.entries(recipe.ingredients).every(([name, need]) => (counts[name] || 0) >= need);
}

// ===== v11 recipes: full wood sets, storage blocks, stone families, dyes, redstone parts, workstations, gear ============
import { resolve as _res, BLOCKS as _BLOCKS, ID as _ID } from '../game/data';
const R = (id: string, result: string, count: number, rows: string[], key: Record<string, string>, category = 'building') => {
  if (!_res(result) || RECIPES.some(r => r.id === id) || Object.values(key).some(v => !_res(v))) return;
  const small = rows.length <= 2 && rows.every(r => r.length <= 2);
  recipe(id, result, count, rows, key, small ? 'inventory' : 'crafting_table', category);
};
const WOODS = ['oak', 'birch', 'spruce', 'jungle', 'acacia', 'dark_oak', 'cherry', 'mangrove', 'pale_oak', 'crimson', 'warped', 'poplar'];
for (const w of WOODS) {
  const P = { P: w + '_planks' }, PS = { P: w + '_planks', S: 'stick' };
  R(w + '_stick', 'stick', 4, ['P', 'P'], P, 'materials');
  R(w + '_crafting_table', 'crafting_table', 1, ['PP', 'PP'], P, 'utility');
  R(w + '_chest', 'chest', 1, ['PPP', 'P P', 'PPP'], P, 'utility');
  R(w + '_slab', w + '_slab', 6, ['PPP'], P);
  R(w + '_stairs', w + '_stairs', 4, ['P  ', 'PP ', 'PPP'], P);
  R(w + '_fence', w + '_fence', 3, ['PSP', 'PSP'], PS);
  R(w + '_door', w + '_door', 3, ['PP', 'PP', 'PP'], P);
  R(w + '_trapdoor', w + '_trapdoor', 2, ['PPP', 'PPP'], P);
  R(w + '_pressure_plate', w + '_pressure_plate', 1, ['PP'], P, 'redstone');
  R(w + '_button', w + '_button', 1, ['P'], P, 'redstone');
  R(w + '_bowl', 'bowl', 4, ['P P', ' P '], P, 'materials');
  R(w + '_shield', 'shield', 1, ['PIP', 'PPP', ' P '], { P: w + '_planks', I: 'iron_ingot' }, 'tools');
  R(w + '_bookshelf', 'bookshelf', 1, ['PPP', 'BBB', 'PPP'], { P: w + '_planks', B: 'book' }, 'utility');
  R(w + '_sign', 'sign', 3, ['PPP', 'PPP', ' S '], PS, 'utility');
  R(w + '_boat', 'boat', 1, ['P P', 'PPP'], P, 'tools');
}
for (const [blockName, itemName] of [['coal_block', 'coal'], ['iron_block', 'iron_ingot'], ['gold_block', 'gold_ingot'], ['diamond_block', 'diamond'], ['emerald_block', 'emerald'], ['lapis_block', 'lapis_lazuli'], ['copper_block', 'copper_ingot'], ['netherite_block', 'netherite_ingot'], ['redstone_block', 'redstone'], ['hay_block', 'wheat'], ['bone_block', 'bone_meal'], ['slime_block', 'slime_ball'], ['iron_ingot', 'iron_nugget'], ['gold_ingot', 'gold_nugget'], ['melon', 'melon_slice'], ['packed_ice', 'ice'], ['prismarine_bricks', 'prismarine_shard']]) {
  R(blockName + '_pack', blockName, 1, ['XXX', 'XXX', 'XXX'], { X: itemName }, 'materials');
  if (!['melon', 'packed_ice', 'prismarine_bricks'].includes(blockName)) R(blockName + '_unpack', itemName, 9, ['X'], { X: blockName }, 'materials');
}
for (const [res, n, src] of [['polished_granite', 4, 'granite'], ['polished_diorite', 4, 'diorite'], ['polished_andesite', 4, 'andesite'], ['polished_deepslate', 4, 'cobbled_deepslate'], ['deepslate_bricks', 4, 'polished_deepslate'], ['deepslate_tiles', 4, 'deepslate_bricks'], ['polished_blackstone', 4, 'blackstone'], ['polished_blackstone_bricks', 4, 'polished_blackstone'], ['prismarine', 1, 'prismarine_shard'], ['quartz_block', 1, 'quartz'], ['quartz_bricks', 4, 'quartz_block'], ['amethyst_block', 1, 'amethyst_shard'], ['glowstone', 1, 'glowstone_dust'], ['snow_block', 1, 'snowball'], ['clay', 1, 'clay_ball'], ['bricks', 1, 'brick'], ['nether_bricks', 1, 'nether_brick'], ['magma_block', 1, 'magma_cream'], ['mud_bricks', 4, 'packed_mud'], ['cut_copper', 4, 'copper_block'], ['honey_block', 1, 'honey_bottle'], ['white_wool', 1, 'string'], ['smooth_sandstone', 4, 'cut_sandstone'], ['red_sandstone', 1, 'red_sand']] as const)
  R(res + '_2x2', res, n, ['XX', 'XX'], { X: src });
const MISC: [string, string, number, string[], Record<string, string>, string][] = [
  ['dark_prismarine', 'dark_prismarine', 1, ['XXX', 'XIX', 'XXX'], { X: 'prismarine_shard', I: 'ink_sac' }, 'building'],
  ['sea_lantern', 'sea_lantern', 1, ['SCS', 'CCC', 'SCS'], { S: 'prismarine_shard', C: 'prismarine_crystals' }, 'building'],
  ['mossy_cobblestone', 'mossy_cobblestone', 1, ['CV'], { C: 'cobblestone', V: 'vine' }, 'building'],
  ['mossy_stone_bricks', 'mossy_stone_bricks', 1, ['CV'], { C: 'stone_bricks', V: 'vine' }, 'building'],
  ['chiseled_stone_bricks', 'chiseled_stone_bricks', 1, ['S', 'S'], { S: 'stone_brick_slab' }, 'building'],
  ['coarse_dirt', 'coarse_dirt', 4, ['DG', 'GD'], { D: 'dirt', G: 'gravel' }, 'building'],
  ['packed_mud', 'packed_mud', 1, ['MW'], { M: 'mud', W: 'wheat' }, 'building'],
  ['red_nether_bricks', 'red_nether_bricks', 1, ['NW', 'WN'], { N: 'nether_brick', W: 'nether_wart' }, 'building'],
  ['snow_layer', 'snow_layer', 6, ['SSS'], { S: 'snow_block' }, 'building'],
  ['moss_carpet', 'moss_carpet', 3, ['MM'], { M: 'moss_block' }, 'building'],
  ['tinted_glass', 'tinted_glass', 2, [' A ', 'AGA', ' A '], { A: 'amethyst_shard', G: 'glass' }, 'building'],
  ['iron_door', 'iron_door', 3, ['II', 'II', 'II'], { I: 'iron_ingot' }, 'building'],
  ['chain', 'chain', 1, ['N', 'I', 'N'], { N: 'iron_nugget', I: 'iron_ingot' }, 'building'],
  ['bone_meal', 'bone_meal', 3, ['B'], { B: 'bone' }, 'materials'],
  ['sugar', 'sugar', 1, ['S'], { S: 'sugar_cane' }, 'materials'],
  ['fermented_spider_eye', 'fermented_spider_eye', 1, ['ES', 'M '], { E: 'spider_eye', S: 'sugar', M: 'brown_mushroom' }, 'materials'],
  ['glistering_melon_slice', 'glistering_melon_slice', 1, ['NNN', 'NMN', 'NNN'], { N: 'gold_nugget', M: 'melon_slice' }, 'materials'],
  ['magma_cream', 'magma_cream', 1, ['BS'], { B: 'blaze_powder', S: 'slime_ball' }, 'materials'],
  ['glass_bottle', 'glass_bottle', 3, ['G G', ' G '], { G: 'glass' }, 'materials'],
  ['netherite_upgrade', 'netherite_upgrade', 2, ['DTD', 'DND', 'DDD'], { D: 'diamond', T: 'netherite_upgrade', N: 'netherrack' }, 'materials'],
  ['golden_carrot', 'golden_carrot', 1, ['NNN', 'NCN', 'NNN'], { N: 'gold_nugget', C: 'carrot' }, 'food'],
  ['enchanted_golden_apple', 'enchanted_golden_apple', 1, ['GGG', 'GAG', 'GGG'], { G: 'gold_block', A: 'apple' }, 'food'],
  ['mushroom_stew', 'mushroom_stew', 1, ['RB', 'W '], { R: 'red_mushroom', B: 'brown_mushroom', W: 'bowl' }, 'food'],
  ['rabbit_stew', 'rabbit_stew', 1, [' R ', 'CPM', ' B '], { R: 'cooked_rabbit', C: 'carrot', P: 'baked_potato', M: 'brown_mushroom', B: 'bowl' }, 'food'],
  ['beetroot_soup', 'beetroot_soup', 1, ['BBB', 'BBB', ' W '], { B: 'beetroot', W: 'bowl' }, 'food'],
  ['pumpkin_pie', 'pumpkin_pie', 1, ['PS', 'E '], { P: 'pumpkin', S: 'sugar', E: 'egg' }, 'food'],
  ['honey_bottle', 'honey_bottle', 4, ['BB', 'BB'], { B: 'glass_bottle' }, 'food'],
  ['brewing_stand', 'brewing_stand', 1, [' B ', 'CCC'], { B: 'blaze_rod', C: 'cobblestone' }, 'utility'],
  ['cauldron', 'cauldron', 1, ['I I', 'I I', 'III'], { I: 'iron_ingot' }, 'utility'],
  ['smithing_table', 'smithing_table', 1, ['II', 'PP', 'PP'], { I: 'iron_ingot', P: 'oak_planks' }, 'utility'],
  ['cartography_table', 'cartography_table', 1, ['AA', 'PP', 'PP'], { A: 'paper', P: 'oak_planks' }, 'utility'],
  ['fletching_table', 'fletching_table', 1, ['FF', 'PP', 'PP'], { F: 'flint', P: 'oak_planks' }, 'utility'],
  ['loom', 'loom', 1, ['SS', 'PP'], { S: 'string', P: 'oak_planks' }, 'utility'],
  ['lectern', 'lectern', 1, ['SSS', ' B ', ' S '], { S: 'oak_slab', B: 'bookshelf' }, 'utility'],
  ['stonecutter', 'stonecutter', 1, [' I ', 'SSS'], { I: 'iron_ingot', S: 'stone' }, 'utility'],
  ['grindstone', 'grindstone', 1, ['TST', 'P P'], { T: 'stick', S: 'stone', P: 'oak_planks' }, 'utility'],
  ['blast_furnace', 'blast_furnace', 1, ['III', 'IFI', 'SSS'], { I: 'iron_ingot', F: 'furnace', S: 'smooth_stone' }, 'utility'],
  ['smoker', 'smoker', 1, [' L ', 'LFL', ' L '], { L: 'oak_log', F: 'furnace' }, 'utility'],
  ['anvil_blocks', 'anvil', 1, ['BBB', ' I ', 'III'], { B: 'iron_block', I: 'iron_ingot' }, 'utility'],
  ['soul_torch', 'soul_torch', 4, ['C', 'S', 'O'], { C: 'coal', S: 'stick', O: 'soul_sand' }, 'utility'],
  ['soul_lantern', 'soul_lantern', 1, ['NNN', 'NTN', 'NNN'], { N: 'iron_nugget', T: 'soul_torch' }, 'utility'],
  ['painting', 'painting', 1, ['SSS', 'SWS', 'SSS'], { S: 'stick', W: 'white_wool' }, 'utility'],
  ['item_frame', 'item_frame', 1, ['SSS', 'SLS', 'SSS'], { S: 'stick', L: 'leather' }, 'utility'],
  ['crossbow', 'crossbow', 1, ['SIS', 'TST', ' S '], { S: 'stick', I: 'iron_ingot', T: 'string' }, 'tools'],
  ['mace', 'mace', 1, ['H', 'B'], { H: 'heavy_core', B: 'breeze_rod' }, 'tools'],
  ['turtle_helmet', 'turtle_helmet', 1, ['SSS', 'S S'], { S: 'scute' }, 'tools'],
  ['spectral_arrow', 'spectral_arrow', 2, [' G ', 'GAG', ' G '], { G: 'glowstone_dust', A: 'arrow' }, 'tools'],
  ['fishing_rod', 'fishing_rod', 1, ['  S', ' ST', 'S T'], { S: 'stick', T: 'string' }, 'tools'],
  ['spyglass', 'spyglass', 1, ['A', 'C', 'C'], { A: 'amethyst_shard', C: 'copper_ingot' }, 'tools'],
  ['lead', 'lead', 2, ['SS ', 'SB ', '  S'], { S: 'string', B: 'slime_ball' }, 'tools'],
  ['map', 'map', 1, ['PPP', 'PCP', 'PPP'], { P: 'paper', C: 'compass' }, 'tools'],
  ['writable_book', 'writable_book', 1, ['BI', 'F '], { B: 'book', I: 'ink_sac', F: 'feather' }, 'tools'],
  ['minecart', 'minecart', 1, ['I I', 'III'], { I: 'iron_ingot' }, 'tools'],
  ['repeater', 'repeater', 1, ['TRT', 'SSS'], { T: 'redstone_torch', R: 'redstone', S: 'stone' }, 'redstone'],
  ['comparator', 'comparator', 1, [' T ', 'TQT', 'SSS'], { T: 'redstone_torch', Q: 'quartz', S: 'stone' }, 'redstone'],
  ['redstone_torch', 'redstone_torch', 1, ['R', 'S'], { R: 'redstone', S: 'stick' }, 'redstone'],
  ['observer', 'observer', 1, ['CCC', 'RRQ', 'CCC'], { C: 'cobblestone', R: 'redstone', Q: 'quartz' }, 'redstone'],
  ['hopper', 'hopper', 1, ['I I', 'ICI', ' I '], { I: 'iron_ingot', C: 'chest' }, 'redstone'],
  ['dropper', 'dropper', 1, ['CCC', 'C C', 'CRC'], { C: 'cobblestone', R: 'redstone' }, 'redstone'],
  ['dispenser', 'dispenser', 1, ['CCC', 'CBC', 'CRC'], { C: 'cobblestone', B: 'bow', R: 'redstone' }, 'redstone'],
  ['rail', 'rail', 16, ['I I', 'ISI', 'I I'], { I: 'iron_ingot', S: 'stick' }, 'redstone'],
  ['powered_rail', 'powered_rail', 6, ['G G', 'GSG', 'GRG'], { G: 'gold_ingot', S: 'stick', R: 'redstone' }, 'redstone'],
  ['daylight_detector', 'daylight_detector', 1, ['GGG', 'QQQ', 'SSS'], { G: 'glass', Q: 'quartz', S: 'oak_slab' }, 'redstone'],
  ['target', 'target', 1, [' R ', 'RHR', ' R '], { R: 'redstone', H: 'hay_block' }, 'redstone'],
];
for (const [id, result, count, rows, key, cat] of MISC) R(id, result, count, rows, key, cat);
const ARMOR_ROWS: Record<string, string[]> = { helmet: ['MMM', 'M M'], chestplate: ['M M', 'MMM', 'MMM'], leggings: ['MMM', 'M M', 'M M'], boots: ['M M', 'M M'] };
for (const [tier, mat] of [['leather', 'leather'], ['copper', 'copper_ingot']]) for (const [type, rows] of Object.entries(ARMOR_ROWS)) R(tier + '_' + type, tier + '_' + type, 1, rows, { M: mat }, 'tools');
{
  const k = { M: 'copper_ingot', S: 'stick' };
  R('copper_pickaxe', 'copper_pickaxe', 1, ['MMM', ' S ', ' S '], k, 'tools'); R('copper_axe', 'copper_axe', 1, ['MM', 'MS', ' S'], k, 'tools');
  R('copper_shovel', 'copper_shovel', 1, ['M', 'S', 'S'], k, 'tools'); R('copper_sword', 'copper_sword', 1, ['M', 'M', 'S'], k, 'tools'); R('copper_hoe', 'copper_hoe', 1, ['MM', ' S', ' S'], k, 'tools');
}
const DYE_SRC: Record<string, string[]> = { red: ['poppy', 'beetroot'], yellow: ['dandelion', 'torchflower'], blue: ['cornflower', 'lapis_lazuli'], light_blue: ['blue_orchid'], white: ['bone_meal', 'lily_of_the_valley'], orange: ['orange_tulip'], pink: ['pink_tulip', 'pink_petals'], light_gray: ['azure_bluet', 'oxeye_daisy', 'white_tulip'], magenta: ['allium'], black: ['ink_sac'], brown: ['cocoa_beans'], cyan: ['pitcher_plant'] };
for (const [color, list] of Object.entries(DYE_SRC)) for (const src of list) R(color + '_dye_from_' + src, color + '_dye', 1, ['X'], { X: src }, 'materials');
for (const [out, a, b] of [['orange', 'red', 'yellow'], ['purple', 'red', 'blue'], ['cyan', 'blue', 'green'], ['gray', 'black', 'white'], ['light_gray', 'gray', 'white'], ['pink', 'red', 'white'], ['lime', 'green', 'white'], ['light_blue', 'blue', 'white'], ['magenta', 'purple', 'pink']]) R(out + '_dye_mix', out + '_dye', 2, ['AB'], { A: a + '_dye', B: b + '_dye' }, 'materials');
for (const color of Object.keys(DYES)) {
  const D = color + '_dye';
  if (color !== 'white') R(color + '_wool_dye', color + '_wool', 1, ['WD'], { W: 'white_wool', D }, 'decorations');
  R(color + '_carpet', color + '_carpet', 3, ['WW'], { W: color + '_wool' }, 'decorations');
  R(color + '_stained_glass', color + '_stained_glass', 8, ['GGG', 'GDG', 'GGG'], { G: 'glass', D });
  R(color + '_terracotta', color + '_terracotta', 8, ['TTT', 'TDT', 'TTT'], { T: 'terracotta', D });
  R(color + '_concrete', color + '_concrete', 8, ['SGS', 'GDG', 'SGS'], { S: 'sand', G: 'gravel', D });
  R(color + '_banner', color + '_banner', 1, ['WWW', 'WWW', ' S '], { W: color + '_wool', S: 'stick' }, 'decorations');
}

/** Stonecutter: one input block → a choice of outputs (no waste, like vanilla). */
export const STONECUT: Record<string, { result: string; count: number }[]> = {};
const cut = (from: string, result: string, count = 1) => {
  if (_ID[from] === undefined || _ID[result] === undefined || from === result) return;
  const list = (STONECUT[from] ??= []);
  if (!list.some(o => o.result === result)) list.push({ result, count });
};
for (const b of [..._BLOCKS]) {
  const m = /^(.*)_(stairs|slab|wall)$/.exec(b.name);
  if (!m || b.tool !== 'pickaxe') continue;
  const base = [m[1], m[1] + 's', m[1] + '_block'].find(n => _ID[n] !== undefined && n !== b.name);
  if (!base) continue;
  if (m[2] === 'stairs') R(b.name, b.name, 4, ['M  ', 'MM ', 'MMM'], { M: base });
  else if (m[2] === 'slab') R(b.name, b.name, 6, ['MMM'], { M: base });
  else R(b.name, b.name, 6, ['MMM', 'MMM'], { M: base });
  cut(base, b.name, m[2] === 'slab' ? 2 : 1);
}
for (const [from, ...outs] of [['stone', 'stone_bricks', 'chiseled_stone_bricks'], ['stone_bricks', 'chiseled_stone_bricks'], ['granite', 'polished_granite'], ['diorite', 'polished_diorite'], ['andesite', 'polished_andesite'], ['cobbled_deepslate', 'polished_deepslate', 'deepslate_bricks', 'deepslate_tiles', 'chiseled_deepslate'], ['polished_deepslate', 'deepslate_bricks', 'deepslate_tiles'], ['deepslate_bricks', 'deepslate_tiles'], ['blackstone', 'polished_blackstone', 'polished_blackstone_bricks', 'chiseled_polished_blackstone'], ['polished_blackstone', 'polished_blackstone_bricks', 'chiseled_polished_blackstone'], ['sandstone', 'cut_sandstone', 'chiseled_sandstone'], ['quartz_block', 'quartz_bricks'], ['prismarine', 'prismarine_bricks'], ['end_stone', 'end_stone_bricks'], ['copper_block', 'cut_copper'], ['purpur_block', 'purpur_pillar'], ['basalt', 'smooth_basalt']]) for (const o of outs) cut(from, o, o === 'cut_copper' ? 4 : 1);
for (const [from, via] of [['stone', 'stone_bricks'], ['end_stone', 'end_stone_bricks'], ['quartz_block', 'quartz_bricks']]) for (const o of STONECUT[via] ?? []) cut(from, o.result, o.count);

/** Smithing table: template + base gear + material. Enchantments and wear carry over to the result. */
export const SMITHING: { template: string; base: string; addition: string; result: string }[] = [];
for (const type of ['sword', 'pickaxe', 'axe', 'shovel', 'hoe', 'helmet', 'chestplate', 'leggings', 'boots']) if (_res('netherite_' + type) && _res('diamond_' + type)) SMITHING.push({ template: 'netherite_upgrade', base: 'diamond_' + type, addition: 'netherite_ingot', result: 'netherite_' + type });
for (let i = RECIPES.length - 1; i >= 0; i--) if (/^netherite_(pickaxe|axe|shovel|sword|helmet|chestplate|leggings|boots)$/.test(RECIPES[i].id)) RECIPES.splice(i, 1);

const smelt = (from: string, result: string, time = 10) => { if (_res(from) && _res(result) && !SMELTING[from]) SMELTING[from] = { result, time }; };
const ORE_OUT: Record<string, string> = { coal: 'coal', iron: 'iron_ingot', copper: 'copper_ingot', gold: 'gold_ingot', diamond: 'diamond', emerald: 'emerald', lapis: 'lapis_lazuli', redstone: 'redstone' };
for (const [o, out] of Object.entries(ORE_OUT)) for (const p of ['', 'deepslate_']) smelt(p + o + '_ore', out);
for (const [a, b] of [['raw_copper', 'copper_ingot'], ['nether_quartz_ore', 'quartz'], ['clay_ball', 'brick'], ['clay', 'terracotta'], ['stone', 'smooth_stone'], ['sandstone', 'smooth_sandstone'], ['cobbled_deepslate', 'deepslate'], ['kelp', 'dried_kelp'], ['cactus', 'green_dye'], ['wet_sponge', 'sponge'], ['rabbit', 'cooked_rabbit'], ['stone_bricks', 'cracked_stone_bricks'], ['quartz_block', 'smooth_quartz'], ['basalt', 'smooth_basalt'], ['sea_pickle', 'lime_dye'], ['nether_bricks', 'cracked_nether_bricks']] as const) smelt(a, b, 10);
for (const w of WOODS) { smelt(w + '_log', 'charcoal'); for (const s of ['_planks', '_log', '_slab', '_stairs', '_fence', '_door', '_trapdoor', '_pressure_plate', '_button']) if (_res(w + s) && !FUEL[w + s]) FUEL[w + s] = s === '_button' ? 5 : s === '_slab' ? 7.5 : s === '_door' ? 10 : 15; }
Object.assign(FUEL, { coal_block: 800, bookshelf: 15, bowl: 5, bamboo: 2.5, ladder: 15, barrel: 15, loom: 15, lectern: 15, smithing_table: 15, cartography_table: 15, fletching_table: 15, dried_kelp: 10, ...FUEL });

// ===== record 014: farming, vehicles, redstone additions ==============================================================
R('copper_bulb', 'copper_bulb', 4, [' C ', 'CBC', ' R '], { C: 'copper_block', B: 'blaze_rod', R: 'redstone' }, 'redstone');
R('copper_bulb_ingot', 'copper_bulb', 4, [' C ', 'CBC', ' R '], { C: 'copper_ingot', B: 'blaze_rod', R: 'redstone' }, 'redstone');
R('crafter', 'crafter', 1, ['III', 'ICI', 'RDR'], { I: 'iron_ingot', C: 'crafting_table', R: 'redstone', D: 'dropper' }, 'redstone');
R('crafter_alt', 'crafter', 1, ['III', 'IDI', 'RCR'], { I: 'iron_ingot', D: 'dropper', R: 'redstone', C: 'crafting_table' }, 'redstone');
R('composter', 'composter', 1, ['S S', 'S S', 'SSS'], { S: 'oak_slab' }, 'utility');
R('bell', 'bell', 1, [' S ', 'GGG', 'GGG'], { S: 'stick', G: 'gold_ingot' }, 'utility');
R('carrot_on_a_stick', 'carrot_on_a_stick', 1, ['F ', ' C'], { F: 'fishing_rod', C: 'carrot' }, 'tools');
R('warped_fungus_on_a_stick', 'warped_fungus_on_a_stick', 1, ['F ', ' W'], { F: 'fishing_rod', W: 'warped_fungus' }, 'tools');
R('beetroot_seeds_to_dye', 'red_dye', 1, ['B'], { B: 'beetroot' }, 'materials');
R('pumpkin_seeds', 'pumpkin_seeds', 4, ['P'], { P: 'pumpkin_block' }, 'materials');
R('pumpkin_seeds_vanilla', 'pumpkin_seeds', 4, ['P'], { P: 'pumpkin' }, 'materials');
R('melon_seeds', 'melon_seeds', 1, ['M'], { M: 'melon_slice' }, 'materials');
R('melon_block', 'melon_block', 1, ['MMM', 'MMM', 'MMM'], { M: 'melon_slice' }, 'building');
R('inverted_daylight_detector_recipe', 'daylight_detector', 1, ['GGG', 'QQQ', 'SSS'], { G: 'glass', Q: 'quartz', S: 'oak_slab' }, 'redstone');
R('detector_rail', 'detector_rail', 6, ['I I', 'IPI', 'IRI'], { I: 'iron_ingot', P: 'stone_pressure_plate', R: 'redstone' }, 'redstone');
R('activator_rail', 'activator_rail', 6, ['ISI', 'ITI', 'ISI'], { I: 'iron_ingot', S: 'stick', T: 'redstone_torch' }, 'redstone');
R('lead', 'lead', 2, ['SS ', 'SB ', '  S'], { S: 'string', B: 'slime_ball' }, 'tools');
R('saddle', 'saddle', 1, [' L ', 'LIL'], { L: 'leather', I: 'iron_ingot' }, 'tools');
R('minecart', 'minecart', 1, ['I I', 'III'], { I: 'iron_ingot' }, 'tools');
R('hay_block', 'hay_block', 1, ['WWW', 'WWW', 'WWW'], { W: 'wheat' }, 'building');
smelt('chicken', 'cooked_chicken');
R('cake', 'cake', 1, ['MMM', 'SES', 'WWW'], { M: 'milk_bucket', S: 'sugar', E: 'egg', W: 'wheat' }, 'food');
R('campfire', 'campfire', 1, [' S ', 'SCS', 'LLL'], { S: 'stick', C: 'coal', L: 'oak_log' }, 'utility');
R('dried_kelp_block', 'dried_kelp_block', 1, ['KKK', 'KKK', 'KKK'], { K: 'kelp' }, 'building');
R('quartz_pillar', 'quartz_pillar', 2, ['Q', 'Q'], { Q: 'quartz_block' }, 'building');

// ===== Record 016: minecart variants, scaffolding, tripwire hook, ender chest, chiseled bookshelf, calibrated sculk sensor, soul campfire =====
R('chest_minecart', 'chest_minecart', 1, ['C', 'M'], { C: 'chest', M: 'minecart' }, 'tools');
R('hopper_minecart', 'hopper_minecart', 1, ['H', 'M'], { H: 'hopper', M: 'minecart' }, 'tools');
R('tnt_minecart', 'tnt_minecart', 1, ['T', 'M'], { T: 'tnt', M: 'minecart' }, 'tools');
R('furnace_minecart', 'furnace_minecart', 1, ['F', 'M'], { F: 'furnace', M: 'minecart' }, 'tools');
R('scaffolding', 'scaffolding', 6, ['BSB', 'B B', 'B B'], { B: 'bamboo', S: 'string' }, 'utility');
R('tripwire_hook', 'tripwire_hook', 2, ['I', 'S', 'P'], { I: 'iron_ingot', S: 'stick', P: 'oak_planks' }, 'redstone');
R('ender_chest', 'ender_chest', 1, ['OOO', 'OEO', 'OOO'], { O: 'obsidian', E: 'ender_eye' }, 'utility');
R('chiseled_bookshelf', 'chiseled_bookshelf', 1, ['PPP', 'SSS', 'PPP'], { P: 'oak_planks', S: 'oak_slab' }, 'redstone');
R('calibrated_sculk_sensor', 'calibrated_sculk_sensor', 1, [' A ', 'ASA'], { A: 'amethyst_shard', S: 'sculk_sensor' }, 'redstone');
R('soul_campfire', 'soul_campfire', 1, [' S ', 'SOS', 'LLL'], { S: 'stick', O: 'soul_sand', L: 'oak_log' }, 'utility');

// ===== Graphics & UI additions: Beacon, Brush, Decorated Pot, Signs, Hanging Signs, Armor Trim duplication ============
R('beacon', 'beacon', 1, ['GGG', 'GSG', 'OOO'], { G: 'glass', S: 'nether_star', O: 'obsidian' }, 'utility');
R('brush', 'brush', 1, ['F', 'C', 'S'], { F: 'feather', C: 'copper_ingot', S: 'stick' }, 'tools');
R('decorated_pot_bricks', 'decorated_pot', 1, [' B ', 'B B', ' B '], { B: 'brick' }, 'decorations');
R('oak_sign_recipe', 'oak_sign', 3, ['PPP', 'PPP', ' S '], { P: 'oak_planks', S: 'stick' }, 'utility');
R('spruce_sign_recipe', 'spruce_sign', 3, ['PPP', 'PPP', ' S '], { P: 'spruce_planks', S: 'stick' }, 'utility');
R('oak_hanging_sign', 'oak_hanging_sign', 6, ['C C', 'LLL', 'LLL'], { C: 'chain', L: 'oak_log' }, 'utility');
R('spruce_hanging_sign', 'spruce_hanging_sign', 6, ['C C', 'LLL', 'LLL'], { C: 'chain', L: 'spruce_log' }, 'utility');
for (const tp of TRIM_PATTERNS) {
  const tmpl = `${tp.id}_armor_trim_smithing_template`;
  R(`dup_${tp.id}_trim`, tmpl, 2, ['DTD', 'DBD', 'DDD'], { D: 'diamond', T: tmpl, B: tp.baseBlock }, 'materials');
}

// 1.21 / archaeology / trims: template duplication (`copy_<template>`), brush, wolf armor, beacon, conduit, tuff & copper variants.
import { registerRecipes121 } from './smithing';
registerRecipes121(recipe, id => RECIPES.some(r => r.id === id));

/** Applies a Banner's base color and layered patterns onto a Shield (Java Edition crafting table / inventory combination). */
export function applyBannerToShield(shield: Stack, banner: Stack): Stack | null {
  if (shield.name !== 'shield' || !banner.name.endsWith('_banner')) return null;
  const base = banner.name.replace(/_banner$/, '');
  return {
    ...shield,
    count: 1,
    bannerBase: base,
    patterns: banner.patterns ? banner.patterns.map(l => ({ ...l })) : undefined,
  };
}

type Grid = (string | null)[][];
let recipeGrids: { grid: Grid; mirror: Grid; result: string; count: number }[] | null = null;
export function trimGrid(g: Grid): Grid {
  let rows = g.map(r => [...r]);
  while (rows.length && rows[0].every(c => !c)) rows.shift();
  while (rows.length && rows[rows.length - 1].every(c => !c)) rows.pop();
  if (!rows.length) return [];
  const w = Math.max(...rows.map(r => r.length));
  rows = rows.map(r => { const o = [...r]; while (o.length < w) o.push(null); return o; });
  let l = 0, r = w - 1;
  while (l < w && rows.every(row => !row[l])) l++;
  while (r > l && rows.every(row => !row[r])) r--;
  return rows.map(row => row.slice(l, r + 1).map(c => c ?? null));
}
const sameGrid = (a: Grid, b: Grid) => a.length === b.length && a.every((r, i) => r.length === b[i].length && r.every((c, j) => (c ?? null) === (b[i][j] ?? null)));
export function matchGrid(names: (string | null)[], disabled = 0): { result: string; count: number } | null {
  recipeGrids ??= RECIPES.map(r => { const grid = trimGrid(r.grid); return { grid, mirror: grid.map(row => [...row].reverse()), result: r.result, count: r.count }; });
  const masked = names.slice(0, 9).map((n, i) => (disabled & (1 << i)) ? null : n);
  const g = trimGrid([masked.slice(0, 3), masked.slice(3, 6), masked.slice(6, 9)]);
  if (!g.length) return null;
  for (const r of recipeGrids) if (sameGrid(g, r.grid) || sameGrid(g, r.mirror)) return { result: r.result, count: r.count };
  return null;
}

// ---- Java parity additions: jukebox and the craftable banner patterns ---------------------------------------------------------
import { ID as BLOCK_IDS, ITEM_ID as ITEM_IDS } from '../game/data';
for (const [result, rows, keys, category] of [
  ['jukebox', ['PPP', 'PDP', 'PPP'], { P: 'oak_planks', D: 'diamond' }, 'utility'],
  ['lightning_rod', ['C', 'C', 'C'], { C: 'copper_ingot' }, 'redstone'],
  ['respawn_anchor', ['CCC', 'GGG', 'CCC'], { C: 'crying_obsidian', G: 'glowstone' }, 'utility'],
  ['lodestone', ['SSS', 'SNS', 'SSS'], { S: 'stone_bricks', N: 'netherite_ingot' }, 'utility'],
  ['spyglass', ['A', 'C', 'C'], { A: 'amethyst_shard', C: 'copper_ingot' }, 'tools'],
  ['bundle', ['S', 'L'], { S: 'string', L: 'leather' }, 'tools'],
  ['trapped_chest', ['CT'], { C: 'chest', T: 'tripwire_hook' }, 'redstone'],
  ['suspicious_stew', ['RM', 'BF'], { R: 'red_mushroom', M: 'brown_mushroom', B: 'bowl', F: 'dandelion' }, 'food'],
  ['glass_bottle', ['G G', ' G '], { G: 'glass' }, 'materials'],
  ['flower_banner_pattern', ['PF'], { P: 'paper', F: 'oxeye_daisy' }, 'materials'],
  ['creeper_banner_pattern', ['PF'], { P: 'paper', F: 'creeper_head' }, 'materials'],
  ['skull_banner_pattern', ['PF'], { P: 'paper', F: 'wither_skeleton_skull' }, 'materials'],
  ['mojang_banner_pattern', ['PF'], { P: 'paper', F: 'enchanted_golden_apple' }, 'materials'],
] as [string, string[], Record<string, string>, string][]) {
  const known = (n: string) => BLOCK_IDS[n] !== undefined || ITEM_IDS[n] !== undefined;
  if (known(result) && Object.values(keys).every(known) && !RECIPES.some(r => r.result === result)) recipe(result, result, 1, rows, keys, 'crafting_table', category);
}
