// 1.21 combat maths: the mace and its three enchantments (Density, Breach, Wind Burst), mob armor, and the constants of the four
// new status effects (Wind Charged, Infested, Oozing, Weaving). Pure functions only, shared by survival.ts, the mob manager and tests.

// ---- Mace --------------------------------------------------------------------------------------------------------------
/** Extra smash damage for a fall of `fall` blocks: +4 for each of the first 3, +2 for the next 5, +1 for every block after. */
export const maceSmashBonus = (fall: number) => Math.min(fall, 3) * 4 + Math.min(Math.max(fall - 3, 0), 5) * 2 + Math.max(0, fall - 8);
/** Density: +0.5 damage per level for every block fallen. */
export const densityBonus = (level: number, fall: number) => 0.5 * Math.max(0, level) * Math.max(0, fall);
export const SMASH_MIN_FALL = 1.5;
export const smashDamage = (fall: number, density = 0) => (fall > SMASH_MIN_FALL ? maceSmashBonus(fall) + densityBonus(density, fall) : 0);

/** Breach: each level ignores 15 % of the target's armor. */
export const BREACH_PER_LEVEL = 0.15;
export const breachFactor = (level: number) => Math.max(0, 1 - BREACH_PER_LEVEL * Math.max(0, level));
/** Vanilla armor formula → fraction of the damage that gets through. */
export function armorMultiplier(damage: number, armor: number, toughness = 0) {
  const a = Math.min(20, Math.max(armor / 5, armor - (4 * damage) / (toughness + 8)));
  return 1 - a / 25;
}
export function damageAfterArmor(damage: number, armor: number, breachLevel = 0, toughness = 0) {
  const effective = armor * breachFactor(breachLevel);
  return effective <= 0 ? damage : damage * armorMultiplier(damage, effective, toughness);
}
/** Natural armor points of mobs (vanilla values); trial-spawner mobs from an ominous spawner get `OMINOUS_ARMOR` on top. */
export const MOB_ARMOR: Record<string, number> = {
  zombie: 2, husk: 2, drowned: 2, zombie_villager: 2, zombified_piglin: 2, zoglin: 0, wither: 4, shulker: 20, magma_cube: 6,
  wither_skeleton: 4, piglin_brute: 4, iron_golem: 6, armadillo: 4, turtle: 6, ravager: 4, elder_guardian: 4, warden: 6, horse: 0,
};
export const OMINOUS_ARMOR = 8;
export const mobArmor = (species: string, bonus = 0) => (MOB_ARMOR[species] ?? 0) + bonus;

/** Wind Burst: a landed smash launches the attacker ~7 blocks per level and blows nearby mobs away. */
export const PLAYER_GRAVITY = 24;
export const WIND_BURST_HEIGHT = 7;
export const WIND_BURST_RADIUS = 3.5;
export const windBurstVelocity = (level: number, gravity = PLAYER_GRAVITY) => (level > 0 ? Math.sqrt(2 * gravity * WIND_BURST_HEIGHT * level) : 0);
/** Displacement applied to something at (tx,ty,tz) by a wind burst at (cx,cy,cz); null when out of range. */
export function windKnockback(cx: number, cy: number, cz: number, tx: number, ty: number, tz: number, radius = WIND_BURST_RADIUS, power = 1): [number, number, number] | null {
  const dx = tx - cx, dy = ty - cy, dz = tz - cz, d = Math.hypot(dx, dy, dz);
  if (d > radius) return null;
  const f = (1 - d / radius) * 2.2 * power + 0.6 * power, h = Math.hypot(dx, dz) || 1;
  return [(dx / h) * f, 0.5 * f, (dz / h) * f];
}

// ---- Status effects ----------------------------------------------------------------------------------------------------
export const EFFECTS_121 = ['wind_charged', 'infested', 'oozing', 'weaving'] as const;
export type Effect121 = (typeof EFFECTS_121)[number];
/** Infested: 10 % chance per hit to release 1–2 silverfish. */
export const INFESTED_CHANCE = 0.1;
export const infestedCount = (rng: () => number) => 1 + (rng() < 0.5 ? 1 : 0);
/** Oozing: two slimes on death. */
export const OOZING_SLIMES = 2;
/** Weaving: 2–3 cobwebs on death, and the holder ignores the cobweb movement penalty. */
export const weavingCount = (rng: () => number) => 2 + Math.floor(rng() * 2);
export const COBWEB_SLOW = 0.15;
export const cobwebSpeedFactor = (inWeb: boolean, weaving: boolean) => (!inWeb || weaving ? 1 : COBWEB_SLOW);
export const WIND_CHARGED_RADIUS = 3;

/** Picks up to `count` free cells around (x,y,z) (the cell itself first, then a shuffled 3×3×2 neighbourhood) for cobwebs. */
export function cobwebSpots(isFree: (x: number, y: number, z: number) => boolean, x: number, y: number, z: number, count: number, rng: () => number): [number, number, number][] {
  const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z), cells: [number, number, number][] = [];
  for (let dy = 0; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) if (dx || dy || dz) cells.push([bx + dx, by + dy, bz + dz]);
  for (let i = cells.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [cells[i], cells[j]] = [cells[j], cells[i]]; }
  cells.unshift([bx, by, bz]);
  const out: [number, number, number][] = [];
  for (const c of cells) { if (out.length >= count) break; if (isFree(c[0], c[1], c[2])) out.push(c); }
  return out;
}

// ---- Charged creepers ---------------------------------------------------------------------------------------------------
export const CREEPER_RADIUS = 3;
export const CHARGED_POWER = 2;
export const creeperRadius = (charged: boolean) => CREEPER_RADIUS * (charged ? CHARGED_POWER : 1);
/** Explosion damage at distance `d` from a blast of radius `r` (same falloff the engine uses for the player). */
export const explosionDamage = (r: number, d: number) => (d < r * 2 ? Math.ceil((r * 2 - d) * 2) : 0);
export const MOB_HEADS: Record<string, string> = { zombie: 'zombie_head', skeleton: 'skeleton_skull', creeper: 'creeper_head', wither_skeleton: 'wither_skeleton_skull', piglin: 'piglin_head' };
export const LIGHTNING_CHARGE_RADIUS = 4;
