// Dynamic fluid simulation following Minecraft Java Edition's FlowingFluid / WaterFluid / LavaFluid rules.
//
// Cell state (4 bits): bits 0-2 = distance from the source (0 = source block, water 1..7, overworld lava 2/4/6), bit 3 = falling.
// A flowing cell's "amount" is 8 - distance (falling fluid counts as 8).
//   * Water: tick delay 5 ticks, drop-off 1 (reaches 7 blocks), slope find distance 4, two adjacent sources over a solid floor or a
//     source create a new source (game rule waterSourceConversion).
//   * Lava : tick delay 30 ticks (10 in the Nether), drop-off 2 (3 blocks; 1 / 7 blocks in the Nether), slope find distance 2
//     (4 in the Nether), no infinite lava unless lavaSourceConversion is on, and a flow whose level is RISING waits 4x as long
//     three times out of four (LavaFluid.getSpreadDelay) — the reason lava creeps and lingers.
//   * Fluids fall straight down first. A cell with a hole below only spreads sideways when it is a source with >= 3 source
//     neighbours; otherwise sideways spreading needs a source or a floor. Sideways flow prefers the direction(s) of the nearest
//     drop within the slope find distance (FlowingFluid.getSpread / getSlopeDistance) — the wiki's "up to 5 blocks away for water,
//     3 for lava" counts the starting block.
//   * Waterlogging (SimpleWaterloggedBlock): a waterlogged slab / stairs / fence … IS a water source. It feeds its neighbours through
//     its non-full sides only, counts towards the two-source rule, and a dry waterloggable block that has two water sources beside
//     it over a solid floor becomes waterlogged itself. Flowing water never enters a waterloggable block.
//   * Lava touching water (above or beside it, including waterlogged blocks) becomes obsidian (source) or cobblestone (flowing);
//     lava flowing down into water makes stone; lava above soul soil next to blue ice makes basalt.
import { BLOCKS, ID } from '../game/data';

export interface FluidHost {
  getCell(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
  dimension?(): string;
  sound?(kind: string, p?: { x: number; y: number; z: number }): void;
  /** Waterlogging hooks — all optional; without them the simulation behaves as if nothing could be waterlogged. */
  isWaterlogged?(x: number, y: number, z: number): boolean;
  /** Can the block in this cell hold a water source (slab, stairs, fence, chest …)? */
  waterloggable?(x: number, y: number, z: number): boolean;
  setWaterlogged?(x: number, y: number, z: number, on: boolean): boolean;
  /** Faces through which the block in this cell lets water out: bits 0-3 = +x, -x, +z, -z, bit 4 = down. Default: all five. */
  waterlogOpen?(x: number, y: number, z: number): number;
  /** Game rules (defaults: water true, lava false). */
  waterSourceConversion?(): boolean;
  lavaSourceConversion?(): boolean;
}

const DIRS: readonly [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const NEIGHBORS: readonly [number, number, number][] = [[0, 0, 0], [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
export const WL_OPEN_ALL = 31, WL_OPEN_SIDES = 15, WL_OPEN_DOWN = 16;

export function isFluid(id: number): boolean { return id === ID.water || id === ID.lava; }

/** Blocks a fluid simply washes away when it flows into them (plants, torches, snow layers, wire ...). */
export function isReplaceable(id: number): boolean {
  if (id === 0) return true;
  const d = BLOCKS[id];
  if (!d || d.solid) return false;
  return d.shape === 'cross' || d.name === 'snow_layer' || d.name === 'torch' || d.name === 'redstone_wire' || d.name === 'fire' || d.name === 'lily_pad';
}

export class Fluids {
  private due = new Map<number, { x: number; y: number; z: number; t: number }>();
  private time = 0;
  private reacting = 0;
  /** Number of fluid cells changed since creation (diagnostics / tests). */
  changes = 0;

  constructor(private host: FluidHost, private rnd: () => number = Math.random) {}

  private nether() { return this.host.dimension?.() === 'nether'; }
  /** Unique integer key (< 2^52 for |x|,|z| < 1,048,576 so doubles stay exact). */
  private key(x: number, y: number, z: number) { return ((x + 1048576) * 2097152 + (z + 1048576)) * 512 + (y + 64); }
  /** Seconds between flow ticks: water 5 ticks, lava 30 ticks (10 in the Nether). */
  delay(id: number) { return id === ID.water ? 0.25 : this.nether() ? 0.5 : 1.5; }
  /** Level lost per block travelled. */
  drop(id: number) { return id === ID.water ? 1 : this.nether() ? 1 : 2; }
  /** FlowingFluid.getSlopeFindDistance */
  slope(id: number) { return id === ID.water ? 4 : this.nether() ? 4 : 2; }
  private wl(x: number, y: number, z: number) { return this.host.isWaterlogged?.(x, y, z) === true; }
  private wlOpen(x: number, y: number, z: number) { return this.host.waterlogOpen?.(x, y, z) ?? WL_OPEN_ALL; }

  get pending() { return this.due.size; }
  clear() { this.due.clear(); }

  schedule(x: number, y: number, z: number, delay?: number) {
    const k = this.key(x, y, z);
    if (this.due.has(k) || this.due.size > 40000) return;
    const cell = this.host.getCell(x, y, z);
    if (cell < 0) return;
    let id = cell & 4095;
    if (!isFluid(id)) { if (!this.wl(x, y, z)) return; id = ID.water; }
    this.due.set(k, { x, y, z, t: this.time + (delay ?? this.delay(id)) });
  }

  /** Call after any block change: fluids in / next to the changed cell wake up and lava reacts with water immediately. */
  onBlockChanged(x: number, y: number, z: number) {
    for (const [dx, dy, dz] of NEIGHBORS) {
      const nx = x + dx, ny = y + dy, nz = z + dz, cell = this.host.getCell(nx, ny, nz);
      if (cell < 0) continue;
      const id = cell & 4095;
      if (!isFluid(id)) { if (this.wl(nx, ny, nz)) this.schedule(nx, ny, nz); continue; }
      if (id === ID.lava && this.reacting < 8) { this.reacting++; try { if (this.lavaReact(nx, ny, nz, cell)) continue; } finally { this.reacting--; } }
      this.schedule(nx, ny, nz);
    }
  }

  update(dt: number, budgetMs = 3, maxCells = 200) {
    this.time += dt;
    if (!this.due.size) return;
    const start = performance.now();
    let n = 0;
    for (const [k, e] of this.due) {
      if (e.t > this.time) continue;
      this.due.delete(k);
      this.tick(e.x, e.y, e.z);
      if (++n >= maxCells || performance.now() - start > budgetMs) break;
    }
  }

  // ---------------------------------------------------------------------------------------------------------- core
  /** Vanilla canPassThrough: air / replaceable blocks and *flowing* cells of the same fluid, but never a source of it. */
  private passable(cell: number, id: number) {
    if (cell < 0) return false;
    const cid = cell & 4095;
    return isReplaceable(cid) || (cid === id && ((cell >>> 12) & 15) !== 0);
  }

  /** Replace-or-react placement of `id` at a target cell that is air / replaceable. */
  private place(x: number, y: number, z: number, id: number, state: number) {
    this.changes++;
    this.host.setBlock(x, y, z, id, state);
  }

  /** Is the horizontal neighbour `i` (index into DIRS) of (x, y, z) a source of `id` that is open towards us? */
  private sourceNeighbor(id: number, x: number, y: number, z: number, i: number): boolean {
    const nx = x + DIRS[i][0], nz = z + DIRS[i][1], c = this.host.getCell(nx, y, nz);
    if (c < 0) return false;
    if ((c & 4095) === id) return ((c >>> 12) & 15) === 0;
    // A waterlogged block is a water source, but only through its non-full sides (i ^ 1 = the face looking back at us).
    return id === ID.water && this.wl(nx, y, nz) && ((this.wlOpen(nx, y, nz) >> (i ^ 1)) & 1) === 1;
  }
  /** FlowingFluid.sourceNeighborCount */
  sourceNeighbors(id: number, x: number, y: number, z: number): number {
    let n = 0;
    for (let i = 0; i < 4; i++) if (this.sourceNeighbor(id, x, y, z, i)) n++;
    return n;
  }
  private canConvert(id: number) { return id === ID.water ? this.host.waterSourceConversion?.() !== false : this.host.lavaSourceConversion?.() === true; }

  /** Vanilla getNewLiquid: the state this cell should have given its surroundings (0 = source), or -1 when it should dry up. */
  computeNew(id: number, x: number, y: number, z: number): number {
    let best = 0, sources = 0;
    for (let i = 0; i < 4; i++) {
      if (this.sourceNeighbor(id, x, y, z, i)) { sources++; best = 8; continue; }
      const c = this.host.getCell(x + DIRS[i][0], y, z + DIRS[i][1]);
      if (c < 0 || (c & 4095) !== id) continue;
      const st = (c >>> 12) & 15;
      const amount = st & 8 ? 8 : 8 - (st & 7);
      if (amount > best) best = amount;
    }
    if (sources >= 2 && this.canConvert(id)) {
      const below = this.host.getCell(x, y - 1, z);
      if (below >= 0) {
        const bid = below & 4095;
        if ((BLOCKS[bid]?.solid && !isReplaceable(bid)) || (bid === id && ((below >>> 12) & 15) === 0) || (id === ID.water && this.wl(x, y - 1, z))) return 0; // new source
      }
    }
    const above = this.host.getCell(x, y + 1, z);
    if (above >= 0 && ((above & 4095) === id || (id === ID.water && this.wl(x, y + 1, z) && (this.wlOpen(x, y + 1, z) & WL_OPEN_DOWN) !== 0))) return 8; // falling column
    const amount = best - this.drop(id);
    if (amount <= 0) return -1;
    return 8 - amount;
  }

  /** Lava reacts with adjacent water. Returns true when the lava cell was turned into stone. */
  private lavaReact(x: number, y: number, z: number, cell: number): boolean {
    const state = (cell >>> 12) & 15;
    const below = this.host.getCell(x, y - 1, z) & 4095;
    for (const [dx, dy, dz] of [[0, 1, 0], [1, 0, 0], [-1, 0, 0], [0, 0, 1], [0, 0, -1]] as const) {
      const c = this.host.getCell(x + dx, y + dy, z + dz);
      if (c < 0) continue;
      if ((c & 4095) === ID.water || this.wl(x + dx, y + dy, z + dz)) {
        this.changes++;
        this.host.setBlock(x, y, z, state === 0 ? ID.obsidian : ID.cobblestone, 0);
        this.host.sound?.('fizz', { x, y, z });
        return true;
      }
      if (below === ID.soul_soil && ID.blue_ice !== undefined && (c & 4095) === ID.blue_ice && ID.basalt !== undefined) {
        this.changes++;
        this.host.setBlock(x, y, z, ID.basalt, 0);
        this.host.sound?.('fizz', { x, y, z });
        return true;
      }
    }
    return false;
  }

  /** Vanilla isWaterHole: the cell below accepts the fluid (air, replaceable, or already holding the same fluid). */
  private holeBelow(id: number, x: number, y: number, z: number) {
    const c = this.host.getCell(x, y - 1, z);
    return c >= 0 && (isReplaceable(c & 4095) || (c & 4095) === id || (id === ID.water && this.wl(x, y - 1, z)));
  }

  /** Distance (in blocks) to the nearest hole reachable within the slope find distance (vanilla getSlopeDistance). */
  private slopeDistance(id: number, x: number, y: number, z: number, depth: number, fromDx: number, fromDz: number): number {
    let best = 1000;
    for (const [dx, dz] of DIRS) {
      if (dx === -fromDx && dz === -fromDz) continue;
      const nx = x + dx, nz = z + dz;
      if (!this.passable(this.host.getCell(nx, y, nz), id)) continue;
      if (this.holeBelow(id, nx, y, nz)) return depth;
      if (depth < this.slope(id)) {
        const j = this.slopeDistance(id, nx, y, nz, depth + 1, dx, dz);
        if (j < best) best = j;
      }
    }
    return best;
  }

  private tick(x: number, y: number, z: number) {
    const cell = this.host.getCell(x, y, z);
    if (cell < 0) return;
    const id = cell & 4095;
    if (!isFluid(id)) {
      // A waterlogged block: a water source that only leaks through its open faces.
      if (this.wl(x, y, z)) this.spread(ID.water, x, y, z, 0, this.wlOpen(x, y, z));
      return;
    }
    let state = (cell >>> 12) & 15;
    if (id === ID.lava && this.lavaReact(x, y, z, cell)) return;

    if (state !== 0) {
      const ns = this.computeNew(id, x, y, z);
      if (ns === -1) { this.changes++; this.host.setBlock(x, y, z, 0); return; }
      if (ns !== state) {
        // LavaFluid.getSpreadDelay: a rising, non-falling lava level makes the next tick wait 4x as long 3 times out of 4.
        const rising = id === ID.lava && !(state & 8) && !(ns & 8) && ns !== 0 && ns < state && Math.floor(this.rnd() * 4) !== 0;
        this.changes++;
        this.host.setBlock(x, y, z, id, ns);
        // setBlock re-enters onBlockChanged which re-schedules this cell; fall through only when the new state keeps spreading
        if (rising) { const e = this.due.get(this.key(x, y, z)); if (e) e.t = this.time + this.delay(id) * 4; }
        state = ns;
      }
    }
    this.spread(id, x, y, z, state, WL_OPEN_ALL);
  }

  /** FlowingFluid.spread for a cell holding `id` in `state`; `open` restricts the faces (waterlogged blocks). */
  private spread(id: number, x: number, y: number, z: number, state: number, open: number) {
    const belowCell = this.host.getCell(x, y - 1, z);
    if (belowCell < 0) return;
    const bid = belowCell & 4095;
    const source = state === 0;
    if (open & WL_OPEN_DOWN) {
      if (isReplaceable(bid)) {
        this.place(x, y - 1, z, id, 8);
        // Only a cell fed by three or more sources keeps spreading sideways while it also drains downwards.
        if (this.sourceNeighbors(id, x, y, z) >= 3) this.spreadSides(id, x, y, z, state, open);
        return;
      }
      if (isFluid(bid) && bid !== id) {
        // lava running down into water becomes stone; water falling onto lava turns it to obsidian / cobblestone (via the lava's own reaction)
        if (id === ID.lava) { this.changes++; this.host.setBlock(x, y - 1, z, ID.stone, 0); this.host.sound?.('fizz', { x, y, z }); }
        else this.schedule(x, y - 1, z, 0.05);
        return;
      }
    }
    // Flowing fluid resting on the same fluid (a waterfall landing in a lake, or on a waterlogged block): no sideways spreading.
    if (!source && (bid === id || (id === ID.water && this.wl(x, y - 1, z)))) return;
    this.spreadSides(id, x, y, z, state, open);
  }

  /** FlowingFluid.spreadToSides + getSpread: flow towards the nearest drop(s); with none in range, in every open direction. */
  private spreadSides(id: number, x: number, y: number, z: number, state: number, open: number) {
    const falling = (state & 8) !== 0;
    const amount = falling ? 7 : 8 - (state & 7) - this.drop(id);
    if (amount <= 0) return;

    let bestDist = 1000;
    const picks: { nx: number; nz: number; ns: number; log: boolean }[] = [];
    for (let i = 0; i < 4; i++) {
      if (!((open >> i) & 1)) continue;
      const dx = DIRS[i][0], dz = DIRS[i][1], nx = x + dx, nz = z + dz, nc = this.host.getCell(nx, y, nz);
      if (nc < 0) continue;
      let ns: number, log = false;
      if (this.passable(nc, id)) {
        ns = this.computeNew(id, nx, y, nz);
        if (ns === -1) continue;
      } else if (id === ID.water && !isFluid(nc & 4095) && this.host.waterloggable?.(nx, y, nz) && !this.wl(nx, y, nz)) {
        // A waterloggable block only accepts a SOURCE (two sources beside it over a floor) — never flowing water.
        ns = this.computeNew(id, nx, y, nz);
        if (ns !== 0) continue;
        log = true;
      } else {
        if ((nc & 4095) === id) this.schedule(nx, y, nz);
        continue;
      }
      const d = this.holeBelow(id, nx, y, nz) ? 0 : this.slopeDistance(id, nx, y, nz, 1, dx, dz);
      if (d < bestDist) { bestDist = d; picks.length = 0; }
      if (d <= bestDist) picks.push({ nx, nz, ns, log });
    }
    for (const p of picks) {
      if (p.log) {
        if (this.host.setWaterlogged?.(p.nx, y, p.nz, true)) { this.changes++; this.schedule(p.nx, y, p.nz); }
        continue;
      }
      const nc = this.host.getCell(p.nx, y, p.nz);
      if (nc < 0) continue;
      if (!isReplaceable(nc & 4095)) { if ((nc & 4095) === id) this.schedule(p.nx, y, p.nz); continue; } // flowing cells update on their own tick
      const ns = this.computeNew(id, p.nx, y, p.nz);
      if (ns === -1) continue;
      this.place(p.nx, y, p.nz, id, ns);
    }
  }
}
