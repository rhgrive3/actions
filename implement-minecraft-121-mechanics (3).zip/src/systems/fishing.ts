import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../game/data';
import type { Stack } from '../game/types';

/*
 * Unified Fishing System (Record 014 Perfected).
 *
 * Features:
 *  - Java FishingHook physics on 20 Hz ticks: cast speed 0.6 + 0.5·|(x, tan pitch, z)| blocks/tick, gravity 0.03, drag 0.92,
 *    splash-down damping (0.3, 0.2, 0.3), spring bobbing towards the water surface (vy −= d·rand·0.2), stuck on blocks
 *  - Bite AI: lured after 100-600 ticks (−100 per Lure level; +1 extra tick 25 % of the time in rain, a skipped tick 50 % of the
 *    time without sky access), then a fish swims in for 20-80 ticks on a wandering heading (±9.188° per tick) leaving a wake,
 *    then the bobber is yanked down (−0.4·[0.6, 1]) and the fish nibbles for 20-40 ticks — the only window to reel it in
 *  - The hook vanishes when the player is more than 32 blocks away
 *  - Vanilla 5x4x5 open-water check for Treasure eligibility (in small pools treasure converts to fish)
 *  - Luck of the Sea category shifting, worn durability on Junk gear, random enchantments on Treasure bows/rods/books
 *  - Vanilla Mob Hooking: bobber in flight can hook a mob; reeling in pulls the hooked mob towards the player (3 durability wear)
 *  - Ground reel costs 2 durability, water reel costs 1 durability
 */

export interface FishHost {
  scene?: THREE.Scene;
  getBlock(x: number, y: number, z: number): number;
  particles: {
    burst(p: THREE.Vector3, c: string, n?: number, power?: number): void;
    drop?(p: THREE.Vector3, n: string, c: number, col: string): void;
  };
  sound(k: string, p?: { x: number; y: number; z: number }): void;
  raining?(): boolean;
  enchant?(item: string, rnd: () => number): Record<string, number> | undefined;
  /** Optional mob hook check: returns a mob entity at `pos` if hit in flight. */
  /** Optional raw cell (id | state << 12) for exact water surface heights and source checks. */
  getCell?(x: number, y: number, z: number): number;
  hookMob?(pos: THREE.Vector3): { group?: THREE.Group; pos?: THREE.Vector3; velocity?: THREE.Vector3 } | null;
  /** Pulls a hooked mob towards `origin`. */
  pullMob?(mob: any, origin: THREE.Vector3): void;
}
export type FishingHost = FishHost;
export type LootKind = 'fish' | 'junk' | 'treasure';
export type BobberMesh = THREE.Mesh & {
  state?: 'flying' | 'floating' | 'biting' | 'grounded' | 'hooked';
  hookedMob?: any;
};

const FISH: [string, number][] = [['cod', 60], ['salmon', 25], ['tropical_fish', 2], ['pufferfish', 13]];
const JUNK: [string, number][] = [
  ['lily_pad', 17], ['leather_boots', 10], ['leather', 10], ['bone', 10], ['string', 5],
  ['fishing_rod', 2], ['bowl', 10], ['stick', 5], ['ink_sac', 1], ['rotten_flesh', 10], ['bamboo', 10],
];
const TREASURE: [string, number][] = [
  ['bow', 1], ['enchanted_book', 1], ['fishing_rod', 1], ['name_tag', 1], ['nautilus_shell', 1], ['saddle', 1],
];

export function lootChances(luck: number): Record<LootKind, number> {
  const l = Math.max(0, Math.min(3, luck));
  const treasure = 0.05 + 0.021 * l;
  const junk = Math.max(0, 0.1 - 0.0195 * l);
  return { treasure, junk, fish: 1 - treasure - junk };
}

function weighted(table: [string, number][], rng: () => number): string {
  const usable = table.filter(([n]) => !!resolve(n));
  const list = usable.length ? usable : table;
  let r = rng() * list.reduce((a, b) => a + b[1], 0);
  for (const [n, w] of list) {
    r -= w;
    if (r <= 0) return n;
  }
  return list[0][0];
}

export function rollLoot(
  luck: number,
  openWater = true,
  rng: () => number = Math.random,
  enchant?: FishHost['enchant'],
): { kind: LootKind; stack: Stack } {
  const c = lootChances(luck), r = rng();
  let kind: LootKind = r < c.treasure ? 'treasure' : r < c.treasure + c.junk ? 'junk' : 'fish';
  if (kind === 'treasure' && !openWater) kind = 'fish';
  const name = weighted(kind === 'fish' ? FISH : kind === 'junk' ? JUNK : TREASURE, rng);
  const stack: Stack = { name, count: 1 };
  const max = resolve(name)?.durability;
  if (kind === 'junk' && max) stack.durability = Math.max(1, Math.floor(max * (0.1 + rng() * 0.8)));
  if (kind === 'treasure' && (name === 'bow' || name === 'fishing_rod' || name === 'enchanted_book')) {
    const ench = enchant?.(name, rng);
    if (ench && Object.keys(ench).length) stack.ench = ench;
  }
  return { kind, stack };
}

export function fishingLoot(random: () => number = Math.random, luck = 0, openWater = true): string {
  return rollLoot(luck, openWater, random).stack.name;
}

/** Velocity (blocks/tick) of a caught item flying from the hook to the angler: Δ·0.1, plus √distance·0.08 upwards. */
export function catchVelocity(from: { x: number; y: number; z: number }, to: { x: number; y: number; z: number }) {
  const dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;
  return { x: dx * 0.1, y: dy * 0.1 + Math.sqrt(Math.sqrt(dx * dx + dy * dy + dz * dz)) * 0.08, z: dz * 0.1 };
}

export class Fishing {
  bobber: BobberMesh | null = null;
  hookedMob: any = null;
  lastWear = 1;
  lastStack: Stack | null = null;
  lastKind: LootKind | null = null;
  /** Hook velocity in blocks / game tick. */
  private vel = new THREE.Vector3();
  private hookState: 'flying' | 'bobbing' = 'flying';
  private onGround = false;
  private hitWall = false;
  private open = true;
  private outOfWaterTime = 0;
  /** FishingHook counters, in ticks: fish on the hook / until a fish gets interested / until it reaches the hook. */
  nibble = 0;
  timeUntilLured = 0;
  timeUntilHooked = 0;
  private fishAngle = 0;
  private lure = 0;
  private acc = 0;
  private line: THREE.Line | null = null;
  private lineGeo = new THREE.BufferGeometry();
  public scene: THREE.Scene;
  public host: FishHost;
  private rng: () => number;

  constructor(sceneOrHost: THREE.Scene | FishHost, hostOrRng?: FishHost | (() => number), rng: () => number = Math.random) {
    if ('getBlock' in sceneOrHost) {
      this.host = sceneOrHost;
      this.scene = sceneOrHost.scene!;
      this.rng = typeof hostOrRng === 'function' ? hostOrRng : rng;
    } else {
      this.scene = sceneOrHost;
      this.host = hostOrRng as FishHost;
      this.rng = rng;
    }
  }

  get active() { return !!this.bobber; }
  get biting() { return this.nibble > 0; }
  get phase(): 'casting' | 'waiting' | 'bite' | 'landed' | 'hooked' | undefined {
    if (!this.bobber) return undefined;
    if (this.hookedMob) return 'hooked';
    if (this.nibble > 0) return 'bite';
    if (this.onGround || this.hitWall) return 'landed';
    if (this.hookState === 'bobbing') return 'waiting';
    return 'casting';
  }

  private isWater(x: number, y: number, z: number) { return this.host.getBlock(x, y, z) === ID.water; }
  private isSolid(x: number, y: number, z: number) { const id = this.host.getBlock(x, y, z); return id > 0 && id !== ID.water && !!BLOCKS[id]?.solid; }
  /** Height of the water in the cell (0 = none): 8/9 for sources and falling water, (8 − level)/9 for flows, 1 below more water. */
  private fluidHeight(x: number, y: number, z: number): number {
    if (!this.isWater(x, y, z)) return 0;
    if (this.isWater(x, y + 1, z)) return 1;
    const st = this.host.getCell ? (this.host.getCell(Math.floor(x), Math.floor(y), Math.floor(z)) >>> 12) & 15 : 0;
    return st === 0 || st & 8 ? 8 / 9 : (8 - (st & 7)) / 9;
  }

  /**
   * FishingHook.calculateOpenWater: the 5×4×5 box around the hook (one layer below … two above) must be made of uniform layers —
   * each layer entirely still water sources, or entirely air / lily pads — with water at the bottom and never water above air.
   */
  openWater(p: THREE.Vector3): boolean {
    const bx = Math.floor(p.x), by = Math.floor(p.y), bz = Math.floor(p.z);
    let last: 'above' | 'inside' | 'invalid' = 'invalid';
    for (let dy = -1; dy <= 2; dy++) {
      let layer: 'above' | 'inside' | 'invalid' | null = null;
      for (let dx = -2; dx <= 2 && layer !== 'invalid'; dx++) {
        for (let dz = -2; dz <= 2; dz++) {
          const id = this.host.getBlock(bx + dx, by + dy, bz + dz);
          let t: 'above' | 'inside' | 'invalid';
          if (id === 0 || id === ID.lily_pad) t = 'above';
          else if (id === ID.water) t = this.host.getCell && ((this.host.getCell(bx + dx, by + dy, bz + dz) >>> 12) & 15) !== 0 ? 'invalid' : 'inside';
          else t = 'invalid';
          if (layer === null) layer = t; else if (layer !== t) layer = 'invalid';
          if (layer === 'invalid') break;
        }
      }
      if (layer === 'invalid' || layer === null) return false;
      if (layer === 'above' && last === 'invalid') return false;
      if (layer === 'inside' && last === 'above') return false;
      last = layer;
    }
    return true;
  }

  cast(origin: THREE.Vector3, dir: THREE.Vector3, lure = 0) {
    this.remove();
    const m: BobberMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.18, 0.18, 0.18),
      new THREE.MeshLambertMaterial({ color: '#d93b2b' }),
    );
    m.position.copy(origin).addScaledVector(dir, 0.3);
    m.state = 'flying';
    m.hookedMob = null;
    this.scene.add(m);
    this.bobber = m;
    this.hookedMob = null;
    // FishingHook(player): direction (x, clamp(tan pitch, ±5), z) scaled by 0.6 / length + 0.5 (± a little spread).
    const horiz = Math.hypot(dir.x, dir.z) || 1e-6;
    const vx = dir.x / horiz, vy = Math.max(-5, Math.min(5, dir.y / horiz)), vz = dir.z / horiz;
    const len = Math.hypot(vx, vy, vz);
    const k = 0.6 / len + 0.5 + (this.rng() - 0.5) * 2 * 0.0045;
    this.vel.set(vx * k, vy * k, vz * k);
    this.hookState = 'flying';
    this.onGround = false; this.hitWall = false;
    this.open = true;
    this.outOfWaterTime = 0;
    this.nibble = 0; this.timeUntilLured = 0; this.timeUntilHooked = 0;
    this.acc = 0;
    this.lure = lure;
    this.line = new THREE.Line(this.lineGeo, new THREE.LineBasicMaterial({ color: '#d4d0bd' }));
    this.line.frustumCulled = false;
    this.scene.add(this.line);
    this.host.sound('bow');
  }

  cancel() { this.remove(); }

  /**
   * Reels in. Durability cost as in Java: nothing 0, a catch 1, hook stuck in a block 2, a dropped item 3, any other entity 5.
   */
  reel(luck = 0, playerOrigin?: THREE.Vector3): { caught: { kind: LootKind; stack: Stack } | null; wear: number; xp: number; from: THREE.Vector3; hooked: boolean; hookedMob: any } | null {
    if (!this.bobber) return null;
    const from = this.bobber.position.clone();
    const wasBite = this.nibble > 0;
    const wasGround = this.onGround || this.hitWall;
    const hooked = this.hookedMob;
    const open = this.open;
    this.remove();

    if (hooked) {
      if (playerOrigin) {
        if (this.host.pullMob) this.host.pullMob(hooked, playerOrigin);
        else {
          // FishingHook.pullEntity: the entity gets (angler − hook) · 0.1 blocks/tick of velocity.
          const targetPos = hooked.pos ?? hooked.group?.position;
          if (targetPos) {
            const pull = playerOrigin.clone().sub(targetPos).multiplyScalar(0.45);
            targetPos.add(pull);
            targetPos.y += 0.4;
            if (hooked.group && hooked.pos) hooked.group.position.copy(hooked.pos);
          }
        }
      }
      const wear = hooked.isItem ? 3 : 5;
      this.lastWear = wear;
      this.lastStack = null;
      this.lastKind = null;
      return { caught: null, wear, xp: 0, from, hooked: true, hookedMob: hooked };
    }

    if (wasBite) {
      const rolled = rollLoot(luck, open, this.rng, this.host.enchant);
      const xp = 1 + Math.floor(this.rng() * 6);
      this.host.particles.burst(from, '#9fd3ee', 12, 2.2);
      this.host.sound('water', from);
      this.lastWear = 1;
      this.lastStack = rolled.stack;
      this.lastKind = rolled.kind;
      return { caught: rolled, wear: 1, xp, from, hooked: false, hookedMob: null };
    }

    const wear = wasGround ? 2 : 0;
    this.lastWear = wear;
    this.lastStack = null;
    this.lastKind = null;
    return { caught: null, wear, xp: 0, from, hooked: false, hookedMob: null };
  }

  /** Cast or reel. Returns the caught item name (or '' when nothing was caught, null when cast). */
  use(origin: THREE.Vector3, dir: THREE.Vector3, luck = 0, lure = 0): string | null {
    if (this.bobber) {
      const res = this.reel(luck, origin);
      return res?.caught ? res.caught.stack.name : '';
    }
    this.cast(origin, dir, lure);
    return null;
  }

  remove() {
    if (this.bobber) this.scene.remove(this.bobber);
    if (this.line) this.scene.remove(this.line);
    this.bobber = null;
    this.line = null;
    this.hookedMob = null;
    this.hookState = 'flying';
    this.onGround = false; this.hitWall = false;
    this.nibble = 0;
  }

  private findMobAt(pos: THREE.Vector3, mobs?: () => any[]): any {
    const viaHost = this.host.hookMob?.(pos);
    if (viaHost) return viaHost;
    if (!mobs) return null;
    for (const m of mobs()) {
      const mp = m.pos ?? m.group?.position;
      if (!mp) continue;
      if (Math.hypot(pos.x - mp.x, pos.z - mp.z) < 0.9 && pos.y >= mp.y - 0.4 && pos.y <= mp.y + 1.9) {
        return m;
      }
    }
    return null;
  }

  private seesSky(p: THREE.Vector3) {
    for (let dy = 1; dy <= 64; dy++) if (this.isSolid(p.x, p.y + dy, p.z)) return false;
    return true;
  }

  /** FishingHook.catchingFish — one tick of the bite AI while the hook floats in water. */
  private catchingFish(p: THREE.Vector3) {
    const rnd = this.rng;
    let i = 1;
    const sky = this.seesSky(p);
    if (rnd() < 0.25 && sky && this.host.raining?.()) i++;          // rain: ~20 % faster
    if (rnd() < 0.5 && !sky) i--;                                   // no sky access: ~2x slower
    if (this.nibble > 0) {
      if (--this.nibble <= 0) { this.timeUntilLured = 0; this.timeUntilHooked = 0; }   // it got away
    } else if (this.timeUntilHooked > 0) {
      this.timeUntilHooked -= i;
      if (this.timeUntilHooked > 0) {
        this.fishAngle += (rnd() - rnd()) * 9.188;
        const a = (this.fishAngle * Math.PI) / 180;
        const x = p.x + Math.sin(a) * this.timeUntilHooked * 0.1, z = p.z + Math.cos(a) * this.timeUntilHooked * 0.1, y = Math.floor(p.y) + 1;
        if (this.isWater(x, y - 1, z) && rnd() < 0.35) this.host.particles.burst(new THREE.Vector3(x, y - 0.1, z), '#c8e8f5', 1, 0.4);   // the wake
      } else {
        this.host.sound('water', p);
        this.vel.y -= 0.4 * (0.6 + rnd() * 0.4);
        this.host.particles.burst(p, '#a8d8f0', 14, 2.5);
        this.nibble = 20 + Math.floor(rnd() * 21);
      }
    } else if (this.timeUntilLured > 0) {
      this.timeUntilLured -= i;
      if (rnd() < 0.03) this.host.particles.burst(new THREE.Vector3(p.x + (rnd() - 0.5) * 0.6, Math.floor(p.y) + 0.9, p.z + (rnd() - 0.5) * 0.6), '#d6eef8', 1, 0.3);
      if (this.timeUntilLured <= 0) { this.fishAngle = rnd() * 360; this.timeUntilHooked = 20 + Math.floor(rnd() * 61); }
    } else {
      this.timeUntilLured = 100 + Math.floor(rnd() * 501) - this.lure * 100;   // ≤ 0 with enough Lure: rolled again next tick
    }
  }

  /** Entity.move for the hook: sub-stepped so a fast cast cannot tunnel through a mob or a wall. */
  private move(mobs?: () => any[]) {
    const p = this.bobber!.position, steps = Math.max(1, Math.ceil(this.vel.length() / 0.35));
    const next = new THREE.Vector3();
    for (let i = 0; i < steps; i++) {
      next.copy(p).addScaledVector(this.vel, 1 / steps);
      if (this.hookState === 'flying') {
        const mob = this.findMobAt(next, mobs);
        if (mob) {
          p.copy(next);
          this.hookedMob = mob;
          this.vel.set(0, 0, 0);
          this.host.sound('hurt', p);
          return;
        }
      }
      if (this.isSolid(next.x, next.y, next.z)) {
        if (this.vel.y < 0 && this.isSolid(p.x, next.y, p.z)) { this.onGround = true; p.y = Math.floor(next.y) + 1.02; }
        else this.hitWall = true;
        return;
      }
      p.copy(next);
    }
  }

  /** FishingHook.tick */
  private tick(mobs?: () => any[]) {
    const b = this.bobber!, p = b.position, rnd = this.rng;
    if (this.hookedMob) {
      const m = this.hookedMob, mp = m.pos ?? m.group?.position;
      if (!mp || (typeof m.hp === 'number' && m.hp <= 0)) { this.hookedMob = null; this.hookState = 'flying'; }
      else { p.set(mp.x, mp.y + 0.8, mp.z); return; }
    }
    if (this.onGround || this.hitWall) return;                       // stuck in a block until reeled in
    const by = Math.floor(p.y);
    const fluid = this.fluidHeight(p.x, p.y, p.z), inWater = fluid > 0;
    if (this.hookState === 'flying') {
      if (inWater) {
        this.vel.set(this.vel.x * 0.3, this.vel.y * 0.2, this.vel.z * 0.3);
        this.hookState = 'bobbing';
        this.host.particles.burst(p, '#bfe4f5', 8, 1.5);
        this.host.sound('water', p);
        return;
      }
    } else {
      let d = p.y + this.vel.y - by - fluid;
      if (Math.abs(d) < 0.01) d += Math.sign(d) * 0.1;
      this.vel.set(this.vel.x * 0.9, this.vel.y - d * rnd() * 0.2, this.vel.z * 0.9);
      this.open = this.nibble <= 0 && this.timeUntilHooked <= 0 ? true : this.open && this.outOfWaterTime < 10 && this.openWater(p);
      if (inWater) {
        this.outOfWaterTime = Math.max(0, this.outOfWaterTime - 1);
        if (this.nibble > 0) this.vel.y -= 0.1 * rnd() * rnd();
        this.catchingFish(p);
      } else this.outOfWaterTime = Math.min(10, this.outOfWaterTime + 1);
    }
    if (!inWater) this.vel.y -= 0.03;
    this.move(mobs);
    if (this.onGround || this.hitWall) this.vel.set(0, 0, 0);
    this.vel.multiplyScalar(0.92);
  }

  update(dt: number, rodTip: THREE.Vector3, mobs?: () => any[]) {
    if (!this.bobber) return;
    this.acc = Math.min(this.acc + dt, 0.5);
    while (this.acc >= 0.05 && this.bobber) { this.acc -= 0.05; this.tick(mobs); }
    const b = this.bobber;
    if (!b) return;
    b.hookedMob = this.hookedMob;
    b.state = this.hookedMob ? 'hooked' : this.nibble > 0 ? 'biting' : this.onGround || this.hitWall ? 'grounded' : this.hookState === 'bobbing' ? 'floating' : 'flying';
    // The hook is discarded once the angler is more than 32 blocks away.
    if (b.position.distanceToSquared(rodTip) > 1024) { this.remove(); return; }
    if (this.line) {
      this.lineGeo.setFromPoints([rodTip, b.position]);
      this.lineGeo.computeBoundingSphere();
    }
  }
}
