import { canvas as makeAtlasCanvas } from "../textures/atlas";
// Signs and Hanging Signs: 4-line text per side (front & back), 16 dye colors, Glow Ink Sac fullbright, Honeycomb waxing.
import * as THREE from 'three';
import { DYE_HEX } from './banners';

export interface SignSide {
  lines: [string, string, string, string];
  color: string;
  glowing: boolean;
}
export interface SignData {
  front: SignSide;
  back: SignSide;
  waxed: boolean;
  hanging: boolean;
  wood: string;
  yaw: number;
}

export const SIGN_MAX_LINE_CHARS = 15;

export function newSignData(wood = 'oak', hanging = false, yaw = 0): SignData {
  return {
    front: { lines: ['', '', '', ''], color: '#1d1d21', glowing: false },
    back: { lines: ['', '', '', ''], color: '#1d1d21', glowing: false },
    waxed: false,
    hanging,
    wood,
    yaw,
  };
}

/** Determines which face ('front' or 'back') the player at (px, pz) is facing on a sign at (sx + 0.5, sz + 0.5) with rotation `yaw`. */
export function signSideForPlayer(signYaw: number, sx: number, sz: number, px: number, pz: number): 'front' | 'back' {
  const nx = Math.sin(signYaw), nz = Math.cos(signYaw);
  const dx = px - (sx + 0.5), dz = pz - (sz + 0.5);
  return dx * nx + dz * nz >= 0 ? 'front' : 'back';
}

/** Applies a dye, glow ink sac, regular ink sac, or honeycomb to a sign side; returns 'edit' if the sign GUI should open. */
export function applySignItem(sign: SignData, sideKey: 'front' | 'back', itemName: string): 'waxed' | 'dyed' | 'glow' | 'unglow' | 'locked' | 'edit' {
  if (sign.waxed) return 'locked';
  if (itemName === 'honeycomb') {
    sign.waxed = true;
    return 'waxed';
  }
  const side = sign[sideKey];
  if (itemName.endsWith('_dye')) {
    const hex = DYE_HEX[itemName.replace(/_dye$/, '')];
    if (hex && side.color !== hex) {
      side.color = hex;
      return 'dyed';
    }
  }
  if (itemName === 'glow_ink_sac' && !side.glowing) {
    side.glowing = true;
    return 'glow';
  }
  if (itemName === 'ink_sac' && side.glowing) {
    side.glowing = false;
    return 'unglow';
  }
  return 'edit';
}

export function setSignLine(sign: SignData, sideKey: 'front' | 'back', lineIndex: number, text: string): boolean {
  if (sign.waxed || lineIndex < 0 || lineIndex > 3) return false;
  sign[sideKey].lines[lineIndex] = text.slice(0, SIGN_MAX_LINE_CHARS);
  return true;
}

/** Paints one face of a sign board (96×48 px) with wood plank background and 4 lines of text (with glow outline if glowing). */
export function paintSignSide(ctx: CanvasRenderingContext2D, side: SignSide, wood = 'oak') {
  ctx.fillStyle = wood.includes('spruce') ? '#6e5034' : wood.includes('dark_oak') ? '#46301c' : '#a88754';
  ctx.fillRect(0, 0, 96, 48);
  ctx.fillStyle = '#5c4428';
  ctx.fillRect(0, 0, 96, 2); ctx.fillRect(0, 46, 96, 2);
  ctx.fillRect(0, 0, 2, 48); ctx.fillRect(94, 0, 2, 48);
  if ((ctx as any).font !== undefined) (ctx as any).font = 'bold 9px monospace';
  if ((ctx as any).textAlign !== undefined) (ctx as any).textAlign = 'center';
  for (let i = 0; i < 4; i++) {
    const line = side.lines[i] ?? '';
    if (!line) continue;
    const y = 11 + i * 10;
    if (side.glowing) {
      ctx.fillStyle = side.color === '#1d1d21' ? '#f0e8c0' : '#ffffff';
      if (typeof (ctx as any).fillText === 'function') {
        (ctx as any).fillText(line, 47, y);
        (ctx as any).fillText(line, 49, y);
      } else {
        ctx.fillRect(16, y - 6, Math.min(64, line.length * 4 + 2), 7);
      }
    }
    ctx.fillStyle = side.color;
    if (typeof (ctx as any).fillText === 'function') (ctx as any).fillText(line, 48, y);
    else ctx.fillRect(17, y - 5, Math.min(62, line.length * 4), 5);
  }
}

export function signSideDataUrl(side: SignSide, wood = 'oak') {
  const preview = makeAtlasCanvas(96, 48);
  paintSignSide(preview.getContext('2d') as CanvasRenderingContext2D, side, wood);
  return 'toDataURL' in preview ? (preview as HTMLCanvasElement).toDataURL('image/png') : '';
}

/** 3D meshes for placed Signs and Hanging Signs with independent front & back text faces and glowing unlit material support. */
export class SignMeshes {
  private groups = new Map<string, THREE.Group>();
  private boardGeo = new THREE.BoxGeometry(0.92, 0.46, 0.08);
  private postGeo = new THREE.BoxGeometry(0.10, 0.54, 0.10);
  private chainGeo = new THREE.BoxGeometry(0.06, 0.36, 0.06);
  private faceGeo = new THREE.PlaneGeometry(0.88, 0.42);
  constructor(private scene: THREE.Scene) {}

  set(key: string, x: number, y: number, z: number, data: SignData) {
    this.remove(key);
    const g = new THREE.Group();
    const woodMat = new THREE.MeshLambertMaterial({ color: data.wood.includes('spruce') ? '#6e5034' : '#a88754' });
    const board = new THREE.Mesh(this.boardGeo, woodMat);
    board.position.y = data.hanging ? 0.42 : 0.68;
    g.add(board);

    if (data.hanging) {
      const chainMat = new THREE.MeshLambertMaterial({ color: '#4a5054' });
      for (const sx of [-0.28, 0.28]) {
        const ch = new THREE.Mesh(this.chainGeo, chainMat);
        ch.position.set(sx, 0.82, 0);
        g.add(ch);
      }
    } else {
      const post = new THREE.Mesh(this.postGeo, woodMat);
      post.position.y = 0.27;
      g.add(post);
    }

    for (const [sideKey, dz, ry] of [['front', 0.045, 0], ['back', -0.045, Math.PI]] as const) {
      const side = data[sideKey];
      const cv = makeAtlasCanvas(96, 48) as unknown as HTMLCanvasElement;
      paintSignSide(cv.getContext('2d')!, side, data.wood);
      const tex = new THREE.CanvasTexture(cv);
      tex.magFilter = THREE.NearestFilter;
      tex.colorSpace = THREE.SRGBColorSpace;
      const mat = side.glowing
        ? new THREE.MeshBasicMaterial({ map: tex })
        : new THREE.MeshLambertMaterial({ map: tex });
      const plane = new THREE.Mesh(this.faceGeo, mat);
      plane.position.set(0, board.position.y, dz);
      plane.rotation.y = ry;
      g.add(plane);
    }

    g.position.set(x + 0.5, y, z + 0.5);
    g.rotation.y = data.yaw;
    this.scene.add(g);
    this.groups.set(key, g);
  }

  remove(key: string) {
    const g = this.groups.get(key);
    if (!g) return;
    this.scene.remove(g);
    this.groups.delete(key);
  }

  clear() { for (const k of [...this.groups.keys()]) this.remove(k); }
  get size() { return this.groups.size; }
}
