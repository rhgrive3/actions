import { BLOCKS, ID, resolve, type BlockDef } from '../game/data';
import '../game/content';
import { blockId, blockState, isSlabBlock } from '../game/blockState';
import type { Stack } from '../game/types';
import { DATA_VERSION, DYE_RGB, NS, blendDyeColors, itemsFromNbt, itemsToNbt, shulkerContents, shulkerItem, uuidToIntArray, type NbtItem } from '../game/nbt';
import { CALIBRATED_SENSOR_RANGE, EventBus, SENSOR_RANGE, SNEAK_SILENT, VIBRATION_FREQUENCY, sensorPower } from './events';

/*
 * Record 016 — environment physics, block gimmicks, redstone sensors and block-entity persistence.
 *
 * This module owns the *rules*; it never draws. It talks to the world through `GameplayHost` (the engine satisfies it
 * structurally) and to the outside through `GameplayIO` callbacks, so the whole thing also runs headless in the tests.
 * Everything the renderer needs is published on `events` and through `renderState()` / `blockRenderState()`.
 *
 * All timings are in game ticks (20 per second) and follow Java Edition.
 */

// ---- Host contracts ----------------------------------------------------------------------------------------------------
export interface Vec3Like { x: number; y: number; z: number; }
export interface GameplayHost {
  position: Vec3Like;
  hotbar: (Stack | null)[];
  inventory: (Stack | null)[];
  armor: (Stack | null)[];
  selected: number;
  health: number;
  hunger: number;
  oxygen: number;
  flying: boolean;
  grounded: boolean;
  dead: boolean;
  dimension: string;
  weather: string;
  meta: { mode: string; id: string };
  containers: Record<string, (Stack | null)[]>;
  input: { crouch: boolean; ascend: boolean; run: boolean; useHeld: boolean; pitch: number; yaw: number };
  getCell(x: number, y: number, z: number): number;
  getBlock(x: number, y: number, z: number): number;
  setBlock(x: number, y: number, z: number, id: number, state?: number): boolean;
}
export interface EntityView { x: number; y: number; z: number; kind: 'mob' | 'item' | 'vehicle'; push?: (dy: number) => void; }
export interface GameplayIO {
  /** World write that also registers the cell with the redstone engine. */
  rsSet(x: number, y: number, z: number, id: number, state: number): boolean;
  /** Redstone signal arriving at a cell (wire level, strongly powered block, or a repeater/comparator facing `toward`). */
  rsInput(x: number, y: number, z: number, toward?: readonly [number, number, number]): number;
  /** "x,y,z" keys of every redstone component currently loaded. */
  rsPositions(): Iterable<string>;
  drop(x: number, y: number, z: number, stack: Stack): void;
  give(stack: Stack): boolean;
  sound(kind: string, pos?: Vec3Like): void;
  toast(ja: string, en: string): void;
  damage(amount: number, source: string): void;
  /** Side effects of a finished meal / drink (potion effects, milk, chorus fruit...). Hunger is handled here. */
  finishConsume(stack: Stack): void;
  openContainer(key: string): void;
  consumeHeld(): void;
  wearHeld(amount: number): void;
  entities(): EntityView[];
  skyVisible(x: number, y: number, z: number): boolean;
  snowing(x: number, z: number): boolean;
  randomTickSpeed(): number;
  random(): number;
  /** Campfire recipe lookup: raw food -> cooked food (null when the item cannot be cooked on a campfire). */
  cookResult(name: string): string | null;
}

// ---- Constants (vanilla values) ----------------------------------------------------------------------------------------
export type Pose = 'standing' | 'sneaking' | 'crawling' | 'swimming';
export const POSE_HEIGHT: Record<Pose, number> = { standing: 1.8, sneaking: 1.5, crawling: 0.6, swimming: 0.6 };
export const POSE_EYE: Record<Pose, number> = { standing: 1.62, sneaking: 1.27, crawling: 0.4, swimming: 0.4 };
export const PLAYER_WIDTH = 0.6;

export const USE_TICKS_DEFAULT = 32;
export const USE_TICKS: Record<string, number> = { dried_kelp: 16, honey_bottle: 40 };
/** Saturation gained = food * modifier * 2, capped at the new food level. */
export const SATURATION_MODIFIER: Record<string, number> = {
  apple: 0.3, baked_potato: 0.6, beetroot: 0.6, beetroot_soup: 0.6, bread: 0.6, carrot: 0.6, chorus_fruit: 0.3, cooked_chicken: 0.6, cooked_cod: 0.6,
  cooked_mutton: 0.8, cooked_porkchop: 0.8, cooked_rabbit: 0.6, cooked_salmon: 0.8, cooked_beef: 0.8, cookie: 0.1, dried_kelp: 0.3,
  enchanted_golden_apple: 1.2, golden_apple: 1.2, golden_carrot: 1.2, glow_berries: 0.1, honey_bottle: 0.1, melon_slice: 0.3, mushroom_stew: 0.6,
  poisonous_potato: 0.3, potato: 0.3, pufferfish: 0.1, pumpkin_pie: 0.3, rabbit_stew: 0.6, raw_beef: 0.3, beef: 0.3, chicken: 0.3, cod: 0.1, mutton: 0.3,
  porkchop: 0.3, rabbit: 0.3, salmon: 0.1, rotten_flesh: 0.1, spider_eye: 0.8, suspicious_stew: 0.6, sweet_berries: 0.1, tropical_fish: 0.1,
};
const RETURNED: Record<string, string> = { mushroom_stew: 'bowl', rabbit_stew: 'bowl', beetroot_soup: 'bowl', suspicious_stew: 'bowl', honey_bottle: 'glass_bottle', milk_bucket: 'bucket' };
const ALWAYS_EDIBLE = new Set(['golden_apple', 'enchanted_golden_apple', 'chorus_fruit', 'honey_bottle', 'suspicious_stew']);

export const FREEZE_TICKS = 140;
export const FREEZE_DAMAGE_INTERVAL = 40;
export const SCAFFOLD_MAX_DISTANCE = 7;
export const CAMPFIRE_COOK_TICKS = 600;
export const CAMPFIRE_SMOKE_HEIGHT = 10;
export const SIGNAL_SMOKE_HEIGHT = 25;
/** A column gets a precipitation tick with 1/16 chance per chunk per tick, at one of 256 columns. */
export const PRECIPITATION_TICK_CHANCE = 1 / 4096;
export const RAIN_FILL_CHANCE = 0.05;
export const SNOW_FILL_CHANCE = 0.1;
export const DRIP_WATER_CHANCE = 45 / 256;
export const DRIP_LAVA_CHANCE = 15 / 256;
export const DRIPSTONE_REACH = 11;
export const TRIPWIRE_MAX_LENGTH = 40;
export const CAULDRON_WATER = 0, CAULDRON_LAVA = 1, CAULDRON_POWDER_SNOW = 2;
const CAULDRON_IDS = ['minecraft:water_cauldron', 'minecraft:lava_cauldron', 'minecraft:powder_snow_cauldron'];
export const ENDER_KEY = 'ender_chest';

const H4: readonly (readonly [number, number])[] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
const N6: readonly (readonly [number, number, number])[] = [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]];
/** Horizontal facings in the redstone engine's order: 0 +X, 1 +Z, 2 -X, 3 -Z. */
const FACE4: readonly (readonly [number, number, number])[] = [[1, 0, 0], [0, 0, 1], [-1, 0, 0], [0, 0, -1]];
const FACING_NAMES = ['east', 'south', 'west', 'north'];
/** Tripwire hook attachment state -> direction the hook (and its string) points. */
const HOOK_DIR: Record<number, readonly [number, number]> = { 1: [1, 0], 2: [-1, 0], 3: [0, 1], 4: [0, -1] };
/** Chest-style facing state -> outward normal of the front face. */
const FRONT: readonly (readonly [number, number, number])[] = [[0, 0, 1], [-1, 0, 0], [0, 0, -1], [1, 0, 0]];
const BOOKS = new Set(['book', 'writable_book', 'written_book', 'enchanted_book', 'knowledge_book']);
const DIM_ID: Record<string, string> = { overworld: 'minecraft:overworld', nether: 'minecraft:the_nether', end: 'minecraft:the_end' };
const LEATHER = /^leather_(helmet|chestplate|leggings|boots|horse_armor)$/;
const key = (x: number, y: number, z: number) => `${x},${y},${z}`;
const gpParseCache = new Map<string, [number, number, number]>();
const parse = (k: string): [number, number, number] => {
  let p = gpParseCache.get(k);
  if (!p) {
    const c1 = k.indexOf(','), c2 = k.indexOf(',', c1 + 1);
    p = [Number(k.slice(0, c1)), Number(k.slice(c1 + 1, c2)), Number(k.slice(c2 + 1))];
    if (gpParseCache.size > 32768) gpParseCache.clear();
    gpParseCache.set(k, p);
  }
  return p;
};

// ---- Pure helpers (exported for tests and for the renderer) --------------------------------------------------------------
/** TargetBlock.calculatePower: 15 in the bull's eye, falling off linearly to 1 at the edge of the face that was hit. */
export function targetSignal(axis: 'x' | 'y' | 'z', hx: number, hy: number, hz: number): number {
  const frac = (v: number) => v - Math.floor(v);
  const d = Math.abs(frac(hx) - 0.5), e = Math.abs(frac(hy) - 0.5), f = Math.abs(frac(hz) - 0.5);
  const g = axis === 'y' ? Math.max(d, f) : axis === 'z' ? Math.max(d, e) : Math.max(e, f);
  return Math.max(1, Math.ceil(15 * Math.min(1, Math.max(0, (0.5 - g) / 0.5))));
}
/** Chiseled bookshelf slot (0-5) for a hit on its front face: three columns left to right, top row first. */
export function bookshelfSlot(facing: number, fx: number, fy: number, fz: number): number {
  const u = facing === 0 ? fx : facing === 2 ? 1 - fx : facing === 3 ? 1 - fz : fz;
  const col = Math.max(0, Math.min(2, Math.floor(u * 3)));
  return col + (fy >= 0.5 ? 0 : 3);
}
export const usageTicks = (name: string) => USE_TICKS[name] ?? USE_TICKS_DEFAULT;

// ---- Persistence -------------------------------------------------------------------------------------------------------
export interface NbtBlockEntity {
  id: string; x: number; y: number; z: number; keepPacked?: boolean;
  Items?: NbtItem[]; CookingTimes?: number[]; CookingTotalTimes?: number[];
  last_interacted_slot?: number; last_vibration_frequency?: number; CustomColor?: number;
}
export interface GameplaySave {
  DataVersion: number;
  Player: { UUID: number[]; foodSaturationLevel: number; TicksFrozen: number; EnderItems: NbtItem[]; enderUpdatedAt?: number };
  Dimensions: Record<string, { block_states: Record<string, Record<string, string | number | boolean>>; block_entities: NbtBlockEntity[] }>;
}
interface Props { waterlogged?: boolean; facing?: number; }
interface BE {
  id: string;
  items?: (Stack | null)[]; times?: number[]; totals?: number[];
  last?: number;
  freq?: number; phase?: number; until?: number; power?: number; pend?: { at: number; freq: number; dist: number } | null;
  color?: number;
}
interface DimStore { props: Map<string, Props>; be: Map<string, BE>; }
interface UseState { name: string; slot: number; tick: number; total: number; kind: 'eat' | 'drink'; }

export class Gameplay {
  readonly events = new EventBus();
  // player
  pose: Pose = 'standing';
  poseForced = false;
  saturation = 5;
  ticksFrozen = 0;
  use: UseState | null = null;
  feetY = 0;
  noFall = false;
  inScaffold = false;
  inPowderSnow = false;
  bubble: -1 | 0 | 1 = 0;
  private bubbleVy = 0;
  private moving = false;
  // ender chest (per player, shared by every ender chest block)
  enderItems: (Stack | null)[] = Array(27).fill(null);
  enderDirty = false;
  enderUpdatedAt = 0;
  playerUUID = '00000000-0000-0000-0000-000000000000';
  private openKey = '';
  // world
  tickCount = 0;
  private acc = 0;
  private stores: Record<string, DimStore> = {};
  private sensors: [number, number, number][] = [];
  private hooks: [number, number, number][] = [];
  private indexAt = -1000;
  private targets = new Map<string, number>();
  private hookHold = new Map<string, number>();
  private hookAttached = new Map<string, boolean>();
  private scaffoldQueue: [number, number, number][] = [];
  private scaffoldBusy = false;

  constructor(public host: GameplayHost, public io: GameplayIO) {}

  // ======================================================================================================================
  // Stores
  // ======================================================================================================================
  private store(dim = this.host.dimension): DimStore { return this.stores[dim] ??= { props: new Map(), be: new Map() }; }
  private be(x: number, y: number, z: number, create?: string): BE | undefined {
    const s = this.store(), k = key(x, y, z);
    let b = s.be.get(k);
    if (!b && create) { b = { id: create }; s.be.set(k, b); }
    return b;
  }
  private creative() { return this.host.meta.mode === 'creative'; }
  private survival() { return this.host.meta.mode === 'survival' || this.host.meta.mode === 'adventure'; }

  // ======================================================================================================================
  // Tick loop
  // ======================================================================================================================
  update(dt: number) {
    this.acc += dt;
    let n = 0;
    while (this.acc >= 0.05 && n < 5) { this.acc -= 0.05; n++; this.tick(); }
    if (this.acc > 0.25) this.acc = 0;
  }

  tick() {
    this.tickCount++;
    this.events.tick = this.tickCount;
    if (this.tickCount - this.indexAt >= 20) this.refreshIndex();
    this.tickUse();
    this.tickFreeze();
    this.tickBubbles();
    this.tickCampfires();
    this.tickCauldrons();
    this.tickSensors();
    this.tickTargets();
    this.tickTripwires();
  }

  private refreshIndex() {
    this.indexAt = this.tickCount;
    const sensors: [number, number, number][] = [], hooks: [number, number, number][] = [];
    for (const k of this.io.rsPositions()) {
      const p = parse(k), id = this.host.getBlock(p[0], p[1], p[2]);
      if (id <= 0) continue;
      if (id === ID.sculk_sensor || id === ID.calibrated_sculk_sensor) sensors.push(p);
      else if (id === ID.tripwire_hook) hooks.push(p);
    }
    this.sensors = sensors; this.hooks = hooks;
  }

  // ======================================================================================================================
  // 1. Survival physics: poses, eating, scaffolding, powder snow, bubble columns, waterlogging
  // ======================================================================================================================
  height() { return POSE_HEIGHT[this.pose]; }
  eyeHeight() { return POSE_EYE[this.pose]; }

  isWaterlogged(x: number, y: number, z: number) { return this.store().props.get(key(Math.floor(x), Math.floor(y), Math.floor(z)))?.waterlogged === true; }
  /** Water for physics purposes: a water block, or any block that carries water inside (slab, stairs, fence, chest...). */
  isWater(x: number, y: number, z: number) { return this.host.getBlock(x, y, z) === ID.water || this.isWaterlogged(x, y, z); }
  waterloggable(def: BlockDef | undefined, state = 0): boolean {
    if (!def || def.id <= 0) return false;
    const n = def.name;
    if (isSlabBlock(def)) return state !== 2;
    if (def.shape === 'stairs' || def.shape === 'fence' || def.shape === 'trapdoor' || def.shape === 'chest' || def.shape === 'pane' || def.shape === 'lantern') return true;
    return n === 'scaffolding' || n === 'campfire' || n === 'unlit_campfire' || n === 'sculk_sensor' || n === 'calibrated_sculk_sensor' || n === 'tripwire_hook' || n === 'tripwire'
      || n === 'chain' || n === 'pointed_dripstone' || n.endsWith('rail') || n === 'lantern' || n === 'soul_lantern' || n === 'end_rod';
  }
  /**
   * Faces through which a waterlogged block lets its water out (Java: only the non-full sides). Bits 0-3 = +x, -x, +z, -z, bit 4 = down.
   * Bottom slabs keep their full bottom face shut, stairs additionally their full back face; top slabs / upside-down stairs drain downwards.
   */
  waterlogOpen(x: number, y: number, z: number): number {
    const cell = this.host.getCell(x, y, z), def = BLOCKS[blockId(cell)], state = blockState(cell);
    if (!def) return 31;
    if (isSlabBlock(def)) return state === 1 ? 31 : 15;
    if (def.shape === 'stairs') {
      const back = [8, 1, 4, 2][state & 3];                 // facing 0: -z, 1: +x, 2: +z, 3: -x
      return ((state & 4 ? 31 : 15) & ~back);
    }
    return 31;
  }
  setWaterlogged(x: number, y: number, z: number, on: boolean) {
    const s = this.store(), k = key(x, y, z), p = s.props.get(k) ?? {};
    if (!!p.waterlogged === on) return false;
    if (on) p.waterlogged = true; else delete p.waterlogged;
    if (Object.keys(p).length) s.props.set(k, p); else s.props.delete(k);
    this.events.emit('waterlogged', { x, y, z, waterlogged: on });
    return true;
  }

  /** Called once at the start of every physics step: samples the surroundings and settles the pose. */
  beginPhysics(water: boolean, moving: boolean, fits: (height: number) => boolean) {
    const h = this.host, p = h.position, spectator = h.meta.mode === 'spectator';
    this.feetY = p.y;
    this.moving = moving;
    const feet = h.getBlock(p.x, p.y + 0.1, p.z), body = h.getBlock(p.x, p.y + Math.max(0.2, this.height() * 0.5), p.z);
    this.inScaffold = !spectator && !h.flying && feet === ID.scaffolding;
    this.inPowderSnow = !spectator && (feet === ID.powder_snow || body === ID.powder_snow);
    const column = spectator ? 0 : this.bubbleAt(p.x, p.y + 0.3, p.z);
    if (column !== this.bubble) {
      this.bubble = column;
      this.events.emit('bubble_column', { drag: column === 0 ? null : column < 0 });
    }

    let want: Pose = 'standing';
    if (!spectator && !h.flying) {
      if (water && h.input.run && moving) want = 'swimming';
      else if (h.input.crouch) want = 'sneaking';
    }
    let next: Pose = want, forced = false;
    if (!spectator) {
      // Not enough head room: duck (1.5), and if even that does not fit — a trapdoor or piston closed the gap — crawl (0.6).
      if (next === 'standing' && !fits(POSE_HEIGHT.standing)) { next = 'sneaking'; forced = true; }
      if (next === 'sneaking' && !fits(POSE_HEIGHT.sneaking)) { next = 'crawling'; forced = true; }
    }
    if (next !== this.pose || forced !== this.poseForced) {
      this.pose = next; this.poseForced = forced;
      this.events.emit('pose', { pose: next, height: POSE_HEIGHT[next], eyeHeight: POSE_EYE[next], forced });
    }
  }

  /** Scaffolding and powder snow are only solid for whoever stands above them and is not sneaking (vanilla shape context). */
  specialCollision(id: number, state: number, bx: number, by: number, bz: number, minX: number, minY: number, minZ: number, maxX: number, maxY: number, maxZ: number): boolean {
    const descending = this.host.input.crouch;
    if (maxX <= bx || minX >= bx + 1 || maxZ <= bz || minZ >= bz + 1) return false;
    if (id === ID.scaffolding) {
      if (!descending && this.feetY >= by + 1 - 1e-3) return maxY > by + 14 / 16 && minY < by + 1;
      if (!descending && (state & 8) !== 0 && this.feetY >= by + 2 / 16 - 1e-3) return maxY > by && minY < by + 2 / 16;
      return false;
    }
    if (id === ID.powder_snow) return this.canWalkOnPowderSnow() && !descending && this.feetY >= by + 1 - 1e-3 && maxY > by && minY < by + 1;
    return false;
  }

  /**
   * Ground movement-speed multiplier from the surroundings: powder snow (≈ Java's 0.9 stuck factor with the velocity reset) and freezing
   * (−0.05 × frozen on the 0.1 movement_speed attribute → half speed when fully frozen). Sneaking / crawling (input × 0.3) and swimming
   * (water drag 0.8 / 0.9) are part of the engine's tick physics now (game/playerPhysics.ts).
   */
  adjustSpeed(speed: number, _water: boolean): number {
    // Legacy callers pass m/s: sneaking / crawling never exceeds 1.65. The engine passes the multiplier 1, which this leaves alone.
    if (this.pose === 'crawling' || this.pose === 'sneaking') speed = Math.min(speed, 1.65);
    if (this.inPowderSnow) speed *= 0.45;
    if (this.ticksFrozen > 0) speed *= 1 - 0.5 * Math.min(1, this.ticksFrozen / FREEZE_TICKS);
    return speed;
  }

  /** Vertical velocity after scaffolding climbing, powder snow sinking, sprint-swimming and bubble columns. */
  adjustVertical(vy: number, dt: number, water: boolean, _onLadder: boolean): number {
    const h = this.host, inp = h.input, p = h.position;
    this.noFall = false;
    if (water) {
      if (this.bubble !== 0) {
        const surface = !this.isWater(p.x, p.y + 1, p.z);
        if (this.bubble > 0) {
          // Soul sand: +0.06 b/t² up to 0.7 b/t inside the column, and a much harder kick at the surface.
          this.bubbleVy = Math.min(surface ? 20 : 14, Math.max(this.bubbleVy, 0) + (surface ? 40 : 24) * dt);
          vy = Math.max(vy, this.bubbleVy);
        } else {
          // Magma: -0.03 b/t² down to -0.3 b/t (-0.9 b/t when dragged in from the surface).
          this.bubbleVy = Math.max(surface ? -18 : -6, Math.min(this.bubbleVy, 0) - 12 * dt);
          vy = Math.min(vy, this.bubbleVy);
        }
        this.noFall = true;
      } else this.bubbleVy = 0;
      return vy;
    }
    this.bubbleVy = 0;
    if (this.inScaffold) {
      this.noFall = true;
      return inp.ascend ? 2.35 : inp.crouch ? -2.2 : Math.max(vy, -3);
    }
    if (this.inPowderSnow) {
      this.noFall = true;
      const boots = this.canWalkOnPowderSnow();
      if (inp.ascend && (boots || h.grounded)) return boots ? 1.6 : 3.2;
      return Math.min(3.2, Math.max(vy, -1.2));
    }
    return vy;
  }

  landed(fall: number) {
    const p = this.host.position;
    if (fall > 0.6) this.vibrate('hit_ground', p.x, p.y, p.z, { sneaking: this.host.input.crouch });
  }

  canWalkOnPowderSnow() { return this.host.armor[3]?.name === 'leather_boots'; }
  wearsLeather() { return this.host.armor.some(a => !!a && a.name.startsWith('leather_')); }

  /** +1 soul sand (upward), -1 magma block (downward drag), 0 no column. The column is every water cell above the base block. */
  bubbleAt(x: number, y: number, z: number): -1 | 0 | 1 {
    const fx = Math.floor(x), fz = Math.floor(z);
    let fy = Math.floor(y);
    if (this.host.getBlock(fx, fy, fz) !== ID.water) return 0;
    for (let i = 0; i < 64; i++) {
      const b = this.host.getBlock(fx, --fy, fz);
      if (b === ID.water) continue;
      return b > 0 && b === ID.soul_sand ? 1 : b > 0 && b === ID.magma_block ? -1 : 0;
    }
    return 0;
  }

  private tickBubbles() {
    const h = this.host, p = h.position;
    // Both column types refill the air supply (vanilla), which is what makes magma "elevators down" survivable.
    if (this.bubble !== 0 || this.bubbleAt(p.x, p.y + 1.5, p.z) !== 0) h.oxygen = 20;
    for (const e of this.io.entities()) {
      if (!e.push || h.getBlock(e.x, e.y + 0.2, e.z) !== ID.water) continue;
      const c = this.bubbleAt(e.x, e.y + 0.2, e.z);
      if (c === 0) continue;
      const surface = !this.isWater(e.x, e.y + 1, e.z);
      e.push(c > 0 ? (surface ? 0.9 : 0.7) : (surface ? -0.45 : -0.3));
    }
  }

  private tickFreeze() {
    const h = this.host, p = h.position, before = this.ticksFrozen;
    const inSnow = h.getBlock(p.x, p.y + 0.1, p.z) === ID.powder_snow || h.getBlock(p.x, p.y + Math.max(0.2, this.height() * 0.5), p.z) === ID.powder_snow;
    if (inSnow && this.survival() && !h.dead && !this.wearsLeather()) this.ticksFrozen = Math.min(FREEZE_TICKS, this.ticksFrozen + 1);
    else this.ticksFrozen = Math.max(0, this.ticksFrozen - 2);
    const full = this.ticksFrozen >= FREEZE_TICKS;
    if (full && this.survival() && !h.dead && this.tickCount % FREEZE_DAMAGE_INTERVAL === 0) this.io.damage(1, 'freeze');
    if ((before === 0) !== (this.ticksFrozen === 0) || (before >= FREEZE_TICKS) !== full) {
      this.events.emit('freeze', { ticksFrozen: this.ticksFrozen, progress: this.ticksFrozen / FREEZE_TICKS, fullyFrozen: full });
    }
  }

  // ---- Eating & drinking (hold to use) -----------------------------------------------------------------------------------
  /** Starts a 32-tick (16 for dried kelp) use session. Nothing is consumed unless the button stays down until the end. */
  beginConsume(stack: Stack, kind?: 'eat' | 'drink'): boolean {
    const h = this.host, def = resolve(stack.name);
    const k = kind ?? (stack.name === 'honey_bottle' ? 'drink' : 'eat');
    if (k === 'eat' && h.hunger >= 20 && !this.creative() && !ALWAYS_EDIBLE.has(stack.name)) return false;
    if (k === 'eat' && !def?.food) return false;
    if (this.use && this.use.name === stack.name && this.use.slot === h.selected) return true;
    if (!h.input.useHeld) {
      this.io.toast(k === 'eat' ? '使用ボタンを長押しすると食べます' : '使用ボタンを長押しすると飲みます', k === 'eat' ? 'Hold use to eat' : 'Hold use to drink');
      return true;
    }
    this.use = { name: stack.name, slot: h.selected, tick: 0, total: usageTicks(stack.name), kind: k };
    this.events.emit('use_start', { item: stack.name, kind: k, ticks: this.use.total });
    return true;
  }
  cancelUse() {
    const u = this.use;
    if (!u) return;
    this.use = null;
    this.events.emit('use_cancel', { item: u.name, kind: u.kind, tick: u.tick });
  }
  useProgress() { return this.use ? Math.min(1, this.use.tick / this.use.total) : 0; }

  private tickUse() {
    const u = this.use, h = this.host;
    if (!u) return;
    const held = h.hotbar[h.selected];
    if (!h.input.useHeld || h.dead || !held || held.name !== u.name || h.selected !== u.slot) { this.cancelUse(); return; }
    u.tick++;
    if (u.tick < u.total) {
      if (u.tick % 4 === 0) this.events.emit('use_tick', { item: u.name, kind: u.kind, tick: u.tick, total: u.total });
      return;
    }
    // Finished: only now do hunger, saturation and the empty container change hands.
    this.use = null;
    const def = resolve(held.name), food = def?.food ?? 0, creative = this.creative();
    let saturation = 0;
    if (food > 0) {
      h.hunger = Math.min(20, h.hunger + food);
      saturation = food * (SATURATION_MODIFIER[held.name] ?? 0.6) * 2;
      this.saturation = Math.min(h.hunger, this.saturation + saturation);
    }
    this.io.finishConsume({ ...held, count: 1 });
    const back = RETURNED[held.name] ?? (u.kind === 'drink' ? 'glass_bottle' : null);
    if (!creative) {
      held.count--;
      if (held.count <= 0) h.hotbar[h.selected] = back ? { name: back, count: 1 } : null;
      else if (back && !this.io.give({ name: back, count: 1 })) this.io.drop(h.position.x, h.position.y + 1, h.position.z, { name: back, count: 1 });
    }
    this.vibrate(u.kind, h.position.x, h.position.y + 1, h.position.z);
    this.events.emit('use_finish', { item: held.name, kind: u.kind, food, saturation, returned: creative ? null : back });
    // Keep eating while the button stays down, like vanilla.
    const again = h.hotbar[h.selected];
    if (again && again.name === u.name) this.beginConsume(again, u.kind);
  }

  /** Exhaustion drains the hidden saturation first, and the visible food bar only once that is gone. */
  exhaust(amount: number) {
    const take = Math.min(this.saturation, amount);
    this.saturation -= take;
    this.host.hunger = Math.max(0, this.host.hunger - (amount - take));
  }

  // ---- Scaffolding -------------------------------------------------------------------------------------------------------
  private supportsScaffold(cell: number): boolean {
    const id = blockId(cell), def = BLOCKS[id];
    if (id <= 0 || !def?.solid) return false;
    if (def.shape === 'cube') return true;
    if (isSlabBlock(def)) return blockState(cell) !== 0;
    return def.shape === 'stairs' && (blockState(cell) & 4) !== 0;
  }
  /** ScaffoldingBlock.calculateDistance: 0 on solid ground, +1 per horizontal step away from a supported column, 7 = unsupported. */
  scaffoldDistance(x: number, y: number, z: number): number {
    const h = this.host, below = h.getCell(x, y - 1, z);
    let d = SCAFFOLD_MAX_DISTANCE;
    if (blockId(below) === ID.scaffolding) d = blockState(below) & 7;
    else if (this.supportsScaffold(below)) return 0;
    for (const [dx, dz] of H4) {
      const c = h.getCell(x + dx, y, z + dz);
      if (blockId(c) !== ID.scaffolding) continue;
      d = Math.min(d, (blockState(c) & 7) + 1);
      if (d === 1) break;
    }
    return d;
  }
  private queueScaffold(x: number, y: number, z: number) {
    this.scaffoldQueue.push([x, y, z]);
    if (!this.scaffoldBusy) this.runScaffold();
  }
  private runScaffold() {
    const h = this.host;
    this.scaffoldBusy = true;
    try {
      let guard = 0;
      while (this.scaffoldQueue.length && guard++ < 8192) {
        const [x, y, z] = this.scaffoldQueue.shift()!, cell = h.getCell(x, y, z);
        if (blockId(cell) !== ID.scaffolding) continue;
        const d = this.scaffoldDistance(x, y, z);
        if (d >= SCAFFOLD_MAX_DISTANCE) { this.collapseScaffold(x, y, z); continue; }
        const bottom = d > 0 && h.getBlock(x, y - 1, z) !== ID.scaffolding, st = d | (bottom ? 8 : 0);
        if (st === blockState(cell)) continue;
        h.setBlock(x, y, z, ID.scaffolding, st);
        this.events.emit('scaffolding', { x, y, z, distance: d, bottom });
        for (const n of N6) this.scaffoldQueue.push([x + n[0], y + n[1], z + n[2]]);
      }
      this.scaffoldQueue.length = 0;
    } finally { this.scaffoldBusy = false; }
  }
  /** The seventh block away from support cannot hold: it falls, and re-forms where it lands if that spot is supported. */
  private collapseScaffold(x: number, y: number, z: number) {
    const h = this.host;
    h.setBlock(x, y, z, 0);
    let land = y;
    for (let yy = y - 1; yy >= y - 128; yy--) {
      const b = h.getBlock(x, yy, z);
      if (b === 0 || b === ID.water) { land = yy; continue; }
      break;
    }
    let landedAt: [number, number, number] | null = null;
    const spot = h.getBlock(x, land, z);
    if (land < y && (spot === 0 || spot === ID.water) && this.scaffoldDistance(x, land, z) < SCAFFOLD_MAX_DISTANCE) {
      h.setBlock(x, land, z, ID.scaffolding, 0);
      if (spot === ID.water) this.setWaterlogged(x, land, z, true);
      this.scaffoldQueue.push([x, land, z]);
      landedAt = [x, land, z];
    } else this.io.drop(x + 0.5, land + 0.5, z + 0.5, { name: 'scaffolding', count: 1 });
    this.events.emit('scaffolding_collapse', { x, y, z, landedAt });
    for (const n of N6) this.scaffoldQueue.push([x + n[0], y + n[1], z + n[2]]);
  }

  // ======================================================================================================================
  // 2. World hooks: placement, replacement, breaking
  // ======================================================================================================================
  private lookFacing(): number {
    const yaw = this.host.input.yaw, fx = -Math.sin(yaw), fz = -Math.cos(yaw);
    return Math.abs(fx) > Math.abs(fz) ? (fx > 0 ? 0 : 2) : fz > 0 ? 1 : 3;
  }

  /** After the player placed a block. `replaced` is what occupied the cell before (water -> waterlogged). */
  placed(x: number, y: number, z: number, id: number, state: number, held: Stack | null, replaced: number) {
    const def = BLOCKS[id];
    if (!def) return;
    if (replaced === ID.water && id !== ID.water && this.waterloggable(def, state)) this.setWaterlogged(x, y, z, true);
    if (id === ID.shulker_box) {
      const contents = shulkerContents(held);
      if (contents) this.host.containers[key(x, y, z)] = contents;
    } else if (id === ID.scaffolding) this.queueScaffold(x, y, z);
    else if (id === ID.campfire || id === ID.unlit_campfire) this.campfireBE(x, y, z);
    else if (id === ID.cauldron) this.be(x, y, z, 'minecraft:cauldron');
    else if (id === ID.chiseled_bookshelf) this.bookshelfBE(x, y, z);
    else if (id === ID.calibrated_sculk_sensor) {
      const s = this.store(), k = key(x, y, z);
      s.props.set(k, { ...(s.props.get(k) ?? {}), facing: this.lookFacing() });
      this.sensors.push([x, y, z]);
    } else if (id === ID.sculk_sensor) this.sensors.push([x, y, z]);
    else if (id === ID.tripwire_hook) this.hooks.push([x, y, z]);
    this.vibrate(id === ID.water || id === ID.lava ? 'fluid_place' : 'block_place', x + 0.5, y + 0.5, z + 0.5);
  }

  /** From Engine.setBlock, before a cell changes its block ID (any cause: mining, explosions, pistons, commands). */
  beforeReplace(x: number, y: number, z: number, prevId: number, _prevState: number, newId: number) {
    const k = key(x, y, z), s = this.store();
    if (prevId === ID.shulker_box && prevId > 0) {
      // Shulker boxes never spill: tool, fist or explosion, the contents travel inside the item (BlockEntityTag.Items).
      const stack = shulkerItem(this.host.containers[k]);
      delete this.host.containers[k];
      if (!(this.creative() && !stack.tag)) {
        this.io.drop(x + 0.5, y + 0.5, z + 0.5, stack);
        this.events.emit('shulker_box_drop', { x, y, z, items: stack.tag?.BlockEntityTag?.Items?.length ?? 0 });
      }
    }
    const be = s.be.get(k);
    if (!be) return;
    if (this.isCampfire(prevId) && this.isCampfire(newId)) return;
    for (const it of be.items ?? []) if (it) this.io.drop(x + 0.5, y + 0.6, z + 0.5, it);
    s.be.delete(k);
  }

  /** From Engine.setBlock, after the cell changed its block ID. */
  afterReplace(x: number, y: number, z: number, prevId: number, newId: number) {
    const s = this.store(), k = key(x, y, z), props = s.props.get(k);
    if (props && !(this.isCampfire(prevId) && this.isCampfire(newId))) {
      s.props.delete(k);
      if (props.waterlogged) {
        this.events.emit('waterlogged', { x, y, z, waterlogged: false });
        if (newId === 0) this.host.setBlock(x, y, z, ID.water);      // the water that was inside stays behind
      }
    }
    if (ID.scaffolding === undefined) return;
    let near = prevId === ID.scaffolding || newId === ID.scaffolding;
    if (!near) for (const n of N6) if (this.host.getBlock(x + n[0], y + n[1], z + n[2]) === ID.scaffolding) { near = true; break; }
    if (near) {
      for (const n of N6) this.scaffoldQueue.push([x + n[0], y + n[1], z + n[2]]);
      this.queueScaffold(x, y, z);
    }
  }

  /** After the player mined a block. */
  broken(x: number, y: number, z: number, def: BlockDef, _state: number, tool: string) {
    this.vibrate('block_destroy', x + 0.5, y + 0.5, z + 0.5);
    if (def.name !== 'tripwire') return;
    if (tool === 'shears') { this.events.emit('tripwire', { cut: [x, y, z], disarmed: true, powered: false }); return; }
    for (const [dx, dz] of [[1, 0], [0, 1]] as const) {
      const a = this.findHook(x, y, z, -dx, -dz), b = this.findHook(x, y, z, dx, dz);
      if (!a || !b) continue;
      for (const hk of [a, b]) this.hookHold.set(key(hk[0], hk[1], hk[2]), this.tickCount + 10);
      this.events.emit('tripwire', { cut: [x, y, z], hooks: [a, b], disarmed: false, powered: true });
    }
  }

  // ======================================================================================================================
  // Right-click on a block. Returns true when the click was consumed.
  // ======================================================================================================================
  interact(t: { x: number; y: number; z: number; id: number; normal: Vec3Like }, held: Stack | null, hit: Vec3Like): boolean {
    const h = this.host, def = BLOCKS[t.id];
    if (!def || h.dead) return false;
    if (h.input.crouch && held) return false;                       // sneaking uses the item instead of the block
    const name = held?.name ?? '';
    if (t.id === ID.cauldron && this.useCauldron(t.x, t.y, t.z, held)) return true;
    if (this.isCampfire(t.id) && this.useCampfire(t.x, t.y, t.z, held)) return true;
    if (t.id === ID.chiseled_bookshelf && t.id > 0) return this.useBookshelf(t, held, hit);
    if (t.id === ID.ender_chest && t.id > 0) return this.openEnderChest(t.x, t.y, t.z);
    if (name === 'scaffolding' && t.id === ID.scaffolding) return this.extendScaffold(t);
    const state = blockState(h.getCell(t.x, t.y, t.z));
    if (name === 'water_bucket' && this.waterloggable(def, state) && !this.isWaterlogged(t.x, t.y, t.z)) {
      this.setWaterlogged(t.x, t.y, t.z, true);
      this.swapHeld({ name: 'bucket', count: 1 });
      this.io.sound('water', t);
      this.vibrate('fluid_place', t.x + 0.5, t.y + 0.5, t.z + 0.5);
      return true;
    }
    if (name === 'bucket' && this.isWaterlogged(t.x, t.y, t.z)) {
      this.setWaterlogged(t.x, t.y, t.z, false);
      this.swapHeld({ name: 'water_bucket', count: 1 });
      this.io.sound('water', t);
      this.vibrate('fluid_pickup', t.x + 0.5, t.y + 0.5, t.z + 0.5);
      return true;
    }
    return false;
  }

  /** Trades one held item for `next` (bucket <-> water bucket, bottle <-> water bottle). Creative keeps the original. */
  private swapHeld(next: Stack) {
    const h = this.host, held = h.hotbar[h.selected];
    if (this.creative() || !held) return;
    if (held.count <= 1) h.hotbar[h.selected] = next;
    else { held.count--; if (!this.io.give(next)) this.io.drop(h.position.x, h.position.y + 1, h.position.z, next); }
  }

  private extendScaffold(t: { x: number; y: number; z: number; normal: Vec3Like }): boolean {
    const h = this.host;
    // Clicking the top extends sideways in the direction the player faces; clicking a side stacks on top of the column.
    const dir = t.normal.y > 0 ? FACE4[this.lookFacing()] : ([0, 1, 0] as const);
    let x = t.x, y = t.y, z = t.z;
    for (let i = 0; i < SCAFFOLD_MAX_DISTANCE; i++) {
      x += dir[0]; y += dir[1]; z += dir[2];
      const b = h.getBlock(x, y, z);
      if (b === ID.scaffolding) continue;
      if (b !== 0 && b !== ID.water) return true;
      if (h.setBlock(x, y, z, ID.scaffolding, 0)) {
        this.io.consumeHeld();
        this.io.sound('place', { x, y, z });
        this.placed(x, y, z, ID.scaffolding, 0, null, b);
      }
      return true;
    }
    return true;
  }

  // ---- Ender chest -------------------------------------------------------------------------------------------------------
  /** Every ender chest opens the same 27 slots: they belong to the player (UUID), not to the block. */
  openEnderChest(x: number, y: number, z: number): boolean {
    const h = this.host, above = BLOCKS[h.getBlock(x, y + 1, z)];
    if (above?.solid && !above.transparent && above.shape === 'cube') { this.io.toast('エンダーチェストの上がふさがっています', 'The ender chest is blocked'); return true; }
    this.bindContainer(ENDER_KEY, this.enderItems);
    this.openKey = ENDER_KEY;
    this.events.emit('ender_chest_open', { x, y, z, uuid: this.playerUUID });
    this.vibrate('container_open', x + 0.5, y + 0.5, z + 0.5);
    this.io.sound('chest', { x, y, z });
    this.io.openContainer(ENDER_KEY);
    return true;
  }
  /** Exposes a slot array to the container screen without writing it into the per-dimension save (non-enumerable). */
  bindContainer(k: string, slots: (Stack | null)[]) {
    Object.defineProperty(this.host.containers, k, { value: slots, enumerable: false, configurable: true, writable: true });
  }
  setEnderItems(slots: (Stack | null)[], updatedAt = Date.now()) {
    for (let i = 0; i < 27; i++) this.enderItems[i] = slots[i] ?? null;      // same array: an open screen stays in sync
    this.enderUpdatedAt = updatedAt;
    this.enderDirty = false;
  }
  /** The container screen was closed and the game resumed. */
  screenClosed() {
    if (this.openKey !== ENDER_KEY) return;
    this.openKey = '';
    this.enderDirty = true;
    this.enderUpdatedAt = Date.now();
    const p = this.host.position;
    this.vibrate('container_close', p.x, p.y + 1, p.z);
    this.events.emit('ender_chest_close', { uuid: this.playerUUID, items: this.enderItems.filter(Boolean).length });
  }

  // ---- Chiseled bookshelf ------------------------------------------------------------------------------------------------
  private bookshelfBE(x: number, y: number, z: number): BE {
    const be = this.be(x, y, z, 'minecraft:chiseled_bookshelf')!;
    be.items ??= Array(6).fill(null);
    be.last ??= -1;
    return be;
  }
  private useBookshelf(t: { x: number; y: number; z: number; normal: Vec3Like }, held: Stack | null, hit: Vec3Like): boolean {
    const h = this.host, facing = blockState(h.getCell(t.x, t.y, t.z)) & 3, f = FRONT[facing];
    if (t.normal.x !== f[0] || t.normal.y !== f[1] || t.normal.z !== f[2]) return false;      // only the front has slots
    const slot = bookshelfSlot(facing, hit.x - t.x, hit.y - t.y, hit.z - t.z);
    return this.bookshelfSlotUse(t.x, t.y, t.z, slot, held);
  }
  /** One slot of a chiseled bookshelf: an occupied slot gives its book back, an empty one takes the held book. */
  bookshelfSlotUse(x: number, y: number, z: number, slot: number, held: Stack | null): boolean {
    const be = this.bookshelfBE(x, y, z), items = be.items!, h = this.host;
    if (slot < 0 || slot > 5) return false;
    if (items[slot]) {
      const book = items[slot]!;
      items[slot] = null;
      if (!this.io.give(book)) this.io.drop(x + 0.5, y + 0.5, z + 0.5, book);
      this.io.sound('wood', { x, y, z });
    } else if (held && BOOKS.has(held.name)) {
      items[slot] = { ...held, count: 1 };
      if (!this.creative()) { held.count--; if (held.count <= 0) h.hotbar[h.selected] = null; }
      this.io.sound('wood', { x, y, z });
    } else return true;                                               // empty slot, no book in hand: nothing happens
    be.last = slot;                                                   // comparators read this (slot + 1)
    this.events.emit('chiseled_bookshelf', { x, y, z, slot, occupied: items.map(Boolean), lastInteractedSlot: slot });
    this.vibrate('block_change', x + 0.5, y + 0.5, z + 0.5);
    return true;
  }

  // ---- Campfire ----------------------------------------------------------------------------------------------------------
  isCampfire(id: number) { return id > 0 && (id === ID.campfire || id === ID.unlit_campfire); }
  private campfireBE(x: number, y: number, z: number): BE {
    const be = this.be(x, y, z, 'minecraft:campfire')!;
    be.items ??= Array(4).fill(null);
    be.times ??= [0, 0, 0, 0];
    be.totals ??= [CAMPFIRE_COOK_TICKS, CAMPFIRE_COOK_TICKS, CAMPFIRE_COOK_TICKS, CAMPFIRE_COOK_TICKS];
    return be;
  }
  /** A hay bale directly underneath turns the fire into a signal fire: smoke rises 25 blocks instead of 10. */
  signalFire(x: number, y: number, z: number) { return ID.hay_block !== undefined && this.host.getBlock(x, y - 1, z) === ID.hay_block; }
  setCampfireLit(x: number, y: number, z: number, lit: boolean, spill = false): boolean {
    const h = this.host, cell = h.getCell(x, y, z), id = blockId(cell);
    if (!this.isCampfire(id) || (id === ID.campfire) === lit) return false;
    if (lit && this.isWaterlogged(x, y, z)) return false;
    const be = this.campfireBE(x, y, z);
    h.setBlock(x, y, z, lit ? ID.campfire : ID.unlit_campfire, blockState(cell));
    if (spill) {
      be.items!.forEach((it, i) => { if (it) { this.io.drop(x + 0.5, y + 0.6, z + 0.5, it); be.items![i] = null; be.times![i] = 0; } });
    }
    this.io.sound(lit ? 'fuse' : 'water', { x, y, z });
    this.emitCampfire(x, y, z);
    return true;
  }
  private emitCampfire(x: number, y: number, z: number) {
    const be = this.be(x, y, z);
    this.events.emit('campfire', { x, y, z, lit: this.host.getBlock(x, y, z) === ID.campfire, signalFire: this.signalFire(x, y, z), waterlogged: this.isWaterlogged(x, y, z), items: (be?.items ?? []).map(i => i?.name ?? null) });
  }
  private useCampfire(x: number, y: number, z: number, held: Stack | null): boolean {
    const h = this.host, lit = h.getBlock(x, y, z) === ID.campfire, name = held?.name ?? '';
    if (name === 'flint_and_steel' && !lit) {
      if (this.isWaterlogged(x, y, z)) { this.io.toast('水に浸かっていて火がつきません', 'It is waterlogged and will not light'); return true; }
      if (this.setCampfireLit(x, y, z, true)) { this.io.wearHeld(1); this.vibrate('block_change', x + 0.5, y + 0.5, z + 0.5); }
      return true;
    }
    if (name.endsWith('_shovel') && lit) { this.setCampfireLit(x, y, z, false, true); this.io.wearHeld(1); return true; }
    if (name === 'water_bucket' && !this.isWaterlogged(x, y, z)) {
      this.setCampfireLit(x, y, z, false, true);
      this.setWaterlogged(x, y, z, true);
      this.swapHeld({ name: 'bucket', count: 1 });
      this.emitCampfire(x, y, z);
      return true;
    }
    if (!held || !this.io.cookResult(name)) return false;
    const be = this.campfireBE(x, y, z), slot = be.items!.findIndex(i => !i);
    if (slot < 0) return true;
    be.items![slot] = { name, count: 1 };
    be.times![slot] = 0;
    be.totals![slot] = CAMPFIRE_COOK_TICKS;
    this.io.consumeHeld();
    this.io.sound('place', { x, y, z });
    this.emitCampfire(x, y, z);
    return true;
  }
  private tickCampfires() {
    const h = this.host, s = this.store(), p = h.position;
    if (this.survival() && !h.dead && this.tickCount % 10 === 0 && h.getBlock(p.x, p.y + 0.05, p.z) === ID.campfire && ID.campfire !== undefined) this.io.damage(1, 'fire');
    for (const [k, be] of s.be) {
      if (be.id !== 'minecraft:campfire') continue;
      const [x, y, z] = parse(k), id = h.getBlock(x, y, z);
      if (id < 0) continue;                                           // chunk not loaded: the fire keeps its state
      if (!this.isCampfire(id)) { s.be.delete(k); continue; }
      const lit = id === ID.campfire, items = be.items!, times = be.times!, totals = be.totals!;
      for (let i = 0; i < 4; i++) {
        if (!items[i]) continue;
        if (!lit) { times[i] = Math.max(0, times[i] - 2); continue; }   // an unlit fire slowly loses its progress
        if (++times[i] < totals[i]) continue;
        const result = this.io.cookResult(items[i]!.name) ?? items[i]!.name;
        items[i] = null; times[i] = 0;
        this.io.drop(x + 0.5, y + 0.8, z + 0.5, { name: result, count: 1 });
        this.events.emit('campfire_cooked', { x, y, z, slot: i, result });
        this.emitCampfire(x, y, z);
      }
      if (lit && this.tickCount % 10 === 0) {
        const signal = this.signalFire(x, y, z);
        this.events.emit('campfire_smoke', { x, y, z, signalFire: signal, height: signal ? SIGNAL_SMOKE_HEIGHT : CAMPFIRE_SMOKE_HEIGHT });
      }
    }
  }

  // ---- Cauldron ----------------------------------------------------------------------------------------------------------
  cauldronAt(x: number, y: number, z: number): { level: number; content: number } | null {
    const cell = this.host.getCell(x, y, z);
    if (blockId(cell) !== ID.cauldron) return null;
    const st = blockState(cell);
    return { level: st & 3, content: st & 3 ? (st >> 2) & 3 : CAULDRON_WATER };
  }
  setCauldron(x: number, y: number, z: number, content: number, level: number) {
    level = Math.max(0, Math.min(3, level));
    this.host.setBlock(x, y, z, ID.cauldron, level ? (content << 2) | level : 0);
    const be = this.be(x, y, z, 'minecraft:cauldron')!;
    if (!level || content !== CAULDRON_WATER) delete be.color;
    this.events.emit('cauldron', { x, y, z, content: level ? ['water', 'lava', 'powder_snow'][content] : 'empty', level, color: be.color ?? null });
  }
  private useCauldron(x: number, y: number, z: number, held: Stack | null): boolean {
    const c = this.cauldronAt(x, y, z), name = held?.name ?? '';
    if (!c || !held) return false;
    const be = this.be(x, y, z, 'minecraft:cauldron')!, pos = { x, y, z };
    const water = c.level > 0 && c.content === CAULDRON_WATER;
    if (name === 'water_bucket' || name === 'lava_bucket') {
      this.setCauldron(x, y, z, name === 'lava_bucket' ? CAULDRON_LAVA : CAULDRON_WATER, 3);
      this.swapHeld({ name: 'bucket', count: 1 });
      this.io.sound('water', pos); this.vibrate('fluid_place', x + 0.5, y + 0.5, z + 0.5);
      return true;
    }
    if (name === 'bucket') {
      if (c.level < 3 || c.content === CAULDRON_POWDER_SNOW) return true;
      this.setCauldron(x, y, z, CAULDRON_WATER, 0);
      this.swapHeld({ name: c.content === CAULDRON_LAVA ? 'lava_bucket' : 'water_bucket', count: 1 });
      this.io.sound('water', pos); this.vibrate('fluid_pickup', x + 0.5, y + 0.5, z + 0.5);
      return true;
    }
    if (name === 'glass_bottle') {
      if (!water) return true;
      this.setCauldron(x, y, z, CAULDRON_WATER, c.level - 1);
      this.swapHeld({ name: 'water_bottle', count: 1 });
      this.io.sound('water', pos); this.vibrate('fluid_pickup', x + 0.5, y + 0.5, z + 0.5);
      return true;
    }
    if (name === 'water_bottle') {
      if (c.level >= 3 || (c.level > 0 && c.content !== CAULDRON_WATER)) return true;
      this.setCauldron(x, y, z, CAULDRON_WATER, c.level + 1);
      this.swapHeld({ name: 'glass_bottle', count: 1 });
      this.io.sound('water', pos); this.vibrate('fluid_place', x + 0.5, y + 0.5, z + 0.5);
      return true;
    }
    if (name.endsWith('_dye') && DYE_RGB[name.slice(0, -4)] !== undefined) {
      if (!water) return true;
      be.color = blendDyeColors(be.color, [DYE_RGB[name.slice(0, -4)]]);
      this.io.consumeHeld();
      this.io.sound('water', pos);
      this.events.emit('cauldron', { x, y, z, content: 'water', level: c.level, color: be.color });
      return true;
    }
    if (LEATHER.test(name)) {
      if (!water) return false;
      const current = held.tag?.display?.color;
      if (be.color !== undefined) {
        if (current === be.color) return true;
        held.tag = { ...(held.tag ?? {}), display: { ...(held.tag?.display ?? {}), color: be.color } };     // dye it
      } else if (current !== undefined) {
        const display = { ...(held.tag?.display ?? {}) };
        delete display.color;                                                                                // wash it
        const tag = { ...(held.tag ?? {}) };
        if (Object.keys(display).length) tag.display = display; else delete tag.display;
        if (Object.keys(tag).length) held.tag = tag; else delete held.tag;
      } else return false;                                             // nothing to wash: let the armour be equipped
      this.setCauldron(x, y, z, CAULDRON_WATER, c.level - 1);
      this.io.sound('water', pos);
      return true;
    }
    return false;
  }
  /** Rain / snow landing in an open cauldron (one precipitation tick). Returns true when the level rose. */
  cauldronPrecipitation(x: number, y: number, z: number): boolean {
    const c = this.cauldronAt(x, y, z);
    if (!c || !this.io.skyVisible(x, y + 1, z)) return false;
    const snow = this.io.snowing(x, z);
    if (this.io.random() >= (snow ? SNOW_FILL_CHANCE : RAIN_FILL_CHANCE)) return false;
    const content = snow ? CAULDRON_POWDER_SNOW : CAULDRON_WATER;
    if (c.level >= 3 || (c.level > 0 && c.content !== content)) return false;
    this.setCauldron(x, y, z, content, c.level + 1);
    return true;
  }
  /** Fluid held above a stalactite hanging over the cauldron: 'water' | 'lava' | null, plus the tip position. */
  dripSource(x: number, y: number, z: number): { fluid: 'water' | 'lava'; tip: [number, number, number] } | null {
    const h = this.host;
    if (ID.pointed_dripstone === undefined) return null;
    let yy = y + 1;
    while (yy <= y + DRIPSTONE_REACH && h.getBlock(x, yy, z) === 0) yy++;
    if (yy > y + DRIPSTONE_REACH || h.getBlock(x, yy, z) !== ID.pointed_dripstone) return null;
    const tip: [number, number, number] = [x, yy, z];
    let len = 0;
    while (h.getBlock(x, yy, z) === ID.pointed_dripstone && len <= DRIPSTONE_REACH) { yy++; len++; }
    if (len > DRIPSTONE_REACH) return null;
    const root = BLOCKS[h.getBlock(x, yy, z)];
    if (!root?.solid) return null;
    const above = h.getBlock(x, yy + 1, z);
    return above === ID.water ? { fluid: 'water', tip } : above === ID.lava ? { fluid: 'lava', tip } : null;
  }
  /** One random tick of the dripstone above: 45/256 for water, 15/256 for lava. Returns true when the level rose. */
  cauldronDrip(x: number, y: number, z: number): boolean {
    const c = this.cauldronAt(x, y, z), src = c && this.dripSource(x, y, z);
    if (!c || !src) return false;
    if (this.io.random() >= (src.fluid === 'water' ? DRIP_WATER_CHANCE : DRIP_LAVA_CHANCE)) return false;
    if (src.fluid === 'lava') { if (c.level > 0) return false; this.setCauldron(x, y, z, CAULDRON_LAVA, 3); }
    else { if (c.level >= 3 || (c.level > 0 && c.content !== CAULDRON_WATER)) return false; this.setCauldron(x, y, z, CAULDRON_WATER, c.level + 1); }
    this.events.emit('dripstone_drip', { x, y, z, fluid: src.fluid, tip: src.tip });
    return true;
  }
  private tickCauldrons() {
    const h = this.host, s = this.store();
    const raining = h.weather !== 'clear' && h.dimension === 'overworld', randomTick = this.io.randomTickSpeed() / 4096;
    for (const [k, be] of s.be) {
      if (be.id !== 'minecraft:cauldron') continue;
      const [x, y, z] = parse(k), id = h.getBlock(x, y, z);
      if (id < 0) continue;
      if (id !== ID.cauldron) { s.be.delete(k); continue; }
      if (raining && this.io.random() < PRECIPITATION_TICK_CHANCE) this.cauldronPrecipitation(x, y, z);
      if (randomTick > 0 && this.io.random() < randomTick) this.cauldronDrip(x, y, z);
    }
  }

  // ======================================================================================================================
  // 3. Redstone: sculk sensors, target block, tripwire
  // ======================================================================================================================
  /** Publishes a game event as a vibration. Sensors in range pick it up after it travelled (1 block per tick). */
  vibrate(event: string, x: number, y: number, z: number, opts: { sneaking?: boolean } = {}) {
    const freq = VIBRATION_FREQUENCY[event];
    if (!freq) return;
    if (opts.sneaking && SNEAK_SILENT.has(event)) return;
    if (!this.sensors.length) return;
    this.events.emit('vibration', { event, frequency: freq, x, y, z });
    const h = this.host, sx = Math.floor(x), sy = Math.floor(y), sz = Math.floor(z);
    for (const [bx, by, bz] of this.sensors) {
      const id = h.getBlock(bx, by, bz), calibrated = id === ID.calibrated_sculk_sensor;
      if (id <= 0 || (id !== ID.sculk_sensor && !calibrated)) continue;
      if (bx === sx && by === sy && bz === sz) continue;
      const range = calibrated ? CALIBRATED_SENSOR_RANGE : SENSOR_RANGE;
      const dist = Math.hypot(x - bx - 0.5, y - by - 0.5, z - bz - 0.5);
      if (dist > range) continue;
      const be = this.be(bx, by, bz, calibrated ? 'minecraft:calibrated_sculk_sensor' : 'minecraft:sculk_sensor')!;
      if (be.phase || be.pend) continue;                              // busy: active, cooling down, or a signal is on its way
      if (calibrated) {
        const tuned = this.calibration(bx, by, bz);
        if (tuned > 0 && tuned !== freq) continue;                    // tuned to one frequency: everything else is ignored
      }
      if (this.occluded(x, y, z, bx, by, bz)) continue;
      const ticks = Math.max(1, Math.floor(dist));
      be.pend = { at: this.tickCount + ticks, freq, dist };
      this.events.emit('vibration_travel', { from: [x, y, z], to: [bx, by, bz], ticks, frequency: freq });
    }
  }
  /** Cell behind a calibrated sensor (its input side), for the redstone engine. */
  sensorBack(x: number, y: number, z: number): [number, number, number] | null {
    const facing = this.store().props.get(key(x, y, z))?.facing;
    if (facing === undefined) return null;
    const f = FACE4[facing & 3];
    return [x - f[0], y - f[1], z - f[2]];
  }
  /** Signal strength fed into the input side of a calibrated sensor (0 = listens to everything). */
  calibration(x: number, y: number, z: number): number {
    const back = this.sensorBack(x, y, z);
    return back ? Math.max(0, Math.min(15, this.io.rsInput(back[0], back[1], back[2], [x, y, z]))) : 0;
  }
  /** Wool between the source and the sensor swallows the vibration. */
  private occluded(x: number, y: number, z: number, bx: number, by: number, bz: number): boolean {
    const tx = bx + 0.5, ty = by + 0.5, tz = bz + 0.5, steps = Math.ceil(Math.hypot(tx - x, ty - y, tz - z) * 2);
    const sx = Math.floor(x), sy = Math.floor(y), sz = Math.floor(z);
    for (let i = 1; i < steps; i++) {
      const f = i / steps, cx = Math.floor(x + (tx - x) * f), cy = Math.floor(y + (ty - y) * f), cz = Math.floor(z + (tz - z) * f);
      if ((cx === sx && cy === sy && cz === sz) || (cx === bx && cy === by && cz === bz)) continue;
      const id = this.host.getBlock(cx, cy, cz);
      if (id > 0 && BLOCKS[id]?.name.endsWith('_wool')) return true;
    }
    return false;
  }
  private tickSensors() {
    const h = this.host, s = this.store();
    for (const [k, be] of s.be) {
      if (be.id !== 'minecraft:sculk_sensor' && be.id !== 'minecraft:calibrated_sculk_sensor') continue;
      if (!be.pend && !be.phase) continue;
      const [x, y, z] = parse(k), id = h.getBlock(x, y, z);
      if (id < 0) continue;
      const calibrated = id === ID.calibrated_sculk_sensor;
      if (id !== ID.sculk_sensor && !calibrated) { s.be.delete(k); continue; }
      if (be.pend && this.tickCount >= be.pend.at) {
        const { freq, dist } = be.pend;
        be.pend = null;
        be.freq = freq;
        be.power = sensorPower(dist, calibrated ? CALIBRATED_SENSOR_RANGE : SENSOR_RANGE);
        be.phase = 1;
        be.until = this.tickCount + (calibrated ? 10 : 30);
        this.io.rsSet(x, y, z, id, be.power);
        this.io.sound('xp', { x, y, z });
        this.events.emit('sculk_sensor', { x, y, z, phase: 'active', power: be.power, frequency: freq, calibrated });
      } else if (be.phase === 1 && this.tickCount >= (be.until ?? 0)) {
        be.phase = 2;
        be.until = this.tickCount + 10;
        be.power = 0;
        this.io.rsSet(x, y, z, id, 0);
        this.events.emit('sculk_sensor', { x, y, z, phase: 'cooldown', power: 0, frequency: be.freq ?? 0, calibrated });
      } else if (be.phase === 2 && this.tickCount >= (be.until ?? 0)) {
        be.phase = 0;
        this.events.emit('sculk_sensor', { x, y, z, phase: 'inactive', power: 0, frequency: be.freq ?? 0, calibrated });
      }
    }
  }

  /** A projectile stopped inside a block. Works out where it entered, then feeds target blocks and nearby sensors. */
  projectileHit(kind: string, px: number, py: number, pz: number, vx: number, vy: number, vz: number): number {
    const h = this.host, cx = Math.floor(px), cy = Math.floor(py), cz = Math.floor(pz), id = h.getBlock(cx, cy, cz);
    if (id <= 0) return 0;
    const len = Math.hypot(vx, vy, vz) || 1, nx = vx / len, ny = vy / len, nz = vz / len;
    let hx = px, hy = py, hz = pz;
    let axis: 'x' | 'y' | 'z' = Math.abs(nx) >= Math.abs(ny) && Math.abs(nx) >= Math.abs(nz) ? 'x' : Math.abs(ny) >= Math.abs(nz) ? 'y' : 'z';
    for (let i = 1; i <= 80; i++) {
      const qx = px - nx * i * 0.02, qy = py - ny * i * 0.02, qz = pz - nz * i * 0.02;
      if (Math.floor(qx) !== cx) { axis = 'x'; break; }
      if (Math.floor(qy) !== cy) { axis = 'y'; break; }
      if (Math.floor(qz) !== cz) { axis = 'z'; break; }
      hx = qx; hy = qy; hz = qz;
    }
    this.vibrate('projectile_land', hx, hy, hz);
    if (id !== ID.target) return 0;
    const arrow = kind === 'player_arrow' || kind === 'mob_arrow' || kind === 'trident';
    return this.hitTarget(cx, cy, cz, axis, hx, hy, hz, arrow ? 20 : 8);
  }
  /** Lights a target block: strength from how close to the centre of the face the hit was, for 20 (arrows) or 8 ticks. */
  hitTarget(x: number, y: number, z: number, axis: 'x' | 'y' | 'z', hx: number, hy: number, hz: number, ticks = 8): number {
    const power = targetSignal(axis, hx, hy, hz);
    this.io.rsSet(x, y, z, ID.target, power);
    this.targets.set(key(x, y, z), this.tickCount + ticks);
    this.events.emit('target_hit', { x, y, z, power, ticks, hit: [hx, hy, hz], axis });
    return power;
  }
  private tickTargets() {
    for (const [k, until] of this.targets) {
      if (this.tickCount < until) continue;
      this.targets.delete(k);
      const [x, y, z] = parse(k);
      if (this.host.getBlock(x, y, z) === ID.target) this.io.rsSet(x, y, z, ID.target, 0);
    }
  }

  // ---- Tripwire ----------------------------------------------------------------------------------------------------------
  /** String run from a hook to the opposing hook (at most 40 strings, at least one). Null when the circuit is open. */
  tripwireLine(x: number, y: number, z: number, dir: readonly [number, number]): { end: [number, number, number]; wires: [number, number, number][] } | null {
    const h = this.host, wires: [number, number, number][] = [];
    for (let i = 1; i <= TRIPWIRE_MAX_LENGTH + 1; i++) {
      const cx = x + dir[0] * i, cz = z + dir[1] * i, cell = h.getCell(cx, y, cz), id = blockId(cell);
      if (id > 0 && id === ID.tripwire) { wires.push([cx, y, cz]); continue; }
      if (id > 0 && id === ID.tripwire_hook && wires.length > 0) {
        const od = HOOK_DIR[blockState(cell) & 7];
        if (od && od[0] === -dir[0] && od[1] === -dir[1]) return { end: [cx, y, cz], wires };
      }
      return null;
    }
    return null;
  }
  private findHook(x: number, y: number, z: number, dx: number, dz: number): [number, number, number] | null {
    const h = this.host;
    for (let i = 1; i <= TRIPWIRE_MAX_LENGTH + 1; i++) {
      const cx = x + dx * i, cz = z + dz * i, cell = h.getCell(cx, y, cz), id = blockId(cell);
      if (id > 0 && id === ID.tripwire) continue;
      if (id > 0 && id === ID.tripwire_hook) {
        const od = HOOK_DIR[blockState(cell) & 7];
        return od && od[0] === -dx && od[1] === -dz ? [cx, y, cz] : null;
      }
      return null;
    }
    return null;
  }
  private wireTouched(w: readonly [number, number, number], ents: EntityView[]): boolean {
    const h = this.host, p = h.position;
    if (!h.dead && h.meta.mode !== 'spectator' && p.x > w[0] - 0.3 && p.x < w[0] + 1.3 && p.z > w[2] - 0.3 && p.z < w[2] + 1.3 && p.y < w[1] + 0.16 && p.y + this.height() > w[1]) return true;
    for (const e of ents) if (e.x > w[0] - 0.25 && e.x < w[0] + 1.25 && e.z > w[2] - 0.25 && e.z < w[2] + 1.25 && e.y < w[1] + 0.5 && e.y > w[1] - 0.6) return true;
    return false;
  }
  private tickTripwires() {
    if (!this.hooks.length) return;
    const h = this.host, ents = this.io.entities();
    for (const [x, y, z] of this.hooks) {
      const cell = h.getCell(x, y, z);
      if (blockId(cell) !== ID.tripwire_hook) continue;
      const st = blockState(cell), dir = HOOK_DIR[st & 7], k = key(x, y, z);
      if (!dir) continue;
      const line = this.tripwireLine(x, y, z, dir);
      if (line && line.wires.some(w => this.wireTouched(w, ents))) this.hookHold.set(k, this.tickCount + 10);
      const powered = (this.hookHold.get(k) ?? 0) > this.tickCount, was = (st & 8) !== 0, attached = !!line;
      if (powered !== was) {
        this.io.rsSet(x, y, z, ID.tripwire_hook, powered ? st | 8 : st & 7);
        this.io.sound('click', { x, y, z });
      }
      if (powered !== was || this.hookAttached.get(k) !== attached) this.events.emit('tripwire', { hook: [x, y, z], attached, powered });
      this.hookAttached.set(k, attached);
      if (!powered) this.hookHold.delete(k);
      // String flags for the renderer: bit 0 attached, bit 1 powered, bit 3 strung along Z (bit 2 = disarmed is kept).
      if (line) for (const w of line.wires) {
        const ws = blockState(h.getCell(w[0], w[1], w[2])), want = (ws & 4) | 1 | (powered ? 2 : 0) | (dir[0] === 0 ? 8 : 0);
        if (ws !== want) h.setBlock(w[0], w[1], w[2], ID.tripwire, want);
      }
    }
  }

  /** Comparator reading for the blocks this module owns; -1 = not ours (the engine falls back to container fullness). */
  comparatorOverride(x: number, y: number, z: number): number {
    const id = this.host.getBlock(x, y, z);
    if (id <= 0) return -1;
    if (id === ID.chiseled_bookshelf) return (this.be(x, y, z)?.last ?? -1) + 1;
    if (id === ID.sculk_sensor || id === ID.calibrated_sculk_sensor) { const be = this.be(x, y, z); return be?.phase === 1 ? be.freq ?? 0 : 0; }
    if (id === ID.cauldron) return this.cauldronAt(x, y, z)?.level ?? 0;
    return -1;
  }

  // ======================================================================================================================
  // Rendering flags
  // ======================================================================================================================
  /** Player flags for the renderer / HUD (hitbox, animation state, overlays). */
  renderState() {
    return {
      pose: this.pose, poseForced: this.poseForced, hitbox: { width: PLAYER_WIDTH, height: this.height() }, eyeHeight: this.eyeHeight(),
      using: this.use ? { item: this.use.name, kind: this.use.kind, tick: this.use.tick, total: this.use.total } : null,
      ticksFrozen: this.ticksFrozen, freezeProgress: this.ticksFrozen / FREEZE_TICKS, fullyFrozen: this.ticksFrozen >= FREEZE_TICKS,
      inPowderSnow: this.inPowderSnow, onScaffolding: this.inScaffold, bubbleColumn: this.bubble > 0 ? 'up' : this.bubble < 0 ? 'down' : null,
      saturation: this.saturation,
    };
  }
  /** Vanilla-style block state properties for one cell (what the mesher / block-entity renderer needs to know). */
  blockRenderState(x: number, y: number, z: number): Record<string, unknown> | null {
    const h = this.host, cell = h.getCell(x, y, z), id = blockId(cell), st = blockState(cell);
    if (id <= 0) return null;
    const out: Record<string, unknown> = {}, be = this.be(x, y, z), props = this.store().props.get(key(x, y, z));
    if (props?.waterlogged) out.waterlogged = true;
    if (id === ID.scaffolding) { out.distance = st & 7; out.bottom = (st & 8) !== 0; }
    else if (this.isCampfire(id)) {
      const signal = this.signalFire(x, y, z);
      Object.assign(out, { lit: id === ID.campfire, signal_fire: signal, smokeHeight: signal ? SIGNAL_SMOKE_HEIGHT : CAMPFIRE_SMOKE_HEIGHT, items: (be?.items ?? []).map(i => i?.name ?? null), cookProgress: (be?.times ?? []).map((t, i) => t / (be?.totals?.[i] || CAMPFIRE_COOK_TICKS)) });
    } else if (id === ID.cauldron) { const c = this.cauldronAt(x, y, z)!; Object.assign(out, { level: c.level, content: c.level ? ['water', 'lava', 'powder_snow'][c.content] : 'empty', color: be?.color ?? null }); }
    else if (id === ID.chiseled_bookshelf) { (be?.items ?? Array(6).fill(null)).forEach((it, i) => { out[`slot_${i}_occupied`] = !!it; }); out.last_interacted_slot = be?.last ?? -1; out.facing = st & 3; }
    else if (id === ID.sculk_sensor || id === ID.calibrated_sculk_sensor) Object.assign(out, { sculk_sensor_phase: ['inactive', 'active', 'cooldown'][be?.phase ?? 0], power: st & 15, frequency: be?.freq ?? 0, ...(props?.facing !== undefined ? { facing: FACING_NAMES[props.facing & 3] } : {}) });
    else if (id === ID.target) out.power = st & 15;
    else if (id === ID.tripwire_hook) Object.assign(out, { attached: this.hookAttached.get(key(x, y, z)) ?? false, powered: (st & 8) !== 0 });
    else if (id === ID.tripwire) Object.assign(out, { attached: (st & 1) !== 0, powered: (st & 2) !== 0, disarmed: (st & 4) !== 0, axis: st & 8 ? 'z' : 'x' });
    return Object.keys(out).length ? out : null;
  }
  hud() {
    return {
      pose: this.pose as string, freeze: this.ticksFrozen / FREEZE_TICKS, frozen: this.ticksFrozen >= FREEZE_TICKS, saturation: this.saturation,
      bubble: this.bubble as number, using: this.use ? { name: this.use.name, kind: this.use.kind as string, progress: this.useProgress() } : null,
    };
  }

  // ======================================================================================================================
  // Save / load (vanilla NBT layout)
  // ======================================================================================================================
  save(): GameplaySave {
    const Dimensions: GameplaySave['Dimensions'] = {};
    for (const [dim, s] of Object.entries(this.stores)) {
      const block_states: Record<string, Record<string, string | number | boolean>> = {};
      for (const [k, p] of s.props) {
        const o: Record<string, string | number | boolean> = {};
        if (p.waterlogged) o.waterlogged = true;
        if (p.facing !== undefined) o.facing = FACING_NAMES[p.facing & 3];
        if (Object.keys(o).length) block_states[k] = o;
      }
      const block_entities: NbtBlockEntity[] = [];
      for (const [k, be] of s.be) {
        const [x, y, z] = parse(k), n: NbtBlockEntity = { id: be.id, x, y, z, keepPacked: false };
        if (be.id === 'minecraft:campfire') { n.Items = itemsToNbt(be.items ?? []); n.CookingTimes = [...(be.times ?? [0, 0, 0, 0])]; n.CookingTotalTimes = [...(be.totals ?? [600, 600, 600, 600])]; }
        else if (be.id === 'minecraft:chiseled_bookshelf') { n.Items = itemsToNbt(be.items ?? []); n.last_interacted_slot = be.last ?? -1; }
        else if (be.id === 'minecraft:sculk_sensor' || be.id === 'minecraft:calibrated_sculk_sensor') n.last_vibration_frequency = be.freq ?? 0;
        else if (be.id === 'minecraft:cauldron') { if (be.color === undefined) continue; n.CustomColor = be.color; }
        block_entities.push(n);
      }
      // Cauldrons without a dye colour are still tracked (rain, dripstone); they are stored by position only.
      for (const [k, be] of s.be) if (be.id === 'minecraft:cauldron' && be.color === undefined) { const [x, y, z] = parse(k); block_entities.push({ id: be.id, x, y, z, keepPacked: false }); }
      if (Object.keys(block_states).length || block_entities.length) Dimensions[DIM_ID[dim] ?? dim] = { block_states, block_entities };
    }
    return {
      DataVersion: DATA_VERSION,
      Player: { UUID: uuidToIntArray(this.playerUUID), foodSaturationLevel: this.saturation, TicksFrozen: this.ticksFrozen, EnderItems: itemsToNbt(this.enderItems), enderUpdatedAt: this.enderUpdatedAt },
      Dimensions,
    };
  }

  load(save?: GameplaySave | null) {
    this.stores = {};
    this.pose = 'standing'; this.poseForced = false; this.use = null; this.bubble = 0; this.bubbleVy = 0; this.noFall = false;
    this.saturation = save?.Player?.foodSaturationLevel ?? 5;
    this.ticksFrozen = save?.Player?.TicksFrozen ?? 0;
    this.enderItems = itemsFromNbt(save?.Player?.EnderItems, 27);
    this.enderUpdatedAt = save?.Player?.enderUpdatedAt ?? 0;
    this.enderDirty = false; this.openKey = '';
    this.sensors = []; this.hooks = []; this.indexAt = -1000;
    this.targets.clear(); this.hookHold.clear(); this.hookAttached.clear(); this.scaffoldQueue.length = 0;
    const byVanilla = Object.fromEntries(Object.entries(DIM_ID).map(([k, v]) => [v, k]));
    for (const [vid, d] of Object.entries(save?.Dimensions ?? {})) {
      const s = this.store(byVanilla[vid] ?? vid);
      for (const [k, p] of Object.entries(d.block_states ?? {})) {
        const o: Props = {};
        if (p.waterlogged === true) o.waterlogged = true;
        if (typeof p.facing === 'string' && FACING_NAMES.includes(p.facing)) o.facing = FACING_NAMES.indexOf(p.facing);
        if (Object.keys(o).length) s.props.set(k, o);
      }
      for (const n of d.block_entities ?? []) {
        const be: BE = { id: n.id };
        if (n.id === 'minecraft:campfire') { be.items = itemsFromNbt(n.Items, 4); be.times = [0, 1, 2, 3].map(i => n.CookingTimes?.[i] ?? 0); be.totals = [0, 1, 2, 3].map(i => n.CookingTotalTimes?.[i] ?? CAMPFIRE_COOK_TICKS); }
        else if (n.id === 'minecraft:chiseled_bookshelf') { be.items = itemsFromNbt(n.Items, 6); be.last = n.last_interacted_slot ?? -1; }
        else if (n.id === 'minecraft:sculk_sensor' || n.id === 'minecraft:calibrated_sculk_sensor') be.freq = n.last_vibration_frequency ?? 0;
        else if (n.id === 'minecraft:cauldron') { if (n.CustomColor !== undefined) be.color = n.CustomColor; }
        else continue;
        s.be.set(key(n.x, n.y, n.z), be);
      }
    }
  }

  /** Vanilla block id for a cauldron cell (`minecraft:cauldron`, `water_cauldron`, ...), for exporters. */
  cauldronBlockId(x: number, y: number, z: number): string | null {
    const c = this.cauldronAt(x, y, z);
    return c ? (c.level ? CAULDRON_IDS[c.content] : NS + 'cauldron') : null;
  }
}
