// Decorated Pots (4-face Pottery Sherd binding) and Suspicious Sand / Gravel Archaeology Brushing.
import * as THREE from 'three';
import { canvas } from '../textures/canvas';

export const POTTERY_SHERDS: { id: string; item: string; ja: string; en: string; motif: string[] }[] = [
  { id: 'archer', item: 'archer_pottery_sherd', ja: '射手の壺の欠片', en: 'Archer Pottery Sherd', motif: ['00111000','01001100','11111110','01001100','00111000'] },
  { id: 'arms_up', item: 'arms_up_pottery_sherd', ja: 'バンザイの壺の欠片', en: 'Arms Up Pottery Sherd', motif: ['10011001','10011001','11111111','00111100','00100100'] },
  { id: 'brewer', item: 'brewer_pottery_sherd', ja: '醸造家の壺の欠片', en: 'Brewer Pottery Sherd', motif: ['00011000','00011000','01111110','11111111','01111110'] },
  { id: 'burn', item: 'burn_pottery_sherd', ja: '炎の壺の欠片', en: 'Burn Pottery Sherd', motif: ['00100100','01101110','11111111','11111111','01111110'] },
  { id: 'danger', item: 'danger_pottery_sherd', ja: '危険の壺の欠片', en: 'Danger Pottery Sherd', motif: ['01100110','11111111','01111110','10100101','01000010'] },
  { id: 'explorer', item: 'explorer_pottery_sherd', ja: '探検家の壺の欠片', en: 'Explorer Pottery Sherd', motif: ['00111100','01000010','10011001','01000010','00111100'] },
  { id: 'friend', item: 'friend_pottery_sherd', ja: '友の壺の欠片', en: 'Friend Pottery Sherd', motif: ['01100110','01100110','11111111','01011010','01000010'] },
  { id: 'heart', item: 'heart_pottery_sherd', ja: 'ハートの壺の欠片', en: 'Heart Pottery Sherd', motif: ['01100110','11111111','11111111','01111110','00011000'] },
  { id: 'heartbreak', item: 'heartbreak_pottery_sherd', ja: '傷心の壺の欠片', en: 'Heartbreak Pottery Sherd', motif: ['01100110','11101111','11010111','01101110','00010000'] },
  { id: 'howl', item: 'howl_pottery_sherd', ja: '遠吠えの壺の欠片', en: 'Howl Pottery Sherd', motif: ['00001110','00011111','01111100','11111000','10010000'] },
  { id: 'miner', item: 'miner_pottery_sherd', ja: '鉱夫の壺の欠片', en: 'Miner Pottery Sherd', motif: ['01111110','11011011','00011000','00011000','00011000'] },
  { id: 'mourner', item: 'mourner_pottery_sherd', ja: '悲嘆の壺の欠片', en: 'Mourner Pottery Sherd', motif: ['00111100','01011010','01111110','00100100','01100110'] },
  { id: 'plenty', item: 'plenty_pottery_sherd', ja: '豊穣の壺の欠片', en: 'Plenty Pottery Sherd', motif: ['01111110','10000001','11111111','11111111','01111110'] },
  { id: 'prize', item: 'prize_pottery_sherd', ja: '宝物の壺の欠片', en: 'Prize Pottery Sherd', motif: ['00111100','01111110','11111111','01111110','00111100'] },
  { id: 'sheaf', item: 'sheaf_pottery_sherd', ja: '麦束の壺の欠片', en: 'Sheaf Pottery Sherd', motif: ['10100101','01111110','00111100','01111110','10100101'] },
  { id: 'shelter', item: 'shelter_pottery_sherd', ja: '木陰の壺の欠片', en: 'Shelter Pottery Sherd', motif: ['00111100','01111110','11111111','00011000','00011000'] },
  { id: 'skull', item: 'skull_pottery_sherd', ja: 'ドクロの壺の欠片', en: 'Skull Pottery Sherd', motif: ['01111110','11011011','11111111','01011010','01011010'] },
  { id: 'snort', item: 'snort_pottery_sherd', ja: '鼻息の壺の欠片', en: 'Snort Pottery Sherd', motif: ['01111110','11111111','10111101','11111111','01000010'] },
];

export const EXTRA_SHERDS_121: { id: string; item: string; ja: string; en: string; motif: string[] }[] = [
  { id: 'angler', item: 'angler_pottery_sherd', ja: '釣り人の壺の欠片', en: 'Angler Pottery Sherd', motif: ['00111000','01000100','01011100','00010000','00111000'] },
  { id: 'blade', item: 'blade_pottery_sherd', ja: '刃の壺の欠片', en: 'Blade Pottery Sherd', motif: ['00000110','00001100','00011000','01110000','11000000'] },
  { id: 'flow', item: 'flow_pottery_sherd', ja: '流れの壺の欠片', en: 'Flow Pottery Sherd', motif: ['00111100','01000010','00111100','01000010','00111100'] },
  { id: 'guster', item: 'guster_pottery_sherd', ja: '突風の壺の欠片', en: 'Guster Pottery Sherd', motif: ['11111110','00111100','01111110','00011000','00010000'] },
  { id: 'scrape', item: 'scrape_pottery_sherd', ja: '削りの壺の欠片', en: 'Scrape Pottery Sherd', motif: ['10101010','01010101','10101010','01010101','10101010'] },
];

const ALL_SHERDS = [...POTTERY_SHERDS, ...EXTRA_SHERDS_121];

export const isPotSideItem = (name: string): boolean => name === 'brick' || ALL_SHERDS.some(s => s.item === name);
export const sherdDef = (name: string) => ALL_SHERDS.find(s => s.item === name || s.id === name);

/**
 * Checks a 3×3 crafting grid (row-major 0..8) for the rhombic Decorated Pot recipe:
 * top (1) = back, left (3) = left, right (5) = right, bottom (7) = front, all other slots empty.
 */
export function matchDecoratedPotRecipe(cells: (string | null)[]): [string, string, string, string] | null {
  if (cells.length !== 9) return null;
  for (const emptyIdx of [0, 2, 4, 6, 8]) if (cells[emptyIdx]) return null;
  const top = cells[1], left = cells[3], right = cells[5], bottom = cells[7];
  if (!top || !left || !right || !bottom) return null;
  if (![top, left, right, bottom].every(isPotSideItem)) return null;
  return [top, left, right, bottom];
}

/** Paints a 16×16 terracotta pot face with the sherd relief motif (or plain brick wall when `side === "brick"`). */
export function paintPotFace(ctx: CanvasRenderingContext2D, side: string) {
  ctx.fillStyle = '#8a4c36';
  ctx.fillRect(0, 0, 16, 16);
  ctx.fillStyle = '#703b28';
  ctx.fillRect(0, 0, 16, 2);
  ctx.fillRect(0, 14, 16, 2);
  ctx.fillRect(0, 0, 1, 16);
  ctx.fillRect(15, 0, 1, 16);
  const def = sherdDef(side);
  if (!def) return;
  ctx.fillStyle = '#c47452';
  ctx.fillRect(2, 3, 12, 10);
  ctx.fillStyle = '#562818';
  def.motif.forEach((row, ry) => {
    [...row].forEach((ch, rx) => {
      if (ch === '1') ctx.fillRect(4 + rx, 5 + ry, 1, 1);
    });
  });
}

const faceTexCache = new Map<string, THREE.CanvasTexture>();
function potFaceTexture(side: string): THREE.CanvasTexture {
  let tex = faceTexCache.get(side);
  if (!tex) {
    const cv = canvas(16, 16) as unknown as HTMLCanvasElement;
    paintPotFace(cv.getContext('2d')!, side);
    tex = new THREE.CanvasTexture(cv);
    tex.magFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    faceTexCache.set(side, tex);
  }
  return tex;
}

/** Manages placed Decorated Pots that have custom 4-side Pottery Sherd textures `[back, left, right, front]`. */
export class DecoratedPotMeshes {
  private meshes = new Map<string, THREE.Mesh>();
  private geo = new THREE.BoxGeometry(0.88, 0.88, 0.88);
  constructor(private scene: THREE.Scene) {}

  set(key: string, x: number, y: number, z: number, sherds: string[], yaw = 0) {
    this.remove(key);
    const [back = 'brick', left = 'brick', right = 'brick', front = 'brick'] = sherds;
    const topMat = new THREE.MeshLambertMaterial({ color: '#703b28' });
    // BoxGeometry material order: [+X (right), -X (left), +Y (top), -Y (bottom), +Z (front), -Z (back)]
    const mats = [
      new THREE.MeshLambertMaterial({ map: potFaceTexture(right) }),
      new THREE.MeshLambertMaterial({ map: potFaceTexture(left) }),
      topMat,
      topMat,
      new THREE.MeshLambertMaterial({ map: potFaceTexture(front) }),
      new THREE.MeshLambertMaterial({ map: potFaceTexture(back) }),
    ];
    const mesh = new THREE.Mesh(this.geo, mats as unknown as THREE.Material);
    mesh.position.set(x + 0.5, y + 0.44, z + 0.5);
    mesh.rotation.y = yaw;
    this.scene.add(mesh);
    this.meshes.set(key, mesh);
  }

  remove(key: string) {
    const m = this.meshes.get(key);
    if (!m) return;
    this.scene.remove(m);
    this.meshes.delete(key);
  }

  clear() { for (const k of [...this.meshes.keys()]) this.remove(k); }
  get size() { return this.meshes.size; }
}

/** Archaeological loot pool extracted when brushing Suspicious Sand / Suspicious Gravel completes (stage 3 -> extracted). */
export const ARCHAEOLOGY_LOOT: string[] = [
  ...ALL_SHERDS.map(s => s.item),
  'emerald',
  'diamond',
  'music_disc_relic',
  'wayfinder_armor_trim_smithing_template',
  'shaper_armor_trim_smithing_template',
  'raiser_armor_trim_smithing_template',
  'host_armor_trim_smithing_template',
];

export function pickArchaeologyLoot(x: number, y: number, z: number): string {
  const h = Math.abs(Math.imul(x * 73856093 ^ y * 19349663 ^ z * 83492791, 2654435761)) >>> 0;
  return ARCHAEOLOGY_LOOT[h % ARCHAEOLOGY_LOOT.length];
}

export const DEFAULT_SHERDS: [string, string, string, string] = ["brick", "brick", "brick", "brick"];
