// 作業B: Java Edition 1.21 の爆発（ServerExplosion）を純粋関数で再現する。
// 出典: Minecraft Wiki — Explosion（Block destruction / Exposure / Damage / Dropping blocks）, 各ブロックの Blast resistance。
import { BLOCKS, ID, type BlockDef } from '../game/data';
import type { AABB } from './combatRules';

/**
 * Blast resistance by block name (Wiki infoboxes). Blocks not listed fall back to their hardness, which matches Java's
 * `BlockBehaviour.Properties.strength(h)` (resistance = hardness) for most blocks — explicit entries cover the exceptions.
 */
const RESISTANCE: Record<string, number> = {
  air: 0, water: 100, lava: 100, bedrock: 3600000, end_portal_frame: 3600000, end_portal: 3600000, end_gateway: 3600000,
  barrier: 3600000.8, command_block: 3600000, structure_block: 3600000, jigsaw: 3600000, light: 3600000.8, reinforced_deepslate: 1200,
  obsidian: 1200, crying_obsidian: 1200, ancient_debris: 1200, netherite_block: 1200, respawn_anchor: 1200, anvil: 1200,
  chipped_anvil: 1200, damaged_anvil: 1200, enchanting_table: 1200, ender_chest: 600,
  stone: 6, cobblestone: 6, mossy_cobblestone: 6, stone_bricks: 6, mossy_stone_bricks: 6, cracked_stone_bricks: 6, chiseled_stone_bricks: 6,
  smooth_stone: 6, bricks: 6, andesite: 6, diorite: 6, granite: 6, polished_andesite: 6, polished_diorite: 6, polished_granite: 6,
  deepslate: 6, cobbled_deepslate: 6, deepslate_bricks: 6, deepslate_tiles: 6, polished_deepslate: 6, tuff: 6, calcite: 0.75,
  iron_block: 6, gold_block: 6, diamond_block: 6, emerald_block: 6, copper_block: 6, lapis_block: 3, redstone_block: 6, coal_block: 6,
  nether_bricks: 6, red_nether_bricks: 6, blackstone: 6, polished_blackstone: 6, polished_blackstone_bricks: 6, basalt: 4.2,
  end_stone: 9, end_stone_bricks: 9, purpur_block: 6, purpur_pillar: 6, prismarine: 6, prismarine_bricks: 6, dark_prismarine: 6,
  netherrack: 0.4, soul_sand: 0.5, soul_soil: 0.5, glowstone: 0.3, sea_lantern: 0.3, glass: 0.3, glass_pane: 0.3, ice: 0.5, packed_ice: 0.5,
  blue_ice: 2.8, dirt: 0.5, grass_block: 0.6, sand: 0.5, red_sand: 0.5, gravel: 0.6, clay: 0.6, snow_block: 0.2, snow: 0.1,
  tnt: 0, oak_leaves: 0.2, birch_leaves: 0.2, cobweb: 4, iron_bars: 6, iron_door: 5, chest: 2.5, trapped_chest: 2.5, barrel: 2.5,
  furnace: 3.5, crafting_table: 2.5, sandstone: 0.8, red_sandstone: 0.8, terracotta: 4.2, wool: 0.8, hay_block: 0.5, sponge: 0.6,
  pumpkin: 1, melon: 1, beacon: 3, conduit: 3, spawner: 5, bookshelf: 1.5, mud_bricks: 3, packed_mud: 3, amethyst_block: 1.5,
};
const resCache: number[] = [];
export function blastResistance(id: number): number {
  if (id <= 0) return 0;
  const c = resCache[id];
  if (c !== undefined) return c;
  const def: BlockDef | undefined = BLOCKS[id];
  let r = 0;
  if (def) {
    if (RESISTANCE[def.name] !== undefined) r = RESISTANCE[def.name];
    else if (!Number.isFinite(def.hardness)) r = 3600000;
    else if (/_ore$/.test(def.name)) r = 3;
    else if (/_wool$/.test(def.name)) r = 0.8;
    else if (/_concrete$/.test(def.name)) r = 1.8;
    else if (/_terracotta$/.test(def.name)) r = 4.2;
    else if (/_leaves$/.test(def.name)) r = 0.2;
    else if (/(_planks|_log|_wood|_stairs|_slab|_fence)$/.test(def.name) && def.tool === 'axe') r = 3;
    else r = Math.max(0, def.hardness);
  }
  resCache[id] = r;
  return r;
}
/** Fluids are never destroyed (their FluidState resistance of 100 also dampens the ray). Unbreakable blocks never break. */
const explodableCache: boolean[] = [];
export function explodable(id: number): boolean {
  if (id <= 0 || id === ID.water || id === ID.lava) return false;
  const c = explodableCache[id];
  if (c !== undefined) return c;
  const def = BLOCKS[id];
  const ok = !!def && Number.isFinite(def.hardness) && blastResistance(id) < 3600000;
  explodableCache[id] = ok;
  return ok;
}

/** Precomputed 1,352 unit direction vectors to the outer shell of the 16x16x16 ServerExplosion cube. */
const EXPLOSION_RAYS: Float64Array = (() => {
  const arr: number[] = [];
  for (let i = 0; i < 16; i++) for (let j = 0; j < 16; j++) for (let k = 0; k < 16; k++) {
    if (i !== 0 && i !== 15 && j !== 0 && j !== 15 && k !== 0 && k !== 15) continue;
    const dx = i / 15 * 2 - 1, dy = j / 15 * 2 - 1, dz = k / 15 * 2 - 1;
    const len = Math.hypot(dx, dy, dz);
    arr.push(dx / len, dy / len, dz / len);
  }
  return new Float64Array(arr);
})();

/**
 * ServerExplosion.calculateExplodedPositions: rays to the outer cells of a 16³ grid, intensity = power × (0.7 … 1.3),
 * step 0.3 blocks: intensity −= (resistance + 0.3) × 0.3 at non-air blocks, then −= 0.22500001 per step.
 * Returns unique block positions in discovery order (`rnd` drives the per-ray randomness: deterministic in tests).
 */
export function explosionBlocks(getBlock: (x: number, y: number, z: number) => number, cx: number, cy: number, cz: number, power: number, rnd: () => number = Math.random): [number, number, number][] {
  const out: [number, number, number][] = [], seen = new Set<number>();
  const rays = EXPLOSION_RAYS, nRays = rays.length;
  for (let r = 0; r < nRays; r += 3) {
    const dx = rays[r], dy = rays[r + 1], dz = rays[r + 2];
    let intensity = power * (0.7 + rnd() * 0.6), x = cx, y = cy, z = cz;
    while (intensity > 0) {
      const bx = Math.floor(x), by = Math.floor(y), bz = Math.floor(z), id = getBlock(bx, by, bz);
      if (id > 0) intensity -= (blastResistance(id) + 0.3) * 0.3;
      if (intensity > 0 && explodable(id)) {
        const key = ((bx + 1048576) * 2097152 + (bz + 1048576)) * 512 + (by + 64);
        if (!seen.has(key)) { seen.add(key); out.push([bx, by, bz]); }
      }
      x += dx * 0.3; y += dy * 0.3; z += dz * 0.3;
      intensity -= 0.22500001;
    }
  }
  return out;
}

/** True when the segment a→b crosses a collidable block (full-cube approximation of the collision shape). */
export function segmentBlocked(getBlock: (x: number, y: number, z: number) => number, ax: number, ay: number, az: number, bx: number, by: number, bz: number): boolean {
  const dx = bx - ax, dy = by - ay, dz = bz - az, len = Math.hypot(dx, dy, dz);
  if (len < 1e-9) return false;
  const ux = dx / len, uy = dy / len, uz = dz / len;
  let x = Math.floor(ax), y = Math.floor(ay), z = Math.floor(az);
  const ex = Math.floor(bx), ey = Math.floor(by), ez = Math.floor(bz);
  const sx = ux > 0 ? 1 : -1, sy = uy > 0 ? 1 : -1, sz = uz > 0 ? 1 : -1;
  const tdx = Math.abs(1 / (ux || 1e-12)), tdy = Math.abs(1 / (uy || 1e-12)), tdz = Math.abs(1 / (uz || 1e-12));
  let tmx = (ux > 0 ? x + 1 - ax : ax - x) * tdx, tmy = (uy > 0 ? y + 1 - ay : ay - y) * tdy, tmz = (uz > 0 ? z + 1 - az : az - z) * tdz;
  for (let n = 0; n < 512; n++) {
    const id = getBlock(x, y, z);
    if (id > 0 && BLOCKS[id]?.solid) return true;
    if (x === ex && y === ey && z === ez) return false;
    if (tmx < tmy && tmx < tmz) { if (tmx > len) return false; x += sx; tmx += tdx; }
    else if (tmy < tmz) { if (tmy > len) return false; y += sy; tmy += tdy; }
    else { if (tmz > len) return false; z += sz; tmz += tdz; }
  }
  return false;
}

/** Explosion.getSeenPercent: sample grid over the entity box, rays to the centre, fraction unobstructed. */
export function exposure(getBlock: (x: number, y: number, z: number) => number, cx: number, cy: number, cz: number, b: AABB): number {
  const d0 = 1 / ((b.maxX - b.minX) * 2 + 1), d1 = 1 / ((b.maxY - b.minY) * 2 + 1), d2 = 1 / ((b.maxZ - b.minZ) * 2 + 1);
  const d3 = (1 - Math.floor(1 / d0) * d0) / 2, d4 = (1 - Math.floor(1 / d2) * d2) / 2;
  let seen = 0, total = 0;
  for (let a = 0; a <= 1; a += d0) for (let c = 0; c <= 1; c += d1) for (let e = 0; e <= 1; e += d2) {
    const x = b.minX + (b.maxX - b.minX) * a + d3, y = b.minY + (b.maxY - b.minY) * c, z = b.minZ + (b.maxZ - b.minZ) * e + d4;
    if (!segmentBlocked(getBlock, x, y, z, cx, cy, cz)) seen++;
    total++;
  }
  return total ? seen / total : 0;
}

/** impact = (1 − dist / 2P) × exposure; damage = (impact² + impact) / 2 × 7 × 2P + 1. 0 outside 2P. */
export function explosionImpact(power: number, dist: number, exp: number): number {
  const q = dist / (2 * power);
  return q > 1 ? 0 : (1 - q) * exp;
}
export function explosionDamage(power: number, dist: number, exp: number): number {
  if (dist / (2 * power) > 1) return 0;
  const i = explosionImpact(power, dist, exp);
  return (i * i + i) / 2 * 7 * (2 * power) + 1;
}
/** Player damage per difficulty (Wiki Explosion › Damage). */
export function scaleForDifficulty(dmg: number, difficulty: string): number {
  if (difficulty === 'peaceful') return 0;
  if (difficulty === 'easy') return Math.min(dmg / 2 + 1, dmg);
  if (difficulty === 'hard') return dmg * 1.5;
  return dmg;
}
/** Knockback magnitude in blocks/tick: impact × multiplier × (1 − explosion_knockback_resistance). Blast Protection: 0.15 / level (1.21, 未確認). */
export const explosionKnockback = (impact: number, ekr = 0, multiplier = 1) => impact * multiplier * (1 - Math.min(1, Math.max(0, ekr)));

export type ExplosionKind = 'tnt' | 'mob' | 'block';
export interface DropRules { tntExplosionDropDecay?: boolean; mobExplosionDropDecay?: boolean; blockExplosionDropDecay?: boolean }
/** Drop chance of a destroyed block: 1/power when the kind's *ExplosionDropDecay game rule is on (TNT: off by default). */
export function dropChance(kind: ExplosionKind, power: number, rules: DropRules = {}): number {
  const decay = kind === 'tnt' ? rules.tntExplosionDropDecay === true : kind === 'mob' ? rules.mobExplosionDropDecay !== false : rules.blockExplosionDropDecay !== false;
  return decay ? 1 / power : 1;
}
/** Blocks that always drop regardless of decay (Wiki): dragon egg, beacon, conduit, heads, shulker boxes, decorated pots. */
export const ALWAYS_DROP = /^(dragon_egg|beacon|conduit|decorated_pot)$|_head$|_skull$|shulker_box$/;
/** PrimedTnt.wasExploded: fuse = nextInt(80 / 4) + 80 / 8 → 10‥29 ticks. Returns seconds. */
export const chainFuseSeconds = (rnd: () => number = Math.random) => (Math.floor(rnd() * 20) + 10) / 20;
export const TNT_FUSE_SECONDS = 80 / 20;
