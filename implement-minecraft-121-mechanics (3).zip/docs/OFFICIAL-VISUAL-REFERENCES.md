# Official Visual References

## Primary Sources

Official web materials were checked before implementing the effects. The actual official Java sprite images were also downloaded from Mojang's distribution service and visually inspected, rather than relying only on third-party descriptions.

1. [Minecraft: Nether Update out today on Java](https://www.minecraft.net/en-us/article/nether-update-java): the Nether biomes, falling white ash in Basalt Deltas, falling ash and blue atmosphere in Soul Sand Valleys.
2. [Minecraft Snapshot 20w15a](https://www.minecraft.net/en-us/article/minecraft-snapshot-20w15a): the appearance of Basalt Deltas and flowing flakes of white ash.
3. [Around the Block: Soul Sand Valley](https://www.minecraft.net/en-us/article/around-block--soul-sand-valley): the official biome imagery and its cyan, haunted atmosphere.
4. [Caves & Cliffs: Part II out today on Java](https://www.minecraft.net/en-us/article/caves---cliffs--part-ii-out-today-java): snowy slopes, groves, frozen peaks and jagged peaks.
5. [Mojang's official version manifest](https://piston-meta.mojang.com/mc/game/version_manifest_v2.json): version 1.21.1 was selected as the stable Java visual reference.
6. [Official Java 1.21.1 client](https://piston-data.mojang.com/v1/objects/30c73b1c5da787909b2f73340419fdf13b9def88/client.jar): SHA-1 `30c73b1c5da787909b2f73340419fdf13b9def88`, independently matched after download.

Minecraft.net article text was obtained through web search. Its page-fetch endpoint was unavailable in this environment. Official sprite images were obtained directly from the Mojang-hosted client, and an enlarged contact sheet was inspected during development.

## Sprite Inspection

The following files inside the official client were examined. The client archive and the extracted official textures are not redistributed in the release ZIP.

| Effect | Official Java particle definition | Official texture inspected | Implementation |
| --- | --- | --- | --- |
| Critical | `crit.json` | `critical_hit.png` | Warm tan, diagonal cross/star silhouette; short outward burst and damping |
| Enchanted hit | `enchanted_hit.json` | `enchanted_hit.png` | Pale cyan cross/ring spark; not a large sweeping-attack arc |
| Potion | `entity_effect.json` | `effect_7.png` through `effect_0.png` | Animated pixel spiral; effect-color blending; rising orbit following the entity |
| Portal | `portal.json` | `generic_0.png` through `generic_7.png` | Purple growing motes; eased inward attraction |
| Lava | `lava.json` | `lava.png` | Bright orange/yellow particle; upward pop and gravity |
| Dripping fluids | `dripping_water.json`, `dripping_lava.json` | `drip_hang.png`, `drip_fall.png`, `drip_land.png` | Hanging, falling and landing stages; blue water and bright orange lava |
| Rain impact | `rain.json` | `splash_0.png` through `splash_3.png` | Small, animated blue splash on exposed solid blocks |
| Happy villager | `happy_villager.json` | `glint.png` | Green four-point glint, not a green debris cube |
| Nether atmosphere | `white_ash.json`, `ash.json`, `crimson_spore.json`, `warped_spore.json` | `generic_0.png` | Biome-specific density, color, drift and vertical motion |
| Snow | Environment texture | `textures/environment/snow.png` | White pixel flakes with slow falling motion and lateral drift |

## Fidelity Notes

- This is an unofficial, browser-oriented visual reimplementation. Particle masks are newly drawn; neither Java source nor the official client is included.
- Legacy request names are preserved as public API names: `mobSpell` corresponds to Java's `entity_effect`, `lava_pop` to `lava`, `drip_water` / `drip_lava` to dripping fluid particles, and `rain_splash` to rain impact sprites.
- The Soul Sand Valley uses low-saturation blue-gray ash against cyan fog. Official Java uses `ash` here; neon-blue soul-fire sparks would be a different effect. Basalt Deltas use falling white ash.
- The rendering-only temperature lookup supports every cold biome in the existing generator, namespaced biome IDs, dry-biome suppression and altitude cooling. It does not reproduce Java's temperature-noise function and never changes generated blocks or accumulates snow layers.
- Rain and snow are sampled at each precipitation column's surface. Roof heights clip precipitation in the GPU shader. Splashes use the actual column biome and reject fluids, unloaded columns and snow.
- FOV uses Java-inspired movement-speed multiplication and a squared bow-charge curve, with a single frame-rate-independent camera update. The existing underwater narrowing is preserved, and spyglass zoom has priority.
- Geometry is pooled, textures and materials are shared, ambient work is budgeted, and resources are disposed. Particle motion is not a gameplay or terrain-generation modification.

Minecraft and its official assets belong to Mojang Studios / Microsoft. This project is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.