/*
 * Work A — random ticks, crop growth, weather, sleep and moon phase against Java Edition 1.21 (logic only, seeded RNG).
 * Run: npx tsx scripts/test-world-ticks.ts
 */
import '../src/game/content';
import { ID } from '../src/game/data';
import { Farming, type FarmHost } from '../src/systems/farming';
import { random } from '../src/input/math';
import * as WC from '../src/game/worldClock';

const results: { name: string; ok: boolean }[] = [];
function check(name: string, ok: boolean, info = '') {
  results.push({ name, ok });
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? '  — ' + info : ''}`);
}
const rel = (a: number, b: number) => Math.abs(a - b) / b;
const K = (x: number, y: number, z: number) => `${x},${y},${z}`;
class World implements FarmHost {
  cells = new Map<string, number>();
  growthAt = new Map<string, number>();
  tick = () => 0;
  getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) { const c = id === 0 ? 0 : id | (state << 12); if (c === 0) this.cells.delete(K(x, y, z)); else this.cells.set(K(x, y, z), c); return true; }
  put(x: number, y: number, z: number, name: string, state = 0) { this.setBlock(x, y, z, ID[name], state); }
  state(x: number, y: number, z: number) { return this.getCell(x, y, z) >>> 12; }
  daylight() { return 1; }
  raining() { return false; }
}
/** Java: every block is picked randomTickSpeed / 4096 times per tick → 4096 / 3 ticks ≈ 68.27 s between random ticks. */
const MEAN_TICKS = 4096 / 3;

// ---- 1. Per-block random tick rate ---------------------------------------------------------------------------------------------
class Counting extends Farming {
  hits = new Map<string, number>();
  randomTick(x: number, y: number, z: number) { const k = K(x, y, z); this.hits.set(k, (this.hits.get(k) ?? 0) + 1); }
}
function rate(speed: number, ticks: number, n = 1000) {
  const w = new World();
  for (let i = 0; i < n; i++) w.put(i, 0, 0, 'farmland', 7);
  const f = new Counting(w, random(7 + speed));
  f.speed = speed;
  for (let i = 0; i < n; i++) f.register(i, 0, 0);
  for (let t = 0; t < ticks; t++) f.gameTick();
  let total = 0; for (const v of f.hits.values()) total += v;
  return { perBlockPerTick: total / n / ticks, hitBlocks: f.hits.size, total };
}
{
  const r3 = rate(3, 40000);
  const interval = 1 / r3.perBlockPerTick;
  check('random ticks: each block ≈ every 4096 / 3 = 1365.3 ticks (68.27 s) at randomTickSpeed 3', rel(interval, MEAN_TICKS) < 0.03,
    `${interval.toFixed(1)} ticks = ${(interval / 20).toFixed(2)} s (${r3.total} hits over 1000 blocks × 40 000 ticks)`);
  const r30 = rate(30, 8000), r0 = rate(0, 4000);
  check('randomTickSpeed scales the rate (30 → 10×, 0 → none)', rel(r30.perBlockPerTick / r3.perBlockPerTick, 10) < 0.05 && r0.total === 0, `30: ${(1 / r30.perBlockPerTick).toFixed(1)} ticks, 0: ${r0.total} hits`);
  check('every registered block gets random ticks (uniform choice)', r3.hitBlocks > 990, `${r3.hitBlocks} / 1000 blocks hit`);
}

// ---- 2. Crops: growthChance once per random tick, no ×0.65 -------------------------------------------------------------------------
{
  // 7 × 7 isolated wheat crops on moist farmland: points = 1 + 3 → 1 / (floor(25 / 4) + 1) = 1/7 per random tick, 7 stages
  const w = new World(), f = new Farming(w, random(2024));
  const crops: [number, number][] = [];
  for (let i = 0; i < 7; i++) for (let j = 0; j < 7; j++) {
    const x = i * 6, z = j * 6;
    w.put(x, 0, z, 'farmland', 7); w.put(x + 2, 0, z, 'water'); w.put(x, 1, z, 'wheat_crop', 0);
    f.register(x, 0, z); f.register(x, 1, z); crops.push([x, z]);
  }
  const chance = f.growthChance(0, 1, 0, ID.wheat_crop);
  const done = new Map<string, number>();
  for (let t = 0; t < 600000 && done.size < crops.length; t++) {
    f.gameTick();
    if (t % 20 === 0) for (const [x, z] of crops) if (!done.has(K(x, 1, z)) && w.state(x, 1, z) >= 7) done.set(K(x, 1, z), f.ticks);
  }
  const mean = [...done.values()].reduce((a, b) => a + b, 0) / done.size, expected = 7 / chance * MEAN_TICKS;
  check('wheat on moist farmland: expected 7 / (1/7) random ticks ≈ 55.8 min (Monte Carlo, 49 crops)', done.size === 49 && rel(mean, expected) < 0.15,
    `chance ${chance.toFixed(4)}, mean ${(mean / 20 / 60).toFixed(1)} min vs expected ${(expected / 20 / 60).toFixed(1)} min`);
}
{
  const w = new World();
  w.put(0, 0, 0, 'farmland', 7); w.put(0, 1, 0, 'beetroots', 0); w.put(5, 0, 0, 'soul_sand'); w.put(5, 1, 0, 'nether_wart', 0);
  const f = new Farming(w, random(5));
  let beet = 0, wart = 0;
  const N = 60000;
  for (let i = 0; i < N; i++) {
    w.put(0, 1, 0, 'beetroots', 0); f.randomTick(0, 1, 0); if (w.state(0, 1, 0) > 0) beet++;
    w.put(5, 1, 0, 'nether_wart', 0); f.randomTick(5, 1, 0); if (w.state(5, 1, 0) > 0) wart++;
  }
  const beetWant = (2 / 3) * f.growthChance(0, 1, 0, ID.beetroots);
  check('beetroots grow with 2/3 × the crop chance (1 random tick in 3 is skipped)', rel(beet / N, beetWant) < 0.06, `${(beet / N).toFixed(4)} vs ${beetWant.toFixed(4)}`);
  check('nether wart grows with 1/10 per random tick', rel(wart / N, 0.1) < 0.05, `${(wart / N).toFixed(4)}`);
}

// ---- 3. Saplings, sugar cane / cactus, bamboo, berries, cocoa ---------------------------------------------------------------------
{
  const w = new World(); w.put(0, 0, 0, 'grass_block');
  const f = new Farming(w, random(11));
  let adv = 0; const N = 70000;
  for (let i = 0; i < N; i++) { w.put(0, 1, 0, 'oak_sapling', 0); f.randomTick(0, 1, 0); if ((w.state(0, 1, 0) & 1) === 1) adv++; }
  check('sapling: 1/7 per random tick per stage (two stages → tree)', rel(adv / N, 1 / 7) < 0.04, `${(adv / N).toFixed(4)} (1/7 = 0.1429)`);
}
{
  const w = new World(); w.put(0, 0, 0, 'sand'); w.put(1, 0, 0, 'water'); w.put(0, 1, 0, 'sugar_cane', 0);
  const f = new Farming(w, random(3));
  for (let i = 0; i < 15; i++) f.randomTick(0, 1, 0);
  const before = w.getCell(0, 2, 0);
  f.randomTick(0, 1, 0);
  check('sugar cane: age 0–15, grows one block on the 16th random tick of the top block', before === 0 && (w.getCell(0, 2, 0) & 4095) === ID.sugar_cane && w.state(0, 1, 0) === 0);
  for (let i = 0; i < 16; i++) f.randomTick(0, 2, 0);
  for (let i = 0; i < 40; i++) f.randomTick(0, 3, 0);
  check('sugar cane stops at 3 blocks', (w.getCell(0, 3, 0) & 4095) === ID.sugar_cane && w.getCell(0, 4, 0) === 0);
  // Monte Carlo through the tick loop: 300 cactus columns, mean time to the first growth ≈ 16 × 68.27 s ≈ 18.2 min
  const w2 = new World(), f2 = new Farming(w2, random(77));
  for (let i = 0; i < 300; i++) { w2.put(i * 2, 0, 0, 'sand'); w2.put(i * 2, 1, 0, 'cactus', 0); f2.register(i * 2, 1, 0); }
  const grown = new Map<number, number>();
  for (let t = 0; t < 200000 && grown.size < 300; t++) {
    f2.gameTick();
    if (t % 20 === 0) for (let i = 0; i < 300; i++) if (!grown.has(i) && w2.getCell(i * 2, 2, 0) !== 0) grown.set(i, f2.ticks);
  }
  const mean = [...grown.values()].reduce((a, b) => a + b, 0) / grown.size;
  check('cactus: mean time to grow one block ≈ 16 random ticks ≈ 18.2 min (Monte Carlo, 300 columns)', grown.size === 300 && rel(mean, 16 * MEAN_TICKS) < 0.06, `${(mean / 1200).toFixed(1)} min`);
}
{
  const w = new World(), f = new Farming(w, random(9));
  const N = 60000;
  let bamboo = 0, berry = 0, cocoa = 0, vine = 0;
  w.put(0, 0, 0, 'grass_block'); w.put(3, 0, 0, 'grass_block'); w.put(6, 5, 0, 'jungle_log');
  for (let i = 0; i < N; i++) {
    w.put(0, 1, 0, 'bamboo', 0); w.setBlock(0, 2, 0, 0); f.randomTick(0, 1, 0); if (w.getCell(0, 2, 0) !== 0) bamboo++;
    w.put(3, 1, 0, 'sweet_berry_bush', 0); f.randomTick(3, 1, 0); if (w.state(3, 1, 0) > 0) berry++;
    w.put(7, 5, 0, 'cocoa', 0); f.randomTick(7, 5, 0); if (w.state(7, 5, 0) > 0) cocoa++;
    w.put(9, 5, 0, 'vine', 0); w.setBlock(9, 4, 0, 0); f.randomTick(9, 5, 0); if (w.getCell(9, 4, 0) !== 0) vine++;
  }
  check('bamboo: 1/3 per random tick (light ≥ 9, air above)', rel(bamboo / N, 1 / 3) < 0.03, (bamboo / N).toFixed(4));
  check('sweet berry bush: 1/5 per random tick', rel(berry / N, 0.2) < 0.04, (berry / N).toFixed(4));
  check('cocoa: 1/5 per random tick (ages 0–2)', rel(cocoa / N, 0.2) < 0.04, (cocoa / N).toFixed(4));
  check('vine growing down: 1/4 × 1/6 × 1/2 = 1/48 (other directions not modelled)', rel(vine / N, 1 / 48) < 0.12, (vine / N).toFixed(4));
  w.put(20, 0, 0, 'grass_block');
  for (let y = 1; y <= 15; y++) w.put(20, y, 0, 'bamboo', 0);
  for (let i = 0; i < 300; i++) f.randomTick(20, 15, 0);
  check('bamboo stops at 16 blocks', (w.getCell(20, 16, 0) & 4095) === ID.bamboo && w.getCell(20, 17, 0) === 0);
}

// ---- 4. Weather cycle ---------------------------------------------------------------------------------------------------------------
{
  const c = new WC.WeatherCycle(), rng = random(4242);
  const rain: number[] = [], clear: number[] = [], thunderOn: number[] = [];
  let run = 0, last = c.raining, tRun = 0, tLast = c.thundering, stormWhileDry = 0;
  for (let t = 0; t < 30_000_000; t++) {
    c.tick(rng);
    if (c.state === 'storm' && !c.raining) stormWhileDry++;
    if (c.raining !== last) { if (t > 200000) (last ? rain : clear).push(run); run = 0; last = c.raining; }
    run++;
    if (c.thundering !== tLast) { if (tLast && t > 200000) thunderOn.push(tRun); tRun = 0; tLast = c.thundering; }
    tRun++;
  }
  const avg = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;
  check('rain lasts 12 000–24 000 ticks (mean 18 000)', Math.min(...rain) >= 12000 && Math.max(...rain) <= 24000 && rel(avg(rain), 18000) < 0.03, `${rain.length} spells, ${Math.min(...rain)}–${Math.max(...rain)}, mean ${avg(rain).toFixed(0)}`);
  check('clear weather lasts 12 000–180 000 ticks (mean 96 000)', Math.min(...clear) >= 12000 && Math.max(...clear) <= 180000 && rel(avg(clear), 96000) < 0.08, `${clear.length} spells, ${Math.min(...clear)}–${Math.max(...clear)}, mean ${avg(clear).toFixed(0)}`);
  check('thunder flag: on 3 600–15 600 ticks, on its own timer; storms only while it rains', Math.min(...thunderOn) >= 3600 && Math.max(...thunderOn) <= 15600 && stormWhileDry === 0, `${thunderOn.length} thunder spells, mean ${avg(thunderOn).toFixed(0)}`);
  const q = new WC.WeatherCycle();
  q.set('clear', rng, 100);
  for (let t = 0; t < 101; t++) q.tick(rng);
  check('/weather clear <t>: when the clear timer ends both flags flip on → thunderstorm (wiki quirk)', q.state === 'storm');
  const s = new WC.WeatherCycle(); s.set('storm', rng);
  check('/weather thunder: default 3 600–15 600 ticks', s.rainTime >= 3600 && s.rainTime <= 15600 && s.state === 'storm');
}

// ---- 5. Sleep, day counter, moon phase -----------------------------------------------------------------------------------------------
{
  const woke = WC.wakeUp(4);
  check('waking up: time 0 (sunrise) of the next day, no healing involved', woke.time === 0 && woke.day === 5 && WC.SLEEP_TICKS === 100);
  const r = new WC.WeatherCycle(); r.set('rain', Math.random); r.sleptThrough();
  const c = new WC.WeatherCycle(); c.rainTime = 5000; c.sleptThrough();
  check('sleeping resets the weather cycle only while it rains (Java)', r.state === 'clear' && r.rainTime === 0 && c.rainTime === 5000);
  check('beds: 12 542–23 459 clear, 12 010–23 991 rain, any time in a thunderstorm', WC.canSleepAt(12542 / 24000, 'clear') && !WC.canSleepAt(12500 / 24000, 'clear') && WC.canSleepAt(12100 / 24000, 'rain') && WC.canSleepAt(0.3, 'storm') && !WC.canSleepAt(23500 / 24000, 'clear'));
  const phases = Array.from({ length: 10 }, (_, d) => WC.moonPhase(d));
  check('moon phase = day % 8, one phase per 24 000-tick day', phases.join() === '0,1,2,3,4,5,6,7,0,1', phases.join());
  const meta = { playTime: 3700 };
  check('old saves without dayCount fall back to play time / 1200 s; dayCount is stored on the meta', WC.dayOf(meta) === 3 && (WC.setDay(meta, 9), WC.dayOf(meta) === 9));
  console.log(`      before: Math.floor(playTime / 240 % 8) changed every 240 s = 4800 ticks (5 phases per day); now every 1200 s (24 000 ticks)`);
}

const passed = results.filter(r => r.ok).length;
console.log(`\n${passed}/${results.length} random tick / weather / time checks passed`);
if (passed !== results.length) process.exit(1);
