import { Redstone, type RedstoneHost } from '../src/systems/redstone';
import { BLOCKS, ID } from '../src/game/data';
import '../src/game/content';
import '../src/game/content121';

// Let us test the logic of line(origin) if fixed(first) returns false:
// When line(n) is called for n = [1, 1, 0] (obsidian attached to slime):
// In Java Edition:
// Slime at (1, 0, 0) moving +X (+dir) tries to pull or push obsidian at (1, 1, 0).
// Since obsidian is attached to slime, obsidian MUST move +X.
// But obsidian is immovable! So the entire structure CANNOT MOVE.
// Therefore line(n) must return false if fixed(first)!
