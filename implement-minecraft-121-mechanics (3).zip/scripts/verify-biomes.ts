import assert from 'node:assert/strict';
import * as THREE from 'three';
import { END_OUTER_ARRIVAL, Terrain, SEA, MIN_Y, HEIGHT, BIOME_LABELS } from '../src/world/terrain';
import { BLOCKS, ID } from '../src/game/data';
import '../src/game/content';
import { MobManager } from '../src/entities/mobs';

/*
 * Biome conformance checks against the Minecraft Wiki biome descriptions.
 * For every biome the game can generate we sample real chunks and assert the traits the Wiki lists for it:
 * temperature/precipitation (snow layers, ice), surface material, characteristic flora, water, and dimension-specific blocks.
 * Each test names the property it verifies; a failure prints the biome, property and a short sample.
 */

type Sample = {
  biome: string; center: [number, number];
  top: Map<string, number>; under: Map<string, number>; above: Map<string, number>;
  water: number; ice: number; lava: number; minH: number; maxH: number; columns: number; glow: number; fire: number;
  logs: Map<string, number>; maxLog: number; lowWater: number;
};

function tally(m: Map<string, number>, name: string) { m.set(name, (m.get(name) ?? 0) + 1); }
function biomeCenter(t: Terrain, biome: string, radius = 2600, dim: 'overworld' | 'nether' | 'end' = 'overworld', seed = '849281'): [number, number] | null {
  if (dim === 'end') return [0, 0];
  const found = t.locate(biome, 0, 0);
  if (found && t.biome(found[0], found[2]) === biome) return [found[0], found[2]];
  for (let r = 0; r <= radius; r += 24) {
    const steps = Math.max(1, Math.floor(r * 0.5));
    for (let s = 0; s < steps; s++) {
      const a = (s / steps) * Math.PI * 2, x = Math.round(Math.cos(a) * r), z = Math.round(Math.sin(a) * r);
      if (t.biome(x, z) === biome) return [x, z];
    }
  }
  return null;
}

function sample(seed: string, biome: string, dim: 'overworld' | 'nether' | 'end' = 'overworld', span = 4): Sample | null {
  const t = new Terrain(seed, dim);
  const c = biomeCenter(t, biome, 3200, dim, seed);
  if (!c) return null;
  const top = new Map<string, number>(), under = new Map<string, number>(), above = new Map<string, number>(), logs = new Map<string, number>();
  let water = 0, ice = 0, lava = 0, minH = 999, maxH = -999, columns = 0, maxLog = 0, lowWater = 0, glow = 0, fire = 0;
  const cx0 = Math.floor(c[0] / 16), cz0 = Math.floor(c[1] / 16);
  for (let dz = -span; dz <= span; dz++) for (let dx = -span; dx <= span; dx++) {
    const g = t.generate(cx0 + dx, cz0 + dz, [], false);
    for (let z = 0; z < 16; z++) for (let x = 0; x < 16; x++) {
      const wx = (cx0 + dx) * 16 + x, wz = (cz0 + dz) * 16 + z;
      if (t.biome(wx, wz) !== biome) continue;
      const h = t.height(wx, wz);
      const cell = (y: number) => (y < MIN_Y || y >= MIN_Y + HEIGHT) ? 0 : g.data[(y - MIN_Y) * 256 + z * 16 + x] & 4095;
      columns++;
      if (h < minH) minH = h;
      if (h > maxH) maxH = h;
      tally(top, BLOCKS[cell(h)]?.name ?? 'air');
      tally(under, BLOCKS[cell(h - 2)]?.name ?? 'air');
      tally(above, BLOCKS[cell(h + 1)]?.name ?? 'air');
      // Plants that float on the water surface (lily pads) sit one block above sea level, not directly above the bed.
      if (h < SEA && cell(SEA) === ID.water) tally(above, BLOCKS[cell(SEA + 1)]?.name ?? 'air');

      let sawWater = false;
      for (let y = MIN_Y + 4; y < MIN_Y + HEIGHT; y++) {
        const c = cell(y);
        if (c === ID.ice) ice++;
        if (c === ID.lava) lava++;
        if (c === ID.glowstone) glow++;
        if (c === ID.fire) fire++;
        if (c === ID.water) { sawWater = true; water++; }
        if (y < SEA - 1) continue;
        if (c === ID.water) lowWater++;
      }
      void sawWater;
      for (let y = h + 1; y <= h + 12; y++) {
        const n = BLOCKS[cell(y)]?.name ?? '';
        if (n.endsWith('_log') || n.endsWith('_stem')) {
          tally(logs, n);
          let len = 1;
          while ((BLOCKS[cell(y + len)]?.name ?? '') === n) len++;
          if (len > maxLog) maxLog = len;
        }
      }
    }
  }
  return { biome, center: c, top, under, above, water, ice, lava, minH, maxH, columns, logs, maxLog, lowWater, glow, fire };
}

const results: { biome: string; prop: string; ok: boolean; note?: string }[] = [];
function check(biome: string, prop: string, fn: () => void) {
  try { fn(); results.push({ biome, prop, ok: true }); }
  catch (e) { results.push({ biome, prop, ok: false, note: e instanceof Error ? e.message.split('\n')[0] : String(e) }); }
}
const has = (m: Map<string, number>, ...names: string[]) => names.some(n => (m.get(n) ?? 0) > 0);
const count = (m: Map<string, number>, ...names: string[]) => names.reduce((s, n) => s + (m.get(n) ?? 0), 0);
const topOf = (s: Sample) => [...s.top.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'none';
const fmt = (m: Map<string, number>) => [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, v]) => k + ':' + v).join(',');

const SEEDS = ['849281', '12345', 'hello'];
const OW = 'overworld' as const;

// ---------------------------------------------------------------- Overworld biomes
const plains = sample('849281', 'plains');
check('plains', 'surface is grass and the biome is reachable', () => {
  assert.ok(plains, 'plains not found');
  assert.ok(plains!.columns > 40, 'too few columns ' + plains!.columns);
  assert.ok(has(plains!.top, 'grass_block'), 'top=' + fmt(plains!.top));
});
check('plains', 'Wiki flora: short grass, dandelions/poppies, occasional oak', () => {
  assert.ok(has(plains!.above, 'short_grass'), 'above=' + fmt(plains!.above));
  assert.ok(count(plains!.above, 'poppy', 'dandelion', 'oxeye_daisy', 'azure_bluet', 'cornflower') > 0, 'no flowers');
  assert.ok(has(plains!.logs, 'oak_log'), 'logs=' + fmt(plains!.logs));
});
check('plains', 'no snow or ice in a temperate biome', () => {
  assert.equal(plains!.ice, 0);
  assert.ok(!has(plains!.above, 'snow_layer', 'snow_block'));
});

const forest = sample('849281', 'forest');
check('forest', 'Wiki: grass floor, dense oak/birch canopy', () => {
  assert.ok(forest, 'forest not found');
  assert.ok(has(forest!.top, 'grass_block'));
  assert.ok(has(forest!.logs, 'oak_log', 'birch_log'), 'logs=' + fmt(forest!.logs));
  assert.ok(count(forest!.logs, 'oak_log', 'birch_log') > 20, 'tree density too low ' + fmt(forest!.logs));
});

const birch = sample('849281', 'birch_forest');
check('birch_forest', 'Wiki: birch trees dominate (no oak trees)', () => {
  assert.ok(birch, 'birch_forest not found');
  assert.ok(has(birch!.logs, 'birch_log'), 'logs=' + fmt(birch!.logs));
  assert.equal(birch!.logs.get('oak_log') ?? 0, 0, 'oak trees present in birch forest');
});

const flower = sample('849281', 'flower_forest');
check('flower_forest', 'Wiki: extremely flower-rich grass, oak/birch trees', () => {
  assert.ok(flower, 'flower_forest not found');
  assert.ok(has(flower!.top, 'grass_block'));
  const flowers = count(flower!.above, 'poppy', 'dandelion', 'cornflower', 'lily_of_the_valley', 'orange_tulip', 'pink_tulip', 'oxeye_daisy', 'allium', 'azure_bluet');
  assert.ok(flowers > 25, 'flower density too low: ' + flowers);
  assert.ok(has(flower!.logs, 'oak_log', 'birch_log'));
});

const taiga = sample('849281', 'taiga');
check('taiga', 'Wiki: spruce trees, ferns, podzol patches, no snow layer below the snow line', () => {
  assert.ok(taiga, 'taiga not found');
  assert.ok(has(taiga!.logs, 'spruce_log'), 'logs=' + fmt(taiga!.logs));
  assert.ok(has(taiga!.top, 'grass_block', 'podzol'), 'top=' + fmt(taiga!.top));
  assert.ok(has(taiga!.above, 'fern', 'short_grass', 'sweet_berry_bush'), 'above=' + fmt(taiga!.above));
});

const snowy = sample('849281', 'snowy_plains');
check('snowy_plains', 'Wiki: snow layer over grass, precipitation is snow', () => {
  assert.ok(snowy, 'snowy_plains not found');
  assert.ok(has(snowy!.above, 'snow_layer') || has(snowy!.top, 'snow_block'), 'no snow cover: above=' + fmt(snowy!.above));
  assert.ok(has(snowy!.top, 'grass_block', 'snow_block'), 'top=' + fmt(snowy!.top));
  assert.ok(!has(snowy!.logs, 'oak_log'), 'oak trees in snowy plains');
});
check('snowy_plains', 'Wiki: still water freezes into ice', () => {
  assert.ok(snowy!.ice > 0, 'no ice in snowy plains');
});

const slopes = sample('849281', 'snowy_slopes');
check('snowy_slopes', 'Wiki: high mountain slopes covered in snow', () => {
  assert.ok(slopes, 'snowy_slopes not found');
  assert.ok(slopes!.maxH > 44, 'not high ground: maxH=' + slopes!.maxH);
  assert.ok(has(slopes!.top, 'snow_block'), 'top=' + fmt(slopes!.top));
});

const hills = sample('849281', 'windswept_hills');
check('windswept_hills', 'Wiki: elevated grass/stone/gravel with sparse spruce', () => {
  assert.ok(hills, 'windswept_hills not found');
  assert.ok(hills!.maxH > 44, 'not elevated: maxH=' + hills!.maxH);
  assert.ok(has(hills!.top, 'grass_block', 'stone', 'gravel'), 'top=' + fmt(hills!.top));
});

const desert = sample('849281', 'desert');
check('desert', 'Wiki: sand over sandstone, cactus and dead bushes, no rain', () => {
  assert.ok(desert, 'desert not found');
  assert.ok(has(desert!.top, 'sand'), 'top=' + fmt(desert!.top));
  assert.ok(has(desert!.under, 'sandstone', 'sand'), 'under=' + fmt(desert!.under));
  assert.ok(count(desert!.above, 'cactus', 'dead_bush') > 0, 'no desert plants');
  assert.equal(desert!.ice, 0);
});

const savanna = sample('849281', 'savanna');
check('savanna', 'Wiki: acacia trees over dry grass, tall grass', () => {
  assert.ok(savanna, 'savanna not found');
  assert.ok(has(savanna!.top, 'grass_block'), 'top=' + fmt(savanna!.top));
  assert.ok(has(savanna!.logs, 'acacia_log'), 'logs=' + fmt(savanna!.logs));
  assert.ok(has(savanna!.above, 'short_grass', 'fern'), 'above=' + fmt(savanna!.above));
});

const jungle = sample('849281', 'jungle');
check('jungle', 'Wiki: tall jungle trees, vines/bamboo/melons, lush grass', () => {
  assert.ok(jungle, 'jungle not found');
  assert.ok(has(jungle!.logs, 'jungle_log'), 'logs=' + fmt(jungle!.logs));
  assert.ok(jungle!.maxLog >= 6, 'jungle trunk too short: ' + jungle!.maxLog);
  assert.ok(count(jungle!.above, 'vine', 'bamboo', 'melon', 'jungle_fern', 'short_grass', 'large_fern') > 10, 'jungle foliage=' + fmt(jungle!.above));
});

const swamp = sample('849281', 'swamp');
check('swamp', 'Wiki: flat waterlogged lowland, lily pads, vines, mushrooms, clay', () => {
  assert.ok(swamp, 'swamp not found');
  assert.ok(swamp!.lowWater > 10, 'not waterlogged: ' + swamp!.lowWater);
  assert.ok(has(swamp!.above, 'lily_pad'), 'no lily pads');
  assert.ok(has(swamp!.top, 'grass_block', 'dirt'), 'top=' + fmt(swamp!.top));
  assert.ok(count(swamp!.above, 'short_grass', 'blue_orchid', 'brown_mushroom', 'seagrass') > 0, 'above=' + fmt(swamp!.above));
});

const badlands = sample('849281', 'badlands');
check('badlands', 'Wiki: red sand over banded terracotta, dry, cactus/dead bush', () => {
  assert.ok(badlands, 'badlands not found');
  assert.ok(has(badlands!.top, 'red_sand', 'terracotta', 'orange_terracotta', 'red_terracotta'), 'top=' + fmt(badlands!.top));
  assert.ok(count(badlands!.under, 'terracotta', 'orange_terracotta', 'red_terracotta', 'yellow_terracotta', 'white_terracotta') > 0, 'under=' + fmt(badlands!.under));
  assert.equal(badlands!.ice, 0);
});

const cherry = sample('849281', 'cherry_grove');
check('cherry_grove', 'Wiki: cherry trees and pink petal carpets on grass', () => {
  assert.ok(cherry, 'cherry_grove not found');
  assert.ok(has(cherry!.logs, 'cherry_log'), 'logs=' + fmt(cherry!.logs));
  assert.ok(has(cherry!.above, 'pink_petals'), 'no pink petals');
});

const mushroom = sample('849281', 'mushroom_fields');
check('mushroom_fields', 'Wiki: mycelium floor, huge mushrooms, surrounded by ocean', () => {
  assert.ok(mushroom, 'mushroom_fields not found');
  assert.ok(has(mushroom!.top, 'mycelium'), 'top=' + fmt(mushroom!.top));
  assert.ok(has(mushroom!.logs, 'mushroom_stem'), 'no huge mushrooms: logs=' + fmt(mushroom!.logs));
  assert.ok(has(mushroom!.above, 'red_mushroom', 'brown_mushroom', 'red_mushroom_block', 'brown_mushroom_block'), 'no mushrooms');
});

const beach = sample('849281', 'beach');
check('beach', 'Wiki: sand beach at the water edge, sugar cane nearby', () => {
  assert.ok(beach, 'beach not found');
  assert.ok(has(beach!.top, 'sand'), 'top=' + fmt(beach!.top));
  assert.ok(beach!.lowWater > 0 || has(beach!.above, 'sugar_cane'), 'not near water');
});

const river = sample('849281', 'river');
check('river', 'Wiki: flowing fresh water with sand/clay/gravel bed', () => {
  assert.ok(river, 'river not found');
  assert.ok(river!.lowWater > 0, 'no water in river sample');
  assert.ok(has(river!.top, 'sand', 'clay', 'gravel', 'water'), 'bed=' + fmt(river!.top));
});

const frozenRiver = sample('849281', 'frozen_river');
check('frozen_river', 'Wiki: frozen river surface is ice', () => {
  assert.ok(frozenRiver, 'frozen_river not found');
  assert.ok(frozenRiver!.ice > 0, 'no ice in frozen river');
});

const ocean = sample('849281', 'ocean');
check('ocean', 'Wiki: water with sand/gravel floor, seagrass and kelp', () => {
  assert.ok(ocean, 'ocean not found');
  assert.ok(ocean!.lowWater > 20, 'not water: ' + ocean!.lowWater);
  assert.ok(has(ocean!.above, 'seagrass', 'kelp', 'sea_pickle', 'tube_coral_block'), 'no ocean plants: ' + fmt(ocean!.above));
});
const deep = sample('849281', 'deep_ocean');
check('deep_ocean', 'Wiki: ocean deeper than 30 blocks', () => {
  assert.ok(deep, 'deep_ocean not found');
  assert.ok(SEA - deep!.minH >= 26, 'not deep enough: ' + (SEA - deep!.minH));
});
const frozenOcean = sample('849281', 'frozen_ocean');
check('frozen_ocean', 'Wiki: frozen ocean has an ice surface', () => {
  assert.ok(frozenOcean, 'frozen_ocean not found');
  assert.ok(frozenOcean!.ice > 0, 'no ice');
});
const stony = sample('849281', 'stony_shore');
check('stony_shore', 'Wiki: stone/gravel shore instead of sand', () => {
  assert.ok(stony, 'stony_shore not found');
  const stoneish = count(stony!.top, 'stone', 'gravel', 'andesite');
  assert.ok(stoneish > stony!.columns * 0.5, 'top=' + fmt(stony!.top));
  assert.ok((stony!.top.get('sand') ?? 0) < stony!.columns * 0.2, 'too much sand on a stony shore');
});
const meadow = sample('849281', 'meadow');
check('meadow', 'Wiki: flower meadow on a plateau with no trees', () => {
  assert.ok(meadow, 'meadow not found');
  assert.ok(has(meadow!.top, 'grass_block'), 'top=' + fmt(meadow!.top));
  assert.ok(count(meadow!.above, 'poppy', 'dandelion', 'cornflower', 'allium', 'azure_bluet', 'oxeye_daisy', 'orange_tulip', 'short_grass', 'tall_grass') > 10, 'few flowers: ' + fmt(meadow!.above));
  assert.equal((meadow!.logs.size), 0, 'trees in meadow: ' + fmt(meadow!.logs));
});
const darkForest = sample('849281', 'dark_forest');
check('dark_forest', 'Wiki: dark oak canopy and occasional huge mushrooms', () => {
  assert.ok(darkForest, 'dark_forest not found');
  assert.ok(has(darkForest!.logs, 'dark_oak_log'), 'logs=' + fmt(darkForest!.logs));
});
const sunflower = sample('849281', 'sunflower_plains');
check('sunflower_plains', 'Wiki: plains covered in sunflowers', () => {
  assert.ok(sunflower, 'sunflower_plains not found');
  assert.ok(has(sunflower!.above, 'sunflower'), 'above=' + fmt(sunflower!.above));
});
const bamboo = sample('849281', 'bamboo_jungle');
check('bamboo_jungle', 'Wiki: dense bamboo stalks and jungle trees', () => {
  assert.ok(bamboo, 'bamboo_jungle not found');
  assert.ok(has(bamboo!.above, 'bamboo'), 'above=' + fmt(bamboo!.above));
});
const mangrove = sample('849281', 'mangrove_swamp');
check('mangrove_swamp', 'Wiki: mud surface, mangrove logs/roots and water', () => {
  assert.ok(mangrove, 'mangrove_swamp not found');
  assert.ok(has(mangrove!.top, 'mud', 'grass_block'), 'top=' + fmt(mangrove!.top));
  assert.ok(has(mangrove!.logs, 'mangrove_log'), 'logs=' + fmt(mangrove!.logs));
});
const warmOcean = sample('849281', 'warm_ocean');
check('warm_ocean', 'Wiki: sand seabed with coral reefs and sea pickles', () => {
  assert.ok(warmOcean, 'warm_ocean not found');
  assert.ok(has(warmOcean!.top, 'sand'), 'top=' + fmt(warmOcean!.top));
  assert.ok(has(warmOcean!.above, 'seagrass', 'tube_coral_block', 'brain_coral_block', 'fire_coral_block', 'sea_pickle'), 'above=' + fmt(warmOcean!.above));
});
const oldPine = sample('849281', 'old_growth_pine_taiga');
check('old_growth_pine_taiga', 'Wiki: podzol patches, coarse dirt and tall spruce trunks', () => {
  assert.ok(oldPine, 'old_growth_pine_taiga not found');
  assert.ok(has(oldPine!.top, 'podzol', 'coarse_dirt', 'grass_block'), 'top=' + fmt(oldPine!.top));
  assert.ok(has(oldPine!.logs, 'spruce_log'), 'logs=' + fmt(oldPine!.logs));
});
const jagged = sample('849281', 'jagged_peaks');
check('jagged_peaks', 'Wiki: soaring jagged stone/snow mountain peaks', () => {
  assert.ok(jagged, 'jagged_peaks not found');
  assert.ok(jagged!.maxH >= 130, 'maxH too low: ' + jagged!.maxH);
  assert.ok(has(jagged!.top, 'snow_block', 'stone'), 'top=' + fmt(jagged!.top));
});
const stonyPeaks = sample('849281', 'stony_peaks');
check('stony_peaks', 'Wiki: warm stone peaks with calcite strips', () => {
  assert.ok(stonyPeaks, 'stony_peaks not found');
  assert.ok(has(stonyPeaks!.top, 'stone', 'calcite', 'gravel'), 'top=' + fmt(stonyPeaks!.top));
});

// ---------------------------------------------------------------- Nether biomes
const nw = sample('849281', 'nether_wastes', 'nether');
check('nether_wastes', 'Wiki: netherrack floor, lava sea, glowstone and fire', () => {
  assert.ok(nw, 'nether wastes not found');
  assert.ok(has(nw!.top, 'netherrack'), 'top=' + fmt(nw!.top));
  assert.ok(nw!.lava > 0, 'no lava');
  assert.ok(nw!.glow > 0 || nw!.fire > 0 || has(nw!.top, 'glowstone'), 'no glowstone/fire');
});
const crimson = sample('849281', 'crimson_forest', 'nether');
check('crimson_forest', 'Wiki: crimson nylium, huge crimson fungi, shroomlight, roots', () => {
  assert.ok(crimson, 'crimson forest not found');
  assert.ok(has(crimson!.top, 'crimson_nylium'), 'top=' + fmt(crimson!.top));
  assert.ok(has(crimson!.logs, 'crimson_log'), 'stems=' + fmt(crimson!.logs));
  assert.ok(has(crimson!.above, 'crimson_fungus', 'crimson_roots', 'weeping_vines', 'crimson_leaves') || has(crimson!.top, 'shroomlight', 'crimson_leaves'), 'flora=' + fmt(crimson!.above));
  assert.equal(crimson!.water, 0, 'water in the nether');
});
const warped = sample('849281', 'warped_forest', 'nether');
check('warped_forest', 'Wiki: warped nylium, warped fungi, twisting vines, shroomlight', () => {
  assert.ok(warped, 'warped forest not found');
  assert.ok(has(warped!.top, 'warped_nylium'), 'top=' + fmt(warped!.top));
  assert.ok(has(warped!.logs, 'warped_log'), 'stems=' + fmt(warped!.logs));
  assert.ok(has(warped!.above, 'warped_fungus', 'warped_roots', 'twisting_vines', 'nether_sprouts') || has(warped!.top, 'shroomlight', 'warped_leaves'), 'flora=' + fmt(warped!.above));
});
const valley = sample('849281', 'soul_sand_valley', 'nether');
check('soul_sand_valley', 'Wiki: soul sand/soil, soul fire, basalt pillars and fossils', () => {
  assert.ok(valley, 'soul sand valley not found');
  assert.ok(has(valley!.top, 'soul_sand', 'soul_soil'), 'top=' + fmt(valley!.top));
  assert.ok(count(valley!.top, 'basalt', 'blackstone', 'bone_block') > 0, 'no basalt/fossils: ' + fmt(valley!.top));
  assert.ok(has(valley!.above, 'soul_fire', 'soul_torch') || has(valley!.top, 'soul_fire'), 'no soul fire');
});
const deltas = sample('849281', 'basalt_deltas', 'nether');
check('basalt_deltas', 'Wiki: basalt/blackstone terrain with magma and lava, no fungi forests', () => {
  assert.ok(deltas, 'basalt deltas not found');
  assert.ok(has(deltas!.top, 'basalt', 'blackstone'), 'top=' + fmt(deltas!.top));
  assert.ok(count(deltas!.top, 'magma_block', 'gilded_blackstone') > 0, 'no magma/gilded blackstone: ' + fmt(deltas!.top));
  assert.equal(deltas!.logs.size, 0, 'trees in basalt deltas');
});

// ---------------------------------------------------------------- End
const end = sample('849281', 'the_end', 'end');
check('the_end', 'Wiki: end stone islands, chorus plants, obsidian pillars with crystals', () => {
  assert.ok(end, 'end not found');
  assert.ok(has(end!.top, 'end_stone'), 'top=' + fmt(end!.top));
});
let endFeatures = '';
check('the_end', 'outer islands carry chorus plants and an end city', () => {
  const t = new Terrain('849281', 'end');
  const tallyNames = new Map<string, number>();
  // Outer islands lie 1,000+ blocks out (vanilla): sample the main island and the chunks around the arrival island.
  const acx = END_OUTER_ARRIVAL[0] >> 4, acz = END_OUTER_ARRIVAL[2] >> 4;
  for (const [cx, cz] of [[0, 0], [acx, acz], [acx - 1, acz + 1], [acx + 1, acz + 3], [acx + 1, acz - 1]]) {
    const g = t.generate(cx, cz, [], true);
    for (const v of g.data) tally(tallyNames, BLOCKS[v & 4095]?.name ?? 'air');
  }
  endFeatures = fmt(tallyNames);
  assert.ok(has(tallyNames, 'chorus_plant', 'chorus_flower'), 'no chorus plants');
  assert.ok(has(tallyNames, 'end_rod', 'purpur_block', 'shulker_box', 'obsidian'), 'no end city/pillars: ' + endFeatures);
});

// ---------------------------------------------------------------- mob spawning
check('mushroom_fields', 'Wiki: hostile mobs never spawn on mushroom fields (any light level)', () => {
  assert.ok(mushroom, 'mushroom_fields not found');
  const t = new Terrain('849281');
  const c = mushroom!.center;
  const y = t.height(c[0], c[1]) + 1;
  const host = {
    terrain: t, position: new THREE.Vector3(c[0] + 0.5, y, c[1] + 0.5), camera: new THREE.PerspectiveCamera(), dimension: 'overworld', dragonDefeated: false,
    getBlock: () => 0, damage() {}, addItem: () => true, toast() {}, sound() {}, explode() {}, teleport() {}, openTrade() {},
    onDragonDefeated() {}, onEnterGateway() {}, levitate() {}, particles: { burst() {}, drop() {}, spark() {} },
  };
  const m = new MobManager(new THREE.Scene(), host as never);
  m.mobs = [];
  for (let i = 0; i < 300; i++) { (m as unknown as { spawnTimer: number }).spawnTimer = 99; m.update(0.2, 0, false); }
  // Only mobs that actually stand inside the mushroom fields count: the spawn ring can reach the surrounding ocean.
  const hostile = m.mobs.filter(mob => ['zombie', 'skeleton', 'creeper', 'spider', 'enderman'].includes(mob.species) && t.biome(mob.group.position.x, mob.group.position.z) === 'mushroom_fields');
  assert.equal(hostile.length, 0, 'hostiles spawned: ' + hostile.map(h => h.species).join(','));
});

// ---------------------------------------------------------------- coverage
check('*', 'all App biome labels are producible by the generator', () => {
  const labels = Object.keys(BIOME_LABELS);
  const seen = new Set<string>();
  for (const seed of SEEDS) {
    const t = new Terrain(seed);
    for (let z = -4800; z <= 4800; z += 40) for (let x = -4800; x <= 4800; x += 40) seen.add(t.biome(x, z));
    // cave biomes are a property of (x, y, z): sample a few depths below the surface
    for (let z = -900; z <= 900; z += 45) for (let x = -900; x <= 900; x += 45) for (const y of [-40, 10, 40]) { const c = t.caveBiome(x, y, z); if (c) seen.add(c); }
    const tn = new Terrain(seed, 'nether');
    for (let z = -2000; z <= 2000; z += 40) for (let x = -2000; x <= 2000; x += 40) seen.add(tn.biome(x, z));
  }
  const missing = labels.filter(l => !seen.has(l) && l !== 'the_end');
  assert.deepEqual(missing, [], 'not generated: ' + missing.join(','));
  // every generated label must also have exactly one Japanese and English name for the HUD
  for (const l of labels) { assert.ok(BIOME_LABELS[l].ja.length > 0, l + ' has no Japanese label'); assert.ok(BIOME_LABELS[l].en.length > 0, l + ' has no English label'); }
  const groups = new Set(Object.values(BIOME_LABELS).map(v => v.group));
  assert.deepEqual([...groups].sort(), ['end', 'nether', 'overworld']);
});

const passed = results.filter(r => r.ok).length;
for (const r of results) if (!r.ok) console.log(`FAIL  ${r.biome} / ${r.prop}${r.note ? '  — ' + r.note : ''}`);
console.log(`\n${passed}/${results.length} biome property checks passed`);
const summary = [...new Map(results.map(r => [r.biome, r])).keys()];
console.log('checked biomes:', summary.length);
if (passed !== results.length) process.exit(1);
