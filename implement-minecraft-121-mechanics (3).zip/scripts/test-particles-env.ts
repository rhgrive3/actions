// Record 019 verification suite: Java Edition particles (src/render/particles.ts) and weather / atmosphere / dynamic FOV
// (src/render/environment.ts). Every expectation below is a constant or formula of the vanilla client
// (CritParticle, SpellParticle, PortalParticle, LavaParticle, DripParticle, WaterDropParticle, SuspendedTownParticle,
// Level.animateTick, LevelRenderer.tickRain, Biome precipitation, biome `effects.particle`, getFieldOfViewModifier).
import * as THREE from 'three';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import '../src/game/content';
import { BLOCKS, ID } from '../src/game/data';
import {
  FxSim, FX_SPECS, FX_ALIASES, FX_COLORS, FX_MAX, FX_RANGE, FX_TICK, FX_ATLAS, RAIN_SPLASH_RADIUS,
  buildFxAtlasPixels, fxRenderSize, fxFrame, hexToRgb, entityFxBox,
  animateWorldTick, dripBlockBelow, rainColumnTop, isFullSolid, isImpermeable,
  ParticleSystem, type FxBox, type FxKind, type FxWorld,
} from '../src/render/particles';
import {
  precipitationAt, biomeTemperature, biomeClimate, snowLine, stepPrecipitationMix, BIOME_CLIMATE, SNOW_TEMPERATURE, SNOW,
  NETHER_AMBIENT, NETHER_DUST_CAPACITY, netherAmbientFor,
  fovModifier, stepFovModifier, fovDegrees, FOV_EFFECTS,
  AtmosphereFx, DriftField,
} from '../src/render/environment';

let pass = 0, fail = 0;
function ok(name: string, cond: boolean, detail: unknown = '') {
  if (cond) { pass++; console.log('PASS  ' + name); }
  else { fail++; console.log('FAIL  ' + name + (detail !== '' ? '  -> ' + JSON.stringify(detail) : '')); }
}
const near = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) <= eps;
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
type SpawnArgs = [FxKind, number, number, number, number, number, number];
/** Records the arguments of every spawn() call. */
function record(sim: FxSim): SpawnArgs[] {
  const rec: SpawnArgs[] = [], orig = sim.spawn.bind(sim);
  sim.spawn = ((kind: FxKind, x: number, y: number, z: number, xa = 0, ya = 0, za = 0, color?: [number, number, number], alpha = 1) => {
    rec.push([kind, x, y, z, xa, ya, za]);
    return orig(kind, x, y, z, xa, ya, za, color, alpha);
  }) as typeof sim.spawn;
  return rec;
}
const BOX: FxBox = { x: 0, y: 64, z: 0, w: 0.6, h: 1.8 };
const STONE = ID.stone, WATER = ID.water, LAVA = ID.lava, GLASS = ID.glass, PORTAL = ID.portal, MAGMA = ID.magma_block;
const world = (f: (x: number, y: number, z: number) => number): FxWorld => ({ getBlock: f });

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 1. Registry, aliases and sprite sheet');
{
  ok('block ids used by the ambience exist', [STONE, WATER, LAVA, GLASS, PORTAL, MAGMA].every(v => typeof v === 'number' && v > 0));
  const wanted: [string, string[]][] = [
    ['crit', ['crit']], ['enchanted_hit', ['enchanted_hit']], ['mobSpell', ['entity_effect']], ['portal', ['portal']],
    ['lava_pop', ['lava', 'smoke']], ['drip_water', ['dripping_water', 'falling_water', 'splash']],
    ['drip_lava', ['dripping_lava', 'falling_lava', 'landing_lava']], ['rain_splash', ['rain']], ['happy_villager', ['happy_villager']],
  ];
  for (const [alias, ids] of wanted) {
    const kinds = FX_ALIASES[alias] ?? [];
    ok(`requested effect "${alias}" maps to Java particle(s) ${ids.join(' -> ')}`, kinds.length === ids.length && kinds.every((k, i) => FX_SPECS[k]?.id === ids[i]), kinds);
  }
  const px = buildFxAtlasPixels(), w = FX_ATLAS.cols * FX_ATLAS.cell;
  ok('sprite sheet is an 8x4 grid of 8 px sprites (64x32 RGBA)', px.length === 64 * 32 * 4 && w === 64);
  const opaque = (slot: number) => {
    let n = 0;
    const ox = (slot % 8) * 8, oy = Math.floor(slot / 8) * 8;
    for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) if (px[((oy + y) * w + ox + x) * 4 + 3] === 255) n++;
    return n;
  };
  const slots = new Set<number>();
  for (const k of Object.keys(FX_SPECS) as FxKind[]) for (const f of FX_SPECS[k].frames) slots.add(f);
  ok('every sprite frame referenced by a particle is drawn', [...slots].every(sl => opaque(sl) >= 4), [...slots].map(sl => [sl, opaque(sl)]));
  ok('crit star is a sparse, pointed sprite (not a filled blob)', opaque(FX_SPECS.crit.frames[0]) < 30 && opaque(FX_SPECS.crit.frames[0]) > 12);
  const spell = FX_SPECS.effect.frames.map(opaque);
  ok('effect swirl plays 4 frames from the large swirl down to a dot', spell.length === 4 && spell[0] > spell[1] && spell[1] > spell[2] && spell[2] > spell[3], spell);
  const pix = (slot: number, x: number, y: number) => { const i = ((Math.floor(slot / 8) * 8 + y) * w + (slot % 8) * 8 + x) * 4; return [px[i], px[i + 1], px[i + 2]]; };
  const glint = pix(FX_SPECS.happy_villager.frames[0], 3, 0), ember = pix(FX_SPECS.lava.frames[0], 3, 3);
  ok('happy_villager glint sprite is green', glint[1] > glint[0] * 2 && glint[1] > glint[2] * 2, glint);
  ok('lava ember sprite is orange-yellow with a hot centre', ember[0] === 255 && ember[1] > 180 && ember[2] < 140, ember);
  ok('emissive particles: enchanted_hit, portal, lava, lava drips, happy_villager', ['enchanted_hit', 'portal', 'lava', 'dripping_lava', 'falling_lava', 'landing_lava', 'happy_villager'].every(k => FX_SPECS[k as FxKind].emissive) && !FX_SPECS.crit.emissive && !FX_SPECS.rain.emissive);
  ok('particles tick at 20 Hz and are visible within 32 blocks', FX_TICK === 0.05 && FX_RANGE === 32);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 2. crit (critical hit stars)');
{
  const sim = new FxSim(rng(11));
  const p = sim.spawn('crit', 0, 65, 0, 0.5, 0.7, -0.2)!;
  ok('crit lifetime = 6 / (rand*0.8+0.6) -> 4‥10 ticks', p.life >= 4 && p.life <= 10, p.life);
  ok('crit starts light grey-white (0.6‥0.9, r = g = b)', p.r >= 0.6 && p.r <= 0.9 && p.r === p.g && p.g === p.b, [p.r, p.g, p.b]);
  ok('crit quad size = base (0.1‥0.2) x 0.75', p.size >= 0.075 - 1e-9 && p.size <= 0.15 + 1e-9, p.size);
  ok('crit velocity = emitter direction x 0.4 (+ 10 % noise)', Math.abs(p.vx - 0.2) < 0.02 && Math.abs(p.vz + 0.08) < 0.02 && p.vy > 0.27 && p.vy < 0.31, [p.vx, p.vy, p.vz]);
  ok('crit pops in: size 0 on spawn', fxRenderSize(p, 0) === 0);
  const vx0 = p.vx, c0 = p.r;
  sim.tick();
  ok('crit reaches full size within the first tick (age/life x 32)', near(fxRenderSize(p, 0), p.size));
  sim.tick(); sim.tick();
  ok('crit fades towards orange: green x0.96, blue x0.9 per tick', near(p.g, c0 * 0.96 ** 3, 1e-9) && near(p.b, c0 * 0.9 ** 3, 1e-9) && p.r === c0 && p.r > p.g && p.g > p.b);
  ok('crit friction 0.7 per tick', near(p.vx, vx0 * 0.7 ** 3, 1e-9));

  const em = new FxSim(rng(3)), rec = record(em);
  em.crit(BOX);
  em.tick();
  const first = rec.length;
  ok('crit emitter: up to 16 stars in the first tick', first >= 1 && first <= 16 && em.emitters.length === 1, first);
  em.tick(); em.tick();
  ok('crit emitter lives 3 ticks (TrackingEmitter)', em.emitters.length === 0);
  const total = em.spawned.crit ?? 0;
  ok('crit emitter keeps the tries inside the unit sphere: ~25 of 48', total >= 12 && total <= 40 && total === rec.length, total);
  ok('crit stars start inside the middle of the victim (x ± w/4, y + h x 0.25‥0.75)', rec.every(a => Math.abs(a[1] - BOX.x) <= BOX.w / 4 + 1e-9 && Math.abs(a[3] - BOX.z) <= BOX.w / 4 + 1e-9 && a[2] >= BOX.y + BOX.h * 0.25 - 1e-9 && a[2] <= BOX.y + BOX.h * 0.75 + 1e-9));
  ok('crit stars fly outwards with a 0.2 upward bias', rec.every(a => Math.abs(a[4]) <= 1 && Math.abs(a[6]) <= 1 && a[5] >= -0.8 && a[5] <= 1.2) && rec.some(a => a[4] > 0) && rec.some(a => a[4] < 0));
  for (let i = 0; i < 12; i++) em.tick();
  ok('all crit stars are gone within 10 ticks of the last emission', em.list.length === 0);

  const mv = new FxSim(rng(5)), mrec = record(mv);
  let bx = 0;
  mv.crit(() => ({ ...BOX, x: bx }));
  mv.tick();
  const n1 = mrec.length;
  bx = 5;
  mv.tick();
  ok('crit emitter follows a moving victim', mrec.slice(n1).length > 0 && mrec.slice(n1).every(a => Math.abs(a[1] - 5) <= BOX.w / 4 + 1e-9));
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 3. enchanted_hit (Sharpness / Smite / Bane of Arthropods / Impaling sparks)');
{
  const sim = new FxSim(rng(21));
  const p = sim.spawn('enchanted_hit', 0, 65, 0, 0, 0.2, 0)!;
  ok('enchanted_hit = crit tinted red x0.3, green x0.8', near(p.r / p.b, 0.3, 1e-9) && near(p.g / p.b, 0.8, 1e-9) && p.b >= 0.6 && p.b <= 0.9, [p.r, p.g, p.b]);
  ok('enchanted_hit reads as a blue-white spark (b > g > r)', p.b > p.g && p.g > p.r * 2);
  ok('enchanted_hit shares the crit physics (gravity 0.5 x 0.04, friction 0.7)', near(p.gravity, 0.02) && p.friction === 0.7 && p.life >= 4 && p.life <= 10);
  ok('enchanted_hit uses its own sparkle sprite', FX_SPECS.enchanted_hit.frames[0] !== FX_SPECS.crit.frames[0]);
  const em = new FxSim(rng(22));
  em.enchantedHit(BOX);
  em.tick(); em.tick(); em.tick();
  ok('enchantedHit() runs the same 3-tick emitter with enchanted_hit particles', (em.spawned.enchanted_hit ?? 0) >= 12 && em.spawned.crit === undefined && em.emitters.length === 0, em.spawned);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 4. mobSpell / entity_effect (status-effect swirls)');
{
  const count = (opts: { ambient?: boolean; invisible?: boolean }, seed: number) => {
    const sim = new FxSim(rng(seed));
    let n = 0;
    for (let i = 0; i < 4000; i++) { if (sim.mobSpell(BOX, [1, 0, 0], opts)) n++; sim.list.length = 0; }
    return n;
  };
  const n4 = count({}, 31), n20 = count({ ambient: true }, 32), n15 = count({ invisible: true }, 33);
  ok('effect swirls: 1 in 4 per tick (5 per second)', n4 > 900 && n4 < 1100, n4);
  ok('ambient (beacon) effects: 1 in 20', n20 > 150 && n20 < 250, n20);
  ok('invisible entities: 1 in 15', n15 > 210 && n15 < 330, n15);

  const sim = new FxSim(rng(34));
  const amb = sim.mobSpell(BOX, [0.2, 0.4, 0.6], { ambient: true, force: true })!;
  ok('ambient swirls are 15 % opaque, normal ones fully opaque', amb.a === 0.15 && sim.mobSpell(BOX, [1, 1, 1], { force: true })!.a === 1);
  ok('swirl takes the colour of the status effect', amb.r === 0.2 && amb.g === 0.4 && amb.b === 0.6);
  const seen = new Set<string>();
  for (let i = 0; i < 60; i++) { const q = sim.mobSpell(BOX, [[1, 0, 0], [0, 0, 1]], { force: true })!; seen.add(q.r + ',' + q.b); }
  ok('with several effects each swirl picks one of their colours (no blending)', seen.size === 2 && seen.has('1,0') && seen.has('0,1'), [...seen]);
  ok('poison colour from the effect table converts to RGB', (() => { const c = hexToRgb('#4e9331'); return near(c[0], 0x4e / 255) && near(c[1], 0x93 / 255) && near(c[2], 0x31 / 255); })());

  const p = sim.mobSpell(BOX, [1, 0, 1], { force: true, time: 0 })!;
  const r0 = Math.hypot(p.x - BOX.x, p.z - BOX.z), y0 = p.y, a0 = p.orbit!.angle;
  ok('swirl starts on a ring just outside the body (w/2 + 0.05) at a random height', near(r0, BOX.w / 2 + 0.05, 1e-9) && y0 >= BOX.y && y0 <= BOX.y + BOX.h);
  ok('time = 0 starts the helix on the x axis', Math.abs(p.z - BOX.z) < 1e-9);
  const q = sim.mobSpell(BOX, [1, 0, 1], { force: true, time: Math.PI / 10 })!;
  ok('the spawn point winds around the entity with time (5 rad/s)', Math.abs(q.x - BOX.x) < 1e-9 && near(Math.abs(q.z - BOX.z), 0.35, 1e-9));
  ok('swirl lifetime = 8 / (rand*0.8+0.2) -> 8‥40 ticks', p.life >= 8 && p.life <= 40, p.life);
  ok('swirl floats upward: gravity -0.1 x 0.04, friction 0.96', near(p.gravity, -0.004) && p.friction === 0.96 && p.vy > 0);
  ok('first frame is the large swirl', fxFrame(p) === FX_SPECS.effect.frames[0]);
  const ys: number[] = [y0];
  for (let i = 0; i < 8; i++) { sim.tick(); ys.push(p.y); }
  ok('swirl keeps rising every tick', ys.every((v, i) => i === 0 || v > ys[i - 1]), ys);
  ok('swirl accelerates upward (buoyant)', ys[8] - ys[7] > ys[1] - ys[0]);
  ok('swirl circles the entity: 0.25 rad per tick -> a spiral', near(p.orbit!.angle - a0, 2.0, 1e-9) && near(Math.hypot(p.x - BOX.x, p.z - BOX.z), r0 + 8 * 0.003, 1e-9));
  const old = { ...p, age: p.life - 1 };
  ok('last frame is the small dot', fxFrame(old) === FX_SPECS.effect.frames[3]);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 5. portal (nether portals & endermen)');
{
  const sim = new FxSim(rng(41));
  const p = sim.spawn('portal', 10, 64, 10, 1.5, -0.5, 0.8)!;
  ok('portal colour: r = 0.9f, g = 0.3f, b = f with f in 0.4‥1 (purple)', near(p.r / p.b, 0.9, 1e-9) && near(p.g / p.b, 0.3, 1e-9) && p.b >= 0.4 && p.b <= 1, [p.r, p.g, p.b]);
  ok('portal lifetime 40‥49 ticks', p.life >= 40 && p.life <= 49, p.life);
  ok('portal quad size 0.1 x (0.5‥0.7)', p.size >= 0.05 - 1e-9 && p.size <= 0.07 + 1e-9);
  ok('portal mote appears displaced from its origin (offset + 1 block up)', near(p.x, 11.5) && near(p.y, 64.5) && near(p.z, 10.8));
  ok('portal mote starts invisible-small and grows', fxRenderSize(p, 0) === 0);
  const d = () => Math.hypot(p.x - 10, p.y - 64, p.z - 10);
  const d0 = d(), life = p.life;
  for (let i = 0; i < Math.floor(life / 2); i++) sim.tick();
  const dHalf = d();
  for (let i = Math.floor(life / 2); i < life; i++) sim.tick();
  ok('portal mote is sucked into its origin (distance -> 0 at the end of its life)', d() < 1e-9 && dHalf < d0 && sim.list.includes(p), [d0, dHalf, d()]);
  ok('portal mote is at full size when it arrives', near(fxRenderSize(p, 0), p.size, 1e-9));
  sim.tick();
  ok('portal mote disappears after arriving', !sim.list.includes(p));

  const b = new FxSim(rng(42)), rec = record(b);
  b.portal(3, 64, 7, false);
  ok('nether portal block: 4 motes per animate tick', rec.length === 4 && rec.every(a => a[0] === 'portal'));
  ok('motes start 0.25 in front of / behind the portal plane and are pulled back through it', rec.every(a => near(Math.abs(a[3] - 7.5), 0.25) && Math.sign(a[6]) === Math.sign(a[3] - 7.5) && Math.abs(a[6]) <= 2 && a[1] >= 3 && a[1] <= 4 && a[2] >= 64 && a[2] <= 65), rec);
  rec.length = 0;
  b.portal(3, 64, 7, true);
  ok('portal plane along Z: the offset is on the X axis', rec.length === 4 && rec.every(a => near(Math.abs(a[1] - 3.5), 0.25) && a[3] >= 7 && a[3] <= 8));

  const e = new FxSim(rng(43)), erec = record(e), ender: FxBox = { x: 0, y: 64, z: 0, w: 0.6, h: 2.9 };
  e.enderman(ender);
  ok('enderman: 2 portal motes per tick inside its bounding box, drifting in from above', erec.length === 2 && erec.every(a => a[0] === 'portal' && Math.abs(a[1]) <= 0.3 && Math.abs(a[3]) <= 0.3 && a[2] >= 63.75 && a[2] <= 66.65 && a[5] <= 0 && a[5] >= -1 && Math.abs(a[4]) <= 1));

  // A 2-wide portal in the XY plane (blocks at x = 0‥1, y = 64‥66, z = 0).
  const w = world((x, y, z) => (z === 0 && (x === 0 || x === 1) && y >= 64 && y <= 66 ? PORTAL : 0));
  const a = new FxSim(rng(44)), arec = record(a);
  let hum = 0;
  for (let i = 0; i < 20; i++) { animateWorldTick(a, w, 0.5, 65, 0.5, { samples: 2000, radius: 4, sound: k => { if (k === 'portal') hum++; } }); a.list.length = 0; }
  ok('animate tick finds portal blocks and emits motes around them', arec.length >= 40 && arec.every(r => r[0] === 'portal'), arec.length);
  ok('portal orientation is detected from the neighbouring portal blocks', arec.every(r => near(Math.abs(r[3] - 0.5), 0.25) && r[1] >= 0 && r[1] <= 2 && r[2] >= 64 && r[2] <= 67));
  ok('portal hum is requested occasionally (1 in 100 visits)', hum >= 0 && hum < arec.length / 4);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 6. lava_pop (embers hopping off lava)');
{
  const sim = new FxSim(rng(51), (_x, y) => y <= 10);
  const p = sim.lavaPop(5, 10, 5)!;
  ok('ember starts on the lava surface (y + 1) at a random spot of the block', p.kind === 'lava' && p.y === 11 && p.x >= 5 && p.x <= 6 && p.z >= 5 && p.z <= 6);
  ok('ember jumps up at 0.05‥0.45 blocks/tick', p.vy >= 0.05 && p.vy <= 0.45, p.vy);
  ok('ember: gravity 0.75 x 0.04, friction 0.999, lifetime 16‥80 ticks', near(p.gravity, 0.03) && p.friction === 0.999 && p.life >= 16 && p.life <= 80, p.life);
  const s0 = fxRenderSize(p, 0), life = p.life;
  let apex = p.y, low = p.y;
  for (let i = 0; i < life; i++) { sim.tick(); apex = Math.max(apex, p.y); low = Math.min(low, p.y); }
  ok('ember arcs up and is pulled back down', apex > 11.04, apex);
  ok('ember never sinks into the block below', low >= 11);
  ok('ember shrinks as it cools (size x (1 - t²))', fxRenderSize(p, 0) < s0 * 0.1 && s0 === p.size);
  ok('ember trails smoke puffs', (sim.spawned.smoke ?? 0) >= 3, sim.spawned.smoke);
  const smoke = sim.list.find(q => q.kind === 'smoke') ?? sim.spawn('smoke', 0, 12, 0)!;
  ok('smoke is dark grey (brightness < 0.3) and rises', smoke.r <= 0.3 && smoke.r === smoke.g && smoke.gravity < 0);

  // A lava lake at y = 10 under open air.
  const lake = world((_x, y) => (y === 10 ? LAVA : y < 10 ? STONE : 0));
  const a = new FxSim(rng(52)), rec = record(a);
  let pops = 0, ambient = 0;
  for (let i = 0; i < 200; i++) { animateWorldTick(a, lake, 0, 12, 0, { sound: k => { if (k === 'lava_pop') pops++; else if (k === 'lava_ambient') ambient++; } }); a.list.length = 0; }
  const embers = rec.filter(r => r[0] === 'lava');
  ok('lava surfaces under air pop embers at random (1 in 100 per visit)', embers.length > 20 && embers.length < 200, embers.length);
  ok('every ember starts on top of a lava block', embers.every(r => r[2] === 11));
  ok('each pop requests the block.lava.pop sound', pops === embers.length && pops > 0, [pops, embers.length]);
  ok('lava ambient sound is rarer than the pops (1 in 200)', ambient > 0 && ambient < pops, [ambient, pops]);
  ok('lava resting on solid rock does not drip', !rec.some(r => r[0] === 'dripping_lava'));
  const covered = world((_x, y) => (y === 10 ? LAVA : y < 10 || y === 11 ? STONE : 0));
  const c = new FxSim(rng(53));
  for (let i = 0; i < 100; i++) animateWorldTick(c, covered, 0, 12, 0, {});
  ok('covered lava (no air above) never pops', c.spawned.lava === undefined);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 7. drip_water / drip_lava (cave ceilings)');
{
  ok('stone is a full solid block, glass is impermeable, fluids are not solid', isFullSolid(STONE) && !isFullSolid(WATER) && !isFullSolid(0) && isImpermeable(GLASS) && !isImpermeable(STONE));
  const col = (blocks: Record<number, number>) => world((x, y, z) => (x === 0 && z === 0 ? blocks[y] ?? 0 : 0));
  ok('water above a stone ceiling with air below drips from that block', dripBlockBelow(col({ 10: WATER, 9: STONE }), 0, 10, 0) === 9);
  ok('lava above a stone ceiling drips too', dripBlockBelow(col({ 10: LAVA, 9: STONE }), 0, 10, 0) === 9);
  ok('glass never lets a drip through', dripBlockBelow(col({ 10: WATER, 9: GLASS }), 0, 10, 0) === null);
  ok('no drip when the ceiling rests on another solid block', dripBlockBelow(col({ 10: WATER, 9: STONE, 8: STONE }), 0, 10, 0) === null);
  ok('no drip into water', dripBlockBelow(col({ 10: WATER, 9: STONE, 8: WATER }), 0, 10, 0) === null);
  ok('no drip from fluid that hangs in mid air', dripBlockBelow(col({ 10: WATER }), 0, 10, 0) === null);

  const sim = new FxSim(rng(61), (_x, y) => y <= 0);
  const p = sim.drip(0, 9, 0, 'water')!;
  ok('water drip forms 0.05 under the ceiling block', p.kind === 'dripping_water' && near(p.y, 8.95) && p.x >= 0 && p.x <= 1);
  ok('water drip colour (0.2, 0.3, 1.0)', p.r === 0.2 && p.g === 0.3 && p.b === 1 && FX_COLORS.water.join() === '0.2,0.3,1');
  for (let i = 0; i < 40; i++) sim.tick();
  const sag = 8.95 - p.y;
  ok('drip hangs for 40 ticks, sagging slowly (gravity 0.06 x 0.02)', sim.count('dripping_water') === 1 && sag > 0.3 && sag < 1, sag);
  sim.tick();
  ok('tick 41: the hanging drip turns into falling_water', sim.count('dripping_water') === 0 && sim.count('falling_water') === 1);
  const f = sim.list.find(q => q.kind === 'falling_water')!;
  ok('falling drop keeps the position and falls with gravity 0.06', near(f.y, p.y, 1e-9) && f.gravity === 0.06 && f.physics);
  const y1 = f.y;
  sim.tick(); sim.tick(); sim.tick();
  ok('falling drop is far faster than the hanging one', y1 - f.y > 0.3, y1 - f.y);
  for (let i = 0; i < 60; i++) sim.tick();
  ok('the drop lands on the floor and bursts into a splash', sim.count('falling_water') === 0 && sim.spawned.splash === 1 && sim.spawned.falling_water === 1, sim.spawned);

  const lv = new FxSim(rng(62), (_x, y) => y <= 0);
  const l = lv.drip(0, 9, 0, 'lava')!;
  ok('lava drip starts white-hot', l.kind === 'dripping_lava' && l.r === 1 && l.g === 1 && l.b === 1);
  for (let i = 0; i < 10; i++) lv.tick();
  ok('lava drip cools while hanging: g = 16/(t+16), b = 4/(t+8)', l.r === 1 && near(l.g, 16 / 26, 1e-12) && near(l.b, 4 / 18, 1e-12), [l.g, l.b]);
  for (let i = 10; i < 40; i++) lv.tick();
  ok('lava drip sags half as fast as water (gravity x 0.01)', 8.95 - l.y > 0.15 && 8.95 - l.y < sag, 8.95 - l.y);
  // Inspect the blob on the tick it lands: it only lives 16‥80 ticks.
  for (let i = 0; i < 70 && !lv.spawned.landing_lava; i++) lv.tick();
  ok('lava drop lands as a landing_lava blob', lv.spawned.falling_lava === 1 && lv.spawned.landing_lava === 1 && lv.spawned.splash === undefined && lv.count('falling_lava') === 0, lv.spawned);
  const blob = lv.list.find(q => q.kind === 'landing_lava');
  ok('landing_lava is orange (1.0, 0.286, 0.083) and lies on the floor', !!blob && blob.r === 1 && near(blob.g, 0.2857143) && near(blob.b, 0.083333336) && near(blob.y, 1.001, 1e-9), blob && [blob.r, blob.g, blob.b, blob.y]);
  const blobLife = blob?.life ?? 0, by0 = blob?.y;
  for (let i = 0; i < blobLife; i++) lv.tick();
  ok('the blob stays put for its 16‥80 tick lifetime, then disappears', blobLife >= 16 && blobLife <= 80 && !!blob && lv.list.includes(blob) && blob.y === by0 && (lv.tick(), !lv.list.includes(blob)), blobLife);

  // Flooded cave: a water layer at y = 20 on a stone ceiling at y = 19, open cave below, floor at y <= 10.
  const cave = world((_x, y) => (y === 20 ? WATER : y === 19 || y <= 10 ? STONE : 0));
  const a = new FxSim(rng(63), (x, y, z) => cave.getBlock(x, y, z) === STONE), rec = record(a);
  for (let i = 0; i < 160; i++) { animateWorldTick(a, cave, 0, 15, 0, {}); a.tick(); }
  const drips = rec.filter(r => r[0] === 'dripping_water');
  ok('cave ceilings under water drip continuously', drips.length > 100, drips.length);
  ok('every drip hangs from the underside of the ceiling', drips.every(r => near(r[2], 18.95)));
  ok('the drips fall and splash on the cave floor', (a.spawned.falling_water ?? 0) > 50 && (a.spawned.splash ?? 0) > 20, a.spawned);
  ok('splashes appear on the floor (y = 11)', rec.filter(r => r[0] === 'splash').every(r => near(r[2], 11.001, 1e-9)));
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 8. rain_splash (rain hitting the ground)');
{
  const flat = world((_x, y) => (y <= 63 ? STONE : 0));
  ok('rainColumnTop finds the highest solid block under open sky', rainColumnTop(flat, 0, 0, 93, 55) === 63);
  ok('rainColumnTop rejects columns that are covered at the scan start', rainColumnTop(world(() => STONE), 0, 0, 93, 55) === null);
  ok('rainColumnTop returns null over a bottomless column', rainColumnTop(world(() => 0), 0, 0, 93, 55) === null);

  const sim = new FxSim(rng(71)), rec = record(sim);
  animateWorldTick(sim, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  ok('full rain, "decreased" particles: 100 x rain² / 2 = 50 splashes per tick', rec.length === 50 && rec.every(r => r[0] === 'rain'), rec.length);
  ok('splashes sit on the top face of the block the rain lands on', rec.every(r => r[2] === 64));
  ok('splashes appear within 10 blocks of the player', RAIN_SPLASH_RADIUS === 10 && rec.every(r => r[1] >= -10 && r[1] < 11 && r[3] >= -10 && r[3] < 11) && rec.some(r => Math.abs(r[1]) > 5));
  const all = new FxSim(rng(72));
  animateWorldTick(all, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 1, decreased: false });
  ok('"all" particles: 100 splashes per tick', all.spawned.rain === 100);
  const half = new FxSim(rng(73));
  animateWorldTick(half, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 0.5 });
  ok('splash count scales with rain strength squared (0.5 -> 12)', half.spawned.rain === 12, half.spawned.rain);
  const dry = new FxSim(rng(74));
  animateWorldTick(dry, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 0 });
  ok('no rain, no splashes', dry.list.length === 0);
  const snowy = new FxSim(rng(75));
  animateWorldTick(snowy, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 1, precipitation: () => 'snow' });
  ok('no splashes where the precipitation is snow', snowy.list.length === 0);
  const desert = new FxSim(rng(76));
  animateWorldTick(desert, flat, 0.5, 65.6, 0.5, { samples: 0, rain: 1, precipitation: () => 'none' });
  ok('no splashes in dry biomes', desert.list.length === 0);

  // A 7x7 roof at y = 70 above the player.
  const roofed = world((x, y, z) => (y <= 63 || (y === 70 && Math.abs(x) <= 3 && Math.abs(z) <= 3) ? STONE : 0));
  const r = new FxSim(rng(77)), rrec = record(r);
  for (let i = 0; i < 10; i++) animateWorldTick(r, roofed, 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  const under = rrec.filter(a => Math.floor(a[1]) >= -3 && Math.floor(a[1]) <= 3 && Math.floor(a[3]) >= -3 && Math.floor(a[3]) <= 3);
  ok('under a roof the rain splashes on the roof, never on the floor beneath it', under.length > 20 && under.every(a => a[2] === 71) && rrec.filter(a => !under.includes(a)).every(a => a[2] === 64), under.length);
  const cave = world((x, y, z) => (Math.abs(x) <= 12 && Math.abs(z) <= 12 && y >= 64 && y <= 68 ? 0 : STONE));
  const c = new FxSim(rng(78));
  animateWorldTick(c, cave, 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  ok('no splashes inside a cave', c.list.length === 0);
  const tall = world((_x, y) => (y <= 80 ? STONE : 0));
  const t = new FxSim(rng(79));
  animateWorldTick(t, tall, 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  ok('surfaces more than 10 blocks above the camera are skipped', t.list.length === 0);
  const pond = new FxSim(rng(80)), prec = record(pond);
  animateWorldTick(pond, world((_x, y) => (y === 63 ? WATER : y < 63 ? STONE : 0)), 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  ok('on water the droplets sit on the water surface', prec.length === 50 && prec.every(a => near(a[2], 63.89)));
  const hot = new FxSim(rng(81));
  animateWorldTick(hot, world((_x, y) => (y === 63 ? MAGMA : y < 63 ? STONE : 0)), 0.5, 65.6, 0.5, { samples: 0, rain: 1 });
  ok('rain on magma (or lava) hisses into smoke instead', hot.spawned.smoke === 50 && hot.spawned.rain === undefined, hot.spawned);

  const b = new FxSim(rng(82), (_x, y) => y <= 63);
  const d = b.rainSplash(0, 64, 0)!;
  ok('rain droplet hops up at 0.1‥0.3 blocks/tick with gravity 0.06', d.kind === 'rain' && d.vy >= 0.1 && d.vy <= 0.3 && d.gravity === 0.06 && d.life >= 8 && d.life <= 40);
  let top = d.y, lo = d.y;
  for (let i = 0; i < 41; i++) { b.tick(); if (b.list.includes(d)) { top = Math.max(top, d.y); lo = Math.min(lo, d.y); } }
  ok('droplet bounces less than a block high and stays above the ground', top > 64 && top < 65 && lo >= 64, [top, lo]);
  ok('droplet is gone within its 8‥40 tick lifetime', b.list.length === 0);
  ok('droplets are tinted rain-blue', d.b > d.g && d.g > d.r);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 9. happy_villager (bone meal, crop growth, trading)');
{
  const sim = new FxSim(rng(91)), rec = record(sim);
  sim.happyVillager(3, 64, 3);
  ok('bone meal: 15 glints', rec.length === 15 && rec.every(r => r[0] === 'happy_villager'));
  ok('glints are spread through the whole block', rec.every(r => r[1] >= 3 && r[1] <= 4 && r[2] >= 64 && r[2] <= 65 && r[3] >= 3 && r[3] <= 4) && rec.some(r => r[2] > 64.6) && rec.some(r => r[2] < 64.4));
  ok('glint drift velocity is gaussian x 0.02', rec.every(r => Math.abs(r[4]) < 0.12 && Math.abs(r[5]) < 0.12));
  const start = sim.list.map(p => [p.x, p.y, p.z]);
  ok('glint lifetime = 20 / (rand*0.8+0.2) -> 20‥100 ticks, no gravity', sim.list.every(p => p.life >= 20 && p.life <= 100 && p.gravity === 0));
  const ps = [...sim.list];
  for (let i = 0; i < 20; i++) sim.tick();
  ok('glints hang almost still (< 0.15 block in a second)', ps.every((p, i) => Math.hypot(p.x - start[i][0], p.y - start[i][1], p.z - start[i][2]) < 0.15));
  ok('glints stay their own (green sprite) colour: white tint', ps.every(p => p.r === 1 && p.g === 1 && p.b === 1));
  for (let i = 0; i < 81; i++) sim.tick();
  ok('glints vanish after at most 100 ticks', sim.list.length === 0);
  rec.length = 0;
  sim.happyVillager(0, 64, 0, 3, 0.5, 0.6);
  ok('natural crop growth uses a small puff (3 glints, low in the block)', rec.length === 3 && rec.every(r => r[2] <= 64.6));
  rec.length = 0;
  const villager: FxBox = { x: 10, y: 64, z: 10, w: 0.6, h: 1.95 };
  sim.happyVillagerAround(villager);
  ok('trade: 5 glints around and above the villager', rec.length === 5 && rec.every(r => Math.abs(r[1] - 10) <= 0.6 && Math.abs(r[3] - 10) <= 0.6 && r[2] >= 65 && r[2] <= 66.95));
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 10. Simulation limits, timing and the three.js layer');
{
  const sim = new FxSim(rng(101));
  sim.viewer = { x: 0, y: 64, z: 0 };
  ok('particles beyond 32 blocks from the camera are not created', sim.spawn('crit', 33, 64, 0) === null && sim.spawn('crit', 31, 64, 0) !== null);
  sim.viewer = null;
  for (let i = 0; i < FX_MAX + 10; i++) sim.spawn('happy_villager', 0, 64, 0);
  ok(`particle count is capped at ${FX_MAX}`, sim.list.length === FX_MAX);
  sim.clear();
  ok('clear() removes particles and emitters', sim.list.length === 0 && sim.emitters.length === 0);
  const t = new FxSim(rng(102));
  ok('step() converts real time into 20 Hz ticks and keeps the remainder for interpolation', t.step(0.16) === 3 && near(t.alpha, 0.2, 1e-6) && t.ticks === 3);
  ok('a long frame is clamped (no spiral of death)', t.step(5) === 5);
  const box = entityFxBox({ position: { x: 1, y: 64, z: 2 }, scale: { y: 1.45 } }, { position: { y: 1.6 } });
  ok('mob bounding box is derived from the rig (enderman ≈ 2.8 tall)', box.x === 1 && box.y === 64 && box.z === 2 && near(box.h, 1.95 * 1.45, 1e-9) && box.w > 0.3);

  const scene = new THREE.Scene(), ps = new ParticleSystem(scene);
  ok('the billboard layer adds nothing to the scene until a particle exists', scene.children.length === 0);
  const api = ['crit', 'enchantedHit', 'mobSpell', 'portal', 'endermanPortal', 'lavaPop', 'dripWater', 'dripLava', 'rainSplash', 'happyVillager', 'happyVillagerAround'];
  ok('ParticleSystem exposes every new effect', api.every(n => typeof (ps as unknown as Record<string, unknown>)[n] === 'function'));
  ok('dripWater / dripLava / lavaPop / rainSplash create the right Java particles', ps.dripWater(0, 70, 0)?.kind === 'dripping_water' && ps.dripLava(0, 70, 0)?.kind === 'dripping_lava' && ps.lavaPop(0, 63, 0)?.kind === 'lava' && ps.rainSplash(0, 64, 0)?.kind === 'rain');
  ps.crit(BOX);
  ps.update(0.05, (_x, y) => (y < 64 ? STONE : 0), () => false);
  const pts = scene.children.find(o => (o as THREE.Points).isPoints) as THREE.Points | undefined;
  ok('particles are drawn as one camera-facing point-sprite batch', !!pts && scene.children.filter(o => (o as THREE.Points).isPoints).length === 1);
  const geo = pts!.geometry;
  ok('draw range follows the live particle count', geo.drawRange.count === ps.fx.list.length && ps.fx.list.length >= 4, [geo.drawRange.count, ps.fx.list.length]);
  ok('per-particle colour, size, frame and glow attributes are uploaded', !!geo.getAttribute('aColor') && geo.getAttribute('aColor').itemSize === 4 && geo.getAttribute('aMisc').itemSize === 3 && geo.getAttribute('position').count === FX_MAX);
  const mat = pts!.material as THREE.ShaderMaterial;
  ok('sprite sheet is a nearest-filtered data texture', (mat.uniforms.uMap.value as THREE.DataTexture).magFilter === THREE.NearestFilter && (mat.uniforms.uMap.value as THREE.DataTexture).image.width === 64);
  ok('billboards are depth-tested but do not write depth', mat.depthTest && !mat.depthWrite && mat.transparent);
  const cam = new THREE.PerspectiveCamera(70, 16 / 9, 0.1, 500);
  cam.position.set(0, 65, 0);
  ps.setView(cam, 1080, 0.1);
  ok('sprite scale = viewport height / (2 tan(fov/2))', near(mat.uniforms.uScale.value, 1080 / (2 * Math.tan((35 * Math.PI) / 180)), 1e-6));
  ok('ambient light is clamped so particles never go black', mat.uniforms.uAmbient.value === 0.25);
  ok('the camera becomes the 32-block cull origin', ps.fx.viewer?.y === 65 && ps.lavaPop(100, 64, 0) === null);
  for (let i = 0; i < 40; i++) ps.update(0.05, (_x, y) => (y < 64 ? STONE : 0), () => false);
  // Everything above was spawned on or above the floor (blocks below y = 64 are solid), so nothing may end up inside it.
  ok('physics particles collide with the world passed to update()', ps.fx.list.filter(p => p.physics).every(p => p.y >= 64), ps.fx.list.filter(p => p.physics && p.y < 64).map(p => [p.kind, p.y]));
  ps.burst(new THREE.Vector3(0, 65, 0), '#ffffff', 5);
  ok('the original block-debris burst still works next to the new layer', ps.particles.length === 5);
  ps.clear();
  ok('clear() empties both layers', ps.fx.list.length === 0 && ps.particles.length === 0 && geo.drawRange.count === 0);
  ps.dispose();
  ok('dispose() removes the batch from the scene', !scene.children.some(o => (o as THREE.Points).isPoints));
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 11. Rain <-> snow by biome temperature');
{
  ok('snow threshold is temperature 0.15', SNOW_TEMPERATURE === 0.15);
  const snowy = ['snowy_plains', 'ice_spikes', 'snowy_taiga', 'snowy_beach', 'frozen_river', 'frozen_ocean', 'grove', 'snowy_slopes', 'jagged_peaks', 'frozen_peaks'];
  ok('cold and snowy-mountain biomes get snow', snowy.every(b => precipitationAt(b, 70) === 'snow'), snowy.filter(b => precipitationAt(b, 70) !== 'snow'));
  const rainy = ['plains', 'forest', 'birch_forest', 'dark_forest', 'swamp', 'jungle', 'taiga', 'meadow', 'cherry_grove', 'beach', 'river', 'ocean', 'mushroom_fields', 'stony_peaks'];
  ok('temperate biomes get rain at normal heights', rainy.every(b => precipitationAt(b, 70) === 'rain'), rainy.filter(b => precipitationAt(b, 70) !== 'rain'));
  const dry = ['desert', 'savanna', 'savanna_plateau', 'windswept_savanna', 'badlands', 'eroded_badlands', 'wooded_badlands'];
  ok('deserts, savannas and badlands stay dry', dry.every(b => precipitationAt(b, 70) === 'none'));
  ok('no precipitation in the Nether or the End', precipitationAt('plains', 70, 'nether') === 'none' && precipitationAt('snowy_plains', 70, 'end') === 'none');
  ok('Java base temperatures: jagged_peaks -0.7, grove -0.2, snowy_taiga -0.5, taiga 0.25, plains 0.8, desert 2.0', BIOME_CLIMATE.jagged_peaks.t === -0.7 && BIOME_CLIMATE.grove.t === -0.2 && BIOME_CLIMATE.snowy_taiga.t === -0.5 && BIOME_CLIMATE.taiga.t === 0.25 && BIOME_CLIMATE.plains.t === 0.8 && BIOME_CLIMATE.desert.t === 2);
  ok('temperature is constant up to Y=80, then drops 0.00125 per block', biomeTemperature('taiga', 64) === 0.25 && biomeTemperature('taiga', 80) === 0.25 && near(biomeTemperature('taiga', 120), 0.2, 1e-12));
  ok('windswept hills (0.2): rain below Y=120, snow above', precipitationAt('windswept_hills', 119) === 'rain' && precipitationAt('windswept_hills', 122) === 'snow' && snowLine('windswept_hills') === 121, snowLine('windswept_hills'));
  ok('taiga (0.25) turns to snow above Y=160', precipitationAt('taiga', 150) === 'rain' && precipitationAt('taiga', 170) === 'snow' && snowLine('taiga') === 161, snowLine('taiga'));
  ok('snow lines: always in snowy biomes, never in plains / stony peaks / deserts', snowLine('snowy_plains') === -Infinity && snowLine('plains') === Infinity && snowLine('stony_peaks') === Infinity && snowLine('desert') === Infinity);
  ok('unknown biome names fall back sensibly', biomeClimate('frozen_whatever').t < 0.15 && !biomeClimate('red_desert').wet && biomeClimate('somewhere').t === 0.8);

  const mix = { rain: 1, snow: 0 };
  stepPrecipitationMix(mix, 'snow', 0.1);
  ok('rain fades out while snow fades in (cross-fade, not a hard cut)', mix.rain < 1 && mix.rain > 0.5 && mix.snow > 0 && mix.snow < 0.5 && near(mix.rain + mix.snow, 1, 1e-9), mix);
  for (let i = 0; i < 80; i++) stepPrecipitationMix(mix, 'snow', 0.1);
  ok('the blend settles on pure snow', mix.rain < 1e-4 && mix.snow > 0.9999);
  for (let i = 0; i < 80; i++) stepPrecipitationMix(mix, 'none', 0.1);
  ok('dry biome: both fade away', mix.rain < 1e-4 && mix.snow < 1e-4);
  ok('snowflakes fall slowly (≤ 2 blocks/s, rain falls at 20+) and sway sideways', SNOW.fall > 0.5 && SNOW.fall <= 2 && SNOW.sway >= 0.5);

  const scene = new THREE.Scene(), fx = new AtmosphereFx(scene);
  ok('atmosphere adds a snow field and a nether dust field to the scene', scene.children.length === 2 && fx.snow instanceof DriftField && fx.snow.count === SNOW.count);
  const run = (o: { biome: string; weather: 'clear' | 'rain' | 'storm'; y?: number; dimension?: string; precipBiome?: string }, steps = 60) => {
    for (let i = 0; i < steps; i++) fx.update({ dt: 0.1, elapsed: i * 0.1, camera: { x: 5, y: o.y ?? 70, z: -3 }, scale: 700, dimension: o.dimension ?? 'overworld', biome: o.biome, precipBiome: o.precipBiome, weather: o.weather });
    return fx;
  };
  run({ biome: 'plains', weather: 'rain' });
  ok('plains + rain weather: rain, no snow', fx.precipitation === 'rain' && fx.mix.rain > 0.99 && !fx.snow.points.visible);
  run({ biome: 'snowy_plains', weather: 'rain' }, 1);
  ok('walking into a snowy biome starts the switch immediately', fx.precipitation === 'snow' && fx.mix.snow > 0.1 && fx.mix.rain < 0.9 && fx.snow.points.visible);
  run({ biome: 'snowy_plains', weather: 'rain' });
  ok('snowy biome: snow replaces the rain completely', fx.mix.snow > 0.99 && fx.mix.rain < 0.01 && fx.snow.material.uniforms.uOpacity.value > 0.7);
  ok('snow field is centred on the camera', fx.snow.material.uniforms.uCam.value.x === 5 && fx.snow.material.uniforms.uCam.value.y === 70 && fx.snow.material.uniforms.uCam.value.z === -3);
  ok('snow drifts downward with wind', fx.snow.material.uniforms.uDrift.value.y === -SNOW.fall && fx.snow.material.uniforms.uJitter.value === SNOW.sway);
  const light = fx.snow.material.uniforms.uOpacity.value;
  run({ biome: 'snowy_plains', weather: 'storm' });
  ok('a storm makes the snowfall denser', fx.snow.material.uniforms.uOpacity.value > light);
  run({ biome: 'plains', weather: 'storm' });
  ok('back in a temperate biome it rains again', fx.precipitation === 'rain' && fx.mix.rain > 0.99 && !fx.snow.points.visible);
  run({ biome: 'jagged_peaks', weather: 'rain', y: 180 });
  ok('snowy mountain peaks: snow', fx.precipitation === 'snow' && fx.snow.points.visible);
  run({ biome: 'windswept_hills', weather: 'rain', y: 100 });
  const low = fx.precipitation;
  run({ biome: 'windswept_hills', weather: 'rain', y: 140 });
  ok('climbing above the snow line switches rain to snow', low === 'rain' && fx.precipitation === 'snow');
  run({ biome: 'lush_caves', precipBiome: 'snowy_taiga', weather: 'rain' });
  ok('the surface biome (not the cave biome) decides the precipitation', fx.precipitation === 'snow');
  run({ biome: 'desert', weather: 'storm' });
  ok('desert: neither rain nor snow', fx.precipitation === 'none' && fx.mix.rain < 0.01 && fx.mix.snow < 0.01 && !fx.snow.points.visible);
  run({ biome: 'snowy_plains', weather: 'clear' });
  ok('clear weather: nothing falls', fx.precipitation === 'none' && !fx.snow.points.visible);
  fx.dispose();
  ok('atmosphere dispose() detaches both fields', scene.children.length === 0);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 12. Nether biome ash & spores');
{
  const N = NETHER_AMBIENT;
  ok('soul sand valley: ash, probability 0.00625', N.soul_sand_valley.particle === 'ash' && N.soul_sand_valley.probability === 0.00625);
  ok('crimson forest: crimson_spore, probability 0.025', N.crimson_forest.particle === 'crimson_spore' && N.crimson_forest.probability === 0.025);
  ok('warped forest: warped_spore, probability 0.01428', N.warped_forest.particle === 'warped_spore' && N.warped_forest.probability === 0.01428);
  ok('basalt deltas: white_ash, probability 0.118093334', N.basalt_deltas.particle === 'white_ash' && N.basalt_deltas.probability === 0.118093334);
  ok('nether wastes (and the overworld) have no ambient particle', netherAmbientFor('nether', 'nether_wastes') === null && netherAmbientFor('overworld', 'basalt_deltas') === null && netherAmbientFor('nether', 'basalt_deltas') === N.basalt_deltas);
  ok('white ash colour (0.729, 0.694, 0.761)', near(N.basalt_deltas.color[0], 0.7294118) && near(N.basalt_deltas.color[1], 0.69411767) && near(N.basalt_deltas.color[2], 0.7607843));
  ok('crimson spore colour (0.9, 0.4, 0.5)', N.crimson_forest.color.join() === '0.9,0.4,0.5');
  ok('warped spore colour (0.1, 0.1, 0.3) — dark blue', N.warped_forest.color.join() === '0.1,0.1,0.3');
  const ash = N.soul_sand_valley;
  ok('ash is neutral grey with brightness ≤ 0.5', ash.color[0] === ash.color[1] && ash.color[1] === ash.color[2] && ash.color2[0] === ash.color2[2] && ash.color2[0] <= 0.5 && ash.color[0] < ash.color2[0]);
  ok('particle density follows the biome probabilities', N.basalt_deltas.count === NETHER_DUST_CAPACITY && N.crimson_forest.count === 212 && N.warped_forest.count === 121 && N.soul_sand_valley.count === 53, [N.basalt_deltas.count, N.crimson_forest.count, N.warped_forest.count, N.soul_sand_valley.count]);
  ok('basalt deltas is a storm: densest and blown sideways', N.basalt_deltas.count > 4 * N.crimson_forest.count && N.basalt_deltas.drift[0] < -0.5 && N.basalt_deltas.drift[2] < -0.5 && N.basalt_deltas.drift[1] < 0);
  ok('crimson spores hover, warped spores and ash sink', Math.abs(N.crimson_forest.drift[1]) < 0.1 && N.warped_forest.drift[1] < -0.5 && ash.drift[1] < -0.5 && ash.drift[0] === 0);

  const fx = new AtmosphereFx(new THREE.Scene());
  const run = (dimension: string, biome: string, steps = 20) => { for (let i = 0; i < steps; i++) fx.update({ dt: 0.1, elapsed: i * 0.1, camera: { x: 0, y: 40, z: 0 }, scale: 700, dimension, biome, weather: 'rain' }); };
  run('nether', 'basalt_deltas');
  const u = fx.dust.material.uniforms;
  ok('basalt deltas: 1000 white-ash particles fade in', fx.dust.points.visible && fx.dust.count === 1000 && fx.dust.geometry.drawRange.count === 1000 && near(u.uOpacity.value, N.basalt_deltas.opacity, 1e-9) && near(u.uColor.value.x, 0.7294118));
  ok('white ash is blown with gust-like velocity spread', u.uSpread.value === 1 && u.uDrift.value.x === -0.95);
  ok('it never rains or snows in the Nether', fx.precipitation === 'none' && !fx.snow.points.visible);
  run('nether', 'crimson_forest', 1);
  ok('crossing a biome border fades the old particles out first', fx.dustSpec === N.basalt_deltas && u.uOpacity.value < N.basalt_deltas.opacity && u.uOpacity.value > 0);
  run('nether', 'crimson_forest');
  ok('crimson forest: 212 red spores', fx.dustSpec === N.crimson_forest && fx.dust.count === 212 && u.uColor.value.x === 0.9 && u.uColor.value.y === 0.4 && fx.dust.points.visible);
  run('nether', 'warped_forest');
  ok('warped forest: 121 dark-blue spores', fx.dust.count === 121 && u.uColor.value.z === 0.3 && u.uDrift.value.y === -0.95);
  run('nether', 'soul_sand_valley');
  ok('soul sand valley: 53 grey ash flakes', fx.dust.count === 53 && u.uColor2.value.x === 0.5 && u.uSpread.value === 0);
  run('nether', 'nether_wastes');
  ok('nether wastes: the air is clear', !fx.dust.points.visible && fx.dustSpec === null);
  run('nether', 'basalt_deltas');
  run('overworld', 'plains');
  ok('leaving the Nether removes the ash', !fx.dust.points.visible && u.uOpacity.value === 0);
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 13. Dynamic FOV');
{
  ok('standing still: x1', fovModifier({}) === 1);
  ok('sprinting: (1.3 + 1) / 2 = x1.15', near(fovModifier({ sprinting: true }), 1.15, 1e-12));
  ok('Speed I: x1.1, Speed II: x1.2', near(fovModifier({ speed: 1 }), 1.1, 1e-12) && near(fovModifier({ speed: 2 }), 1.2, 1e-12));
  ok('sprinting with Speed I: (1.3 x 1.2 + 1) / 2 = x1.28', near(fovModifier({ sprinting: true, speed: 1 }), 1.28, 1e-12));
  ok('Slowness I: x0.925', near(fovModifier({ slowness: 1 }), 0.925, 1e-12));
  ok('creative flight: x1.1, sprint-flying x1.265', near(fovModifier({ flying: true }), 1.1, 1e-12) && near(fovModifier({ flying: true, sprinting: true }), 1.265, 1e-12));
  ok('bow fully drawn (20 ticks): x0.85', near(fovModifier({ bowTicks: 20 }), 0.85, 1e-12) && near(fovModifier({ bowTicks: 60 }), 0.85, 1e-12));
  ok('bow half drawn: quadratic ease, 1 - 0.5² x 0.15 = x0.9625', near(fovModifier({ bowTicks: 10 }), 0.9625, 1e-12));
  const draw = Array.from({ length: 21 }, (_, t) => fovModifier({ bowTicks: t }));
  ok('drawing the bow narrows the view monotonically', draw.every((v, i) => i === 0 || v < draw[i - 1] || (i === 1 && v < 1)) && draw[0] === 1, draw.slice(0, 4));
  ok('sprinting while drawing combines both: 1.15 x 0.85', near(fovModifier({ sprinting: true, bowTicks: 20 }), 0.9775, 1e-12));
  ok('modifier is clamped to 0.1‥1.5', fovModifier({ sprinting: true, speed: 5 }) === 1.5 && FOV_EFFECTS.min === 0.1 && FOV_EFFECTS.max === 1.5);
  ok('Slowness VII stops at x0.5', near(fovModifier({ slowness: 7 }), 0.5, 1e-12));
  ok('"FOV Effects" slider scales the change (0 = off, 0.5 = half)', fovModifier({ sprinting: true, effectScale: 0 }) === 1 && near(fovModifier({ sprinting: true, effectScale: 0.5 }), 1.075, 1e-12));
  ok('spyglass scoping: x0.1', fovModifier({ scope: 0.1 }) === 0.1 && near(fovModifier({ scope: 0.1, bowTicks: 20 }), 0.85, 1e-12));
  ok('one tick moves the FOV half way to its target', near(stepFovModifier(1, 1.15, 0.05), 1.075, 1e-12));
  ok('easing is frame-rate independent', near(stepFovModifier(stepFovModifier(1, 1.15, 0.025), 1.15, 0.025), stepFovModifier(1, 1.15, 0.05), 1e-12));
  let f = 1;
  for (let i = 0; i < 60; i++) f = stepFovModifier(f, 1.15, 1 / 60);
  ok('the sprint kick settles within a second', near(f, 1.15, 1e-5), f);
  ok('releasing sprint eases back', stepFovModifier(1.15, 1, 0.05) < 1.15 && stepFovModifier(1.15, 1, 0.05) > 1);
  ok('70° base: 80.5° sprinting, 59.5° with a drawn bow', near(fovDegrees(70, 1.15), 80.5, 1e-9) && near(fovDegrees(70, 0.85), 59.5, 1e-9));
  ok('camera under water / lava: x60/70 (70° -> 60°)', near(fovDegrees(70, 1, { submerged: true }), 60, 1e-9));
}

// ---------------------------------------------------------------------------------------------------------------------
console.log('--- 14. Game wiring and scope guard');
{
  const src = (p: string) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
  const engine = src('src/game/engine.ts'), survival = src('src/game/survival.ts'), env = src('src/render/environment.ts'), farming = src('src/systems/farming.ts'), mobs = src('src/entities/mobs.ts');
  ok('melee: a critical hit emits crit stars on the victim', /if \(crit\) e\.particles\.crit\?\.\(hitBox\)/.test(survival));
  ok('melee: Sharpness / Smite / Bane / Impaling bonus damage emits enchanted_hit', /lvl\(held, 'sharpness'\) > 0 \|\| special > 0\) e\.particles\.enchantedHit\?\.\(hitBox\)/.test(survival));
  ok('the old yellow cube spark is replaced by the star particle', !/spark\?\.\(center, '#ffd866'/.test(mobs));
  ok('engine drives block ambience at 20 Hz', /animateWorldTick\(this\.particles\.fx, this, cam\.x, cam\.y, cam\.z/.test(engine) && /this\.fxAcc >= FX_TICK/.test(engine));
  ok('rain splashes only where it actually rains', /rain: this\.dimension === 'overworld' && this\.weather !== 'clear' && this\.environment\.precipitation === 'rain' \? 1 : 0/.test(engine));
  ok('player status effects emit swirls', /this\.particles\.mobSpell\(\{ x: this\.position\.x/.test(engine));
  ok('mob status effects emit swirls', /this\.particles\.mobSpell\(box, cols/.test(engine));
  ok('endermen emit portal motes', /if \(enderman\) this\.particles\.endermanPortal\(box\)/.test(engine));
  ok('bone meal / growth uses happy_villager glints', /particles: \(x, y, z, _color, n\) => this\.particles\.happyVillager\(/.test(engine));
  ok('natural crop growth is reported by the farming system and shown', /this\.host\.cropGrew\?\.\(x, y, z\)/.test(farming) && /cropGrew: \(x, y, z\) => this\.particles\.happyVillager\(/.test(engine));
  ok('a successful trade makes the villager happy', /this\.addXp\(3\); this\.villagerHappy\(\);/.test(engine) && /happyVillagerAround\(entityFxBox\(best\.group, best\.head\)\)/.test(engine));
  ok('camera FOV is driven by Environment.updateFov (sprint, Speed, bow, flight, water)', /this\.environment\.updateFov\(this\.camera, this\.settings\.fov, \{/.test(engine) && /bowTicks: this\.useItemName === 'bow'/.test(engine) && /speed: SV\.amp\(this, 'speed'\)/.test(engine));
  ok('no second code path overrides the camera FOV every frame', !/const wantFov =/.test(engine));
  ok('the surface biome is passed to the environment for rain / snow', /nightVision, this\.surfaceBiome\)/.test(engine));
  ok('nether ambience no longer uses the old glowing placeholder motes', !env.includes('#63d8f2') && /this\.atmosphere\.update\(/.test(env));
  ok('rain volume follows the camera height', /Math\.round\(p\.y \/ 16\) \* 16 - 24/.test(env));

  // World generation must stay byte-identical to the integrated archive.
  const WORLD: Record<string, string> = {
    'chunk.worker.ts': '1aa6bae2bf5ddfa75a242788a20d8647a6ceb7e3e9f65e44238f8a9759b8e5b8',
    'dungeons.ts': '328605b8360e133a04152ed3184d3b981829d26fbdd25ce45568881861da901b',
    'features.ts': 'c38b19317eb5f907bee426566a7740c26ccf2ca71cc99c6ca5f57f188d31e746',
    'mesher.ts': 'd934ff1b978c8801d6bda73d6d4f99a781cfabb2317b8b1874f4f277deaa8967',
    'overworld.ts': 'e97083ef8aa8708e970a03cdbc48ccbd8f4f0cc65b65bf2c9cc143877e47c71e',
    'raycast.ts': 'adea10a559cd006ee8ee483ad804624c1e8ffa87dee749c1f2d8a0547ecd5219',
    'shapes.ts': '05c862cf639ec91b447ee8caede206ccfe9294a78bc07e1d73d030d9e6e10b74',
    'structures.ts': '92fbae02ab329bf5208ac6ecb291feedd08884be703e9dd69680a81dab31e635',
    'terrain.ts': '0defd5a8e4e06c99e9f56d55b0c019bc450581b64120355ed4fa565ec7b0ff92',
    'underground.ts': '577f8e5daccf6240ae3bda0fce48d005be4a3fb784bf2f5bcea70422c733081e',
  };
  const changed = Object.keys(WORLD).filter(f => createHash('sha256').update(readFileSync(new URL('../src/world/' + f, import.meta.url))).digest('hex') !== WORLD[f]);
  ok('src/world/ (world generation) is byte-identical to the integrated archive: 10 files', changed.length === 0, changed);
  ok('magma and lava are registered blocks with a definition', !!BLOCKS[MAGMA] && !!BLOCKS[LAVA]);
}

console.log(`\n${pass}/${pass + fail} particle & environment checks passed`);
if (fail) process.exit(1);
