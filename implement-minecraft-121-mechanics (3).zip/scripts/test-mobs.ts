import assert from 'node:assert/strict';
import * as THREE from 'three';
import { MobManager, type Species } from '../src/entities/mobs';
import '../src/game/content';

/*
 * Walk-cycle checks that do not need a browser. Each mob is spawned in a stub world, moved a known distance per frame and its limb
 * pivots are inspected: quadrupeds must use diagonal pairs, bipeds opposite arm/leg, chickens two legs (not four), spiders eight
 * splayed legs, and every limb must stay within a sane angle so feet never clip through the ground.
 */

function manager() {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
  camera.position.set(0, 2, 0);
  const particles = { burst() {}, drop() {}, spark() {} };
  const mobs = new MobManager(scene, {
    terrain: { height: () => 73, biome: () => 'plains' } as never,
    position: new THREE.Vector3(0, 74, 6), camera, dimension: 'overworld',
    getBlock: () => 0, damage() {}, addItem: () => true, toast() {}, sound() {}, explode() {}, openTrade() {},
    particles: particles as never,
  });
  return { mobs, scene };
}

function walk(species: Species, frames = 40, step = 0.06) {
  const { mobs } = manager();
  const m = mobs.spawn(species, 0, 0);
  assert.ok(m, species + ' could spawn');
  for (let i = 0; i < frames; i++) {
    m!.group.position.x += step;
    (mobs as unknown as { update(dt: number, daylight: number, peaceful: boolean): void }).update(1 / 60, 1, false);
  }
  return m!;
}

const results: { name: string; ok: boolean; note?: string }[] = [];
function test(name: string, fn: () => void) {
  try { fn(); results.push({ name, ok: true }); }
  catch (e) { results.push({ name, ok: false, note: e instanceof Error ? e.message : String(e) }); }
}
const limbs = (m: { limbs?: { kind: string; phase: number; amp: number; node: THREE.Object3D; baseX: number }[] }) => m.limbs ?? [];

test('quadruped: four hip-pivoted legs, diagonal pairs', () => {
  const m = walk('cow');
  const l = limbs(m);
  assert.equal(l.length, 4);
  assert.deepEqual(l.map(x => +x.phase.toFixed(2)), [0, Math.PI, Math.PI, 0].map(v => +v.toFixed(2)));
  assert.ok(l.every(x => x.amp <= 0.6));
});
test('quadruped: opposite diagonal legs swing in opposite directions', () => {
  const m = walk('cow');
  const l = limbs(m);
  assert.ok(Math.sign(l[0].node.rotation.x) !== Math.sign(l[1].node.rotation.x));
  assert.ok(Math.sign(l[0].node.rotation.x) === Math.sign(l[3].node.rotation.x));
});
test('quadruped: walk phase advances while moving', () => {
  const m = walk('pig');
  assert.ok((m.walk ?? 0) > 2, 'walk=' + m.walk);
  assert.ok((m.swing ?? 0) > 0.8, 'swing=' + m.swing);
});
test('quadruped: legs ease back to rest when the mob stops', () => {
  const { mobs } = manager();
  const m = mobs.spawn('sheep', 0, 0)!;
  for (let i = 0; i < 30; i++) { m.group.position.x += 0.06; mobs.update(1 / 60, 1, false); }
  m.state = 'graze'; m.timer = 999;      // stop wandering so only the animation damping remains
  for (let i = 0; i < 60; i++) mobs.update(1 / 60, 1, false);
  assert.ok((m.swing ?? 1) < 0.05, 'swing=' + m.swing);
  assert.ok(Math.abs(limbs(m)[0].node.rotation.x) < 0.05, 'leg should return to rest');
});
test('biped: two legs and two arms with opposite phase', () => {
  const m = walk('zombie');
  const l = limbs(m);
  assert.equal(l.filter(x => x.kind === 'leg').length, 2);
  assert.equal(l.filter(x => x.kind === 'arm').length, 2);
  const legs = l.filter(x => x.kind === 'leg'), arms = l.filter(x => x.kind === 'arm');
  assert.ok(Math.sign(legs[0].node.rotation.x) !== Math.sign(legs[1].node.rotation.x));
  assert.ok(Math.sign(arms[0].node.rotation.x - arms[0].baseX) !== Math.sign(arms[1].node.rotation.x - arms[1].baseX));
});
test('zombie arms keep their forward resting pose while walking', () => {
  const m = walk('zombie');
  assert.ok(limbs(m).filter(x => x.kind === 'arm').every(a => a.baseX < -0.5));
});
test('chicken: two legs and two wings, no four-legged walk', () => {
  const m = walk('chicken');
  const l = limbs(m);
  assert.equal(l.filter(x => x.kind === 'leg').length, 2);
  assert.equal(l.filter(x => x.kind === 'wing').length, 2);
});
test('spider: eight legs with the resting splay kept', () => {
  const m = walk('spider');
  const l = limbs(m);
  assert.equal(l.length, 8);
  assert.ok(l.every(x => x.kind === 'spider' && x.node.rotation.z !== 0));
  const left = l.slice(0, 4), right = l.slice(4);
  assert.ok(Math.sign(left[0].node.rotation.y) !== Math.sign(right[0].node.rotation.y));
});
test('wings flap for flying mobs', () => {
  const m = walk('bee', 10, 0);
  const wings = limbs(m).filter(x => x.kind === 'wing');
  assert.equal(wings.length, 2);
});
test('every limb angle stays finite and inside a safe range', () => {
  for (const sp of ['cow', 'pig', 'sheep', 'wolf', 'cat', 'horse', 'chicken', 'zombie', 'skeleton', 'villager', 'spider', 'fox', 'rabbit'] as Species[]) {
    const m = walk(sp, 20, 0.08);
    for (const l of limbs(m)) {
      const limit = l.kind === 'arm' ? 1.7 : 0.9;   // zombie/enderman arms rest pointing forward
      assert.ok(Number.isFinite(l.node.rotation.x) && Math.abs(l.node.rotation.x) < limit, sp + ' ' + l.kind + ' angle ' + l.node.rotation.x);
      assert.ok(Number.isFinite(l.node.rotation.y) && Math.abs(l.node.rotation.y) < 1.2, sp + ' head/leg yaw');
    }
  }
});
test('head looks towards the player when close', () => {
  const { mobs } = manager();
  const m = mobs.spawn('cow', 0, 0)!;
  mobs.update(1 / 60, 1, false);
  assert.ok(Number.isFinite(m.head.rotation.x) && Math.abs(m.head.rotation.x) <= 0.6);
});

const passed = results.filter(r => r.ok).length;
for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.note ? '  — ' + r.note : ''}`);
console.log(`\n${passed}/${results.length} walk-cycle checks passed`);
if (passed !== results.length) process.exit(1);
