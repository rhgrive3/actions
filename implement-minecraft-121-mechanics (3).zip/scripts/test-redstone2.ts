import assert from 'node:assert/strict';
import { Redstone, type RedstoneHost } from '../src/systems/redstone';
import { ID } from '../src/game/data';
import '../src/game/content';

/*
 * Record 014 redstone checks: quasi-connectivity and BUD behaviour, real piston heads, slime/honey structures,
 * observer output face, hopper cooldown, inverted daylight detectors, copper bulbs, crafters and detector rails.
 * Facing order: 0 +X, 1 +Z, 2 -X, 3 -Z, 4 up, 5 down.
 */
const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;
class World implements RedstoneHost {
  cells = new Map<string, number>();
  light = 15;
  crafts: string[] = [];
  ejected: string[] = [];
  transfers = 0;
  movedCount = 0;
  getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    const k = K(x, y, z), cell = id === 0 ? 0 : (id | (state << 12));
    if ((this.cells.get(k) ?? 0) === cell) return false;
    if (cell === 0) this.cells.delete(k); else this.cells.set(k, cell);
    return true;
  }
  eject(x: number, y: number, z: number, dir: number, kind: string) { this.ejected.push(`${kind}:${x},${y},${z}:${dir}`); return true; }
  transfer() { this.transfers++; return true; }
  daylight() { return this.light; }
  craft(x: number, y: number, z: number, dir: number) { this.crafts.push(`${x},${y},${z}:${dir}`); return true; }
}
function make() {
  const w = new World(), r = new Redstone(w);
  (w as RedstoneHost).moved = blocks => { w.movedCount += blocks.length; };
  const put = (x: number, y: number, z: number, name: string, state = 0) => r.set(x, y, z, name === 'air' ? 0 : ID[name], state);
  const cell = (x: number, y: number, z: number) => { const c = w.getCell(x, y, z); return { id: c & 4095, state: c >>> 12 }; };
  const tick = (n = 4) => { for (let i = 0; i < n; i++) r.tick(); };
  return { w, r, put, cell, tick };
}
const results: { name: string; ok: boolean; note?: string }[] = [];
function test(name: string, fn: () => void) {
  try { fn(); results.push({ name, ok: true }); }
  catch (e) { results.push({ name, ok: false, note: e instanceof Error ? e.message : String(e) }); }
}
/** Piston at (0,1,0) facing +X, powered by a lever on its -X side (attachment 2 = support at +X of the lever). */
function leverPiston(kind = 'piston') {
  const c = make();
  c.put(0, 1, 0, kind, 0);
  c.put(-1, 1, 0, 'lever', 2);
  const on = (v: boolean) => c.put(-1, 1, 0, 'lever', v ? 10 : 2);
  return { ...c, on };
}

// ---------------------------------------------------------------- piston heads
test('57 piston head occupies the front cell and disappears on retraction', () => {
  const c = leverPiston(); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, 0);
  c.on(true); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.piston_head);
  assert.equal(c.cell(1, 1, 0).state & 7, 0);
  c.on(false); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, 0);
  assert.equal(c.cell(0, 1, 0).state & 8, 0);
});
test('58 sticky piston head carries the sticky bit and pulls its block back', () => {
  const c = leverPiston('sticky_piston'); c.put(1, 1, 0, 'stone');
  c.on(true); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.piston_head);
  assert.equal(c.cell(1, 1, 0).state & 8, 8);
  assert.equal(c.cell(2, 1, 0).id, ID.stone);
  c.on(false); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.stone);
  assert.equal(c.cell(2, 1, 0).id, 0);
});
test('59 a normal piston leaves the pushed block behind', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'stone');
  c.on(true); c.tick(2); c.on(false); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, 0);
  assert.equal(c.cell(2, 1, 0).id, ID.stone);
});
test('60 a head without its base is removed', () => {
  const c = make(); c.put(5, 1, 0, 'piston_head', 0); c.tick(2);
  assert.equal(c.cell(5, 1, 0).id, 0);
});
test('61 retracted pistons can be pushed, extended ones cannot', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'piston', 4);
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 0).id, ID.piston);
  const d = leverPiston(); d.put(1, 1, 0, 'piston', 4 | 8); d.put(1, 2, 0, 'piston_head', 4);
  d.on(true); d.tick(2);
  assert.equal(d.cell(1, 1, 0).id, ID.piston);
  assert.equal(d.cell(0, 1, 0).state & 8, 0);
});
test('62 pushing crushes plants instead of being blocked', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'stone'); c.put(2, 1, 0, 'poppy');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 0).id, ID.stone);
  assert.equal(c.cell(3, 1, 0).id, 0);
});

// ---------------------------------------------------------------- quasi-connectivity
test('63 BUD: quasi power is ignored until the piston gets a block update', () => {
  const c = make(); c.put(0, 1, 0, 'piston', 0); c.tick(2);
  c.put(1, 2, 0, 'redstone_block');           // next to the cell above the piston, not next to the piston
  c.tick(4);
  assert.equal(c.cell(0, 1, 0).state & 8, 0, 'no update yet, so the piston must not notice');
  c.put(0, 1, 1, 'stone');                     // any neighbour change is an update
  c.tick(2);
  assert.equal(c.cell(0, 1, 0).state & 8, 8);
  assert.equal(c.cell(1, 1, 0).id, ID.piston_head);
});
test('64 BUD: a quasi-powered piston stays extended until it is updated', () => {
  const c = make(); c.put(0, 1, 0, 'piston', 0); c.put(1, 2, 0, 'redstone_block'); c.tick(3);
  assert.equal(c.cell(0, 1, 0).state & 8, 8, 'placing the piston is itself an update');
  c.put(1, 2, 0, 'air'); c.tick(4);
  assert.equal(c.cell(0, 1, 0).state & 8, 8, 'power is gone but nothing told the piston');
  c.put(0, 1, 1, 'stone'); c.tick(2);
  assert.equal(c.cell(0, 1, 0).state & 8, 0);
});
test('65 quasi-connectivity through dust above-diagonal', () => {
  const c = make();
  c.put(1, 1, 0, 'stone'); c.put(1, 2, 0, 'redstone_wire'); c.put(2, 2, 0, 'stone'); c.put(2, 3, 0, 'lever', 8);
  c.put(0, 1, 0, 'piston', 2);                 // faces -X, dust runs diagonally above it
  c.tick(4);
  assert.equal(c.cell(0, 1, 0).state & 8, 8);
});
test('66 droppers are quasi-connected too', () => {
  const c = make(); c.put(0, 1, 0, 'dropper', 0); c.tick(2);
  assert.equal(c.w.ejected.length, 0);
  c.put(1, 2, 0, 'redstone_block'); c.tick(3);
  assert.equal(c.w.ejected.length, 0);
  c.put(0, 1, 1, 'stone'); c.tick(2);
  assert.equal(c.w.ejected.length, 1);
});
test('67 lamps are not quasi-connected', () => {
  const c = make(); c.put(0, 1, 0, 'unlit_redstone_lamp'); c.put(1, 2, 0, 'redstone_block'); c.put(0, 1, 1, 'stone'); c.tick(4);
  assert.equal(c.cell(0, 1, 0).id, ID.unlit_redstone_lamp);
});

// ---------------------------------------------------------------- slime and honey
test('68 slime drags the block on top of it', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'slime_block'); c.put(1, 2, 0, 'stone');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(2, 2, 0).id, ID.stone);
  assert.equal(c.cell(1, 2, 0).id, 0);
  assert.equal(c.w.movedCount, 2);
});
test('69 sticky piston pulls a slime structure back', () => {
  const c = leverPiston('sticky_piston'); c.put(1, 1, 0, 'slime_block'); c.put(1, 2, 0, 'stone'); c.put(1, 1, 1, 'stone');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 1).id, ID.stone);
  c.on(false); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(1, 2, 0).id, ID.stone);
  assert.equal(c.cell(1, 1, 1).id, ID.stone);
  assert.equal(c.cell(2, 1, 0).id, 0);
});
test('70 slime and honey do not stick to each other', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'slime_block'); c.put(1, 1, 1, 'honey_block');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(1, 1, 1).id, ID.honey_block);
});
test('71 honey drags blocks like slime', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'honey_block'); c.put(1, 2, 0, 'stone');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 2, 0).id, ID.stone);
});
test('72 a glued block that is obstructed blocks the whole structure', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'slime_block'); c.put(1, 2, 0, 'stone'); c.put(2, 2, 0, 'obsidian');
  c.on(true); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(0, 1, 0).state & 8, 0);
});
test('73 immovable blocks next to slime simply stay behind', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'slime_block'); c.put(1, 2, 0, 'obsidian');
  c.on(true); c.tick(2);
  assert.equal(c.cell(2, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(1, 2, 0).id, ID.obsidian);
});
test('74 the twelve block limit counts the whole slime structure', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'slime_block');
  for (let x = 2; x <= 9; x++) c.put(x, 1, 0, 'stone');           // 9 in the line
  for (let y = 2; y <= 5; y++) c.put(1, y, 0, 'slime_block');     // a slime column on top is dragged along: 13 blocks
  c.on(true); c.tick(2);
  assert.equal(c.cell(0, 1, 0).state & 8, 0);
  c.put(1, 5, 0, 'air'); c.tick(2);                                 // 12 blocks: now it moves
  assert.equal(c.cell(0, 1, 0).state & 8, 8);
  assert.equal(c.cell(10, 1, 0).id, ID.stone);
  assert.equal(c.cell(2, 2, 0).id, ID.slime_block);
});
test('75 slime chains pull blocks behind each other', () => {
  const c = leverPiston('sticky_piston'); c.put(1, 1, 0, 'slime_block'); c.put(2, 1, 0, 'slime_block'); c.put(3, 1, 0, 'stone');
  c.on(true); c.tick(2);
  assert.equal(c.cell(4, 1, 0).id, ID.stone);
  c.on(false); c.tick(2);
  assert.equal(c.cell(3, 1, 0).id, ID.stone);
  assert.equal(c.cell(1, 1, 0).id, ID.slime_block);
});

// ---------------------------------------------------------------- observers, hoppers
test('76 observer emits from its back face only', () => {
  const c = make();
  c.put(0, 1, 0, 'observer', 0);                // watches (1,1,0), back is (-1,1,0)
  c.put(-1, 1, 0, 'unlit_redstone_lamp'); c.put(0, 1, 2, 'unlit_redstone_lamp'); c.put(0, 1, 1, 'redstone_wire');
  c.tick(3);
  c.put(1, 1, 0, 'stone'); c.tick(1);
  assert.equal(c.cell(-1, 1, 0).id, ID.redstone_lamp, 'lamp behind the observer lights');
  assert.equal(c.cell(0, 1, 1).state, 0, 'dust beside the observer stays dark');
  c.tick(5);
  assert.equal(c.cell(-1, 1, 0).id, ID.unlit_redstone_lamp, 'two tick pulse ends');
  assert.equal(c.cell(0, 1, 2).id, ID.unlit_redstone_lamp);
});
test('77 observer notices state changes (crop growth)', () => {
  const c = make(); c.put(0, 1, 0, 'observer', 0); c.put(-1, 1, 0, 'unlit_redstone_lamp'); c.put(1, 1, 0, 'wheat_crop', 3); c.tick(4);
  assert.equal(c.cell(-1, 1, 0).id, ID.unlit_redstone_lamp);
  c.put(1, 1, 0, 'wheat_crop', 4); c.tick(1);
  assert.equal(c.cell(-1, 1, 0).id, ID.redstone_lamp);
});
test('78 an observer pushed by a piston pulses on arrival', () => {
  const c = leverPiston(); c.put(1, 1, 0, 'observer', 4); c.put(2, 0, 0, 'unlit_redstone_lamp');
  c.on(true); c.tick(1);
  assert.equal(c.cell(2, 1, 0).id, ID.observer);
  c.tick(1);
  assert.equal(c.cell(2, 0, 0).id, ID.redstone_lamp);
});
test('79 hopper moves one item per eight ticks and resumes after being unlocked', () => {
  const c = make(); c.put(0, 1, 0, 'hopper', 5); c.tick(17);
  assert.equal(c.w.transfers, 3);
  c.put(1, 1, 0, 'redstone_block'); c.tick(1);   // dust is not needed: a redstone block next to it locks it
  const before = c.w.transfers; c.put(1, 1, 0, 'air'); c.put(1, 1, 0, 'stone'); c.put(1, 2, 0, 'lever', 8); c.tick(20);
  assert.equal(c.w.transfers, before, 'locked by the powered block');
});

// ---------------------------------------------------------------- daylight detector, bulb, crafter, detector rail
test('80 daylight detector follows the sky light', () => {
  const c = make(); c.put(0, 1, 0, 'daylight_detector'); c.put(1, 1, 0, 'unlit_redstone_lamp'); c.tick(3);
  assert.equal(c.cell(0, 1, 0).state, 15);
  assert.equal(c.cell(1, 1, 0).id, ID.redstone_lamp);
  c.w.light = 0; c.tick(21);
  assert.equal(c.cell(0, 1, 0).state, 0);
  assert.equal(c.cell(1, 1, 0).id, ID.unlit_redstone_lamp);
});
test('81 inverted daylight detector is on at night', () => {
  const c = make(); c.put(0, 1, 0, 'daylight_detector_inverted'); c.put(1, 1, 0, 'unlit_redstone_lamp'); c.tick(3);
  assert.equal(c.cell(0, 1, 0).state, 0);
  c.w.light = 4; c.tick(21);
  assert.equal(c.cell(0, 1, 0).state, 11);
  assert.equal(c.cell(1, 1, 0).id, ID.redstone_lamp);
});
test('82 using a detector toggles the inverted mode', () => {
  const c = make(); c.put(0, 1, 0, 'daylight_detector'); c.tick(3);
  assert.equal(c.r.toggleDetector(0, 1, 0), true);
  assert.equal(c.cell(0, 1, 0).id, ID.daylight_detector_inverted);
  assert.equal(c.cell(0, 1, 0).state, 0);
  assert.equal(c.r.toggleDetector(0, 1, 0), true);
  assert.equal(c.cell(0, 1, 0).id, ID.daylight_detector);
});
test('83 copper bulb toggles on every rising edge', () => {
  const c = make(); c.put(0, 1, 0, 'copper_bulb'); c.put(1, 1, 0, 'lever', 1);
  const on = (v: boolean) => { c.put(1, 1, 0, 'lever', v ? 9 : 1); c.tick(2); };
  c.tick(2); assert.equal(c.cell(0, 1, 0).id, ID.copper_bulb);
  on(true); assert.equal(c.cell(0, 1, 0).id, ID.lit_copper_bulb);
  on(false); assert.equal(c.cell(0, 1, 0).id, ID.lit_copper_bulb, 'stays lit without power');
  on(true); assert.equal(c.cell(0, 1, 0).id, ID.copper_bulb);
  on(false); on(true); assert.equal(c.cell(0, 1, 0).id, ID.lit_copper_bulb);
});
test('84 comparator reads a lit copper bulb as 15', () => {
  const c = make(); c.put(0, 1, 0, 'lit_copper_bulb'); c.put(1, 1, 0, 'comparator', 0); c.put(2, 1, 0, 'redstone_wire'); c.tick(4);
  assert.equal(c.cell(2, 1, 0).state, 15);
  const d = make(); d.put(0, 1, 0, 'copper_bulb'); d.put(1, 1, 0, 'comparator', 0); d.put(2, 1, 0, 'redstone_wire'); d.tick(4);
  assert.equal(d.cell(2, 1, 0).state, 0);
});
test('85 crafter crafts once per rising edge', () => {
  const c = make(); c.put(0, 1, 0, 'crafter', 1); c.put(-1, 1, 0, 'lever', 2); c.tick(3);
  assert.equal(c.w.crafts.length, 0);
  c.put(-1, 1, 0, 'lever', 10); c.tick(5);
  assert.deepEqual(c.w.crafts, ['0,1,0:1']);
  c.put(-1, 1, 0, 'lever', 2); c.tick(2); c.put(-1, 1, 0, 'lever', 10); c.tick(2);
  assert.equal(c.w.crafts.length, 2);
});
test('86 detector rail powers its neighbours while a cart is on it', () => {
  const c = make(); c.put(0, 1, 0, 'detector_rail', 0); c.put(1, 1, 0, 'unlit_redstone_lamp'); c.tick(3);
  assert.equal(c.cell(1, 1, 0).id, ID.unlit_redstone_lamp);
  c.put(0, 1, 0, 'detector_rail', 1); c.tick(2);
  assert.equal(c.cell(1, 1, 0).id, ID.redstone_lamp);
});

for (const r of results) console.log(r.ok ? 'ok   ' : 'FAIL ', r.name, r.note ? ' — ' + r.note.split('\n').slice(0, 4).join(' ') : '');
const passed = results.filter(r => r.ok).length;
console.log(`\n${passed}/${results.length} redstone (record 014) checks passed`);
if (passed !== results.length) process.exit(1);
