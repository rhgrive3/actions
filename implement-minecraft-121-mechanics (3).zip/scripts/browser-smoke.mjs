// In-browser smoke test for the systems of 記録 021 (fluids + waterlogging, Java spawning / mob caps, raids, boats, elytra).
// Needs playwright-core and a headless Chromium outside this project:
//   mkdir /tmp/pw && cd /tmp/pw && npm init -y && npm i playwright-core && npx playwright-core install chromium-headless-shell
//   NODE_PATH=/tmp/pw/node_modules node scripts/browser-smoke.mjs "$PWD/dist/index.html"     (run `npm run build` first)
// Prints one JSON object; `errorCount` must be 0. It is how the per-frame TDZ crash in Engine.placeCamera and the
// 'waterlogged' event payload bug were found — the tsx suites never construct the real Engine.
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';
const dist = process.argv[2];
// Any Playwright layout: find the headless shell binary below ~/.cache/ms-playwright.
const cache = path.join(process.env.HOME, '.cache/ms-playwright');
const findExe = dir => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) { const r = findExe(p); if (r) return r; } else if (e.name === 'headless_shell' || e.name === 'chrome-headless-shell') return p; } return null; };
const exe = findExe(cache);
const browser = await chromium.launch({ executablePath: exe, args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
const page = await browser.newPage({ viewport: { width: 320, height: 180 } });
const errors = [];
page.on('pageerror', e => errors.push('pageerror: ' + String(e.stack ?? e).slice(0, 500)));
page.on('console', m => { if (m.type() === 'error') errors.push('console: ' + m.text().slice(0, 300)); });
await page.goto('file://' + dist);
await page.waitForFunction(() => window.__game, null, { timeout: 60000 });
await page.evaluate(() => {
  const g = window.__game;
  g.setSettings({ ...g.settings, distance: 4, quality: 'low', adaptiveResolution: false, touch: false });
  g.start({ id: 'smoke-1', name: 'smoke', seed: '849281', mode: 'creative', difficulty: 'normal', hardcore: false, structures: true, bonus: false, cheats: true, created: 0, updated: 0, playTime: 0 });
});
await page.waitForFunction(() => window.__game.ready && window.__game.active, null, { timeout: 240000 });
const gameWait = async (sec, timeout = 150000) => {
  const t0 = await page.evaluate(() => window.__game.meta.playTime);
  await page.waitForFunction(([t, s]) => window.__game.meta.playTime - t >= s, [t0, sec], { timeout, polling: 250 });
};
const out = {};
await gameWait(1);
// ---- 1. natural spawning at night (survival-like: creative players still get spawns)
out.night = await page.evaluate(async () => {
  const g = window.__game; let best = null;
  for (const t of [0, 0.25, 0.5, 0.75, 0.85, 0.95]) { g.time = t; await new Promise(r => setTimeout(r, 400)); const d = g.environment.daylight; if (!best || d < best.d) best = { t, d }; }
  g.time = best.t; g.weatherTimer = 99999; g.gamerules.doDaylightCycle = false;
  return best;
});
await gameWait(10);
out.spawn = await page.evaluate(() => {
  const g = window.__game, p = g.position;
  const d = g.mobs.mobs.filter(m => ['zombie', 'skeleton', 'creeper', 'spider', 'enderman', 'witch', 'slime', 'zombie_villager'].includes(m.species)).map(m => Math.round(m.group.position.distanceTo(p)));
  return { mobcap: g.command('/mobcap'), env: { ...g.spawnEnv(), worldSpawn: undefined }, gameTick: g.mobs.gameTick, monsters: d.length, minDist: Math.min(...d), maxDist: Math.max(...d), daylight: g.environment.daylight };
});
// ---- 2. fluids + waterlogging in the live world (platform high in the air)
out.fluid = await page.evaluate(async () => {
  const g = window.__game, X = Math.floor(g.position.x) + 30, Z = Math.floor(g.position.z), Y = Math.floor(g.position.y) + 30;
  const res = []; g.command(`/setblock ${X} ${Y} ${Z} stone`); const stone = g.getBlock(X, Y, Z);
  for (let x = -9; x <= 9; x++) for (let z = -9; z <= 9; z++) g.setBlock(X + x, Y, Z + z, stone);
  res.push(g.command(`/setblock ${X} ${Y + 1} ${Z} oak_slab`));
  const slab = g.getBlock(X, Y + 1, Z);
  // dry fence between two water sources (must become waterlogged), and a hole under the bottom slab (must stay dry)
  res.push(g.command(`/setblock ${X} ${Y + 1} ${Z + 4} oak_fence`), g.command(`/setblock ${X - 1} ${Y + 1} ${Z + 4} water`), g.command(`/setblock ${X + 1} ${Y + 1} ${Z + 4} water`));
  g.setBlock(X, Y, Z, 0);
  const logged = g.gameplay.setWaterlogged(X, Y + 1, Z, true);
  return { X, Y, Z, res, slab, logged, open: g.gameplay.waterlogOpen(X, Y + 1, Z) };
});
await gameWait(4);
out.fluid2 = await page.evaluate(({ X, Y, Z }) => {
  const g = window.__game, c = (x, y, z) => { const v = g.getCell(x, y, z); return [v & 4095, (v >>> 12) & 15]; };
  g.command(`/setblock ${X} ${Y + 5} ${Z + 20} water`); const water = g.getBlock(X, Y + 5, Z + 20); g.command(`/setblock ${X} ${Y + 5} ${Z + 20} air`);
  return { water, n1: c(X + 1, Y + 1, Z), n4: c(X + 4, Y + 1, Z), n7: c(X + 7, Y + 1, Z), n8: c(X + 8, Y + 1, Z), underSlab: c(X, Y, Z), fenceLogged: g.gameplay.isWaterlogged(X, Y + 1, Z + 4), fence: c(X, Y + 1, Z + 4), pending: g.simulation.fluids.pending };
}, out.fluid);
// ---- 3. raid: village -> /raid -> 15 s bar -> wave 1
out.raid0 = await page.evaluate(() => {
  const g = window.__game; g.time = 0.27; const r = [];
  for (let i = 0; i < 4; i++) r.push(g.command('/summon villager'));
  r.push(g.command('/raid 2'));
  const b = g.mobs.getBossInfo();
  return { r, total: g.mobs.raid?.total, bar: b && { name: b.name, hp: b.hp } };
});
await gameWait(8);
out.raid1 = await page.evaluate(() => { const g = window.__game, b = g.mobs.getBossInfo(); return { wave: g.mobs.raid?.wave, bar: b && { name: b.name, hp: b.hp } }; });
await gameWait(9);
out.raid2 = await page.evaluate(() => {
  const g = window.__game, b = g.mobs.getBossInfo(), raiders = g.mobs.mobs.filter(m => m.raidMember), c = g.mobs.raid?.center;
  return { status: g.mobs.raid?.status, wave: g.mobs.raid?.wave, bar: b && { name: b.name, hp: b.hp }, raiders: raiders.map(m => m.species + (m.captain ? '*' : '')),
    dist: raiders.map(m => Math.round(Math.hypot(m.group.position.x - c[0], m.group.position.z - c[2]))) };
});
// ---- 4. boat picks up mobs; elytra glide with the Java integrator
out.boat = await page.evaluate(async () => {
  const g = window.__game, p = g.position;
  g.command('/kill @e'); g.mobs.raid = null;
  const y = g.terrain.height(Math.floor(p.x) + 6, Math.floor(p.z)) + 1;
  const boat = g.vehicles.spawn('boat', Math.floor(p.x) + 6.5, y + 0.2, Math.floor(p.z) + 0.5);
  for (let i = 0; i < 3; i++) g.mobs.spawn('pig', boat.pos.x + 0.3 * i, boat.pos.z + 0.2, false, y);
  return { id: boat.id, y };
});
await gameWait(2);
out.boat2 = await page.evaluate(id => { const g = window.__game, b = g.vehicles.vehicles.find(v => v.id === id); return { passengers: b?.passengers?.length, status: b?.boat?.status, riding: g.mobs.mobs.filter(m => m.vehicleId != null).length, mountFull: b ? g.vehicles.mount(b) : null, pigs: g.mobs.mobs.filter(m => m.species === 'pig').length }; }, out.boat.id);
out.glide0 = await page.evaluate(() => {
  const g = window.__game; g.vehicles.riding = null; g.meta.mode = 'survival'; g.flying = false; g.elytraEquipped = true; g.armor[1] = { name: 'elytra', count: 1 };
  g.position.y += 120; g.fallTop = g.position.y; g.velocity.set(0, 0, 0); g.grounded = false; g.gliding = true; g.input.pitch = 0;
  return { x: g.position.x, y: g.position.y, z: g.position.z };
});
await gameWait(3);
out.glide1 = await page.evaluate(s => {
  const g = window.__game, h = Math.hypot(g.position.x - s.x, g.position.z - s.z);
  const r = { gliding: g.gliding, horiz: +h.toFixed(1), drop: +(s.y - g.position.y).toFixed(1), speedH: +Math.hypot(g.velocity.x, g.velocity.z).toFixed(1), vy: +g.velocity.y.toFixed(2), ticks: g.elytra.ticks };
  g.elytra.boost(1);
  return r;
}, out.glide0);
await gameWait(0.6);
out.rocket = await page.evaluate(() => { const g = window.__game; const r = { speed: +g.velocity.length().toFixed(1), boosting: g.elytra.boosting }; g.gliding = false; g.flying = true; return r; });
const em = {}; for (const e of errors) { const k = e.slice(0, 260); em[k] = (em[k] || 0) + 1; }
out.errorCount = errors.length; out.errors = em;
console.log(JSON.stringify(out));
await browser.close();
