/*
 * Record 016 test suite: environment physics, block entities, redstone sensors, minecart variants, anvil rules, NBT.
 * Runs headless (no WebGL): `npx tsx scripts/test-gameplay.ts`
 */
import * as THREE from 'three';
import { BLOCKS, ID, resolve } from '../src/game/data';
import '../src/game/content';
import { blockId, blockState, makeCell, stateForPlacement } from '../src/game/blockState';
import type { Stack } from '../src/game/types';
import {
  Gameplay, ENDER_KEY, FREEZE_TICKS, CAMPFIRE_COOK_TICKS, bookshelfSlot, targetSignal, usageTicks,
  type EntityView, type GameplayHost, type GameplayIO,
} from '../src/systems/gameplay';
import { Redstone } from '../src/systems/redstone';
import { ENCHANTS, anvilCombine, canApply } from '../src/systems/magic';
import { VehicleManager, FURNACE_FUEL_PER_COAL, TNT_CART_FUSE } from '../src/entities/vehicles';
import { DYE_RGB, blendDyeColors, itemsFromNbt, itemsToNbt, priorWorkPenalty, stackFromNbt, stackToNbt, uuidToIntArray } from '../src/game/nbt';
import { VIBRATION_FREQUENCY, sensorPower } from '../src/systems/events';

let pass = 0, fail = 0, section = '';
const ok = (name: string, cond: boolean, info: unknown = '') => {
  if (cond) pass++;
  else { fail++; console.log(`  ✗ [${section}] ${name}${info !== '' ? ' — ' + JSON.stringify(info) : ''}`); }
};
const group = (name: string, fn: () => void) => {
  section = name;
  const before = fail, start = pass;
  try { fn(); } catch (e) { fail++; console.log(`  ✗ [${name}] threw: ${(e as Error).stack}`); }
  console.log(`${fail === before ? '✓' : '✗'} ${name} (${pass - start} checks)`);
};

function world(mode = 'survival') {
  const cells = new Map<string, number>();
  const k = (x: number, y: number, z: number) => `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
  const drops: { x: number; y: number; z: number; stack: Stack }[] = [], hurt: [number, string][] = [], finished: string[] = [], toasts: string[] = [];
  const ents: EntityView[] = [];
  const cfg = { rnd: 0.5, sky: true, snow: false };
  let g!: Gameplay, rs!: Redstone;
  const host = {
    position: { x: 20.5, y: 1, z: 20.5 },
    hotbar: Array(9).fill(null) as (Stack | null)[], inventory: Array(27).fill(null) as (Stack | null)[], armor: [null, null, null, null] as (Stack | null)[], selected: 0,
    health: 20, hunger: 10, oxygen: 20, flying: false, grounded: true, dead: false, dimension: 'overworld', weather: 'clear', meta: { mode, id: 'test' },
    containers: {} as Record<string, (Stack | null)[]>,
    input: { crouch: false, ascend: false, run: false, useHeld: false, pitch: 0, yaw: 0 },
    getCell: (x: number, y: number, z: number) => cells.get(k(x, y, z)) ?? 0,
    getBlock: (x: number, y: number, z: number) => blockId(cells.get(k(x, y, z)) ?? 0),
    // Mirrors Engine.setBlock: gameplay hooks around the write, then the redstone registration.
    setBlock(x: number, y: number, z: number, id: number, state = 0) {
      x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
      const key = k(x, y, z), prev = cells.get(key) ?? 0, cell = makeCell(id, state);
      if (prev === cell) return false;
      const pid = blockId(prev);
      if (pid !== id) g.beforeReplace(x, y, z, pid, blockState(prev), id);
      if (cell === 0) cells.delete(key); else cells.set(key, cell);
      rs.register(x, y, z); rs.blockChanged(x, y, z);
      if (pid !== id) g.afterReplace(x, y, z, pid, id);
      return true;
    },
  };
  rs = new Redstone({
    getCell: host.getCell, setBlock: (x, y, z, id, st = 0) => host.setBlock(x, y, z, id, st), containerSignal: () => 0,
    comparatorOverride: (x, y, z) => g.comparatorOverride(x, y, z), sensorBack: (x, y, z) => g.sensorBack(x, y, z),
  });
  const io: GameplayIO = {
    rsSet: (x, y, z, id, st) => rs.setExternal(x, y, z, id, st), rsInput: (x, y, z, toward) => rs.inputAt(x, y, z, toward), rsPositions: () => rs.active,
    drop: (x, y, z, stack) => { drops.push({ x, y, z, stack }); },
    give: stack => { const i = host.inventory.findIndex(s => !s); if (i < 0) return false; host.inventory[i] = stack; return true; },
    sound: () => {}, toast: ja => { toasts.push(ja); }, damage: (n, s) => { hurt.push([n, s]); }, finishConsume: s => { finished.push(s.name); },
    openContainer: () => {}, consumeHeld: () => { const s = host.hotbar[host.selected]; if (s && --s.count <= 0) host.hotbar[host.selected] = null; }, wearHeld: () => {},
    entities: () => ents, skyVisible: () => cfg.sky, snowing: () => cfg.snow, randomTickSpeed: () => 3, random: () => cfg.rnd,
    cookResult: n => ({ raw_beef: 'cooked_beef', porkchop: 'cooked_porkchop', chicken: 'cooked_chicken' } as Record<string, string>)[n] ?? null,
  };
  g = new Gameplay(host as GameplayHost, io);
  const set = (x: number, y: number, z: number, name: string, state = 0) => host.setBlock(x, y, z, ID[name], state);
  /** What Engine.use does for a successful placement. */
  const place = (x: number, y: number, z: number, name: string, state = 0, held: Stack | null = null) => {
    const existing = host.getBlock(x, y, z);
    host.setBlock(x, y, z, ID[name], state);
    g.placed(x, y, z, ID[name], state, held, existing);
  };
  const tick = (n = 1, redstone = false) => { for (let i = 0; i < n; i++) { g.tick(); if (redstone) rs.tick(); } };
  const state = (x: number, y: number, z: number) => blockState(host.getCell(x, y, z));
  const hold = (s: Stack | null) => { host.hotbar[host.selected] = s; return s; };
  const click = (x: number, y: number, z: number, held: Stack | null, normal = { x: 0, y: 1, z: 0 }, hit = { x: x + 0.5, y: y + 1, z: z + 0.5 }) =>
    g.interact({ x, y, z, id: host.getBlock(x, y, z), normal }, held, hit);
  return { host, g, rs, cfg, drops, hurt, finished, toasts, ents, set, place, tick, state, hold, click };
}

const required = ['stone', 'water', 'lava', 'oak_planks_slab', 'oak_planks_stairs', 'white_wool', 'hay_block', 'pointed_dripstone', 'soul_sand', 'magma_block', 'powder_snow',
  'redstone_wire', 'redstone_block', 'comparator', 'rail', 'activator_rail', 'target', 'sculk_sensor', 'calibrated_sculk_sensor', 'cauldron', 'campfire', 'unlit_campfire',
  'shulker_box', 'scaffolding', 'ender_chest', 'chiseled_bookshelf', 'tripwire_hook', 'tripwire'];
group('registry', () => {
  for (const n of required) ok('block ' + n, ID[n] !== undefined);
  for (const n of ['bread', 'dried_kelp', 'water_bottle', 'glass_bottle', 'bucket', 'water_bucket', 'lava_bucket', 'leather_boots', 'red_dye', 'book', 'shears', 'flint_and_steel', 'chest_minecart', 'hopper_minecart', 'tnt_minecart', 'furnace_minecart', 'string'])
    ok('item ' + n, !!resolve(n));
  ok('scaffolding is not a collision block', BLOCKS[ID.scaffolding].solid === false);
  ok('tripwire hooks only hang on walls', stateForPlacement(BLOCKS[ID.tripwire_hook], 0, { x: 0, y: 1, z: 0 }) === -1 && stateForPlacement(BLOCKS[ID.tripwire_hook], 0, { x: 1, y: 0, z: 0 }) === 1);
});

group('eating & drinking: hold for 32 ticks (16 dried kelp), cancel on release', () => {
  let w = world();
  w.hold({ name: 'bread', count: 2 }); w.host.input.useHeld = true;
  ok('starts', w.g.beginConsume(w.host.hotbar[0]!) && !!w.g.use && w.g.use.total === 32);
  w.tick(31);
  ok('nothing happens before tick 32', w.host.hunger === 10 && w.host.hotbar[0]!.count === 2 && w.finished.length === 0);
  w.tick(1);
  ok('hunger +5 and one bread used at tick 32', w.host.hunger === 15 && w.host.hotbar[0]!.count === 1, w.host.hunger);
  ok('hidden saturation added (5 * 0.6 * 2)', Math.abs(w.g.saturation - 11) < 1e-9, w.g.saturation);
  ok('side effects fire once on completion', w.finished.join() === 'bread' && w.g.events.count('use_finish') === 1);
  ok('holding on keeps eating', !!w.g.use);

  w = world();
  w.hold({ name: 'bread', count: 1 }); w.host.input.useHeld = true;
  w.g.beginConsume(w.host.hotbar[0]!); w.tick(20);
  w.host.input.useHeld = false; w.tick(1);
  ok('released early: cancelled, nothing consumed', !w.g.use && w.host.hunger === 10 && w.host.hotbar[0]!.count === 1 && w.g.events.count('use_cancel') === 1);
  w.tick(40);
  ok('cancelled meal never completes', w.host.hunger === 10 && w.finished.length === 0);

  w = world();
  w.hold({ name: 'bread', count: 1 }); w.host.input.useHeld = true; w.g.beginConsume(w.host.hotbar[0]!); w.tick(10);
  w.host.selected = 1; w.tick(1);
  ok('switching slots cancels', !w.g.use && w.host.hotbar[0]!.count === 1);

  ok('dried kelp takes 16 ticks, everything else 32', usageTicks('dried_kelp') === 16 && usageTicks('apple') === 32);
  if (resolve('dried_kelp')?.food) {
    w = world(); w.hold({ name: 'dried_kelp', count: 3 }); w.host.input.useHeld = true; w.g.beginConsume(w.host.hotbar[0]!);
    w.tick(15); ok('kelp not done at 15', w.host.hotbar[0]!.count === 3);
    w.tick(1); ok('kelp eaten at 16', w.host.hotbar[0]!.count === 2);
  }
  if (resolve('mushroom_stew')?.food) {
    w = world(); w.hold({ name: 'mushroom_stew', count: 1 }); w.host.input.useHeld = true; w.g.beginConsume(w.host.hotbar[0]!); w.tick(32);
    ok('stew gives the bowl back', w.host.hotbar[0]?.name === 'bowl' && w.host.hotbar[0]?.count === 1, w.host.hotbar[0]);
  }
  w = world(); w.hold({ name: 'water_bottle', count: 1 }); w.host.input.useHeld = true;
  ok('drinks start', w.g.beginConsume(w.host.hotbar[0]!, 'drink')); w.tick(31);
  ok('bottle still full at 31', w.host.hotbar[0]?.name === 'water_bottle'); w.tick(1);
  ok('empty bottle returned at 32', w.host.hotbar[0]?.name === 'glass_bottle' && w.finished.join() === 'water_bottle');
  w = world(); w.hold({ name: 'bread', count: 1 });
  ok('a tap (button not held) eats nothing', w.g.beginConsume(w.host.hotbar[0]!) && !w.g.use && w.toasts.length === 1);
  w = world(); w.host.hunger = 20; w.hold({ name: 'bread', count: 1 }); w.host.input.useHeld = true;
  ok('cannot eat when full', !w.g.beginConsume(w.host.hotbar[0]!));
  w = world(); w.g.saturation = 1; w.g.exhaust(0.4); ok('exhaustion drains saturation first', w.host.hunger === 10 && Math.abs(w.g.saturation - 0.6) < 1e-9);
  w.g.exhaust(1); ok('then the food bar', Math.abs(w.host.hunger - 9.6) < 1e-9 && w.g.saturation === 0);
});

group('poses: sneak 1.5, forced crawl 0.6, swimming', () => {
  const w = world(), g = w.g;
  g.beginPhysics(false, false, () => true); ok('standing 1.8', g.pose === 'standing' && g.height() === 1.8 && g.eyeHeight() === 1.62);
  w.host.input.crouch = true; g.beginPhysics(false, false, () => true); ok('sneaking 1.5', g.pose === 'sneaking' && g.height() === 1.5);
  w.host.input.crouch = false; g.beginPhysics(false, false, h => h <= 1.5);
  ok('low ceiling keeps the sneak hitbox after releasing sneak', g.pose === 'sneaking' && g.poseForced);
  g.beginPhysics(false, false, h => h <= 0.6);
  ok('trapdoor / piston squeeze -> crawling 0.6', g.pose === 'crawling' && g.height() === 0.6 && g.eyeHeight() === 0.4 && g.events.last('pose')?.detail.forced === true);
  ok('crawling is slow', g.adjustSpeed(4.35, false) === 1.65);
  g.beginPhysics(false, false, () => true); ok('stands up again when there is room', g.pose === 'standing' && !g.poseForced);
  w.host.input.run = true; g.beginPhysics(true, true, () => true); ok('sprinting in water -> swimming 0.6', g.pose === 'swimming' && g.height() === 0.6);
  g.beginPhysics(false, true, h => h <= 0.6); ok('leaving water into a 1-block gap -> crawling', g.pose === 'crawling');
  w.host.flying = true; w.host.input.crouch = true; g.beginPhysics(false, false, () => true); ok('flying never shrinks the hitbox', g.pose === 'standing');
});

group('scaffolding: 6 blocks of overhang, the 7th falls', () => {
  const w = world(), g = w.g;
  w.set(0, 0, 0, 'stone');
  w.place(0, 1, 0, 'scaffolding');
  ok('on solid ground: distance 0', w.state(0, 1, 0) === 0);
  for (let x = 1; x <= 6; x++) w.place(x, 1, 0, 'scaffolding');
  ok('six blocks out stay', [1, 2, 3, 4, 5, 6].every(x => w.host.getBlock(x, 1, 0) === ID.scaffolding));
  ok('distance 1..6 with the bottom flag', [1, 2, 3, 4, 5, 6].every(x => w.state(x, 1, 0) === (x | 8)), [1, 2, 3, 4, 5, 6].map(x => w.state(x, 1, 0)));
  w.place(7, 1, 0, 'scaffolding');
  ok('seventh block collapses', w.host.getBlock(7, 1, 0) === 0 && g.events.count('scaffolding_collapse') === 1);
  ok('and drops as an item when it has nowhere to land', w.drops.some(d => d.stack.name === 'scaffolding'));
  w.set(7, -3, 0, 'stone'); w.drops.length = 0;
  w.place(7, 1, 0, 'scaffolding');
  ok('a falling scaffold re-forms where it lands on solid ground', w.host.getBlock(7, 1, 0) === 0 && w.host.getBlock(7, -2, 0) === ID.scaffolding && w.drops.length === 0);
  w.place(0, 2, 0, 'scaffolding'); w.place(0, 3, 0, 'scaffolding');
  ok('towers stay at distance 0', w.state(0, 3, 0) === 0);
  w.host.position = { x: 0.5, y: 2, z: 0.5 };
  // collision: standing on top / sneaking down / climbing up from inside
  const w2 = world(); w2.set(0, 0, 0, 'stone'); w2.place(0, 1, 0, 'scaffolding');
  w2.host.position = { x: 0.5, y: 2.001, z: 0.5 }; w2.g.beginPhysics(false, false, () => true);
  const box = [0.2, 1.93, 0.2, 0.8, 3.7, 0.8] as const;
  ok('top plate carries a player standing above', w2.g.specialCollision(ID.scaffolding, 0, 0, 1, 0, ...box));
  w2.host.input.crouch = true; ok('sneaking lets the player sink through', !w2.g.specialCollision(ID.scaffolding, 0, 0, 1, 0, ...box));
  w2.host.input.crouch = false; w2.host.position.y = 1.2; w2.g.beginPhysics(false, false, () => true);
  ok('from inside it does not collide (climb through)', !w2.g.specialCollision(ID.scaffolding, 0, 0, 1, 0, 0.2, 1.2, 0.2, 0.8, 3, 0.8) && w2.g.inScaffold);
  w2.host.input.ascend = true; ok('jump climbs', w2.g.adjustVertical(-5, 0.05, false, false) === 2.35 && w2.g.noFall);
  w2.host.input.ascend = false; w2.host.input.crouch = true; ok('sneak descends', w2.g.adjustVertical(0, 0.05, false, false) === -2.2);
  // removing the support brings the whole arm down
  w.set(0, 3, 0, 'air'); w.set(0, 2, 0, 'air'); w.set(0, 1, 0, 'air');
  ok('removing the supported column collapses the overhang', [1, 2, 3, 4, 5, 6].every(x => w.host.getBlock(x, 1, 0) !== ID.scaffolding));
  // extension rule
  const w3 = world(); w3.set(0, 0, 0, 'stone'); w3.place(0, 1, 0, 'scaffolding'); w3.host.input.yaw = -Math.PI / 2;      // looking +X
  w3.hold({ name: 'scaffolding', count: 3 });
  ok('clicking the top extends sideways', w3.click(0, 1, 0, w3.host.hotbar[0], { x: 0, y: 1, z: 0 }) && w3.host.getBlock(1, 1, 0) === ID.scaffolding && w3.host.hotbar[0]!.count === 2);
  ok('clicking a side stacks on top', w3.click(0, 1, 0, w3.host.hotbar[0], { x: 0, y: 0, z: 1 }) && w3.host.getBlock(0, 2, 0) === ID.scaffolding);
});

group('powder snow: sinking, freezing, leather boots', () => {
  let w = world();
  w.set(0, 1, 0, 'powder_snow'); w.host.position = { x: 0.5, y: 1, z: 0.5 };
  w.g.beginPhysics(false, false, () => true);
  ok('inside powder snow', w.g.inPowderSnow && w.g.adjustSpeed(4.35, false) < 2.2);
  ok('sinks slowly without fall damage', w.g.adjustVertical(-20, 0.05, false, false) === -1.2 && w.g.noFall);
  ok('no boots: not solid', !w.g.specialCollision(ID.powder_snow, 0, 0, 1, 0, 0.2, 1.9, 0.2, 0.8, 3.7, 0.8));
  w.tick(FREEZE_TICKS - 1);
  ok('freezing builds one tick at a time', w.g.ticksFrozen === FREEZE_TICKS - 1 && w.hurt.length === 0 && !w.g.hud().frozen);
  w.tick(1);
  ok('fully frozen after 140 ticks (hearts turn blue)', w.g.ticksFrozen === FREEZE_TICKS && w.g.hud().frozen && w.g.events.last('freeze')?.detail.fullyFrozen === true);
  w.tick(80);
  ok('1 damage every 40 ticks while frozen', w.hurt.length === 2 && w.hurt.every(h => h[0] === 1 && h[1] === 'freeze'), w.hurt);
  w.host.position.y = 5; w.tick(10);
  ok('thaws twice as fast outside', w.g.ticksFrozen === FREEZE_TICKS - 20);
  w = world(); w.set(0, 1, 0, 'powder_snow'); w.host.position = { x: 0.5, y: 1, z: 0.5 }; w.host.armor[3] = { name: 'leather_boots', count: 1 };
  w.tick(200);
  ok('leather armour prevents freezing', w.g.ticksFrozen === 0 && w.hurt.length === 0);
  w.host.position.y = 2.001; w.g.beginPhysics(false, false, () => true);
  ok('leather boots walk on the surface', w.g.specialCollision(ID.powder_snow, 0, 0, 1, 0, 0.2, 1.93, 0.2, 0.8, 3.7, 0.8));
  w.host.input.crouch = true; ok('sneaking sinks in even with boots', !w.g.specialCollision(ID.powder_snow, 0, 0, 1, 0, 0.2, 1.93, 0.2, 0.8, 3.7, 0.8));
  w = world('creative'); w.set(0, 1, 0, 'powder_snow'); w.host.position = { x: 0.5, y: 1, z: 0.5 }; w.tick(200);
  ok('creative players do not freeze', w.g.ticksFrozen === 0);
});

group('bubble columns: soul sand lifts, magma drags and refills air', () => {
  const w = world(), g = w.g;
  w.set(0, 0, 0, 'soul_sand'); w.set(4, 0, 0, 'magma_block'); w.set(8, 0, 0, 'stone');
  for (let y = 1; y <= 6; y++) { w.set(0, y, 0, 'water'); w.set(4, y, 0, 'water'); w.set(8, y, 0, 'water'); }
  ok('column types', g.bubbleAt(0.5, 3.5, 0.5) === 1 && g.bubbleAt(4.5, 5.5, 0.5) === -1 && g.bubbleAt(8.5, 3.5, 0.5) === 0 && g.bubbleAt(0.5, 8, 0.5) === 0);
  w.host.position = { x: 0.5, y: 2, z: 0.5 }; g.beginPhysics(true, false, () => true);
  let vy = 0; for (let i = 0; i < 40; i++) vy = g.adjustVertical(vy, 0.05, true, false);
  ok('soul sand pushes up to 0.7 blocks/tick', g.bubble === 1 && vy === 14 && g.events.last('bubble_column')?.detail.drag === false, vy);
  w.host.position = { x: 0.5, y: 6.05, z: 0.5 }; g.beginPhysics(true, false, () => true);
  ok('launch at the surface', g.adjustVertical(14, 0.05, true, false) > 14);
  w.host.position = { x: 4.5, y: 3, z: 0.5 }; g.beginPhysics(true, false, () => true);
  vy = 0; for (let i = 0; i < 40; i++) vy = g.adjustVertical(3.6, 0.05, true, false);
  ok('magma drags down at 0.3 blocks/tick, swimming up does not help', g.bubble === -1 && vy === -6 && g.events.last('bubble_column')?.detail.drag === true, vy);
  w.host.oxygen = 2; w.tick(1);
  ok('air supply fully restored inside the column', w.host.oxygen === 20);
  const pushes: number[] = [];
  w.ents.push({ x: 0.5, y: 2, z: 0.5, kind: 'mob', push: d => pushes.push(d) }, { x: 4.5, y: 2, z: 0.5, kind: 'item', push: d => pushes.push(d) }, { x: 8.5, y: 2, z: 0.5, kind: 'mob', push: d => pushes.push(d) });
  w.tick(1);
  ok('mobs and items are carried too', pushes.length === 2 && pushes[0] > 0 && pushes[1] < 0, pushes);
  w.host.position = { x: 8.5, y: 2, z: 0.5 }; w.host.oxygen = 2; g.beginPhysics(true, false, () => true); w.tick(1);
  ok('plain water does nothing', g.bubble === 0 && w.host.oxygen === 2);
});

group('waterlogging: the block keeps its shape and its water', () => {
  const w = world(), g = w.g;
  w.set(2, 1, 0, 'water');
  w.place(2, 1, 0, 'oak_planks_slab');
  ok('slab placed in water is waterlogged', g.isWaterlogged(2, 1, 0) && w.host.getBlock(2, 1, 0) === ID.oak_planks_slab);
  ok('physics sees water, collision still sees the slab', g.isWater(2.5, 1.2, 0.5) && BLOCKS[w.host.getBlock(2, 1, 0)].solid);
  ok('render flag', g.blockRenderState(2, 1, 0)?.waterlogged === true && g.events.last('waterlogged')?.detail.waterlogged === true);
  w.set(2, 1, 0, 'air');
  ok('breaking it leaves the water behind', w.host.getBlock(2, 1, 0) === ID.water && !g.isWaterlogged(2, 1, 0));
  w.set(3, 1, 0, 'oak_planks_stairs'); w.hold({ name: 'water_bucket', count: 1 });
  ok('water bucket fills stairs', w.click(3, 1, 0, w.host.hotbar[0]) && g.isWaterlogged(3, 1, 0) && w.host.hotbar[0]?.name === 'bucket');
  ok('empty bucket takes it back', w.click(3, 1, 0, w.host.hotbar[0]) && !g.isWaterlogged(3, 1, 0) && w.host.hotbar[0]?.name === 'water_bucket');
  w.set(4, 1, 0, 'stone'); ok('full cubes cannot be waterlogged', !w.click(4, 1, 0, w.host.hotbar[0]));
  w.set(5, 1, 0, 'oak_planks_slab', 2); ok('double slabs cannot be waterlogged', !w.click(5, 1, 0, w.host.hotbar[0]));
  for (const n of ['oak_planks_fence', 'oak_trapdoor', 'chest', 'ender_chest', 'campfire', 'scaffolding']) if (ID[n] !== undefined) ok(n + ' is waterloggable', g.waterloggable(BLOCKS[ID[n]]));
  w.set(6, 1, 0, 'water'); w.place(6, 1, 0, 'oak_planks_stairs');
  const save = g.save(), dim = save.Dimensions['minecraft:overworld'];
  ok('saved as a block state property', dim?.block_states['6,1,0']?.waterlogged === true, dim);
  const w2 = world(); w2.g.load(JSON.parse(JSON.stringify(save))); ok('restored on load', w2.g.isWaterlogged(6, 1, 0));
});

group('ender chest: one inventory per player behind every chest', () => {
  const w = world(), g = w.g;
  g.playerUUID = '123e4567-e89b-42d3-a456-426614174000';
  w.set(0, 1, 0, 'ender_chest'); w.set(9, 1, 0, 'ender_chest');
  ok('opens', w.click(0, 1, 0, null) && w.host.containers[ENDER_KEY] === g.enderItems && g.enderItems.length === 27);
  w.host.containers[ENDER_KEY][3] = { name: 'diamond', count: 5 };
  g.screenClosed();
  ok('closing marks it for sync', g.enderDirty && g.events.count('ender_chest_close') === 1);
  ok('not stored per block / per dimension', !Object.keys(w.host.containers).includes(ENDER_KEY) && JSON.stringify(w.host.containers) === '{}');
  w.host.containers = {};                                                  // e.g. after a dimension change
  ok('another ender chest shows the same items', w.click(9, 1, 0, null) && w.host.containers[ENDER_KEY][3]?.name === 'diamond' && w.host.containers[ENDER_KEY][3]?.count === 5);
  const save = g.save();
  ok('saved as vanilla EnderItems', JSON.stringify(save.Player.EnderItems) === JSON.stringify([{ Slot: 3, id: 'minecraft:diamond', Count: 5 }]), save.Player.EnderItems);
  ok('player UUID as int array', save.Player.UUID.length === 4 && JSON.stringify(save.Player.UUID) === JSON.stringify(uuidToIntArray(g.playerUUID)));
  const w2 = world(); w2.g.load(JSON.parse(JSON.stringify(save)));
  ok('restored', w2.g.enderItems[3]?.name === 'diamond' && w2.g.enderItems[3]?.count === 5 && w2.g.enderItems.filter(Boolean).length === 1);
  const open = w.host.containers[ENDER_KEY];
  g.setEnderItems(itemsFromNbt([{ Slot: 0, id: 'minecraft:emerald', Count: 2 }], 27), 123);
  ok('server data replaces the contents in place', open === g.enderItems && open[0]?.name === 'emerald' && open[3] === null && g.enderUpdatedAt === 123);
  w.set(9, 2, 0, 'stone'); ok('blocked by a solid block above', w.click(9, 1, 0, null) && w.toasts.length === 1);
});

group('shulker box: contents travel inside the item', () => {
  const w = world();
  w.set(0, 1, 0, 'shulker_box');
  const sword: Stack = { name: 'diamond_sword', count: 1, ench: { sharpness: 3 }, label: 'Blade' };
  w.host.containers['0,1,0'] = [{ name: 'stone', count: 64 }, null, sword, ...Array(24).fill(null)];
  w.set(0, 1, 0, 'air');                                                    // any cause: tool, fist, explosion
  const drop = w.drops.find(d => d.stack.name === 'shulker_box')?.stack;
  ok('drops one shulker box and nothing loose', w.drops.length === 1 && !!drop);
  const items = drop?.tag?.BlockEntityTag?.Items ?? [];
  ok('BlockEntityTag.Items in vanilla layout', items.length === 2 && items[0].Slot === 0 && items[0].id === 'minecraft:stone' && items[0].Count === 64 && items[1].Slot === 2, items);
  ok('nested item NBT kept', items[1]?.tag?.Enchantments?.[0]?.id === 'minecraft:sharpness' && items[1]?.tag?.Enchantments?.[0]?.lvl === 3 && items[1]?.tag?.display?.Name === '{"text":"Blade"}');
  ok('block container is gone', w.host.containers['0,1,0'] === undefined);
  w.place(4, 1, 0, 'shulker_box', 0, drop!);
  const back = w.host.containers['4,1,0'];
  ok('placing it restores every slot', back?.length === 27 && back[0]?.count === 64 && back[1] === null && back[2]?.ench?.sharpness === 3 && back[2]?.label === 'Blade', back);
  w.drops.length = 0; w.set(8, 1, 0, 'shulker_box'); w.set(8, 1, 0, 'air');
  ok('an empty box drops without a tag', w.drops.length === 1 && w.drops[0].stack.tag === undefined);
  const c = world('creative'); c.set(0, 1, 0, 'shulker_box'); c.set(0, 1, 0, 'air');
  ok('creative: empty boxes drop nothing', c.drops.length === 0);
  c.set(0, 1, 0, 'shulker_box'); c.host.containers['0,1,0'] = [{ name: 'dirt', count: 1 }]; c.set(0, 1, 0, 'air');
  ok('creative: filled boxes still drop', c.drops.length === 1 && c.drops[0].stack.tag?.BlockEntityTag?.Items?.length === 1);
});

group('chiseled bookshelf: six slots, comparator = last slot used', () => {
  ok('slot grid (front +Z)', bookshelfSlot(0, 0.1, 0.9, 1) === 0 && bookshelfSlot(0, 0.5, 0.9, 1) === 1 && bookshelfSlot(0, 0.9, 0.9, 1) === 2 && bookshelfSlot(0, 0.1, 0.2, 1) === 3 && bookshelfSlot(0, 0.9, 0.2, 1) === 5);
  ok('slot grid mirrors with the facing', bookshelfSlot(2, 0.9, 0.9, 0) === 0 && bookshelfSlot(1, 0, 0.9, 0.1) === 0 && bookshelfSlot(3, 1, 0.2, 0.1) === 5);
  const w = world(), g = w.g, front = { x: 0, y: 0, z: 1 };
  w.place(0, 1, 0, 'chiseled_bookshelf', 0);
  ok('empty shelf reads 0', g.comparatorOverride(0, 1, 0) === 0);
  w.hold({ name: 'book', count: 8 });
  ok('book goes into the slot that was clicked', w.click(0, 1, 0, w.host.hotbar[0], front, { x: 0.9, y: 1.2, z: 1 }) && w.host.hotbar[0]!.count === 7);
  ok('comparator 6 for slot 6', g.comparatorOverride(0, 1, 0) === 6);
  w.click(0, 1, 0, w.host.hotbar[0], front, { x: 0.1, y: 1.9, z: 1 });
  ok('comparator 1 for slot 1', g.comparatorOverride(0, 1, 0) === 1);
  w.click(0, 1, 0, w.host.hotbar[0], front, { x: 0.5, y: 1.9, z: 1 });
  ok('comparator 2 for slot 2', g.comparatorOverride(0, 1, 0) === 2 && g.blockRenderState(0, 1, 0)?.slot_1_occupied === true && g.blockRenderState(0, 1, 0)?.slot_2_occupied === false);
  ok('other faces do nothing', !w.click(0, 1, 0, w.host.hotbar[0], { x: 1, y: 0, z: 0 }, { x: 1, y: 1.5, z: 0.5 }));
  ok('taking a book out', w.click(0, 1, 0, null, front, { x: 0.9, y: 1.2, z: 1 }) && w.host.inventory[0]?.name === 'book' && g.comparatorOverride(0, 1, 0) === 6);
  for (const [fx, fy] of [[0.9, 0.2], [0.5, 0.2], [0.1, 0.2], [0.9, 0.9]]) w.click(0, 1, 0, w.host.hotbar[0], front, { x: fx, y: 1 + fy, z: 1 });
  ok('holds at most six books', w.host.hotbar[0]!.count === 1 && (g.save().Dimensions['minecraft:overworld'].block_entities[0].Items?.length ?? 0) === 6);
  const be = g.save().Dimensions['minecraft:overworld'].block_entities[0];
  ok('saved as minecraft:chiseled_bookshelf with last_interacted_slot', be.id === 'minecraft:chiseled_bookshelf' && be.last_interacted_slot === 2 && be.Items?.[0]?.Slot === 0, be);
  w.set(1, 1, 0, 'comparator', 0); w.set(2, 1, 0, 'redstone_wire');
  for (let i = 0; i < 4; i++) w.rs.tick();
  ok('a real comparator outputs the slot number', w.state(2, 1, 0) === 3, w.state(2, 1, 0));
  w.set(0, 1, 0, 'air'); ok('breaking the shelf drops the books', w.drops.filter(d => d.stack.name === 'book').length === 6);
});

group('sculk sensors: frequency, travel time, calibration', () => {
  ok('frequency table', VIBRATION_FREQUENCY.step === 1 && VIBRATION_FREQUENCY.projectile_land === 2 && VIBRATION_FREQUENCY.eat === 8 && VIBRATION_FREQUENCY.block_destroy === 12 && VIBRATION_FREQUENCY.block_place === 13 && VIBRATION_FREQUENCY.explode === 15);
  ok('power falls off with distance', sensorPower(0, 8) === 15 && sensorPower(3, 8) === 10 && sensorPower(8, 8) === 1);
  let w = world(), g = w.g;
  w.place(0, 1, 0, 'sculk_sensor'); w.set(1, 1, 0, 'comparator', 0); w.set(2, 1, 0, 'redstone_wire');
  g.vibrate('step', 0.5, 1.5, 3.5);                                         // 3 blocks away
  w.tick(2, true); ok('the vibration takes 1 tick per block', w.state(0, 1, 0) === 0);
  w.tick(1, true); ok('sensor active, power by distance', w.state(0, 1, 0) === 10 && g.blockRenderState(0, 1, 0)?.sculk_sensor_phase === 'active');
  ok('comparator reading = frequency', g.comparatorOverride(0, 1, 0) === 1);
  w.tick(4, true); ok('a real comparator outputs the frequency, not the power', w.state(2, 1, 0) === 1, w.state(2, 1, 0));
  g.vibrate('explode', 0.5, 1.5, 2.5); ok('busy sensors ignore new vibrations', g.comparatorOverride(0, 1, 0) === 1);
  w.tick(26, true); ok('active for 30 ticks', w.state(0, 1, 0) === 0 && g.comparatorOverride(0, 1, 0) === 0);
  g.vibrate('explode', 0.5, 1.5, 2.5); w.tick(5); ok('10 tick cooldown', w.state(0, 1, 0) === 0);
  w.tick(6); g.vibrate('explode', 0.5, 1.5, 2.5); w.tick(2);
  ok('listens again: explosion = 15', g.comparatorOverride(0, 1, 0) === 15 && w.state(0, 1, 0) === sensorPower(2, 8));
  w = world(); g = w.g; w.place(0, 1, 0, 'sculk_sensor');
  g.vibrate('step', 0.5, 1.5, 3.5, { sneaking: true }); w.tick(5); ok('sneaking steps are silent', w.state(0, 1, 0) === 0);
  g.vibrate('block_place', 0.5, 1.5, 9.6); w.tick(12); ok('out of range (8 blocks)', w.state(0, 1, 0) === 0);
  w.set(0, 1, 2, 'white_wool'); g.vibrate('block_place', 0.5, 1.5, 4.5); w.tick(6); ok('wool blocks the vibration', w.state(0, 1, 0) === 0);
  g.vibrate('block_place', 4.5, 1.5, 0.5); w.tick(5); ok('clear path: block placed = 13', g.comparatorOverride(0, 1, 0) === 13);
  const be = g.save().Dimensions['minecraft:overworld'].block_entities.find(b => b.id === 'minecraft:sculk_sensor');
  ok('saved with last_vibration_frequency', be?.last_vibration_frequency === 13, be);

  // calibrated: input side (towards the player who placed it) selects the one frequency it listens to
  w = world(); g = w.g; w.host.input.yaw = -Math.PI / 2;                    // looking +X -> input side is -X
  w.place(0, 1, 0, 'calibrated_sculk_sensor');
  ok('input side behind the sensor', JSON.stringify(g.sensorBack(0, 1, 0)) === '[-1,1,0]' && g.blockRenderState(0, 1, 0)?.facing === 'east');
  g.vibrate('step', 0.5, 1.5, 12.5); w.tick(13);
  ok('no input: hears everything, 16 block range', g.comparatorOverride(0, 1, 0) === 1 && w.state(0, 1, 0) === sensorPower(12, 16));
  w.tick(30, true);
  for (let x = -1; x >= -8; x--) w.set(x, 1, 0, 'redstone_wire');
  w.set(-9, 1, 0, 'redstone_block');
  for (let i = 0; i < 4; i++) w.rs.tick();
  ok('input signal 8 at the back', w.state(-1, 1, 0) === 8 && g.calibration(0, 1, 0) === 8, [w.state(-1, 1, 0), g.calibration(0, 1, 0)]);
  g.vibrate('step', 0.5, 1.5, 3.5); g.vibrate('explode', 0.5, 1.5, 3.5); w.tick(6, true);
  ok('other frequencies are filtered out', w.state(0, 1, 0) === 0 && g.comparatorOverride(0, 1, 0) === 0);
  g.vibrate('eat', 0.5, 1.5, 3.5); w.tick(4, true);
  ok('the matching frequency (8 = eat) gets through', w.state(0, 1, 0) > 0 && g.comparatorOverride(0, 1, 0) === 8);
  ok('it does not feed its own input', w.state(-1, 1, 0) === 8);
  w.tick(10, true); ok('calibrated sensors stay active for 10 ticks', w.state(0, 1, 0) === 0);
});

group('target block: accuracy -> 1..15', () => {
  ok('bull\'s eye', targetSignal('x', 5, 1.5, 0.5) === 15 && targetSignal('y', 0.5, 2, 0.5) === 15 && targetSignal('z', 0.5, 0.5, 3) === 15);
  ok('edge', targetSignal('x', 5, 1.99, 0.5) === 1 && targetSignal('z', 0.01, 0.5, 3) === 1);
  ok('in between', targetSignal('z', 0.5, 0.75, 0) === 8 && targetSignal('x', 0, 0.5, 0.9) === 3);
  const mono = [0, 0.1, 0.2, 0.3, 0.4, 0.49].map(d => targetSignal('x', 0, 0.5 + d, 0.5));
  ok('monotonic with distance from the centre', mono.every((v, i) => i === 0 || v <= mono[i - 1]) && mono[0] === 15 && mono[5] === 1, mono);
  const w = world(), g = w.g;
  w.set(5, 1, 0, 'target'); w.set(5, 1, 1, 'redstone_wire');
  ok('arrow dead centre -> 15', g.projectileHit('player_arrow', 5.05, 1.5, 0.5, 20, 0, 0) === 15 && w.state(5, 1, 0) === 15 && g.events.last('target_hit')?.detail.axis === 'x');
  w.rs.tick(); w.rs.tick(); ok('analog signal on the wire', w.state(5, 1, 1) === 15, w.state(5, 1, 1));
  w.tick(19); ok('arrows hold the signal 20 ticks', w.state(5, 1, 0) === 15);
  w.tick(1); ok('then it turns off', w.state(5, 1, 0) === 0);
  ok('off centre is weaker', g.projectileHit('player_arrow', 5.05, 1.85, 0.5, 20, 0, 0) === 5);
  w.tick(20);
  ok('hit from above uses the top face', g.projectileHit('snowball', 5.5, 1.95, 0.75, 0, -10, 0) === 8 && g.events.last('target_hit')?.detail.axis === 'y');
  w.tick(7); ok('other projectiles: 8 ticks', w.state(5, 1, 0) === 8); w.tick(1); ok('off after 8', w.state(5, 1, 0) === 0);
  w.set(9, 1, 0, 'stone'); ok('other blocks give no signal', g.projectileHit('player_arrow', 9.05, 1.5, 0.5, 20, 0, 0) === 0);
});

group('tripwire: hooks, string, entities, cutting', () => {
  const w = world(), g = w.g;
  w.place(0, 1, 0, 'tripwire_hook', 1); w.place(4, 1, 0, 'tripwire_hook', 2);
  for (const x of [1, 2, 3]) w.place(x, 1, 0, 'tripwire');
  w.set(0, 1, 1, 'redstone_wire');
  w.tick(1, true);
  ok('circuit attached, idle', g.blockRenderState(0, 1, 0)?.attached === true && g.blockRenderState(4, 1, 0)?.attached === true && (w.state(0, 1, 0) & 8) === 0);
  ok('string flagged attached', w.state(2, 1, 0) === 1 && g.blockRenderState(2, 1, 0)?.attached === true);
  w.host.position = { x: 2.5, y: 1, z: 0.5 }; w.tick(1, true); w.rs.tick();
  ok('player in the string powers both hooks', (w.state(0, 1, 0) & 8) !== 0 && (w.state(4, 1, 0) & 8) !== 0 && g.events.last('tripwire')?.detail.powered === true);
  ok('hook outputs redstone power', w.state(0, 1, 1) === 15, w.state(0, 1, 1));
  ok('string flagged powered', (w.state(2, 1, 0) & 2) !== 0);
  w.host.position = { x: 20.5, y: 1, z: 20.5 }; w.tick(9, true);
  ok('stays on for 10 ticks', (w.state(0, 1, 0) & 8) !== 0);
  w.tick(2, true); w.rs.tick(); ok('then releases', (w.state(0, 1, 0) & 8) === 0 && w.state(0, 1, 1) === 0);
  w.host.position = { x: 2.5, y: 3, z: 0.5 }; w.tick(2); ok('jumping over it is safe', (w.state(0, 1, 0) & 8) === 0);
  w.host.position = { x: 20.5, y: 1, z: 20.5 };
  w.ents.push({ x: 1.5, y: 1, z: 0.5, kind: 'mob' }); w.tick(1); ok('mobs and items trip it too', (w.state(4, 1, 0) & 8) !== 0);
  w.ents.length = 0; w.tick(12); ok('idle again', (w.state(4, 1, 0) & 8) === 0);
  w.set(2, 1, 0, 'air'); g.broken(2, 1, 0, BLOCKS[ID.tripwire], 1, '');
  w.tick(1); ok('cutting the string by hand fires both hooks', (w.state(0, 1, 0) & 8) !== 0 && (w.state(4, 1, 0) & 8) !== 0 && g.blockRenderState(0, 1, 0)?.attached === false);
  w.tick(11); ok('as a 10 tick pulse', (w.state(0, 1, 0) & 8) === 0);
  w.place(2, 1, 0, 'tripwire'); w.tick(1);
  w.set(2, 1, 0, 'air'); g.broken(2, 1, 0, BLOCKS[ID.tripwire], 1, 'shears'); w.tick(1);
  ok('shears disarm it silently', (w.state(0, 1, 0) & 8) === 0 && g.events.last('tripwire')?.detail.disarmed !== false);
  const far = world(); far.place(0, 1, 0, 'tripwire_hook', 1); far.place(42, 1, 0, 'tripwire_hook', 2);
  for (let x = 1; x < 42; x++) far.set(x, 1, 0, 'tripwire');
  far.tick(1); ok('41 strings is too long', far.g.blockRenderState(0, 1, 0)?.attached === false);
  const side = world(); side.place(0, 1, 0, 'tripwire_hook', 1); side.place(3, 1, 0, 'tripwire_hook', 3); side.set(1, 1, 0, 'tripwire'); side.set(2, 1, 0, 'tripwire'); side.tick(1);
  ok('hooks must face each other', side.g.blockRenderState(0, 1, 0)?.attached === false);
});

group('campfire: four independent 30 s timers, signal smoke, water, relighting', () => {
  const w = world(), g = w.g;
  w.place(0, 1, 0, 'campfire');
  w.hold({ name: 'raw_beef', count: 7 });
  ok('takes raw food', w.click(0, 1, 0, w.host.hotbar[0]) && w.host.hotbar[0]!.count === 6);
  w.tick(100);
  w.click(0, 1, 0, w.host.hotbar[0]);
  w.tick(CAMPFIRE_COOK_TICKS - 101);
  ok('nothing cooked before 600 ticks', w.drops.length === 0);
  w.tick(1);
  ok('first item done after exactly 600 ticks', w.drops.length === 1 && w.drops[0].stack.name === 'cooked_beef' && g.events.count('campfire_cooked') === 1);
  w.tick(99); ok('second item runs on its own timer', w.drops.length === 1);
  w.tick(1); ok('and finishes 100 ticks later', w.drops.length === 2);
  for (let i = 0; i < 5; i++) w.click(0, 1, 0, w.host.hotbar[0]);
  ok('four slots at most (the fifth item is refused)', (g.blockRenderState(0, 1, 0)?.items as unknown[]).filter(Boolean).length === 4 && w.host.hotbar[0]?.count === 1, [w.host.hotbar[0], g.blockRenderState(0, 1, 0)?.items]);
  ok('smoke rises 10 blocks', g.blockRenderState(0, 1, 0)?.smokeHeight === 10 && g.blockRenderState(0, 1, 0)?.signal_fire === false);
  w.set(0, 0, 0, 'hay_block'); w.tick(10);
  ok('hay bale underneath: signal fire, 25 blocks', g.blockRenderState(0, 1, 0)?.smokeHeight === 25 && g.events.last('campfire_smoke')?.detail.height === 25 && g.events.last('campfire_smoke')?.detail.signalFire === true);
  w.tick(40); w.drops.length = 0;
  g.setCampfireLit(0, 1, 0, false);
  const before = (g.blockRenderState(0, 1, 0)?.cookProgress as number[])[0];
  w.tick(10);
  ok('an unlit fire loses progress (2 per tick)', w.host.getBlock(0, 1, 0) === ID.unlit_campfire && Math.abs(before - (g.blockRenderState(0, 1, 0)?.cookProgress as number[])[0] - 20 / 600) < 1e-9);
  w.hold({ name: 'flint_and_steel', count: 1 });
  ok('flint and steel relights it', w.click(0, 1, 0, w.host.hotbar[0]) && w.host.getBlock(0, 1, 0) === ID.campfire && g.blockRenderState(0, 1, 0)?.lit === true);
  w.hold({ name: 'water_bucket', count: 1 });
  ok('water puts it out and spills the food', w.click(0, 1, 0, w.host.hotbar[0]) && w.host.getBlock(0, 1, 0) === ID.unlit_campfire && g.isWaterlogged(0, 1, 0) && w.drops.filter(d => d.stack.name === 'raw_beef').length === 4 && w.host.hotbar[0]?.name === 'bucket');
  w.hold({ name: 'flint_and_steel', count: 1 });
  ok('cannot be lit while waterlogged', w.click(0, 1, 0, w.host.hotbar[0]) && w.host.getBlock(0, 1, 0) === ID.unlit_campfire);
  w.hold({ name: 'bucket', count: 1 }); w.click(0, 1, 0, w.host.hotbar[0]);
  w.hold({ name: 'flint_and_steel', count: 1 }); w.click(0, 1, 0, w.host.hotbar[0]);
  ok('dry again: lights', w.host.getBlock(0, 1, 0) === ID.campfire && !g.isWaterlogged(0, 1, 0));
  w.hold({ name: 'raw_beef', count: 1 }); w.click(0, 1, 0, w.host.hotbar[0]); w.tick(5);
  const be = g.save().Dimensions['minecraft:overworld'].block_entities.find(b => b.id === 'minecraft:campfire');
  ok('saved as minecraft:campfire with Items / CookingTimes / CookingTotalTimes', be?.Items?.[0]?.id === 'minecraft:raw_beef' && be?.CookingTimes?.[0] === 5 && be?.CookingTotalTimes?.[0] === 600, be);
  const w2 = world(); w2.set(0, 1, 0, 'campfire'); w2.g.load(JSON.parse(JSON.stringify(g.save()))); w2.tick(595);
  ok('timers survive save and load', w2.drops.length === 1 && w2.drops[0].stack.name === 'cooked_beef');
  w.hold({ name: 'stone', count: 1 }); ok('non-food is refused', !w.click(0, 1, 0, w.host.hotbar[0]));
});

group('cauldron: rain, dripstone, bottles, buckets, leather dye', () => {
  let w = world(), g = w.g;
  w.place(0, 1, 0, 'cauldron');
  w.cfg.rnd = 0.04; ok('rain: 5% per precipitation tick', g.cauldronPrecipitation(0, 1, 0) && g.cauldronAt(0, 1, 0)?.level === 1);
  w.cfg.rnd = 0.06; ok('rain: miss above 5%', !g.cauldronPrecipitation(0, 1, 0));
  w.cfg.rnd = 0.04; w.cfg.sky = false; ok('needs open sky', !g.cauldronPrecipitation(0, 1, 0));
  w.cfg.sky = true; g.cauldronPrecipitation(0, 1, 0); g.cauldronPrecipitation(0, 1, 0);
  ok('fills to 3 and stops', g.cauldronAt(0, 1, 0)?.level === 3 && !g.cauldronPrecipitation(0, 1, 0) && g.comparatorOverride(0, 1, 0) === 3);
  w = world(); g = w.g; w.place(0, 1, 0, 'cauldron'); w.cfg.rnd = 0;
  w.tick(3); ok('no rain, no water', g.cauldronAt(0, 1, 0)?.level === 0);
  w.host.weather = 'rain'; w.tick(2); ok('rain accumulates while it rains', g.cauldronAt(0, 1, 0)?.level === 2);
  w = world(); g = w.g; w.place(0, 1, 0, 'cauldron'); w.cfg.snow = true; w.cfg.rnd = 0.09;
  ok('snow: 10%, fills with powder snow', g.cauldronPrecipitation(0, 1, 0) && g.blockRenderState(0, 1, 0)?.content === 'powder_snow' && g.cauldronBlockId(0, 1, 0) === 'minecraft:powder_snow_cauldron');

  w = world(); g = w.g; w.place(0, 1, 0, 'cauldron');
  w.set(0, 4, 0, 'pointed_dripstone'); w.set(0, 5, 0, 'pointed_dripstone'); w.set(0, 6, 0, 'stone'); w.set(0, 7, 0, 'water');
  ok('finds the stalactite and its water', JSON.stringify(g.dripSource(0, 1, 0)) === JSON.stringify({ fluid: 'water', tip: [0, 4, 0] }));
  w.cfg.rnd = 0.18; ok('water drip misses above 45/256', !g.cauldronDrip(0, 1, 0));
  w.cfg.rnd = 0.17; ok('water drip: +1 level', g.cauldronDrip(0, 1, 0) && g.cauldronAt(0, 1, 0)?.level === 1 && g.events.count('dripstone_drip') === 1);
  g.cauldronDrip(0, 1, 0); g.cauldronDrip(0, 1, 0); ok('up to level 3', g.cauldronAt(0, 1, 0)?.level === 3 && !g.cauldronDrip(0, 1, 0));
  w.set(0, 7, 0, 'air'); ok('no fluid above: no drip', g.dripSource(0, 1, 0) === null);
  w = world(); g = w.g; w.place(0, 1, 0, 'cauldron');
  w.set(0, 3, 0, 'pointed_dripstone'); w.set(0, 4, 0, 'stone'); w.set(0, 5, 0, 'lava');
  w.cfg.rnd = 0.06; ok('lava drip misses above 15/256', !g.cauldronDrip(0, 1, 0));
  w.cfg.rnd = 0.05; ok('lava drip fills the cauldron with lava', g.cauldronDrip(0, 1, 0) && g.blockRenderState(0, 1, 0)?.content === 'lava' && g.cauldronBlockId(0, 1, 0) === 'minecraft:lava_cauldron');
  w.hold({ name: 'bucket', count: 1 }); ok('bucket scoops the lava', w.click(0, 1, 0, w.host.hotbar[0]) && w.host.hotbar[0]?.name === 'lava_bucket' && g.cauldronAt(0, 1, 0)?.level === 0);
  w.set(0, 14, 0, 'air'); const tall = world(); tall.place(0, 1, 0, 'cauldron'); tall.set(0, 14, 0, 'pointed_dripstone'); tall.set(0, 15, 0, 'stone'); tall.set(0, 16, 0, 'water');
  ok('tip more than 11 blocks up is out of reach', tall.g.dripSource(0, 1, 0) === null);

  w = world(); g = w.g; w.place(0, 1, 0, 'cauldron');
  w.hold({ name: 'water_bucket', count: 1 }); ok('water bucket fills it', w.click(0, 1, 0, w.host.hotbar[0]) && g.cauldronAt(0, 1, 0)?.level === 3 && w.host.hotbar[0]?.name === 'bucket');
  w.hold({ name: 'glass_bottle', count: 2 }); ok('bottle takes one level', w.click(0, 1, 0, w.host.hotbar[0]) && g.cauldronAt(0, 1, 0)?.level === 2 && w.host.inventory[0]?.name === 'water_bottle' && w.host.hotbar[0]!.count === 1);
  w.hold({ name: 'water_bottle', count: 1 }); ok('water bottle adds one level', w.click(0, 1, 0, w.host.hotbar[0]) && g.cauldronAt(0, 1, 0)?.level === 3 && w.host.hotbar[0]?.name === 'glass_bottle');
  w.hold({ name: 'red_dye', count: 1 }); ok('dye colours the water', w.click(0, 1, 0, w.host.hotbar[0]) && g.blockRenderState(0, 1, 0)?.color === DYE_RGB.red && w.host.hotbar[0] === null);
  const boots = w.hold({ name: 'leather_boots', count: 1 })!;
  ok('leather armour takes the colour (display.color)', w.click(0, 1, 0, boots) && boots.tag?.display?.color === DYE_RGB.red && g.cauldronAt(0, 1, 0)?.level === 2);
  ok('item NBT carries it', stackToNbt(boots).tag?.display?.color === 11546150);
  const clean = world(); clean.place(0, 1, 0, 'cauldron'); clean.g.setCauldron(0, 1, 0, 0, 3);
  ok('clean water washes the dye off', clean.click(0, 1, 0, boots) && boots.tag === undefined && clean.g.cauldronAt(0, 1, 0)?.level === 2);
  ok('undyed armour is left alone (it gets equipped instead)', !clean.click(0, 1, 0, boots) && clean.g.cauldronAt(0, 1, 0)?.level === 2);
  ok('dye mixing matches vanilla', blendDyeColors(undefined, [DYE_RGB.red]) === DYE_RGB.red && blendDyeColors(DYE_RGB.red, [DYE_RGB.blue]) === ((173 << 16) | (83 << 8) | 152), blendDyeColors(DYE_RGB.red, [DYE_RGB.blue]));
});

group('anvil: prior work penalty 2^n - 1, Too Expensive at 40', () => {
  ok('penalty sequence', [0, 1, 2, 3, 4, 5, 6].map(priorWorkPenalty).join() === '0,1,3,7,15,31,63');
  const ench = ENCHANTS.find(e => !e.curse && e.max >= 3 && canApply(e, 'diamond_sword'))!;
  const book = (lvl = 1): Stack => ({ name: 'enchanted_book', count: 1, ench: { [ench.id]: lvl } });
  const sword: Stack = { name: 'diamond_sword', count: 1 };
  const r1 = anvilCombine(sword, book())!;
  ok('first operation: no penalty, result remembers one use', !!r1 && r1.penalty === 0 && r1.result.tag?.RepairCost === 1 && !r1.tooExpensive, r1);
  const r2 = anvilCombine(r1.result, book(2))!;
  ok('second operation costs 1 more, RepairCost becomes 3', r2.penalty === 1 && r2.result.tag?.RepairCost === 3, r2);
  const base = anvilCombine(sword, book(2))!.cost;
  ok('cost = base + penalty', r2.cost === base + 1, [r2.cost, base]);
  const worked: Stack = { ...sword, tag: { RepairCost: 31 } }, workedBook: Stack = { ...book(), tag: { RepairCost: 15 } };
  const r3 = anvilCombine(worked, workedBook)!;
  ok('both inputs add their penalty', r3.penalty === 46 && r3.result.tag?.RepairCost === 63 && r3.cost === anvilCombine(sword, book())!.cost + 46);
  ok('40 levels or more is Too Expensive', r3.tooExpensive && r3.cost >= 40);
  const r4 = anvilCombine({ ...sword, tag: { RepairCost: 15 } }, book())!;
  ok('just under the cap still works', !r4.tooExpensive && r4.cost < 40, r4.cost);
  const rename = anvilCombine({ ...sword, tag: { RepairCost: 63 } }, null, 'Old Faithful')!;
  ok('a plain rename is capped at 39 and adds no penalty', rename.cost === 39 && !rename.tooExpensive && rename.result.tag?.RepairCost === 63 && rename.result.label === 'Old Faithful', rename);
  ok('RepairCost is written to item NBT', stackToNbt(r2.result).tag?.RepairCost === 3);
});

group('NBT: vanilla item layout round trip', () => {
  const max = resolve('diamond_sword')?.durability ?? 1561;
  const s: Stack = { name: 'diamond_sword', count: 1, durability: max - 100, ench: { sharpness: 3, curse_of_binding: 1 }, label: 'Excalibur', tag: { RepairCost: 3 } };
  const n = stackToNbt(s, 5);
  ok('id / Count / Slot', n.id === 'minecraft:diamond_sword' && n.Count === 1 && n.Slot === 5);
  ok('Damage, RepairCost, display.Name', n.tag?.Damage === 100 && n.tag?.RepairCost === 3 && n.tag?.display?.Name === '{"text":"Excalibur"}', n.tag);
  ok('Enchantments with registry ids (binding_curse)', JSON.stringify(n.tag?.Enchantments) === JSON.stringify([{ id: 'minecraft:sharpness', lvl: 3 }, { id: 'minecraft:binding_curse', lvl: 1 }]), n.tag?.Enchantments);
  ok('round trip', JSON.stringify(stackFromNbt(n)) === JSON.stringify({ name: s.name, count: 1, durability: s.durability, ench: s.ench, label: s.label, tag: s.tag }), stackFromNbt(n));
  ok('enchanted books use StoredEnchantments', !!stackToNbt({ name: 'enchanted_book', count: 1, ench: { mending: 1 } }).tag?.StoredEnchantments);
  const slots: (Stack | null)[] = [null, { name: 'stone', count: 64 }, null, { name: 'apple', count: 3 }];
  ok('Items list keeps slot numbers', JSON.stringify(itemsToNbt(slots)) === JSON.stringify([{ Slot: 1, id: 'minecraft:stone', Count: 64 }, { Slot: 3, id: 'minecraft:apple', Count: 3 }]));
  ok('and restores them', JSON.stringify(itemsFromNbt(itemsToNbt(slots), 4)) === JSON.stringify(slots));
  ok('bad slots are dropped', itemsFromNbt([{ Slot: 99, id: 'minecraft:stone', Count: 1 }, { Slot: 0, id: 'minecraft:stone', Count: 1 }, { Slot: 0, id: 'minecraft:dirt', Count: 1 }], 27).filter(Boolean).length === 1);
});

group('minecart variants: chest, hopper, TNT, furnace', () => {
  const cells = new Map<string, number>(), containers: Record<string, (Stack | null)[]> = {};
  const k = (x: number, y: number, z: number) => `${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
  const booms: number[] = [], dropped: string[] = [], events: string[] = [];
  let loose: Stack | null = null;
  const vm = new VehicleManager(new THREE.Scene(), {
    getCell: (x, y, z) => cells.get(k(x, y, z)) ?? 0, getBlock: (x, y, z) => blockId(cells.get(k(x, y, z)) ?? 0),
    setBlock: (x, y, z, id, st = 0) => { cells.set(k(x, y, z), makeCell(id, st)); return true; },
    drop: (_x, _y, _z, name) => { dropped.push(name); }, dropStack: (_x, _y, _z, s) => { dropped.push(s.name + 'x' + s.count); },
    containerAt: (x, y, z) => containers[k(x, y, z)] ?? null, takeDrop: () => { const s = loose; loose = null; return s; },
    explode: (_x, _y, _z, p) => { booms.push(p); }, emit: t => { events.push(t); },
  });
  const run = (ticks: number) => { for (let i = 0; i < ticks; i++) vm.update(0.05, null); };
  for (let x = 0; x <= 12; x++) cells.set(k(x, 0, 0), makeCell(ID.rail));
  for (let x = 0; x <= 12; x++) cells.set(k(x, -1, 0), makeCell(ID.stone));

  ok('placed on rails', vm.place('hopper_minecart', 2, 0, 0) && vm.vehicles[0].kind === 'hopper_minecart' && vm.vehicles[0].items?.length === 5);
  const hopper = vm.vehicles[0];
  containers[k(2, 1, 0)] = [{ name: 'stone', count: 64 }];
  run(20);
  const got = (hopper.items ?? []).reduce((n, s) => n + (s?.count ?? 0), 0);
  ok('hopper minecart pulls one item per tick from the block above (20/s)', got >= 19 && got <= 21 && containers[k(2, 1, 0)][0]!.count === 64 - got, got);
  cells.set(k(2, 0, 0), makeCell(ID.activator_rail, 1)); run(10);
  ok('a powered activator rail switches it off', hopper.enabled === false && (hopper.items ?? []).reduce((n, s) => n + (s?.count ?? 0), 0) === got);
  cells.set(k(2, 0, 0), makeCell(ID.rail)); delete containers[k(2, 1, 0)];
  loose = { name: 'diamond', count: 7 }; run(2);
  ok('it also sucks up dropped item stacks', hopper.enabled && (hopper.items ?? []).some(s => s?.name === 'diamond' && s.count === 7) && events.includes('hopper_minecart_pull'));

  vm.place('chest_minecart', 6, 0, 0);
  const chest = vm.vehicles.find(v => v.kind === 'chest_minecart')!;
  ok('chest minecart has 27 slots', chest.items?.length === 27);
  chest.items![4] = { name: 'apple', count: 12 };
  const saved = vm.save(), cs = saved.find(s => s.kind === 'chest_minecart')!;
  ok('saved as entity NBT with Items', cs.id === 'minecraft:chest_minecart' && JSON.stringify(cs.Items) === JSON.stringify([{ Slot: 4, id: 'minecraft:apple', Count: 12 }]), cs);
  vm.load(JSON.parse(JSON.stringify(saved)));
  ok('inventories survive save and load', vm.vehicles.find(v => v.kind === 'chest_minecart')?.items?.[4]?.count === 12 && (vm.vehicles.find(v => v.kind === 'hopper_minecart')?.items ?? []).some(s => s?.name === 'diamond'));
  vm.destroy(vm.vehicles.find(v => v.kind === 'chest_minecart')!, true);
  ok('breaking it drops the cart and its contents', dropped.includes('chest_minecart') && dropped.includes('applex12'), dropped);
  vm.clear();

  vm.place('furnace_minecart', 4, 0, 0);
  const furnace = vm.vehicles[0];
  run(10); ok('no fuel: stands still', Math.abs(furnace.pos.x - 4.5) < 1e-6);
  ok('coal adds 3600 ticks and sets the push direction away from the player', vm.addFuel(furnace, 2, 0.5) && furnace.fuel === FURNACE_FUEL_PER_COAL && furnace.pushX === 1 && furnace.pushZ === 0);
  run(40);
  ok('it drives itself along the track', furnace.pos.x > 5.5 && furnace.fuel === FURNACE_FUEL_PER_COAL - 40 && events.includes('furnace_minecart_smoke'), [furnace.pos.x, furnace.fuel]);
  ok('saved with Fuel / PushX / PushZ', vm.save()[0].Fuel === furnace.fuel && vm.save()[0].PushX === 1 && vm.save()[0].PushZ === 0);
  for (let i = 0; i < 12; i++) vm.addFuel(furnace, 0, 0.5);
  ok('fuel is capped at 32000', furnace.fuel <= 32000);
  vm.clear();

  cells.set(k(3, 0, 0), makeCell(ID.activator_rail, 0));
  vm.place('tnt_minecart', 3, 0, 0);
  const tnt = vm.vehicles[0];
  run(20); ok('unpowered activator rail: nothing', tnt.fuse === -1 && booms.length === 0);
  cells.set(k(3, 0, 0), makeCell(ID.activator_rail, 1)); run(1);
  ok('powered activator rail primes the fuse', tnt.fuse >= TNT_CART_FUSE - 2 && events.includes('tnt_minecart_primed'), tnt.fuse);
  run(TNT_CART_FUSE - 3); ok('still ticking', booms.length === 0 && vm.vehicles.length === 1);
  run(4); ok('explodes after 80 ticks with power >= 4', booms.length === 1 && booms[0] >= 4 && vm.vehicles.length === 0, booms);
  cells.set(k(3, 0, 0), makeCell(ID.rail));
  vm.place('tnt_minecart', 9, 0, 0);
  const runner = vm.vehicles[0];
  runner.from.set(9.5, 0, 0.5); runner.to.set(10.5, 0, 0.5); runner.speed = 6; runner.dx = 1;
  run(40);
  ok('running into the end of the track sets it off on impact', booms.length === 2 && vm.vehicles.length === 0, [booms.length, runner.pos.x]);
  vm.place('tnt_minecart', 5, 0, 0);
  ok('flint and steel primes it once', vm.prime(vm.vehicles[0]) && !vm.prime(vm.vehicles[0]) && vm.save()[0].TNTFuse === TNT_CART_FUSE);
});

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
