import assert from 'node:assert/strict';
import * as THREE from 'three';
import '../src/game/content';
import { MobManager, SPECIES, type Species } from '../src/entities/mobs';
import { BLOCKS } from '../src/game/data';
import { tilesFor } from '../src/textures/atlas';
import { Terrain } from '../src/world/terrain';
import { meshChunk, type MeshData } from '../src/world/mesher';
import { packMesh } from '../src/world/meshPack';

/*
 * Record 021 — render optimisations must be invisible.
 *  1. Rig batching: for every species the batched rig must rasterise exactly the same triangles (world position, winding,
 *     shading normal, linear colour, material kind, shadow flags) as the unbatched rig, with far fewer draw calls.
 *  2. Chunk vertex packing: decoded attributes must equal the mesher output within one 16-bit step (normals: exact for
 *     axis-aligned faces), tiles and indices bit-exact.
 */

let passed = 0;
function check(name: string, cond: unknown, note = '') {
  assert.ok(cond, `Failed: ${name} ${note}`);
  console.log(`PASS  ${name}${note ? '  ' + note : ''}`);
  passed++;
}

function manager() {
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 100);
  const particles = { burst() {}, drop() {}, spark() {} };
  return new MobManager(scene, {
    terrain: { height: () => 73, biome: () => 'plains' } as never,
    position: new THREE.Vector3(0, 74, 6), camera, dimension: 'overworld',
    getBlock: () => 0, damage() {}, addItem: () => true, toast() {}, sound() {}, explode() {}, openTrade() {},
    particles: particles as never,
  } as never);
}

type Tri = { key: string; v: number[] };
const OFF = 0.0012345;
function rasterSet(root: THREE.Object3D) {
  root.updateMatrixWorld(true);
  const tris: Tri[] = [];
  let calls = 0;
  const p = new THREE.Vector3(), n = new THREE.Vector3(), nm = new THREE.Matrix3();
  const visit = (o: THREE.Object3D, parentVisible: boolean) => {
    const visible = parentVisible && o.visible;
    const mesh = o as THREE.Mesh;
    if (mesh.isMesh && visible) {
      calls++;
      const g = mesh.geometry, mat = mesh.material as THREE.MeshLambertMaterial;
      const pos = g.getAttribute('position'), nor = g.getAttribute('normal'), col = g.getAttribute('color'), idx = g.getIndex();
      nm.getNormalMatrix(mesh.matrixWorld);
      const flip = mesh.matrixWorld.determinant() < 0;
      const kind = `${mat.type}|${mesh.castShadow ? 1 : 0}${mesh.receiveShadow ? 1 : 0}|${mat.transparent ? 1 : 0}|${mat.opacity}|${mesh.renderOrder}`;
      const vc = !!mat.vertexColors && !!col;
      const count = idx ? idx.count : pos.count;
      for (let t = 0; t < count; t += 3) {
        let ids = [0, 1, 2].map(k => (idx ? idx.getX(t + k) : t + k));
        if (flip) ids = [ids[0], ids[2], ids[1]];
        const verts = ids.map(i => {
          p.fromBufferAttribute(pos as THREE.BufferAttribute, i).applyMatrix4(mesh.matrixWorld);
          n.fromBufferAttribute(nor as THREE.BufferAttribute, i).applyMatrix3(nm).normalize();
          const c = vc ? [col!.getX(i) * mat.color.r, col!.getY(i) * mat.color.g, col!.getZ(i) * mat.color.b] : [mat.color.r, mat.color.g, mat.color.b];
          return [p.x, p.y, p.z, n.x, n.y, n.z, c[0], c[1], c[2]];
        });
        // Canonical rotation (winding preserved): start at the lexicographically smallest rounded position.
        const rk = (v: number[]) => v.slice(0, 3).map(x => Math.round((x + OFF) * 500)).join(',');
        let m = 0;
        for (let k = 1; k < 3; k++) if (rk(verts[k]) < rk(verts[m])) m = k;
        const ord = [verts[m], verts[(m + 1) % 3], verts[(m + 2) % 3]];
        const cx = (ord[0][0] + ord[1][0] + ord[2][0]) / 3, cy = (ord[0][1] + ord[1][1] + ord[2][1]) / 3, cz = (ord[0][2] + ord[1][2] + ord[2][2]) / 3;
        tris.push({ key: `${kind}|${Math.round((cx + OFF) * 50)},${Math.round((cy + OFF) * 50)},${Math.round((cz + OFF) * 50)}`, v: ord.flat() });
      }
    }
    for (const c of o.children) visit(c, visible);
  };
  visit(root, true);
  return { tris, calls };
}

function sameRaster(a: Tri[], b: Tri[], tol = 2e-4) {
  const buckets = new Map<string, Tri[]>();
  for (const t of b) { let l = buckets.get(t.key); if (!l) buckets.set(t.key, l = []); l.push(t); }
  let unmatched = 0;
  for (const t of a) {
    const l = buckets.get(t.key);
    const i = l ? l.findIndex(u => u.v.every((x, k) => Math.abs(x - t.v[k]) <= (k % 9 >= 3 && k % 9 < 6 ? 2e-3 : tol))) : -1;
    if (i < 0) unmatched++;
    else l!.splice(i, 1);
  }
  let left = 0;
  for (const l of buckets.values()) left += l.length;
  return { unmatched, left };
}

// 1. Rig batching ---------------------------------------------------------------------------------------------------
{
  const mobs = manager();
  const build = (s: Species) => (mobs as unknown as { buildModel(s: Species): { g: THREE.Group } }).buildModel(s);
  let before = 0, after = 0, bad: string[] = [];
  for (const species of SPECIES) {
    const ref = rasterSet(build(species).g);
    const opt = rasterSet(mobs.model(species).g);
    before += ref.calls; after += opt.calls;
    const r = sameRaster(ref.tris, opt.tris);
    if (r.unmatched || r.left || ref.tris.length !== opt.tris.length) bad.push(`${species}(${r.unmatched}/${r.left})`);
  }
  check(`All ${SPECIES.length} species rasterise identical triangles after rig batching`, bad.length === 0, bad.join(' '));
  check(`Rig batching cuts mob draw calls ${before} → ${after} (−${Math.round((1 - after / before) * 100)}%)`, after < before * 0.5);

  // Villager outfits are rebuilt on profession changes and batched again.
  const v = mobs.spawn('villager', 0, 0)!;
  v.profession = 'librarian' as never; v.level = 3;
  (mobs as unknown as { syncVillagerOutfit(m: unknown): void }).syncVillagerOutfit(v);
  const outfitMeshes = v.outfit!.children.filter(c => (c as THREE.Mesh).isMesh);
  check('Villager outfit parts are baked into a single mesh', outfitMeshes.length === 1 && outfitMeshes[0].userData.rigBatch === true);
  v.profession = 'farmer' as never;
  (mobs as unknown as { syncVillagerOutfit(m: unknown): void }).syncVillagerOutfit(v);
  check('Rebuilt outfit replaces the previous batch (no stale meshes)', v.outfit!.children.length === 1);

  // Hurt tint still swaps every mesh (batched ones included) and restores the batch material.
  const z = mobs.spawn('zombie', 2, 0)!;
  const tint = (mobs as unknown as { setHurtTint(m: unknown, h: boolean): void });
  tint.setHurtTint(z, true);
  let allRed = true; z.group.traverse(o => { if ((o as THREE.Mesh).isMesh && (o as THREE.Mesh).material !== mobs.hurtMat) allRed = false; });
  tint.setHurtTint(z, false);
  let restored = true; z.group.traverse(o => { if (o.userData.rigBatch && (o as THREE.Mesh).material !== mobs.rigMat) restored = false; });
  check('Hurt flash covers batched meshes and restores the batch material', allRed && restored);

  // Night vision drives the batch emissive exactly like the per-colour materials (emissive = colour × nv × 0.85).
  mobs.applyNightVision(0.6);
  check('Night vision reaches the batched material', Math.abs(mobs.rigMat.emissiveIntensity - 0.51) < 1e-9 && mobs.rigMat.emissive.getHex() === 0xffffff);
  mobs.applyNightVision(0);

  // Removing a mob frees its baked geometries.
  let disposed = 0;
  z.group.traverse(o => { if (o.userData.rigBatch) (o as THREE.Mesh).geometry.addEventListener('dispose', () => disposed++); });
  mobs.scene.remove(z.group);
  check('Removing a mob disposes its baked geometries', disposed > 0);
}

// 2. Chunk vertex packing -------------------------------------------------------------------------------------------
{
  const tiles = BLOCKS.map((_, i) => tilesFor(i));
  let rawBytes = 0, packedBytes = 0, worstUnit = 0, worstNormal = 0, axisExact = true, exactInts = true, fallbacks = 0;
  const bytes = (m: Record<string, ArrayBufferView>) => Object.values(m).reduce((s, a) => s + a.byteLength, 0);
  const cases: [string, number, number][] = [['overworld', 0, 0], ['overworld', 5, -3], ['overworld', -9, 14], ['nether', 1, 2], ['end', 0, 0]];
  for (const [dim, cx, cz] of cases) {
    const t = new Terrain('849281', dim as never);
    const gen = t.generate(cx, cz);
    const mesh = meshChunk(gen.padded, gen.maxY, tiles, gen.tint);
    for (const part of [mesh.solid, mesh.water] as MeshData[]) {
      const pk = packMesh(part);
      rawBytes += bytes(part as never); packedBytes += bytes(pk as never);
      for (const name of ['color', 'wind', 'light'] as const) {
        const a = pk[name];
        if (a instanceof Float32Array) { fallbacks++; continue; }
        for (let i = 0; i < a.length; i++) worstUnit = Math.max(worstUnit, Math.abs(a[i] / 65535 - part[name][i]));
      }
      if (pk.normal instanceof Int8Array) {
        for (let i = 0; i < pk.normal.length; i++) {
          const dec = Math.max(pk.normal[i] / 127, -1), src = part.normal[i];
          worstNormal = Math.max(worstNormal, Math.abs(dec - src));
          if ((src === 0 || src === 1 || src === -1) && dec !== src) axisExact = false;
        }
      } else fallbacks++;
      if (!(pk.tile instanceof Float32Array)) for (let i = 0; i < pk.tile.length; i++) if (pk.tile[i] !== part.tile[i]) exactInts = false;
      for (let i = 0; i < pk.index.length; i++) if (pk.index[i] !== part.index[i]) exactInts = false;
    }
  }
  check('Packed colour / wind / light stay within one 16-bit step of the mesher output', worstUnit <= 0.5 / 65535 + 1e-7, `(max ${worstUnit.toExponential(2)}, float fallbacks ${fallbacks})`);
  check('Axis-aligned normals decode exactly; others within 1/254', axisExact && worstNormal <= 0.5 / 127 + 1e-6, `(max ${worstNormal.toExponential(2)})`);
  check('Tile layers and indices are bit-exact', exactInts);
  check(`Chunk GPU payload shrinks ${(rawBytes / 1048576).toFixed(2)} MB → ${(packedBytes / 1048576).toFixed(2)} MB (−${Math.round((1 - packedBytes / rawBytes) * 100)}%)`, packedBytes < rawBytes * 0.7);
}

console.log(`\n${passed} render-optimisation checks passed.`);
