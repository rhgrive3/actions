// 作業B: logic tests for combat / mobs / explosions / light (Java Edition 1.21 rules). Run: npx tsx scripts/test-combat.ts
import * as THREE from 'three';
import '../src/game/content';
import { ID, BLOCKS, resolve } from '../src/game/data';
import * as SV from '../src/game/survival';
import * as CR from '../src/systems/combatRules';
import * as EX from '../src/systems/explosion';
import { MobManager } from '../src/entities/mobs';
import { Simulation } from '../src/systems/simulation';
import { blockLightAt } from '../src/world/lightField';
import { isDarkEnoughToSpawn } from '../src/entities/spawning';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, info: unknown = '') => { if (cond) pass++; else fail++; console.log((cond ? 'PASS  ' : 'FAIL  ') + name + (cond ? '' : '  → ' + JSON.stringify(info))); };
const near = (a: number, b: number, eps = 1e-6) => Math.abs(a - b) <= eps;
const DTS = [1 / 30, 1 / 60, 1 / 144];

// ---------------------------------------------------------------------------------------------------------- tiny world
class World {
  m = new Map<string, number>();
  get = (x: number, y: number, z: number) => this.m.get(Math.floor(x) + ',' + Math.floor(y) + ',' + Math.floor(z)) ?? 0;
  set(x: number, y: number, z: number, name: string | number) { const id = typeof name === 'number' ? name : ID[name]; if (id) this.m.set(x + ',' + y + ',' + z, id); else this.m.delete(x + ',' + y + ',' + z); }
  floor(y = 63, r = 20) { for (let x = -r; x <= r; x++) for (let z = -r; z <= r; z++) this.set(x, y, z, 'stone'); }
}
function mob(species: string, x: number, y: number, z: number, hp = 20): any {
  const g = new THREE.Group(); g.position.set(x, y, z);
  return { species, group: g, head: new THREE.Object3D(), hp, maxHp: hp, state: 'wander', timer: 0, hurtTimer: 0, vy: 0, tamed: false };
}
function manager(w: World, mobs: any[]): any {
  const mm: any = Object.create(MobManager.prototype);
  Object.assign(mm, {
    crystals: [], projectiles: [], mobs, riding: null, timeline: 0, looting: 0, lastHit: null, attacker: null,
    behaviors: { modifyDamage: (_m: unknown, d: number) => d, breach: 0 }, beh: { armorOf: () => 0 },
    host: { particles: { burst() {}, spark() {}, drop() {} }, sound() {}, getBlock: w.get }, rnd: () => 0.5,
    setHurtTint() {}, provoke() {}, kill(m: any) { mm.mobs = mm.mobs.filter((o: any) => o !== m); },
  });
  return mm;
}
function engine(w: World, mm: any): any {
  const e: any = {
    meta: { mode: 'survival', difficulty: 'normal' }, hotbar: Array(9).fill(null), inventory: Array(27).fill(null), armor: [null, null, null, null], offhand: null,
    effects: {}, absorption: 0, health: 20, hunger: 20, xp: 0, selected: 0, elapsed: 100, attackAt: -10, swingHeld: false, useTime: 0, useItemName: '', blocking: false,
    dead: false, grounded: true, handDip: 0, hitFlash: 0, statistics: {}, position: new THREE.Vector3(0.5, 64, 0.5), velocity: new THREE.Vector3(),
    camera: new THREE.PerspectiveCamera(), input: { crouch: false, run: false }, onToast() {}, onScreen() {}, pause() {}, audio: null,
    particles: { burst() {}, drop() {}, spark() {}, crit() {}, enchantedHit() {} }, getBlock: w.get, mobs: mm,
  };
  e.camera.position.set(0.5, 65.62, 0.5);
  return e;
}
const look = (e: any, x: number, y: number, z: number) => { e.camera.lookAt(x, y, z); e.camera.updateMatrixWorld(true); };
const click = (e: any) => { e.swingHeld = false; e.elapsed += 2; return SV.tryAttack(e, e.hotbar[0], e.hotbar[0] ? resolve(e.hotbar[0].name) : undefined); };

// ================================================================================================ 1. hit detection
{
  const w = new World(); w.floor();
  const z = mob('zombie', 2.5, 64, 0.5, 100), mm = manager(w, [z]), e = engine(w, mm);
  look(e, 2.5, 65.5, 0.5);
  ok('1 open line of sight: the attack hits', click(e) && z.hp < 100, z.hp);
  w.set(1, 64, 0, 'stone'); w.set(1, 65, 0, 'stone');
  const hp = z.hp; mm.timeline += 1;
  ok('1 a wall between player and mob blocks the attack (no hits through walls)', !click(e) && z.hp === hp, z.hp);
  w.set(1, 64, 0, 0); w.set(1, 65, 0, 0);
  z.group.position.set(3.85, 64, 0.5); mm.timeline += 1;            // nearest face at 3.55 − 0.5 (eye x) = 3.05 > 3
  ok('1 survival reach is 3 blocks to the hitbox: just beyond 3 misses', !click(e), z.group.position.x);
  z.group.position.set(3.7, 64, 0.5); mm.timeline += 1;             // face at 3.4 → 2.9 from the eye
  ok('1 … just inside 3 hits', click(e) && z.hp < hp);
  e.meta.mode = 'creative'; z.group.position.set(5.7, 64, 0.5); mm.timeline += 1; const h2 = z.hp;  // face 5.4 → 4.9
  ok('1 creative entity reach 5', click(e) && z.hp < h2);
  e.meta.mode = 'survival';
  z.group.position.set(2.5, 64, 1.6); mm.timeline += 1; look(e, 2.5, 65.5, 0.5); const h3 = z.hp;  // box z 1.3‥1.9, ray along z = 0.5
  ok('1 the ray must intersect the hitbox (a mob beside the crosshair is not hit)', !click(e) && z.hp === h3);
  const spider = mob('spider', 2.5, 64, 1.6, 16); mm.mobs = [spider]; mm.timeline += 1;   // spider box is 1.4 wide → z 0.9‥2.3: still missed
  look(e, 2.5, 64.5, 0.5);
  ok('1 hitbox width comes from the species (wide spider box)', (() => { spider.group.position.set(2.5, 64, 1.1); return click(e) && spider.hp < 16; })(), spider.hp);
  // block closer than the mob → no attack (mining instead)
  const z2 = mob('zombie', 2.8, 64, 0.5, 20); mm.mobs = [z2]; w.set(1, 63, 0, 'stone'); look(e, 2.8, 64.2, 0.5); mm.timeline += 1;
  ok('1 entity vs block: the nearer one wins (block in front → no attack)', CR.resolveClick(2.3, 3, 1.2, 4.5) === 'block' && CR.resolveClick(1.0, 3, 1.2, 4.5) === 'entity');
  // crystals use the same ray test
  const mm2 = manager(w, []); mm2.crystals = [{ pos: new THREE.Vector3(0.5, 64, 3), group: new THREE.Group() }];
  let destroyed = -1; mm2.destroyCrystal = (i: number) => { destroyed = i; };
  w.set(0, 64, 1, 'stone'); w.set(0, 65, 1, 'stone');
  const hitC = mm2.hit(new THREE.Vector3(0.5, 65.6, 0.5), new THREE.Vector3(0, 0, 1), 5, false, 3, CR.rayBlockDistance(w.get, id => id > 0, 0.5, 65.6, 0.5, 0, 0, 1, 4.5));
  ok('1 end crystal behind a wall cannot be hit', !hitC && destroyed === -1);
}

// ================================================================================================ 2. invulnerability timer
{
  const st: CR.IFrameState = {};
  const a = CR.applyIFrames(st, 5, 0), b = CR.applyIFrames(st, 5, 0.2), c = CR.applyIFrames(st, 8, 0.3), d = CR.applyIFrames(st, 8, 0.45), f = CR.applyIFrames(st, 4, 0.55);
  ok('2 i-frames: equal hit within 10 ticks does nothing, larger deals only the excess, timer not restarted', a.dmg === 5 && b.dmg === 0 && c.dmg === 3 && d.dmg === 0 && f.dmg === 4 && f.fresh, [a, b, c, d, f]);
  const w = new World(); w.floor();
  const z = mob('zombie', 2.5, 64, 0.5, 100), mm = manager(w, [z]);
  for (let i = 0; i < 6; i++) mm.hit(new THREE.Vector3(0.5, 65.6, 0.5), new THREE.Vector3(1, 0, 0), 6);
  ok('2 spamming melee during the timer does not add damage (mob)', z.hp === 94, z.hp);
  const e = engine(w, mm), h0 = e.health;
  for (let i = 0; i < 5; i++) SV.hurt(e, 3, 'generic');
  ok('2 player: repeated equal damage within 0.5 s is applied once', near(h0 - e.health, 3), e.health);
  // dt independence: hit every 0.3 s for 3 s at different frame rates
  const res = DTS.map(dt => { const s: CR.IFrameState = {}; let next = 0, sum = 0; const n = Math.round(2.95 / dt); for (let i = 0; i <= n; i++) { const t = i * dt; if (t >= next - 1e-9) { sum += CR.applyIFrames(s, 4, t).dmg; next += 0.3; } } return sum; });
  ok('2 i-frame totals are the same at dt = 1/30, 1/60, 1/144', res.every(v => v === res[0]), res);
}

// ================================================================================================ 4. cooldown & damage
{
  const w = new World(); w.floor();
  const mm = manager(w, []), e = engine(w, mm); look(e, 5, 66, 0.5);
  e.attackAt = -10; e.swingHeld = false;
  SV.tryAttack(e, null, undefined);
  ok('4 swinging at air resets the attack cooldown', e.attackAt === e.elapsed);
  ok('4 hoe attack speed by material (wood 1, stone 2, iron 3, diamond 4, netherite 4, gold 1)',
    ['wooden_hoe', 'stone_hoe', 'iron_hoe', 'diamond_hoe', 'netherite_hoe', 'golden_hoe'].map(CR.attackSpeed).join() === '1,2,3,4,4,1');
  const sw = resolve('diamond_sword')!.damage!;
  const full = CR.meleeDamage(sw, 0, 1, false).total, half = CR.meleeDamage(sw, 0, 0.5, false).total;
  ok('4 cooldown scaling 0.2 + 0.8p² without integer rounding', near(full, sw) && near(half, sw * 0.4), [sw, full, half]);
  const critSharp = CR.meleeDamage(sw, 3, 1, true).total;
  ok('4 critical ×1.5 applies to the base only, Sharpness V (+3) is added afterwards', near(critSharp, sw * 1.5 + 3), critSharp);
  const base: CR.CritState = { charge: 1, fallDistance: 1, onGround: false, onClimbable: false, inWater: false, blind: false, slowFalling: false, levitation: false, riding: false, sprinting: false };
  ok('4 crit conditions (falling, airborne, charge > 0.9) and each blocker', CR.canCrit(base) && !CR.canCrit({ ...base, charge: 0.9 }) && !CR.canCrit({ ...base, onGround: true })
    && !CR.canCrit({ ...base, fallDistance: 0 }) && !CR.canCrit({ ...base, onClimbable: true }) && !CR.canCrit({ ...base, inWater: true }) && !CR.canCrit({ ...base, blind: true })
    && !CR.canCrit({ ...base, riding: true }) && !CR.canCrit({ ...base, sprinting: true }));
  ok('4 sweep damage 1 + ratio × base (Sweeping Edge III: 0.75)', near(CR.sweepDamage(7, 0), 1) && near(CR.sweepDamage(7, 3), 1 + 0.75 * 7));
  const sweepArgs = { sword: true, charge: 1, crit: false, sprintKnock: false, onGround: true, horizSpeed: 0 };
  ok('4 sweep needs: sword, charged, grounded, no crit/sprint-knockback, slow movement (walking 4.3 b/s blocks it)',
    CR.canSweep(sweepArgs) && !CR.canSweep({ ...sweepArgs, horizSpeed: 4.317 }) && !CR.canSweep({ ...sweepArgs, crit: true }) && !CR.canSweep({ ...sweepArgs, sword: false }) && !CR.canSweep({ ...sweepArgs, onGround: false }));
  // integration: full-charge diamond sword hit + sweep of a neighbour
  const t = mob('zombie', 2.5, 64, 0.5, 100), n = mob('zombie', 2.5, 64, 1.6, 100), far = mob('zombie', 2.5, 64, 3.2, 100);
  const mm2 = manager(w, [t, n, far]), e2 = engine(w, mm2); e2.hotbar[0] = { name: 'diamond_sword', count: 1 }; look(e2, 2.5, 65.5, 0.5);
  click(e2);
  ok('4 integration: target takes the full sword damage (no rounding), neighbour inside box+1 takes 1 sweep damage, far one none',
    near(100 - t.hp, sw) && near(100 - n.hp, 1) && far.hp === 100, [t.hp, n.hp, far.hp]);
  e2.grounded = false; e2.velocity.y = -3; (e2 as any).fallTop = 66; mm2.timeline += 1;
  const before = t.hp; click(e2);
  ok('4 integration: falling crit deals 1.5 × base', near(before - t.hp, sw * 1.5), before - t.hp);
}

// ================================================================================================ 3. knockback
{
  const v = CR.applyKnockback({ x: 0, y: 0, z: 0 }, 0.4, 1, 0, true);
  ok('3 base knockback 0.4 b/t → 8 b/s horizontal, vertical min(0.4, vy/2 + 0.4) b/t = 8 b/s', near(v.x, 8) && near(v.y, 8) && near(v.z, 0), v);
  const r = CR.applyKnockback({ x: 0, y: 0, z: 0 }, 0.4, 0, -1, true, 0.6);
  ok('3 knockback resistance scales the strength (hoglin 0.6 → 3.2 b/s)', near(r.z, -3.2), r);
  ok('3 resistance 1 (iron golem) cancels it', CR.applyKnockback({ x: 0, y: 0, z: 0 }, 0.4, 1, 0, true, 1).x === 0);
  const w = new World(); w.floor();
  const z = mob('zombie', 2.5, 64, 0.5, 100), mm = manager(w, [z]), e = engine(w, mm); look(e, 2.5, 65.5, 0.5);
  e.hotbar[0] = { name: 'stone_sword', count: 1, ench: { knockback: 2 } };
  click(e);
  ok('3 player hit: mob gets a velocity (not teleported) — 0.4 base then Knockback II (+1.0 × 0.5)', near(z.group.position.x, 2.5) && near(z.kb.x, (0.2 + 1.0) * 20, 1e-6) && z.vy > 0, [z.group.position.x, z.kb, z.vy]);
  // decay is frame-rate independent
  const disp = DTS.map(dt => { const m2 = mob('zombie', 0.5, 64, 0.5); const mm2 = manager(w, [m2]); m2.kb = { x: 8, y: 0, z: 0 }; const n = Math.round(1 / dt); for (let i = 0; i < n; i++) (mm2 as any).tickKnock(m2, dt); return m2.group.position.x - 0.5; });
  ok('3 knockback travel on the ground is the same at dt = 1/30, 1/60, 1/144 (±2 %)', disp.every(d => Math.abs(d - disp[1]) / disp[1] < 0.02), disp);
  const e2 = engine(w, mm); const vx0 = e2.velocity.x;
  SV.hurt(e2, 2, 'mob', false, { from: new THREE.Vector3(-1, 64, 0.5) });
  ok('3 a mob hit adds +8 b/s to engine.velocity away from the attacker', near(e2.velocity.x - vx0, 8), e2.velocity.x);
  const e3 = engine(w, mm); e3.armor = ['netherite_helmet', 'netherite_chestplate', 'netherite_leggings', 'netherite_boots'].map(n => ({ name: n, count: 1 }));
  SV.hurt(e3, 2, 'mob', false, { from: new THREE.Vector3(-1, 64, 0.5) });
  ok('3 full netherite (0.4 resistance) → 4.8 b/s', near(e3.velocity.x, 4.8), e3.velocity.x);
}

// ================================================================================================ 5. effects on hit
{
  const w = new World(); w.floor();
  const mm = manager(w, [mob('cave_spider', 1, 64, 0)]);
  const eff = (species: string, diff: string) => { const e = engine(w, mm); e.meta.difficulty = diff; SV.hurt(e, 2, 'mob', false, { from: new THREE.Vector3(1, 64, 0), species }); return e.effects; };
  ok('5 cave spider: poison 7 s normal, 15 s hard, none easy', eff('cave_spider', 'normal').poison?.t === 7 && eff('cave_spider', 'hard').poison?.t === 15 && !eff('cave_spider', 'easy').poison);
  ok('5 plain spider gives no poison', !eff('spider', 'hard').poison);
  ok('5 wither skeleton: wither 10 s', eff('wither_skeleton', 'normal').wither?.t === 10);
  ok('5 husk: hunger 7 × floor(regional difficulty) (normal 7 s, hard 14 s, easy none)', eff('husk', 'normal').hunger?.t === 7 && eff('husk', 'hard').hunger?.t === 14 && !eff('husk', 'easy').hunger);
  ok('5 the effect comes from the attacker, not the nearest hostile (zombie hit next to a cave spider → nothing)', Object.keys(eff('zombie', 'hard')).length === 0);
  // Thorns: only the attacker
  const a = mob('zombie', 1.5, 64, 0.5, 20), b = mob('zombie', 0.5, 64, 1.5, 20), mm2 = manager(w, [a, b]), e = engine(w, mm2);
  e.armor = ['diamond_helmet', 'diamond_chestplate', 'diamond_leggings', 'diamond_boots'].map(n => ({ name: n, count: 1, ench: { thorns: 3 } }));
  const rnd = Math.random; Math.random = () => 0;
  SV.hurt(e, 2, 'mob', false, { from: a.group.position.clone(), species: 'zombie', mob: a });
  Math.random = rnd;
  ok('5 Thorns damages only the attacking mob', a.hp < 20 && b.hp === 20, [a.hp, b.hp]);
  // Fire Aspect: burning instead of instant damage; total identical across frame rates
  const burn = DTS.map(dt => { const m = mob('zombie', 0.5, 64, 0.5, 100), m3 = manager(w, [m]); m3.hit(new THREE.Vector3(-1, 65.6, 0.5), new THREE.Vector3(1, 0, 0), 7); m3.ignite(m, CR.fireAspectSeconds(1)); const h = m.hp; for (let t = 0; t < 6; t += dt) { m3.timeline += dt; (m3 as any).tickFire(m, dt); } return h - m.hp; });
  ok('5 Fire Aspect I: 4 s burning → 3 burn damage after the hit (first tick absorbed by i-frames) at every dt', burn.every(b2 => near(b2, 3)), burn);
  const w2 = new World(); w2.floor();
  const zz = mob('zombie', 2.5, 64, 0.5, 100), mm4 = manager(w2, [zz]), e4 = engine(w2, mm4); look(e4, 2.5, 65.5, 0.5);
  e4.hotbar[0] = { name: 'iron_sword', count: 1, ench: { fire_aspect: 2 } }; click(e4);
  ok('5 Fire Aspect II sets 8 s of fire and no instant bonus damage', zz.fireT === 8 && near(100 - zz.hp, resolve('iron_sword')!.damage!), [zz.fireT, zz.hp]);
}

// ================================================================================================ 6. explosions
{
  const seeded = (s: number) => () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x80000000; };
  const w = new World();
  for (let x = -6; x <= 6; x++) for (let y = 58; y <= 70; y++) for (let z = -6; z <= 6; z++) w.set(x, y, z, 'dirt');
  w.set(1, 64, 0, 'obsidian'); w.set(-1, 64, 0, 'water'); w.set(0, 63, 0, 'bedrock'); w.set(0, 64, 0, 0);
  const list = EX.explosionBlocks(w.get, 0.5, 64.5, 0.5, 4, seeded(7)), has = (x: number, y: number, z: number) => list.some(p => p[0] === x && p[1] === y && p[2] === z);
  ok('6 obsidian, water and bedrock are not destroyed; dirt around is', !has(1, 64, 0) && !has(-1, 64, 0) && !has(0, 63, 0) && has(0, 65, 0) && has(0, 64, 1), list.length);
  const maxR = Math.max(...list.map(p => Math.hypot(p[0] + 0.5 - 0.5, p[1] + 0.5 - 64.5, p[2] + 0.5 - 0.5)));
  ok('6 crater is bounded (≈ 4/3 × power at most in weak blocks)', maxR <= 4 / 3 * 4 * 1.3 + 0.9 && list.length > 20, [maxR, list.length]);
  const ws = new World(); for (let x = -6; x <= 6; x++) for (let y = 58; y <= 70; y++) for (let z = -6; z <= 6; z++) ws.set(x, y, z, 'stone'); ws.set(0, 64, 0, 0);
  ok('6 stone (resistance 6) yields a smaller crater than dirt', EX.explosionBlocks(ws.get, 0.5, 64.5, 0.5, 4, seeded(7)).length < list.length);
  const wu = new World(); for (let x = -3; x <= 3; x++) for (let y = 62; y <= 66; y++) for (let z = -3; z <= 3; z++) wu.set(x, y, z, 'water'); wu.set(0, 64, 0, 0); wu.set(0, 61, 0, 'dirt');
  ok('6 TNT under water breaks nothing', EX.explosionBlocks(wu.get, 0.5, 64.5, 0.5, 4, seeded(3)).length === 0);
  // exposure & damage
  const open = new World(), wall = new World();
  for (let y = 60; y <= 70; y++) for (let z = -3; z <= 3; z++) wall.set(2, y, z, 'stone');
  const box = CR.boxAt(4.5, 64, 0.5, 0.6, 1.8);
  const eo = EX.exposure(open.get, 0.5, 64.5, 0.5, box), ew = EX.exposure(wall.get, 0.5, 64.5, 0.5, box);
  const dOpen = EX.explosionDamage(4, 4, eo), dWall = EX.explosionDamage(4, 4, ew);
  ok('6 a wall between TNT and the player cuts damage to the +1 floor', eo === 1 && ew === 0 && near(dWall, 1) && dOpen > 20, [eo, ew, dOpen, dWall]);
  ok('6 damage formula (impact² + impact)/2 × 7 × 2P + 1, zero beyond 2P', near(EX.explosionDamage(4, 0, 1), 57) && EX.explosionDamage(4, 8.01, 1) === 0);
  ok('6 difficulty scaling for players (easy min(d/2+1, d), hard ×1.5, peaceful 0)', near(EX.scaleForDifficulty(20, 'easy'), 11) && near(EX.scaleForDifficulty(20, 'hard'), 30) && EX.scaleForDifficulty(20, 'peaceful') === 0);
  ok('6 drops: TNT 100 %, creeper 1/power, game rule tntExplosionDropDecay → 1/power', EX.dropChance('tnt', 4) === 1 && near(EX.dropChance('mob', 3), 1 / 3) && near(EX.dropChance('tnt', 4, { tntExplosionDropDecay: true }), 0.25) && EX.dropChance('mob', 3, { mobExplosionDropDecay: false }) === 1);
  // TNT chain reaction through the Simulation, at three frame rates
  const chain = DTS.map(dt => {
    const tw = new World(); tw.floor(63, 6); tw.set(0, 64, 0, 'tnt'); tw.set(2, 64, 0, 'tnt'); tw.set(5, 64, 0, 'tnt');
    const booms: number[] = []; let t = 0;
    const sim: Simulation = new Simulation({
      getBlock: tw.get, setBlock: (x, y, z, id) => { tw.set(x, y, z, id); return true; }, toast() {}, sound() {},
      explode: (p) => { booms.push(t); for (const [x, y, z] of EX.explosionBlocks(tw.get, p.x, p.y, p.z, 4, seeded(11))) { const id = tw.get(x, y, z); if (id === ID.tnt) sim.primeChain(x, y, z, seeded(5)); else if (EX.explodable(id)) tw.set(x, y, z, 0); } },
    });
    sim.enqueue(0, 64, 0, ID.tnt);
    for (; t < 10; t += dt) sim.update(dt, (x, y, z) => new THREE.Vector3(x, y, z));
    return booms;
  });
  ok('6 TNT chain: neighbours caught in the blast explode 10‥29 ticks later', chain.every(b => b.length === 3 && b[1] - b[0] >= 0.5 - 1e-6 && b[1] - b[0] <= 1.45 + 0.04), chain);
  ok('6 chain timing is identical (within one frame) at dt = 1/30, 1/60, 1/144', chain.every(b => Math.abs(b[2] - chain[2][2]) <= 1 / 30 + 1e-6), chain.map(b => b[2]));
  const placed = new World(); placed.floor(63, 3); placed.set(0, 64, 0, 'tnt'); let fired = 0;
  const sim2 = new Simulation({ getBlock: placed.get, setBlock: () => true, toast() {}, sound() {}, explode: () => { fired++; } });
  sim2.notify(0, 64, 0, ID.tnt); for (let t = 0; t < 6; t += 0.05) sim2.update(0.05, (x, y, z) => new THREE.Vector3(x, y, z));
  ok('6 placing a TNT block does not prime it (needs fire / redstone / explosion)', fired === 0);
  ok('6 blast resistance table: obsidian 1200, stone 6, dirt 0.5, water 100, bedrock 3.6M', EX.blastResistance(ID.obsidian) === 1200 && EX.blastResistance(ID.stone) === 6 && EX.blastResistance(ID.dirt) === 0.5 && EX.blastResistance(ID.water) === 100 && EX.blastResistance(ID.bedrock) >= 3600000);
}

// ================================================================================================ 7. light
{
  const torch = ID.torch, em = BLOCKS[torch]?.light ?? 0;
  const w = new World(); w.floor(63, 30); w.set(0, 64, 0, 'torch');
  const L = (x: number) => blockLightAt(w.get, x, 64, 0);
  ok('7 torch emits 14', em === 14, em);
  ok('7 light falls by 1 per block: 7 blocks → 7, 12 blocks → 2, 13 → 1, 14 → 0', L(7) === 7 && L(12) === 2 && L(13) === 1 && L(14) === 0, [L(7), L(12), L(13), L(14)]);
  const boxW = new World(); boxW.floor(63, 30); boxW.set(0, 64, 0, 'torch');
  for (const [dx, dy, dz] of [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, 0, 1], [0, 0, -1]]) boxW.set(dx, 64 + dy, dz, 'stone');
  ok('7 a torch sealed behind walls lights nothing outside', blockLightAt(boxW.get, 3, 64, 0) === 0 && blockLightAt(boxW.get, 0, 66, 0) === 0);
  ok('7 spawning: dark spot behind the wall still allows spawning (no light through walls)', isDarkEnoughToSpawn(0, () => blockLightAt(boxW.get, 3, 64, 0), 0, false, 'overworld', () => 0.9));
  const wallW = new World(); wallW.floor(63, 30); wallW.set(0, 64, 0, 'torch');
  for (let y = 64; y <= 80; y++) for (let z = -1; z <= 1; z++) wallW.set(1, y, z, 'stone');
  ok('7 light goes around a wall by path length (3 wide wall: |dz| detour)', blockLightAt(wallW.get, 2, 64, 0) === 14 - 6, blockLightAt(wallW.get, 2, 64, 0));
  const g = new World(); g.set(0, 64, 0, 'glowstone');
  ok('7 opaque emitter (glowstone 15) lights neighbours with 14', blockLightAt(g.get, 1, 64, 0) === 14 && blockLightAt(g.get, 0, 64, 0) === 15);
  const t0 = performance.now(), dark = new World(); dark.floor(63, 30);
  for (let i = 0; i < 300; i++) blockLightAt(dark.get, (i % 20) - 10, 64, Math.floor(i / 20) - 7);
  const ms = (performance.now() - t0) / 300;
  ok('7 dark open-air query stays cheap (< 5 ms each in this Map-backed test world)', ms < 5, ms.toFixed(3) + ' ms');
  console.log(`      (dark query: ${ms.toFixed(3)} ms average)`);
}

console.log(`\n${pass}/${pass + fail} combat / explosion / light checks passed`);
if (fail) process.exit(1);
