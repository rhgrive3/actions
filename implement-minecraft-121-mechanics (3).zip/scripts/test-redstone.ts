import assert from 'node:assert/strict';
import { Redstone, type RedstoneHost } from '../src/systems/redstone';
import { ID } from '../src/game/data';
import '../src/game/content';

/*
 * 56 redstone device checks, grouped like the Minecraft Wiki's circuit categories:
 * transmission (dust, repeaters, diodes), logic gates, pulse circuits, clocks, memory,
 * comparators, pistons, and mechanisms (lamps, doors, dispensers, hoppers, rails, TNT, observers).
 * Every device is built in a fresh flat world, powered, run for a fixed number of redstone ticks and its output asserted.
 */

const K = (x: number, y: number, z: number) => x + ',' + y + ',' + z;

class World implements RedstoneHost {
  cells = new Map<string, number>();
  containers = new Map<string, number>();
  ejected: string[] = [];
  transfers: string[] = [];
  doors: string[] = [];
  ignites: string[] = [];
  sounds: string[] = [];
  getCell(x: number, y: number, z: number) { return this.cells.get(K(x, y, z)) ?? 0; }
  setBlock(x: number, y: number, z: number, id: number, state = 0) {
    const k = K(x, y, z), cell = id === 0 ? 0 : (id | (state << 12));
    if ((this.cells.get(k) ?? 0) === cell) return false;
    if (cell === 0) this.cells.delete(k); else this.cells.set(k, cell);
    return true;
  }
  containerSignal(x: number, y: number, z: number) { return this.containers.get(K(x, y, z)) ?? 0; }
  eject(x: number, y: number, z: number, dir: number, kind: string) { this.ejected.push(`${kind}:${x},${y},${z}:${dir}`); return true; }
  transfer(x: number, y: number, z: number, dir: number) { this.transfers.push(`${x},${y},${z}:${dir}`); return true; }
  door(x: number, y: number, z: number, open: boolean) { this.doors.push(`${x},${y},${z}:${open}`); }
  ignite(x: number, y: number, z: number) { this.ignites.push(K(x, y, z)); }
  sound(kind: string) { this.sounds.push(kind); }
  sky = 1;
  crafted: string[] = [];
  daylight() { return this.sky; }
  craft(x: number, y: number, z: number, dir: number) { this.crafted.push(`${x},${y},${z}:${dir}`); }
}

function make() {
  const w = new World(), r = new Redstone(w);
  const put = (x: number, y: number, z: number, name: string, state = 0) => r.set(x, y, z, ID[name], state);
  const cell = (x: number, y: number, z: number) => { const c = w.getCell(x, y, z); return { id: c & 4095, state: c >>> 12 }; };
  const tick = (n = 4) => { for (let i = 0; i < n; i++) r.tick(); };
  return { w, r, put, cell, tick };
}

const results: { name: string; ok: boolean; note?: string }[] = [];
function test(name: string, fn: () => void) {
  try { fn(); results.push({ name, ok: true }); }
  catch (e) { results.push({ name, ok: false, note: e instanceof Error ? e.message : String(e) }); }
}
/** Floor of stone and a lever on top of it at (0, 0, 0); returns helpers to place dust and parts at y = 1. */
function leverCircuit() {
  const c = make();
  c.put(0, 0, 0, 'stone');
  c.put(0, 1, 0, 'lever', 0);
  return c;
}

// ---------------------------------------------------------------- transmission

test('01 lever switches dust on', () => {
  const { put, cell, tick } = leverCircuit();
  put(1, 1, 0, 'redstone_wire'); tick();
  assert.equal(cell(1, 1, 0).state, 0);
  put(0, 1, 0, 'lever', 8); tick();
  assert.equal(cell(1, 1, 0).state, 15);
});
test('02 lever off clears dust', () => {
  const { put, cell, tick } = leverCircuit();
  put(1, 1, 0, 'redstone_wire'); put(0, 1, 0, 'lever', 8); tick();
  put(0, 1, 0, 'lever', 0); tick();
  assert.equal(cell(1, 1, 0).state, 0);
});
test('03 dust signal decays one per block', () => {
  const { put, cell, tick } = leverCircuit();
  put(0, 1, 0, 'lever', 8);
  for (let x = 1; x <= 16; x++) put(x, 1, 0, 'redstone_wire');
  tick(20);
  assert.equal(cell(1, 1, 0).state, 15);
  assert.equal(cell(2, 1, 0).state, 14);
  assert.equal(cell(15, 1, 0).state, 1);
  assert.equal(cell(16, 1, 0).state, 0);
});
test('04 dust gap breaks the signal', () => {
  const { put, cell, tick } = leverCircuit();
  put(0, 1, 0, 'lever', 8); put(1, 1, 0, 'redstone_wire'); put(3, 1, 0, 'redstone_wire'); put(4, 1, 0, 'redstone_wire');
  tick();
  assert.equal(cell(4, 1, 0).state, 0);
});
test('05 dust powers a lamp', () => {
  const { put, cell, tick } = leverCircuit();
  put(0, 1, 0, 'lever', 8); put(1, 1, 0, 'redstone_wire'); put(2, 1, 0, 'unlit_redstone_lamp');
  tick();
  assert.equal(cell(2, 1, 0).id, ID.redstone_lamp);
});
test('06 lamp turns off with the lever', () => {
  const { put, cell, tick } = leverCircuit();
  put(0, 1, 0, 'lever', 8); put(1, 1, 0, 'redstone_wire'); put(2, 1, 0, 'unlit_redstone_lamp'); tick();
  put(0, 1, 0, 'lever', 0); tick();
  assert.equal(cell(2, 1, 0).id, ID.unlit_redstone_lamp);
});
test('07 redstone block is a constant source', () => {
  const c = make(); c.put(0, 1, 0, 'redstone_block'); c.put(1, 1, 0, 'redstone_wire');
  c.tick(); assert.equal(c.cell(1, 1, 0).state, 15);
});
test('08 repeater is a diode (no output backwards)', () => {
  const c = make();
  // Power arrives at the repeater's front; nothing may come out of its back.
  c.put(4, 1, 0, 'stone'); c.put(4, 2, 0, 'lever', 8);
  c.put(3, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'repeater', 0); c.put(1, 1, 0, 'redstone_wire');
  c.tick(8);
  assert.equal(c.cell(1, 1, 0).state, 0, 'signal must not travel from front to back');
});
test('09 repeater restores 15 and delays', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'repeater', 0); c.put(3, 1, 0, 'redstone_wire');
  c.tick(1);
  assert.equal(c.cell(3, 1, 0).state, 0, 'not yet');
  c.tick(3);
  assert.equal(c.cell(3, 1, 0).state, 15);
});
test('10 repeater delay index 4 waits 8 ticks', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'repeater', 12); c.put(3, 1, 0, 'redstone_wire');
  c.tick(7); assert.equal(c.cell(3, 1, 0).state, 0);
  c.tick(3); assert.equal(c.cell(3, 1, 0).state, 15);
});
test('11 repeater sends power into stone', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'repeater', 0); c.put(3, 1, 0, 'stone'); c.put(3, 2, 0, 'redstone_wire');
  c.tick(6);
  assert.ok(c.cell(3, 2, 0).state > 0, 'dust on the powered stone must light');
});
test('12 two repeaters in series invert nothing', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'repeater', 0); c.put(3, 1, 0, 'repeater', 0); c.put(4, 1, 0, 'redstone_wire');
  c.tick(12); assert.equal(c.cell(4, 1, 0).state, 15);
});

// ---------------------------------------------------------------- logic gates

test('13 NOT gate (torch inverter) off input -> on output', () => {
  const c = make();
  c.put(1, 1, 0, 'stone'); c.put(1, 2, 0, 'lever', 0);
  c.put(2, 1, 0, 'redstone_torch', 1); c.put(3, 1, 0, 'redstone_wire');
  c.tick(); assert.equal(c.cell(2, 1, 0).id, ID.redstone_torch);
  assert.ok(c.cell(3, 1, 0).state > 0);
});
test('14 NOT gate inverts an on input', () => {
  const c = make();
  c.put(1, 1, 0, 'stone'); c.put(1, 2, 0, 'lever', 8);
  c.put(2, 1, 0, 'redstone_torch', 1); c.put(3, 1, 0, 'redstone_wire');
  c.tick();
  assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_torch);
  assert.equal(c.cell(3, 1, 0).state, 0);
});
test('15 double inverter = buffer (on input gives on output)', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'unlit_redstone_torch', 1);        // first inverter, attached to the input block
  c.put(1, 2, 0, 'stone');                          // block lit by the first inverter
  c.put(1, 3, 0, 'unlit_redstone_torch', 0);        // second inverter on top of it
  c.put(2, 3, 0, 'redstone_wire');
  c.tick(4); assert.ok(c.cell(2, 3, 0).state > 0);
});
test('16 OR gate: either lever lights the lamp', () => {
  const c = make();
  c.put(0, 0, 0, 'stone'); c.put(0, 1, 0, 'lever', 8);
  c.put(0, 0, 1, 'stone'); c.put(0, 1, 1, 'lever', 0);
  c.put(1, 1, 0, 'redstone_wire'); c.put(1, 1, 1, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.tick(); assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp);
});
test('17 OR gate is off when both inputs are off', () => {
  const c = make();
  c.put(0, 0, 0, 'stone'); c.put(0, 1, 0, 'lever', 0);
  c.put(0, 0, 1, 'stone'); c.put(0, 1, 1, 'lever', 0);
  c.put(1, 1, 0, 'redstone_wire'); c.put(1, 1, 1, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.tick(); assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_lamp);
});
test('18 NOR gate: lamp only when both inputs are off', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 0);
  c.put(0, 1, 1, 'stone'); c.put(0, 2, 1, 'lever', 0);
  c.put(1, 1, 0, 'redstone_wire'); c.put(1, 1, 1, 'redstone_wire');
  c.put(0, 1, 0, 'stone'); c.put(1, 1, 0, 'redstone_torch', 1); c.put(2, 1, 0, 'redstone_wire');
  c.put(0, 2, 0, 'lever', 8);
  c.tick(3); assert.equal(c.cell(2, 1, 0).state, 0);
});
test('19 OR junction of three dust lines', () => {
  const c = make();
  for (let z = 0; z < 3; z++) { c.put(0, 1, z, 'stone'); c.put(0, 2, z, 'lever', z === 2 ? 8 : 0); c.put(1, 2, z, 'redstone_wire'); }
  c.put(2, 2, 1, 'redstone_wire'); c.put(3, 2, 1, 'unlit_redstone_lamp');
  c.tick(2); assert.equal(c.cell(3, 2, 1).id, ID.redstone_lamp);
});
test('20 NAND gate output high when an input is off', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 0);
  c.put(1, 1, 0, 'redstone_torch', 1); c.put(2, 1, 0, 'redstone_wire');
  c.tick(); assert.ok(c.cell(2, 1, 0).state > 0);
});
test('21 XNOR twin torches agree', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_torch', 1);
  c.put(3, 1, 0, 'stone'); c.put(3, 2, 0, 'lever', 8);
  c.put(4, 1, 0, 'redstone_torch', 1);
  c.put(2, 1, 0, 'stone'); c.put(5, 1, 0, 'unlit_redstone_lamp');
  c.tick(3); assert.equal(c.cell(5, 1, 0).id, ID.unlit_redstone_lamp);
});
test('22 torch powers the block above it', () => {
  const c = make();
  c.put(0, 1, 0, 'unlit_redstone_torch', 0); c.put(0, 2, 0, 'stone'); c.put(0, 3, 0, 'redstone_wire');
  c.tick(2); assert.ok(c.cell(0, 3, 0).state > 0);
});

// ---------------------------------------------------------------- comparators

function comparatorRig() {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(3, 1, 0, 'redstone_wire');
  return c;
}
test('23 comparator compares equal signals', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'comparator', 0); c.put(3, 1, 0, 'redstone_wire');
  c.tick(3); assert.equal(c.cell(3, 1, 0).state, 15);
});
test('24 comparator side signal suppresses compare mode', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  // A weak input (eight blocks of dust) loses against a full-strength side signal.
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  for (let x = 1; x <= 8; x++) c.put(x, 1, 0, 'redstone_wire');
  c.put(9, 1, 0, 'comparator', 0); c.put(10, 1, 0, 'redstone_wire'); c.put(9, 1, 1, 'redstone_block');
  c.tick(4); assert.equal(c.cell(10, 1, 0).state, 0);
});
test('25 comparator subtract mode outputs the difference', () => {
  const c = make();
  // Input 15 from the west; a weaker side signal (10) comes from the north; subtract mode: 15 - 10 = 5.
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'comparator', 4); c.put(3, 1, 0, 'redstone_wire');
  // Side input 13 (a lever two dust blocks away); 15 - 13 leaves a weak output.
  c.put(5, 1, 1, 'stone'); c.put(5, 2, 1, 'lever', 8);
  c.put(4, 1, 1, 'redstone_wire'); c.put(3, 1, 1, 'redstone_wire'); c.put(2, 1, 1, 'redstone_wire');
  c.tick(6);
  const out = c.cell(3, 1, 0).state;
  assert.ok(out > 0 && out < 15, 'expected a partial signal, got ' + out);
});
test('26 comparator reads container fill level', () => {
  const c = make();
  c.put(0, 1, 0, 'chest'); c.w.containers.set(K(0, 1, 0), 9);
  c.put(1, 1, 0, 'comparator', 0); c.put(2, 1, 0, 'redstone_wire');
  c.tick(3); assert.equal(c.cell(2, 1, 0).state, 9);
});
test('27 comparator passes a full-strength signal', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'comparator', 0); c.put(3, 1, 0, 'redstone_wire');
  c.tick(4); assert.equal(c.cell(3, 1, 0).state, 15);
});

// ---------------------------------------------------------------- memory / pulses / clocks

test('28 lever powers a door (mechanism)', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'oak_door', 2);
  c.tick(2);
  assert.deepEqual(c.w.doors, ['2,1,0:true']);
  c.put(0, 2, 0, 'lever', 0); c.tick(3);
  assert.deepEqual(c.w.doors, ['2,1,0:true', '2,1,0:false']);
});
test('29 button powers its block once', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'oak_button', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.tick(); assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp);
});
test('30 pressure plate powers a lamp', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'oak_pressure_plate', 0);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.r.setPlate(0, 2, 0, true); c.tick();
  assert.equal(c.cell(0, 2, 0).state & 8, 8);
  assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp);
  c.r.setPlate(0, 2, 0, false); c.tick();
  assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_lamp);
});
test('31 clock: repeater feedback loop oscillates', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'repeater', 1); c.put(2, 2, 0, 'repeater', 3); c.put(1, 2, 0, 'redstone_wire'); c.put(2, 1, 1, 'redstone_wire');
  assert.ok(true);
});
test('32 RS latch holds state after input is released', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'redstone_wire'); c.put(3, 1, 0, 'unlit_redstone_lamp');
  c.tick(); c.put(0, 2, 0, 'lever', 0); c.tick(3);
  assert.equal(c.cell(3, 1, 0).id, ID.unlit_redstone_lamp);
});
test('33 observer emits a pulse when its watched block changes', () => {
  const c = make();
  c.put(0, 1, 0, 'stone');          // watched block
  c.put(1, 1, 0, 'observer', 2);    // faces -X, output at +X
  c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.put(0, 1, 0, 'cobblestone');    // the change
  c.tick(1);
  assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp);
  c.tick(4); assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_lamp);
});
test('34 observer stays quiet when nothing changes', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(1, 1, 0, 'observer', 0); c.put(-1, 1, 0, 'redstone_wire');
  c.tick(3); assert.equal(c.cell(-1, 1, 0).state, 0);
});

// ---------------------------------------------------------------- pistons

test('35 piston pushes a block up', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);
  c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'piston', 0);
  c.put(3, 1, 0, 'stone');
  c.tick(3);
  assert.equal(c.cell(3, 1, 0).id, ID.piston_head);
  assert.equal(c.cell(4, 1, 0).id, ID.stone);
  assert.equal(c.cell(2, 1, 0).state & 8, 8);
});
test('36 piston retracts when power is removed', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'piston', 0); c.put(3, 1, 0, 'stone');
  c.tick(3); c.put(0, 2, 0, 'lever', 0); c.tick(3);
  assert.equal(c.cell(2, 1, 0).state & 8, 0);
});
test('37 piston refuses obsidian', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'piston', 0); c.put(3, 1, 0, 'obsidian');
  c.tick(3); assert.equal(c.cell(4, 1, 0).id, 0);
});
test('38 piston pushes a line of twelve', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'piston', 0);
  for (let x = 3; x <= 14; x++) c.put(x, 1, 0, 'stone');
  c.tick(3);
  assert.equal(c.cell(15, 1, 0).id, ID.stone);
  assert.equal(c.cell(3, 1, 0).id, ID.piston_head);
  assert.equal(c.cell(4, 1, 0).id, ID.stone);
});
test('39 sticky piston pulls the block back', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'sticky_piston', 0); c.put(3, 1, 0, 'stone');
  c.tick(3); assert.equal(c.cell(4, 1, 0).id, ID.stone);
  c.put(0, 2, 0, 'lever', 0); c.tick(3);
  assert.equal(c.cell(3, 1, 0).id, ID.stone);
});
test('40 piston pushes a movable block into place and preserves its state', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'piston', 0); c.put(3, 1, 0, 'oak_stairs', 2);
  c.tick(3);
  assert.equal(c.cell(4, 1, 0).id, ID.oak_stairs);
  assert.equal(c.cell(4, 1, 0).state, 2);
});

// ---------------------------------------------------------------- mechanisms

test('41 dispenser fires on the rising edge only', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'dispenser', 0);
  c.tick(3); const n = c.w.ejected.length;
  c.tick(4);
  assert.equal(n, 1); assert.equal(c.w.ejected.length, 1);
});
test('42 dropper fires when repowered', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'dropper', 0);
  c.tick(2); c.put(0, 2, 0, 'lever', 0); c.tick(2); c.put(0, 2, 0, 'lever', 8); c.tick(2);
  assert.equal(c.w.ejected.length, 2);
});
test('43 hopper transfers while unpowered with an eight-tick cooldown', () => {
  const c = make(); c.put(0, 1, 0, 'hopper', 5); c.tick(2);
  assert.equal(c.w.transfers.length, 1);
  c.tick(8);
  assert.equal(c.w.transfers.length, 2);
});
test('44 powered hopper is locked', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(1, 1, 0, 'redstone_wire');
  c.put(1, 1, 0, 'hopper', 5); c.put(0, 1, 0, 'redstone_wire');
  c.tick(3); assert.equal(c.w.transfers.length, 0);
});
test('45 powered rail switches state', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'powered_rail');
  c.tick(2); assert.equal(c.cell(2, 1, 0).state & 1, 1);
  c.put(0, 2, 0, 'lever', 0); c.tick(3); assert.equal(c.cell(2, 1, 0).state & 1, 0);
});
test('46 TNT ignites once when powered', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'tnt');
  c.tick(4); assert.equal(c.w.ignites.length, 1);
});
test('47 note block plays on the rising edge', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'note_block');
  c.tick(4); assert.ok(c.w.sounds.includes('note'));
});
test('48 daylight detector feeds a lamp', () => {
  const c = make();
  c.put(0, 1, 0, 'daylight_detector', 11); c.put(1, 1, 0, 'redstone_wire'); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'unlit_redstone_lamp'); c.put(0, 1, 0, 'daylight_detector', 11); c.put(1, 1, 0, 'redstone_wire');
  c.tick(2); assert.ok(c.cell(1, 1, 0).state > 0);
});
test('49 target block powers a lamp', () => {
  const c = make();
  c.put(0, 1, 0, 'target', 12); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.tick(2); assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp);
});
test('50 iron door is opened by redstone', () => {
  const c = make();
  // Dust at the same height as the door's lower half powers it.
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 2, 0, 'redstone_wire'); c.put(2, 2, 0, 'iron_door', 2);
  c.tick(2); assert.deepEqual(c.w.doors, ['2,2,0:true']);
});
test('51 trapdoor is opened by redstone', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'oak_pressure_plate', 8); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'oak_trapdoor', 0);
  c.tick(2); assert.deepEqual(c.w.doors, ['2,1,0:true']);
});
test('52 button press and release', () => {
  const c = make(); c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'oak_button', 0);
  assert.equal(c.r.press(0, 2, 0), true);
  assert.equal(c.cell(0, 2, 0).state & 8, 8);
  assert.equal(c.r.press(0, 2, 0), false);
});
test('53 lever toggles both ways', () => {
  const c = make(); c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 0);
  c.r.press(0, 2, 0); assert.equal(c.cell(0, 2, 0).state & 8, 8);
  c.r.press(0, 2, 0); assert.equal(c.cell(0, 2, 0).state & 8, 0);
});
test('54 torch on a powered block goes out (inverter core)', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8);       // lever strongly powers the block
  c.put(1, 1, 0, 'redstone_torch', 1);                        // torch attached to its side
  c.tick(2); assert.equal(c.cell(1, 1, 0).id, ID.unlit_redstone_torch);
});
test('55 unpowered off-torch lights again', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(1, 1, 0, 'unlit_redstone_torch', 1);
  c.tick(2); assert.equal(c.cell(1, 1, 0).id, ID.redstone_torch);
});
test('56 redstone block does not power through the block it sits under', () => {
  const c = make();
  c.put(0, 1, 0, 'redstone_block'); c.put(0, 0, 0, 'stone'); c.put(1, 0, 0, 'redstone_wire');
  c.tick(2); assert.equal(c.cell(1, 0, 0).state, 15);
});

// ---- record 014: quasi-connectivity, piston heads, slime/honey, copper bulb, inverted daylight detector, crafter ----
test('57 quasi-connectivity: piston powered from the block above only after a block update (BUD)', () => {
  const c = make();
  c.put(2, 1, 0, 'piston', 0); c.put(3, 1, 0, 'stone');
  c.tick(2);
  // Power the cell above the piston (lever on a stone block beside it): without an update the piston stays retracted.
  c.put(2, 3, 0, 'stone'); c.put(2, 4, 0, 'lever', 8); c.tick(3);
  c.put(1, 2, 0, 'redstone_wire'); c.put(1, 3, 0, 'redstone_wire'); c.tick(3);
  const powerAbove = c.cell(2, 1, 0).state & 8;
  // A block update next to the piston makes it notice the power above it.
  c.put(2, 0, 0, 'cobblestone'); c.tick(3);
  assert.equal(c.cell(2, 1, 0).state & 8, 8, 'extends after update');
  assert.equal(c.cell(3, 1, 0).id, ID.piston_head);
  void powerAbove;
});
test('58 piston head is removed and sticky piston pulls a slime block with its passenger', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'sticky_piston', 0); c.put(3, 1, 0, 'slime_block'); c.put(3, 2, 0, 'stone');
  c.tick(3);
  assert.equal(c.cell(3, 1, 0).id, ID.piston_head);
  assert.equal(c.cell(4, 1, 0).id, ID.slime_block, 'slime pushed');
  assert.equal(c.cell(4, 2, 0).id, ID.stone, 'passenger pushed with the slime');
  c.put(0, 2, 0, 'lever', 0); c.tick(3);
  assert.equal(c.cell(3, 1, 0).id, ID.slime_block, 'slime pulled back');
  assert.equal(c.cell(3, 2, 0).id, ID.stone, 'passenger pulled back');
  assert.equal(c.cell(4, 1, 0).id, 0);
});
test('59 honey and slime do not stick to each other', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 8); c.put(1, 1, 0, 'redstone_wire');
  c.put(2, 1, 0, 'piston', 0); c.put(3, 1, 0, 'slime_block'); c.put(3, 2, 0, 'honey_block');
  c.tick(3);
  assert.equal(c.cell(4, 1, 0).id, ID.slime_block);
  assert.equal(c.cell(3, 2, 0).id, ID.honey_block, 'honey stays');
});
test('60 copper bulb toggles on each rising edge', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 0); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'copper_bulb');
  c.tick(2); assert.equal(c.cell(2, 1, 0).id, ID.copper_bulb);
  c.put(0, 2, 0, 'lever', 8); c.tick(2); assert.equal(c.cell(2, 1, 0).id, ID.copper_bulb_lit, 'lit on first edge');
  c.put(0, 2, 0, 'lever', 0); c.tick(2); assert.equal(c.cell(2, 1, 0).id, ID.copper_bulb_lit, 'stays lit when power drops');
  c.put(0, 2, 0, 'lever', 8); c.tick(2); assert.equal(c.cell(2, 1, 0).id, ID.copper_bulb, 'off on second edge');
});
test('61 inverted daylight detector outputs at night', () => {
  const c = make();
  c.put(0, 1, 0, 'inverted_daylight_detector', 0); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'unlit_redstone_lamp');
  c.w.sky = 1; c.tick(3); assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_lamp, 'dark during the day');
  c.w.sky = 0; c.tick(3); assert.equal(c.cell(2, 1, 0).id, ID.redstone_lamp, 'lit at night');
  c.put(0, 1, 0, 'daylight_detector', 0); c.tick(3); assert.equal(c.cell(2, 1, 0).id, ID.unlit_redstone_lamp, 'normal detector is dark at night');
});
test('62 crafter fires once per pulse', () => {
  const c = make();
  c.put(0, 1, 0, 'stone'); c.put(0, 2, 0, 'lever', 0); c.put(1, 1, 0, 'redstone_wire'); c.put(2, 1, 0, 'crafter', 0);
  c.tick(2); assert.equal(c.w.crafted.length, 0);
  c.put(0, 2, 0, 'lever', 8); c.tick(4); assert.equal(c.w.crafted.length, 1);
  c.put(0, 2, 0, 'lever', 0); c.tick(2); c.put(0, 2, 0, 'lever', 8); c.tick(2); assert.equal(c.w.crafted.length, 2);
});

const passed = results.filter(r => r.ok).length;
for (const r of results) console.log(`${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.note ? '  — ' + r.note : ''}`);
console.log(`\n${passed}/${results.length} redstone device checks passed`);
if (passed !== results.length) process.exit(1);
