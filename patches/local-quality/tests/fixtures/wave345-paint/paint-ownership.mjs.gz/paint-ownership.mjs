import { notePaintMutation } from './scoring.mjs';
const STEP = 1 / 60;
const EPS = 1e-10;
const INSTALLED = Symbol.for('inkwave.issue264.paint-ownership-installed');

// Keep the existing RNG draw at the caller while using one recorded mask seed
// for a catalogue special's core and its larger-radius continuation.
export function projectileBurstPaintSeed(projectile, randomSeed) {
  return projectile?.s3AllSpecial && Number.isFinite(projectile.seed) ? projectile.seed : randomSeed;
}


// Keep ordinary clocks numeric on the wire. Decimal strings carry only values
// beyond the safe-integer range, so an accepted causal jump cannot exhaust the
// next local emission or lose precision. Canonical encoding avoids alias IDs.
export function isPaintOrderClock(value) {
  return Number.isSafeInteger(value) && value >= 0
    || typeof value === 'string' && /^[1-9][0-9]*$/.test(value)
      && BigInt(value) > BigInt(Number.MAX_SAFE_INTEGER);
}
export function nextPaintOrderClock(value) {
  if (!isPaintOrderClock(value)) throw new Error('Invalid network paint clock');
  return typeof value === 'number' && value < Number.MAX_SAFE_INTEGER
    ? value + 1 : (BigInt(value) + 1n).toString();
}
export function paintClockComesAfter(a, b) {
  return typeof a === 'number' && typeof b === 'number' ? a > b : BigInt(a) > BigInt(b);
}

const clamp = (x, lo, hi) => x <= lo ? +lo : x >= hi ? +hi : x;
const fract = x => x - Math.floor(x);
const f32 = Math.fround;
const smoothstep = (lo, hi, x) => {
  const t = clamp((x - lo) / (hi - lo), 0, 1);
  return t * t * (3 - 2 * t);
};
// The ancillary mask must not depend on driver-specific sin() or amplified
// floating-point rounding. Quantize once on the CPU, then carry the exact 16-bit
// word in aGrow.w. Every hash intermediate is an integer below 2^24, so highp
// IEEE float arithmetic, including fused multiply/add, gives identical results.
// The power-of-two modulus and byte swap are exact as well. The native body
// wobble and cosmetic tone keep their existing source formulas.
export function paintShapeSeed(seed) { return Math.floor(fract(f32(seed)) * 65536); }
export function paintShapeHash(word, stream, index) {
  let x = (word + stream * 4099 + index * 131) % 65536;
  x = (x * 251 + 13849) % 65536;
  x = (x % 256) * 256 + Math.floor(x / 256);
  x = (x * 251 + 13849) % 65536;
  return x / 65536;
}
export const PAINT_SHAPE_HASH_GLSL = `float paintShapeHash(float word, float stream, float index) {
  float x = mod(word + stream * 4099.0 + index * 131.0, 65536.0);
  x = mod(x * 251.0 + 13849.0, 65536.0);
  x = mod(x, 256.0) * 256.0 + floor(x / 256.0);
  x = mod(x * 251.0 + 13849.0, 65536.0);
  return x / 65536.0;
}`;
// Preserve the original power evaluation and operation order: multiplication
// chains can move ancillary mask coordinates across strict ownership boundaries.
const wobble = (a, s) => 1 + 0.12 * Math.sin(3 * a + s * 6.2831) + 0.08 * Math.sin(5 * a + s * 17.0) +
  0.05 * Math.sin(7 * a + s * 41.0) + 0.03 * Math.sin(11 * a + s * 73.0) +
  0.018 * Math.sin(17 * a + s * 29.0) + 0.17 * Math.pow(Math.max(Math.cos(a - s * 37.7), 0), 28) +
  0.12 * Math.pow(Math.max(Math.cos(a - s * 53.3 - 2.1), 0), 36);

function sdRay(px, py, ax, ay, bx, by, ra, rb) {
  const pax = px - ax, pay = py - ay, bax = bx - ax, bay = by - ay;
  const b2 = bax * bax + bay * bay;
  const h = clamp((pax * bax + pay * bay) / (b2 > 1e-8 ? b2 : 1e-8), 0, 1);
  return Math.hypot(px - ax - bax * h, py - ay - bay * h) - (ra * (1 - h) + rb * h);
}

function counts(kind, shapes) { return shapes[kind] || [0, 0, 0, 0]; }

const _ancillaryPiecePool = [];
const _ancillaryPieces = [];
const _ancillaryMask = { pieces: _ancillaryPieces, sa: 0, sdu: 0, sdv: 0, margin: 0, seed: 0, dT: 0 };
function allocPiece(idx) {
  let p = _ancillaryPiecePool[idx];
  if (!p) {
    p = { type: 0, ax: 0, ay: 0, bx: 0, by: 0, ra: 0, rb: 0, x: 0, y: 0, radius: 0, ux: 0, uy: 0, el: 0, x0: 0, yTop: 0, len: 0, w: 0, h2: 0, k: 0, r: 0, minX: 0, maxX: 0, minY: 0, maxY: 0 };
    _ancillaryPiecePool[idx] = p;
  }
  _ancillaryPieces[idx] = p;
  return p;
}

// #1671: hashes, angles, their cos/sin and the body wobble of each piece
// depend only on the seed, the shape counts, sa and the travel angle, never on
// the face, dn or tn. A growth record asks for them for every face entry on
// every tick; build them once per record with the same expressions and reuse
// them while those inputs are identical (NaN equal to NaN). A group with no
// pieces (the settled pass's drip-only contract) reads none of its values.
const sameTemplateValue = (a, b) => a === b || (a !== a && b !== b);
function ancillaryTemplate(g, seed, word, sa, dirAng, spread, rayCount, satelliteCount, spatterCount) {
  const templates=g._s3AncillaryTemplates ||= [];
  for(const t of templates)if(sameTemplateValue(t.seed,seed)&&sameTemplateValue(t.sa,sa)&&sameTemplateValue(t.dirAng,dirAng)
      &&(!rayCount||t.rayCount===rayCount)&&(!satelliteCount||t.satelliteCount===satelliteCount)&&(!spatterCount||t.spatterCount===spatterCount))return (g._s3AncillaryTemplate=t);
  const wobbles = g._s3Wobble && g._s3WobbleSeed === seed ? g._s3Wobble : (g._s3WobbleSeed = seed, g._s3Wobble = new Map());
  const rays = new Float64Array(rayCount * 6), sats = new Float64Array(satelliteCount * 7);
  const spats = new Float64Array(spatterCount * 7), drips = new Float64Array(6 * 3);
  for (let k = 0; k < rayCount; k++) {
    const h1 = paintShapeHash(word, 0, k), h2 = paintShapeHash(word, 1, k), h3 = paintShapeHash(word, 2, k);
    const a = sa > 0 ? dirAng + (h1 - 0.5) * spread : (k + 0.35 + 0.6 * h1) / rayCount * 6.2831 + seed * 6.2831;
    let w = wobbles.get(a);
    if (w === undefined) { w = wobble(a, seed); wobbles.set(a, w); }
    const at=k*6;rays[at]=Math.cos(a);rays[at+1]=Math.sin(a);rays[at+2]=w;rays[at+3]=h1;rays[at+4]=h2;rays[at+5]=h3;
  }
  for (let k = 0; k < satelliteCount; k++) {
    const h1 = paintShapeHash(word, 3, k), h2 = paintShapeHash(word, 4, k), h3 = paintShapeHash(word, 5, k);
    const a = sa > 0 ? dirAng + (h1 - 0.5) * spread : h1 * 6.2831;
    const ux = Math.cos(a), uy = Math.sin(a);
    const nx = ux * 0.68, ny = uy * 0.68 - 0.32; const l = Math.hypot(nx, ny) || 1;
    const at=k*7;sats[at]=h1;sats[at+1]=h2;sats[at+2]=h3;sats[at+3]=ux;sats[at+4]=uy;sats[at+5]=nx/l;sats[at+6]=ny/l;
  }
  for (let k = 0; k < spatterCount; k++) {
    const h1 = paintShapeHash(word, 6, k), h2 = paintShapeHash(word, 7, k), h3 = paintShapeHash(word, 8, k);
    const a = sa > 0 ? dirAng + (h1 - 0.5) * spread * 1.15 : h1 * 6.2831;
    const ux = Math.cos(a), uy = Math.sin(a);
    const nx = ux * 0.75, ny = uy * 0.75 - 0.25; const l = Math.hypot(nx, ny) || 1;
    const at=k*7;spats[at]=h1;spats[at+1]=h2;spats[at+2]=h3;spats[at+3]=ux;spats[at+4]=uy;spats[at+5]=nx/l;spats[at+6]=ny/l;
  }
  for (let k = 0; k < 6; k++) {const at=k*3;drips[at]=paintShapeHash(word,9,k);drips[at+1]=paintShapeHash(word,10,k);drips[at+2]=paintShapeHash(word,11,k);}
  const template={seed,sa,dirAng,rayCount,satelliteCount,spatterCount,rays,sats,spats,drips};
  if(templates.length>=8)templates.shift();templates.push(template);return (g._s3AncillaryTemplate=template);
}

function prepareAncillary(g, face, lu, lv, dn, sdu, sdv, sa, tn, dT, contract) {
  const R = g.R, r2 = R * R - dn * dn;
  if (r2 <= 0 || R <= 0) return null;
  const r = Math.sqrt(r2), fall = clamp(r / Math.max(R, 1e-3), 0, 1);
  const kind = g.kind, [rayCount, satelliteCount, spatterCount, dripCount] = counts(kind, contract.shapes);
  if (rayCount + satelliteCount + spatterCount + dripCount === 0) return null;
  let pIdx = 0;
  const seed = f32(g.seed), word = paintShapeSeed(seed), pixel = 1 / Math.max(face.atlas?.ppm || 1, 1);
  const dirAng = sa > 0 ? Math.atan2(sdv, sdu) : 0;
  const spread = 6.2831 + (2.5 - 6.2831) * clamp(sa * 1.2, 0, 1);
  const big = kind > 1.5 && kind < 3.5;
  const bodyGrow = 0.4 + 0.6 * (1 - Math.pow(1 - clamp(tn, 0, 1), 4));
  const T = ancillaryTemplate(g, seed, word, sa, dirAng, spread, rayCount, satelliteCount, spatterCount);

  const tsp = 1 - Math.pow(1 - clamp(tn * 1.4, 0, 1), 3);
  for (let k = 0; k < rayCount; k++) {
    const q = k * 6, ux = T.rays[q], uy = T.rays[q + 1], edge = r * bodyGrow * T.rays[q + 2];
    const h1 = T.rays[q + 3], h2 = T.rays[q + 4], h3 = T.rays[q + 5];
    // Same edge-spike length as the composed paint shader (adapter.mjs, paint.js).
    const len = r * (0.04 + 0.16 * h2 * h2 * h2) * tsp;
    const wB = r * (0.055 + 0.06 * h3), tipR = Math.max(r * (0.012 + 0.012 * h3), pixel * 0.45);
    const ax = ux * edge * 0.72, ay = uy * edge * 0.72;
    const tipX = ux * (edge + len) - uy * len * 0.18 * (h1 - 0.5);
    const tipY = uy * (edge + len) + ux * len * 0.18 * (h1 - 0.5);
    const p0 = allocPiece(pIdx++);
    p0.type = 0; p0.ax = ax; p0.ay = ay; p0.bx = tipX; p0.by = tipY; p0.ra = wB; p0.rb = tipR;
    p0.minX = (ax < tipX ? ax : tipX) - wB; p0.maxX = (ax > tipX ? ax : tipX) + wB;
    p0.minY = (ay < tipY ? ay : tipY) - wB; p0.maxY = (ay > tipY ? ay : tipY) + wB;
    const headR = tipR * (1.6 + 1.4 * h2);
    const p1 = allocPiece(pIdx++);
    p1.type = 1; p1.x = tipX; p1.y = tipY; p1.radius = headR;
    p1.minX = tipX - headR; p1.maxX = tipX + headR; p1.minY = tipY - headR; p1.maxY = tipY + headR;
  }

  for (let k = 0; k < satelliteCount; k++) {
    const q = k * 7, h2 = T.sats[q + 1], h3 = T.sats[q + 2];
    const tl = 0.28 + 0.95 * h2, land = smoothstep(tl, tl + 0.2, tn);
    if (land <= 0) continue;
    const ux = face.wall ? T.sats[q + 5] : T.sats[q + 3], uy = face.wall ? T.sats[q + 6] : T.sats[q + 4];
    const dist = r * (1.1 + (big ? 1.05 : 0.8) * h2 * h2);
    const rad = r * (0.028 + 0.085 * h3) * fall * (1 - 0.4 * h2) * (big ? 0.8 : 1) * land;
    const el = 1 + (0.5 + 1.6 * sa) * h2;
    const extent = rad * el;
    const p2 = allocPiece(pIdx++);
    p2.type = 2; p2.x = ux * dist; p2.y = uy * dist; p2.ux = ux; p2.uy = uy; p2.el = el; p2.radius = rad;
    p2.minX = ux * dist - extent; p2.maxX = ux * dist + extent; p2.minY = uy * dist - extent; p2.maxY = uy * dist + extent;
  }

  for (let k = 0; k < spatterCount; k++) {
    const q = k * 7, h2 = T.spats[q + 1], h3 = T.spats[q + 2];
    if (tn < 0.45 + 0.95 * h2) continue;
    const ux = face.wall ? T.spats[q + 5] : T.spats[q + 3], uy = face.wall ? T.spats[q + 6] : T.spats[q + 4];
    const rad = Math.max(r * (0.011 + 0.02 * h3) * fall, pixel * 0.9), dist = r * (1.3 + 1.2 * h2);
    const x = ux * dist, y = uy * dist;
    const p1 = allocPiece(pIdx++);
    p1.type = 1; p1.x = x; p1.y = y; p1.radius = rad;
    p1.minX = x - rad; p1.maxX = x + rad; p1.minY = y - rad; p1.maxY = y + rad;
  }

  if (face.wall && fall > 0.3 && dripCount > 0) {
    const nD = Math.min(6, dripCount + Math.floor(R * 1.2));
    for (let k = 0; k < nD; k++) {
      const h1 = T.drips[k * 3], h2 = T.drips[k * 3 + 1], h3 = T.drips[k * 3 + 2];
      if (k > 1 && h3 < 0.3) continue;
      const x0 = (h1 * 2 - 1) * r * 0.72;
      const c = Math.sqrt(Math.max(1 - (x0 / r) * (x0 / r), 0));
      const yTop = -c * r * 0.7;
      const len = c * r * 0.25 + r * (0.3 + 2.3 * h2 * h2) * fall * dT;
      const w = r * (0.042 + 0.04 * h3) * (0.75 + 0.35 * fall);
      const p3 = allocPiece(pIdx++);
      p3.type = 3; p3.x0 = x0; p3.yTop = yTop; p3.len = len; p3.w = w; p3.h2 = h2; p3.k = k; p3.r = r;
      p3.minX = x0 - w * 2; p3.maxX = x0 + w * 2; p3.minY = yTop - len - w * 2; p3.maxY = yTop + w * 2;
    }
  }
  // Retain V8 elements capacity while exposing only the current live prefix.
  _ancillaryPieces.length = pIdx;
  if (!pIdx) return null;
  _ancillaryMask.sa = sa; _ancillaryMask.sdu = sdu; _ancillaryMask.sdv = sdv;
  _ancillaryMask.margin = pixel * 1.5; _ancillaryMask.seed = seed; _ancillaryMask.dT = dT;
  return _ancillaryMask;
}

function pointInsideAncillary(mask, x, y, seed, p) {
  let px = x, py = y;
  if (mask.sa > 0 && p.type !== 3) {
    const along = px * mask.sdu + py * mask.sdv;
    const scale = along > 0 ? 1 + mask.sa : 1 + 0.25 * mask.sa;
    const perpX = px - along * mask.sdu, perpY = py - along * mask.sdv;
    px = perpX + mask.sdu * (along / scale); py = perpY + mask.sdv * (along / scale);
  }
  const sx = p.type === 3 ? x : px, sy = p.type === 3 ? y : py;
  if (sx < p.minX - mask.margin || sx > p.maxX + mask.margin || sy < p.minY - mask.margin || sy > p.maxY + mask.margin) return false;
  if (p.type === 0 && sdRay(sx, sy, p.ax, p.ay, p.bx, p.by, p.ra, p.rb) < -mask.margin) return true;
  // Keep the signed-distance comparison. Squaring radius - margin changes
  // floating-point rounding at the boundary, including inside/outside decisions.
  if (p.type === 1) {
    const dx = sx - p.x, dy = sy - p.y, rHi = p.radius * (1 + 1e-5) + 1e-8;
    if (!(dx * dx + dy * dy > rHi * rHi) && Math.hypot(dx, dy) - p.radius < -mask.margin) return true;
  }
  if (p.type === 2) {
    let qx = sx - p.x, qy = sy - p.y, along = qx * p.ux + qy * p.uy;
    qx -= p.ux * along * (1 - 1 / p.el); qy -= p.uy * along * (1 - 1 / p.el);
    const rHi = p.radius * (1 + 1e-5) + 1e-8;
    if (!(qx * qx + qy * qy > rHi * rHi) && Math.hypot(qx, qy) - p.radius < -mask.margin) return true;
  }
  if (p.type === 3) {
    let qx = sx - p.x0, qy = sy - p.yTop;
    const ty = clamp(-qy / (p.len > 1e-4 ? p.len : 1e-4), 0, 1);
    qx += Math.sin(qy / p.r * 9 + seed * 20 + p.k * 2.3) * p.w * 0.35 * ty;
    const wt = p.w * (1 + (0.6 - 1) * smoothstep(0.05, 0.85, ty));
    const stream = Math.max(Math.abs(qx) - wt, Math.max(qy, -p.len - qy));
    const tqy = (qy + p.len - p.w * 0.3) * 0.8;
    const bulb = Math.hypot(qx, tqy) - p.w * (1.2 + 0.35 * p.h2) * (0.6 + 0.4 * mask.dT);
    if (stream < -mask.margin || bulb < -mask.margin) return true;
  }
  return false;
}

// A sub-cell dot can miss every fixed sample. Find a real point of its
// opaque core inside the cell instead. The circle/ellipse and directional
// stretch are affine on each side of the travel axis; minimize their SDF on
// the clipped rectangle edges. The returned witness is also GPU-testable.
const dotWitness = new Float64Array(2);
export function paintDotCellWitness(mask, face, x, y, piece) {
  if (piece.type !== 1 && piece.type !== 2) return null;
  const radius = piece.radius - (mask.margin < piece.radius * 0.5 ? mask.margin : piece.radius * 0.5);
  if (!(radius > 0)) return null;
  const x0 = x - face.cu * 0.5, x1 = x + face.cu * 0.5;
  const y0 = y - face.cv * 0.5, y1 = y + face.cv * 0.5;
  const du = mask.sdu, dv = mask.sdv, stretched = mask.sa > 0;
  const along = piece.x * du + piece.y * dv;
  const scale = stretched ? (along > 0 ? 1 + mask.sa : 1 + mask.sa * 0.25) : 1;
  const cx = piece.x + du * along * (scale - 1), cy = piece.y + dv * along * (scale - 1);
  if (cx >= x0 && cx < x1 && cy >= y0 && cy < y1) {
    dotWitness[0] = cx; dotWitness[1] = cy; return dotWitness;
  }
  const radHi = radius * (1 + 1e-5) + 1e-8, radHiSq = radHi * radHi;
  for (let side = 0; side < 4; side++) {
    const ax = side === 0 || side === 3 ? x0 : x1, ay = side < 2 ? y0 : y1;
    const bx = side < 2 ? x1 : x0, by = side === 0 || side === 3 ? y0 : y1;
    for (let branch = 0; branch < (stretched ? 2 : 1); branch++) {
      let lo = 0, hi = 1;
      if (stretched) {
        const a = (ax * du + ay * dv) * (branch ? 1 : -1);
        const b = (bx * du + by * dv) * (branch ? 1 : -1);
        if (a < 0 && b < 0) continue;
        if (a < 0) lo = a / (a - b);
        if (b < 0) hi = a / (a - b);
      }
      const invScale = stretched ? 1 / (1 + mask.sa * (branch ? 1 : 0.25)) : 1;
      let qx = ax + (bx - ax) * lo, qy = ay + (by - ay) * lo;
      let vx = (bx - ax) * (hi - lo), vy = (by - ay) * (hi - lo);
      let a = qx * du + qy * dv, b = vx * du + vy * dv;
      qx += du * a * (invScale - 1); qy += dv * a * (invScale - 1);
      vx += du * b * (invScale - 1); vy += dv * b * (invScale - 1);
      qx -= piece.x; qy -= piece.y;
      if (piece.type === 2) {
        a = (qx * piece.ux + qy * piece.uy) * (1 / piece.el - 1);
        b = (vx * piece.ux + vy * piece.uy) * (1 / piece.el - 1);
        qx += piece.ux * a; qy += piece.uy * a;
        vx += piece.ux * b; vy += piece.uy * b;
      }
      const v2 = vx * vx + vy * vy;
      const t = clamp(-(qx * vx + qy * vy) / (v2 > 1e-30 ? v2 : 1e-30), 0, 1);
      const rx = qx + t * vx, ry = qy + t * vy;
      if (rx * rx + ry * ry > radHiSq || Math.hypot(rx, ry) >= radius) continue;
      const at = lo + t * (hi - lo);
      dotWitness[0] = ax + (bx - ax) * at; dotWitness[1] = ay + (by - ay) * at;
      return dotWitness;
    }
  }
  return null;
}

function cellIsSolidlyVisible(mask, face, x, y, piece) {
  // #1671: nearly every test of a growing bomb is a bead or spatter dot that
  // misses. Unstretched, a dot lies inside the circle of radius
  // radius * max(1, el) about its center; when that circle (with relative and
  // absolute slack far above the rounding of the exact path) stays clear of
  // the closed cell rectangle, no sample is inside and no witness exists.
  // NaN or infinite inputs never reject and keep the exact path.
  if ((piece.type === 1 || piece.type === 2) && !(mask.sa > 0) &&
      face.cu > 0 && face.cv > 0 && Number.isFinite(x + y + face.cu + face.cv + piece.x + piece.y)) {
    const hx = face.cu * 0.5, hy = face.cv * 0.5;
    const ex0 = x - hx - piece.x, ex1 = piece.x - (x + hx), ex = ex0 > 0 ? ex0 : ex1 > 0 ? ex1 : 0;
    const ey0 = y - hy - piece.y, ey1 = piece.y - (y + hy), ey = ey0 > 0 ? ey0 : ey1 > 0 ? ey1 : 0;
    const reach = (piece.type === 2 ? piece.radius * Math.max(1, piece.el) : piece.radius) * (1 + 1e-6) + 1e-9;
    const d2 = ex * ex + ey * ey;
    if (d2 > reach * reach && d2 < Infinity) return false;
  }

  // Conservative stretched dot enclosure: the forward and backward affine
  // images of the original disc cover the entire visible circle/ellipse.
  // Reject only when BOTH discs miss the closed cell. Non-finite, non-unit
  // and degenerate shapes always run the unchanged sample/witness test.
  if ((piece.type === 1 || piece.type === 2) && mask.sa > 0 &&
      Number.isFinite(mask.sa) && Number.isFinite(mask.sdu) && Number.isFinite(mask.sdv) &&
      Number.isFinite(piece.x) && Number.isFinite(piece.y) && Number.isFinite(piece.radius) && piece.radius >= 0 &&
      Number.isFinite(x) && Number.isFinite(y) && face.cu > 0 && face.cv > 0 &&
      Number.isFinite(face.cu) && Number.isFinite(face.cv) &&
      Math.abs(mask.sdu * mask.sdu + mask.sdv * mask.sdv - 1) < 1e-12 &&
      (piece.type !== 2 || (piece.el > 0 && Number.isFinite(piece.el) &&
        Math.abs(piece.ux * piece.ux + piece.uy * piece.uy - 1) < 1e-12))) {
    const u = mask.sdu, v = mask.sdv, along = piece.x * u + piece.y * v;
    const radius = piece.radius * (piece.type === 2 ? Math.max(1, piece.el) : 1);
    const hx = face.cu * 0.5, hy = face.cv * 0.5;
    const frontX = piece.x + u * along * mask.sa, frontY = piece.y + v * along * mask.sa;
    const ex0 = x - hx - frontX, ex1 = frontX - (x + hx), ex = ex0 > 0 ? ex0 : ex1 > 0 ? ex1 : 0;
    const ey0 = y - hy - frontY, ey1 = frontY - (y + hy), ey = ey0 > 0 ? ey0 : ey1 > 0 ? ey1 : 0;
    const frontReach = radius * (1 + mask.sa) * (1 + 1e-5) + 1e-8;
    if (ex * ex + ey * ey > frontReach * frontReach) {
      const backX = piece.x + u * along * mask.sa * 0.25, backY = piece.y + v * along * mask.sa * 0.25;
      const bx0 = x - hx - backX, bx1 = backX - (x + hx), bx = bx0 > 0 ? bx0 : bx1 > 0 ? bx1 : 0;
      const by0 = y - hy - backY, by1 = backY - (y + hy), by = by0 > 0 ? by0 : by1 > 0 ? by1 : 0;
      const backReach = radius * (1 + mask.sa * 0.25) * (1 + 1e-5) + 1e-8;
      if (bx * bx + by * by > backReach * backReach) return false;
    }
  }
  const dx = face.cu * 0.32, dy = face.cv * 0.32;
  // A paint cell owns its area when its center or one of four interior samples
  // lies well inside the shader mask. This catches most sub-cell satellites
  // without treating a hand-mirrored antialias width as gameplay truth.
  for (let i = 0; i < 5; i++) {
    const sx = x + (i === 1 || i === 3 ? -dx : i > 1 ? dx : 0);
    const sy = y + (i === 1 || i === 2 ? -dy : i > 2 ? dy : 0);
    if (pointInsideAncillary(mask, sx, sy, mask.seed, piece)) return true;
  }
  return !!paintDotCellWitness(mask, face, x, y, piece);
}

function ensureOwnershipState(paint) {
  if (!(paint._paintOwnershipOrder instanceof Uint32Array) || paint._paintOwnershipOrder.length !== paint.grid.length) {
    paint._paintOwnershipOrder = new Uint32Array(paint.grid.length);
    paint._paintOwnershipSequence = 0;
    paint._paintOrderRecords = [null];
    paint._paintOrderIds = new Map();
  }
  if (!Array.isArray(paint._paintOrderRecords)) paint._paintOrderRecords = [null];
  if (!(paint._paintOrderIds instanceof Map)) paint._paintOrderIds = new Map();
  if (!(paint._paintOrderRunScratch instanceof Float64Array)) paint._paintOrderRunScratch = new Float64Array(64);
  if (!Number.isFinite(paint._paintSimulationAccumulator)) paint._paintSimulationAccumulator = 0;
}

function paintOrderId(paint, order, prepared=false) {
  if(!prepared)ensureOwnershipState(paint);
  const clock = order?.clock ?? order?.tick;
  const validNetworkOrder = order && isPaintOrderClock(clock)
    && typeof order.peer === 'string' && order.peer.length > 0
    && Number.isSafeInteger(order.seq) && order.seq >= 1;
  let key, record;
  if (validNetworkOrder) {
    record = { clock, epoch: typeof order.epoch === 'string' ? order.epoch : '', peer: order.peer, seq: order.seq,
      tie: typeof order.tie === 'string' ? order.tie : '', legacy: order.legacy === true };
    key = JSON.stringify([record.legacy, record.epoch, record.clock, record.peer, record.seq, record.tie]);
    const existing = paint._paintOrderIds.get(key);
    if (existing) return existing;
  } else {
    paint._paintOwnershipSequence = (paint._paintOwnershipSequence + 1) >>> 0;
    if (paint._paintOwnershipSequence === 0) paint._paintOwnershipSequence = 1;
    // Local metadata needs only the wrapping sequence. Keep the stable record
    // index/returned ID, without retaining one object per local stamp. Network
    // metadata and deduplicated receipt identities remain unchanged.
    record = paint._paintOwnershipSequence;
  }
  const id = paint._paintOrderRecords.length;
  paint._paintOrderRecords.push(record);
  // Local stamps always receive a fresh ID; only network orders are deduplicated.
  if (validNetworkOrder) paint._paintOrderIds.set(key, id);
  return id;
}

function paintOrderComesAfter(paint, nextId, previousId) {
  if (nextId === previousId) return true;
  const a = paint._paintOrderRecords[nextId], b = paint._paintOrderRecords[previousId];
  if (!a) return false;
  if (!b) return true;
  const aLocal = typeof a === 'number' || a.local, bLocal = typeof b === 'number' || b.local;
  if (aLocal || bLocal) {
    if (aLocal && bLocal) return (typeof a === 'number' ? a : a.seq) > (typeof b === 'number' ? b : b.seq);
    return !aLocal;
  }
  if (a.legacy !== b.legacy) return !a.legacy;
  if (a.clock !== b.clock) return paintClockComesAfter(a.clock, b.clock);
  if (a.peer !== b.peer) return a.peer > b.peer;
  if (a.seq !== b.seq) return a.seq > b.seq;
  return a.tie > b.tie;
}

function claimPaintCell(paint, index, value, orderId, orderState = null) {
  if (paint.level?.native && paint.dead[index]) return false;
  const current = orderId || paint._paintCurrentOrder || 0;
  const previous = paint._paintOwnershipOrder[index] || 0;
  if (current && previous === current) return false;
  if (current && previous && !paintOrderComesAfter(paint, current, previous)) return false;
  if (current) paint._paintOwnershipOrder[index] = current;
  if (orderState) orderState.accepted = true;
  return true;
}

// Face-space (x, y) box of one ancillary piece. Rays, beads and satellites are
// defined in the stretched space pointInsideAncillary maps samples into; drips
// (type 3) are tested unstretched. The stretch map is linear on each side of the
// travel axis, so the images of the box corners under both scales, together
// with the original corners (the axis crossing maps to itself), bound the image.
const _cellBox = new Float64Array(4);
function pieceCellBox(mask, p, pad) {
  let x0 = p.minX, x1 = p.maxX, y0 = p.minY, y1 = p.maxY;
  if (mask.sa > 0 && p.type !== 3) {
    const ux = mask.sdu, uy = mask.sdv, ahead = 1 + mask.sa, behind = 1 + 0.25 * mask.sa;
    for (let c = 0; c < 4; c++) {
      const cx = c & 1 ? p.maxX : p.minX, cy = c & 2 ? p.maxY : p.minY;
      const along = cx * ux + cy * uy, s = (along > 0 ? ahead : behind) - 1;
      const mx = cx + ux * along * s, my = cy + uy * along * s;
      if (mx < x0) x0 = mx; if (mx > x1) x1 = mx;
      if (my < y0) y0 = my; if (my > y1) y1 = my;
    }
  }
  _cellBox[0] = x0 - pad; _cellBox[1] = x1 + pad; _cellBox[2] = y0 - pad; _cellBox[3] = y1 + pad;
  return _cellBox;
}

function nextVisitStamp(paint) {
  if (!(paint._paintVisitStamp instanceof Uint32Array) || paint._paintVisitStamp.length !== paint.grid.length) {
    paint._paintVisitStamp = new Uint32Array(paint.grid.length);
    paint._paintVisitSerial = 0;
  }
  paint._paintVisitSerial = (paint._paintVisitSerial + 1) >>> 0;
  if (paint._paintVisitSerial === 0) { paint._paintVisitStamp.fill(0); paint._paintVisitSerial = 1; }
  return paint._paintVisitSerial;
}

// #1671: a settled ray/bead/satellite keeps bit-identical inputs on every
// later drip tick of its growth record, yet claimAncillaryCells re-ran its shape
// test on every cell of its box. A shape miss is a pure function of the face
// entry, cell, mask and piece values, and has no effect. Keep, in the original
// loop order, every cell of the box except those misses and the pure bounds
// rejections, and replay only them when all of those values are === again
// (NaN equal to NaN). Grid, owner order and visit state are re-read on every
// replay through the unchanged body. Drips change with dT and are never kept.
const sameCacheValue = (a, b) => a === b || (a !== a && b !== b);
function cellCacheSlot(paint, g, n, n2, tn, face, piece) {
  // Only native source stages (many small wall charts) and only once growth
  // can no longer change ray/bead/satellite shapes; drip ticks re-use them.
  if (!paint.level?.native || tn < 1.45 || !face.wall || !g.dripDur || piece.type === 3) return null;
  const entryStride = g.entryStride === 8 ? 8 : 7, slot = n / entryStride;
  const byEntry = g._s3AncillaryCells || (g._s3AncillaryCells = []);
  const pieces = byEntry[slot] || (byEntry[slot] = []);
  return pieces[n2] || (pieces[n2] = { key: null, cells: null });
}
function cellCacheKey(key, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece) {
  key[0] = face; key[1] = face.grid; key[2] = face.nu; key[3] = face.cu; key[4] = face.cv;
  key[5] = lu; key[6] = lv; key[7] = ext; key[8] = yLo; key[9] = pad;
  key[10] = bi0; key[11] = bi1; key[12] = bj0; key[13] = bj1;
  key[14] = mask.sa; key[15] = mask.sdu; key[16] = mask.sdv; key[17] = mask.margin;
  // Every numeric field a ray (0), bead (1) or satellite (2) piece carries.
  key[18] = piece.type; key[19] = piece.ax; key[20] = piece.ay; key[21] = piece.bx; key[22] = piece.by;
  key[23] = piece.ra; key[24] = piece.rb; key[25] = piece.x; key[26] = piece.y; key[27] = piece.radius;
  key[28] = piece.ux; key[29] = piece.uy; key[30] = piece.el; key[31] = piece.minX; key[32] = piece.maxX;
  key[33] = piece.minY; key[34] = piece.maxY;
  return key;
}
const _cellCacheProbe = [];
function sameCellCacheKey(cache, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece) {
  const key = cache.key;
  if (!key) return false;
  const next = cellCacheKey(_cellCacheProbe, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece);
  for (let i = 0; i < key.length; i++) if (!sameCacheValue(key[i], next[i])) return false;
  return true;
}
function storeCellCache(cache, cells, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece) {
  cache.key = cellCacheKey(cache.key || new Array(35), face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece);
  cache.cells = cells;
}

// Status bits: 1 cacheable/visited, 2 changed ownership, 4 awarded turf area.
function visitAncillaryCell(paint,g,face,mask,visit,stamp,value,order,index,x,y,piece){
 if(visit[index]===stamp)return 1;
 const previousOrder=paint._paintOwnershipOrder[index]||0;
 if(previousOrder&&order&&!paintOrderComesAfter(paint,order,previousOrder)){visit[index]=stamp;return 1;}
 const previous=paint.grid[index];
 if(previous===value&&previousOrder===order){visit[index]=stamp;return 1;}
 if(!cellIsSolidlyVisible(mask,face,x,y,piece))return 0;
 visit[index]=stamp;
 if(previous===value){claimPaintCell(paint,index,value,order);return 1;}
 if(!claimPaintCell(paint,index,value,order))return 1;
 paint.grid[index]=value;
 if(paint._inkMark){const cell=index-face.grid,j=Math.floor(cell/face.nu);paint._inkMark(face,cell-j*face.nu,j);}
 if(face.turf&&!paint.dead[index]){if(previous)paint.counts[previous-1]--;paint.counts[g.team]++;return 7;}
 return 3;
}

function claimAncillaryCells(paint, g, tn, dT, contract) {
  const E = g.entries;
  if (g.R <= 0.02 || !Array.isArray(E) || !E.length || g.kind === contract.kind.speck) return 0;
  const value = g.team + 1, order = g.paintOrder || 0;
  // Growth records can be reused or acquire extra faces: do not let a stale
  // completion marker silently suppress a newly paintable surface.
  const settledGeometry = E.length === g._ancillaryDoneEntries && g.R === g._ancillaryDoneRadius;
  if (order > 0 && tn >= 1.45 && settledGeometry && g._ancillaryAllDone === order && g.age >= g._ancillaryDoneAge) return 0;
  const floorSettled = order > 0 && tn >= 1.45 && E.length === g._ancillaryFloorEntries && g.R === g._ancillaryFloorRadius && g._ancillaryFloorDone === order && g.age >= g._ancillaryFloorDoneAge;
  let claimed = 0, changed = false;
  const entryStride = g.entryStride === 8 ? 8 : 7;
  for (let n = 0; n < E.length; n += entryStride) {
    const face = E[n], lu = E[n + 1], lv = E[n + 2], dn = E[n + 3], sdu = E[n + 4], sdv = E[n + 5], sa = E[n + 6];
    if (!face?.atlas || dn >= g.R || face.cu <= 0 || face.cv <= 0) continue;
    if (floorSettled && (!face.wall || !g.dripDur)) continue;
    const r = Math.sqrt(Math.max(0, g.R * g.R - dn * dn));
    if (r <= 0.02) continue;
    const reach = contract.reach[g.kind] || 1;
    const ext = r * (reach + 1.4 * sa);
    const down = face.wall && g.dripDur ? r * contract.dripReach : 0;
    const i0 = Math.max(0, Math.floor((lu - ext) / face.cu)), i1 = Math.min(face.nu - 1, Math.floor((lu + ext) / face.cu));
    const j0 = Math.max(0, Math.floor((lv - (ext > down ? ext : down)) / face.cv)), j1 = Math.min(face.nv - 1, Math.floor((lv + ext) / face.cv));
    if (i1 < i0 || j1 < j0) continue;
    const cellArea = face.cu * face.cv;
    const mask = prepareAncillary(g, face, lu, lv, dn, sdu, sdv, sa, tn, dT, contract);
    if (!mask) continue;
    // Visit only cells overlapping a piece box. Dot cores also intersect the
    // cell area between fixed samples, so include the complete half-cell extent.
    const stamp = nextVisitStamp(paint);
    const visit = paint._paintVisitStamp;
    const cu = face.cu, cv = face.cv, nu = face.nu, fGrid = face.grid, hcu = cu * 0.5, hcv = cv * 0.5;
    const pad = (cu > cv ? cu : cv) * 0.5 + mask.margin * (1 + (sa > 0 ? sa : 0)) + 1e-9;
    const yLo = -(ext > down ? ext : down);
    for (let n2 = 0; n2 < mask.pieces.length; n2++) {
      const piece = mask.pieces[n2];
      const box = pieceCellBox(mask, piece, pad);
      const bi0 = Math.max(i0, Math.ceil((box[0] + lu) / cu - 0.5)), bi1 = Math.min(i1, Math.floor((box[1] + lu) / cu - 0.5));
      const bj0 = Math.max(j0, Math.ceil((box[2] + lv) / cv - 0.5)), bj1 = Math.min(j1, Math.floor((box[3] + lv) / cv - 0.5));
      // An empty box visits no cell; skip the cache bookkeeping too.
      if (bi1 < bi0 || bj1 < bj0) continue;
      const cache = cellCacheSlot(paint, g, n, n2, tn, face, piece);
      const cells = cache && sameCellCacheKey(cache, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece) ? cache.cells : null;
      if (cells) {
        for (let k = 0; k < cells.length; k++) {
          const i = cells[k] % nu, j = (cells[k] - i) / nu;
          const status=visitAncillaryCell(paint,g,face,mask,visit,stamp,value,order,fGrid+cells[k],(i+.5)*cu-lu,(j+.5)*cv-lv,piece);
          if(status&2)changed=true;if(status&4)claimed+=cellArea;
        }
        continue;
      }
      const record = cache ? [] : null;
      for (let j = bj0; j <= bj1; j++) {
        const y = (j + 0.5) * cv - lv;
        if (y + hcv < yLo || y - hcv > ext) continue;
        const row = fGrid + j * nu, rowLocal = j * nu;
        for (let i = bi0; i <= bi1; i++) {
          const x = (i + 0.5) * cu - lu;
          if (x + hcu < -ext || x - hcu > ext) continue;
          const status=visitAncillaryCell(paint,g,face,mask,visit,stamp,value,order,row+i,x,y,piece);
          if(status&2)changed=true;if(status&4)claimed+=cellArea;
          if(status&&record)record.push(rowLocal+i);
        }
      }
      if (record) storeCellCache(cache, record, face, lu, lv, ext, yLo, pad, bi0, bi1, bj0, bj1, mask, piece);
    }
  }
  if (order > 0 && tn >= 1.45) {
    g._ancillaryFloorDone = order;
    g._ancillaryFloorDoneAge = g.age;
    g._ancillaryFloorEntries = E.length;
    g._ancillaryFloorRadius = g.R;
    if (dT >= 1 || !g.dripDur) {
      g._ancillaryAllDone = order;
      g._ancillaryDoneAge = g.age;
      g._ancillaryDoneEntries = E.length;
      g._ancillaryDoneRadius = g.R;
    }
  }
  if (changed) notePaintMutation(paint, claimed > 0);
  if (claimed > 0 && g.paintOwner && !g.paintOwner.remote) {
    if (g.paintCreditMode === 1) g.paintOwner.addTurfNoSpecial?.(claimed);
    else g.paintOwner.addTurf?.(claimed);
  }
  return claimed;
}

export function installIssue264PaintOwnership(PaintSystem, contract) {
  const proto = PaintSystem?.prototype;
  if (!proto || typeof proto.splat !== 'function' || typeof proto.flush !== 'function' || typeof proto._emitGrowth !== 'function') {
    throw new TypeError('Issue #264 paint ownership requires native splat, flush, and growth methods');
  }
  if (proto[INSTALLED]) return false;
  const nativeSplat = proto.splat, nativeFlush = proto.flush, nativeClear = proto.clear, nativeDispose = proto.dispose;
  const nativeEmitGrowth = proto._emitGrowth;
  // One retained presentation per authoritative stamp, not one quad per face
  // per hidden frame. Growth records and their entry arrays are pooled, so the
  // snapshot must own its entries before a finished record is released/reused.
  proto._emitGrowth = function hiddenAwarePaintGrowth(g, tn, dT, dripOnly, bodyOnly = false) {
    if (!globalThis.document?.hidden || !g.paintOrder) {
      return nativeEmitGrowth.call(this, g, tn, dT, dripOnly, bodyOnly);
    }
    const pending = this._hiddenPaintGrowth || (this._hiddenPaintGrowth = new Map());
    let row = pending.get(g.paintOrder);
    if (!row) {
      row = { g: { ...g, entries: g.entries.slice(), paintOwner: null }, tn, dT, dripOnly, bodyOnly };
      pending.set(g.paintOrder, row);
      this._hiddenPaintInsertions = (this._hiddenPaintInsertions || 0) + 1;
      if (pending.size >= 128 && this._hiddenPaintInsertions >= 64) {
        // Network rendering is already clipped to authoritative owner cells.
        // Only those records may be pruned: local sub-cell visual ink is
        // intentionally retained even if it has never claimed a grid cell.
        // Future growth may re-add a network stamp when it gains a cell.
        const missing = new Set();
        for(const [id,snapshot] of pending)if(snapshot.g.netOrderId)missing.add(id);
        for(let i=0;i<this._paintOwnershipOrder.length&&missing.size;i++)missing.delete(this._paintOwnershipOrder[i]);
        for(const id of missing)pending.delete(id);
        this._hiddenPaintInsertions = 0;
      }

    } else {
      row.tn = tn; row.dT = dT; row.dripOnly = dripOnly; row.bodyOnly = bodyOnly;
    }
    // A final drip-only pass still needs to reconstruct the body which was
    // never submitted while hidden. Emitting the full current mask is safe:
    // chronological replay and the network owner clips preserve later ink.
    row.dripOnly = false;
  };
  proto._resumePaintPresentation = function resumePaintPresentation() {
    if (globalThis.document?.hidden) return;
    const quads = this._hiddenQuads;
    this._hiddenQuads = null;
    if (quads) for (const args of quads) this._pushQuad(...args);
    if (!this._hiddenPaintGrowth?.size) return;
    const pending = this._hiddenPaintGrowth;
    this._hiddenPaintGrowth = null;
    for (const row of pending.values()) nativeEmitGrowth.call(this, row.g, row.tn, row.dT, row.dripOnly, row.bodyOnly);
  };


  proto._paintOrderId = function issue264PaintOrderId(order) { return paintOrderId(this, order); };
  proto._paintOrderComesAfter = function issue264PaintOrderAfter(nextId, previousId) {
    ensureOwnershipState(this);
    return paintOrderComesAfter(this, nextId, previousId);
  };
  proto._preparePaintOwnership=function(){ensureOwnershipState(this);};
  proto._paintClaimPreparedCell=function(index,value,orderId,orderState){return claimPaintCell(this,index,value,orderId,orderState);};
  proto._paintClaimCell = function issue264ClaimPaintCell(index, value, orderId, orderState) {
    ensureOwnershipState(this);
    return claimPaintCell(this, index, value, orderId, orderState);
  };
  proto._paintOrderRuns = function issue264PaintOrderRuns(face, orderId, u0, u1, v0, v1) {
    ensureOwnershipState(this);
    const padM = (face.atlas.pad - 0.5) / face.atlas.ppm;
    const i0 = Math.max(0, Math.floor(Math.max(0, u0) / face.cu));
    const i1 = Math.min(face.nu - 1, Math.floor(Math.min(face.su, u1) / face.cu));
    const j0 = Math.max(0, Math.floor(Math.max(0, v0) / face.cv));
    const j1 = Math.min(face.nv - 1, Math.floor(Math.min(face.sv, v1) / face.cv));
    let scratch = this._paintOrderRunScratch, runCount = 0;
    for (let j = j0; j <= j1; j++) {
      const row = face.grid + j * face.nu, owners = this._paintOwnershipOrder;
      let i = i0;
      while (i <= i1) {
        while (i <= i1 && owners[row + i] !== orderId) i++;
        if (i > i1) break;
        const start = i++;
        while (i <= i1 && owners[row + i] === orderId) i++;
        const end = i - 1;
        let x0 = Math.max(u0, start * face.cu), x1 = Math.min(u1, (end + 1) * face.cu);
        let y0 = Math.max(v0, j * face.cv), y1 = Math.min(v1, (j + 1) * face.cv);
        if (start === 0) x0 = Math.max(u0, -padM);
        if (end === face.nu - 1) x1 = Math.min(u1, face.su + padM);
        if (j === 0) y0 = Math.max(v0, -padM);
        if (j === face.nv - 1) y1 = Math.min(v1, face.sv + padM);
        if (x1 > x0 && y1 > y0) {
          const offset = runCount * 4;
          if (offset + 4 > scratch.length) {
            const grown = new Float64Array(Math.max(scratch.length * 2, offset + 4));
            grown.set(scratch); this._paintOrderRunScratch = scratch = grown;
          }
          scratch[offset] = x0; scratch[offset + 1] = x1;
          scratch[offset + 2] = y0; scratch[offset + 3] = y1;
          runCount++;
        }
      }
    }
    return runCount;
  };

  proto.splat = function issue264SplatContext(center, radius, team, opts = {}) {
    if (opts.cosmetic) return nativeSplat.call(this, center, radius, team, opts);
    ensureOwnershipState(this);
    const candidate = opts.claimOwner ?? this._paintNextOwner;
    this._paintNextOwner = null;
    const owner = candidate && !candidate.remote && typeof candidate.addTurf === 'function' ? candidate : null;
    const mode = opts.claimMode === 'no-special' ? 1 : 0;
    const callOpts = ('claimOwner' in opts || 'claimMode' in opts) ? { ...opts } : opts;
    if (callOpts !== opts) { delete callOpts.claimOwner; delete callOpts.claimMode; }
    const order = paintOrderId(this, opts.__netOrder,true);
    const previousOrder = this._paintCurrentOrder, previousContext = this._paintOwnerContext;
    const ctxDepth = this._paintOwnerDepth || 0, ctxPool = this._paintOwnerPool || (this._paintOwnerPool = []);
    const ctx = ctxPool[ctxDepth] || (ctxPool[ctxDepth] = { owner: null, mode: 0, order: 0, accepted: false });
    ctx.owner = owner; ctx.mode = mode; ctx.order = order; ctx.accepted = false;
    this._paintOwnerDepth = ctxDepth + 1;
    this._paintCurrentOrder = order;
    this._paintOwnerContext = ctx;
    try { return nativeSplat.call(this, center, radius, team, callOpts); }
    finally { ctx.owner = null; this._paintOwnerDepth = ctxDepth; this._paintCurrentOrder = previousOrder; this._paintOwnerContext = previousContext; }
  };

  proto._advanceSplatOwnership = function issue264AdvanceOwnership(g, phase, dripPhase) {
    if (!g || g.kind === contract.kind.speck || g.R <= 0.02) return 0;
    const tn = phase === undefined ? Math.min(3, Math.max(0, g.age / Math.max(g.dur, 1e-6))) : phase;
    const td = g.dripDur ? Math.min(1, g.age / g.dripDur) : 1;
    const dT = dripPhase === undefined ? (g.dripDur ? 1 - Math.pow(1 - td, 2.2) : 1) : dripPhase;
    return claimAncillaryCells(this, g, tn, dT, contract);
  };
  proto._finishSplatOwnership = function issue264FinishOwnership(g) {
    if (!g || g.kind === contract.kind.speck || g.R <= 0.02) return 0;
    return claimAncillaryCells(this, g, 3, 1, contract);
  };
  proto._clearPaintOwnership = function issue264ClearOwnership() {
    if (this._paintOwnershipOrder) this._paintOwnershipOrder.fill(0);
    this._paintOwnershipSequence = 0;
    this._paintOrderRecords = [null];
    this._paintOrderIds?.clear();
    this._paintSimulationAccumulator = 0;
    this._hiddenPaintGrowth = null;
    this._hiddenPaintInsertions = 0;
    this._paintOwnerContext = null;
    this._paintOwnerDepth = 0;
    this._paintCurrentOrder = 0;
  };
  proto.useFixedPaintClock = function issue264UseFixedPaintClock() {
    ensureOwnershipState(this);
    this._paintUsesFixedClock = true;
  };
  proto.advanceSimulation = function issue264AdvanceSimulation(elapsed) {
    if (!Number.isFinite(elapsed) || elapsed < 0) throw new RangeError('Invalid paint simulation interval');
    this.useFixedPaintClock();
    this._paintSimulationAccumulator += elapsed;
    let count = 0;
    while (this._paintSimulationAccumulator + EPS >= STEP && count < 240) {
      nativeFlush.call(this, STEP);
      this._paintSimulationAccumulator = Math.max(0, this._paintSimulationAccumulator - STEP);
      count++;
    }
    return count;
  };
  proto.flush = function issue264RenderFlush(dt) {
    this._resumePaintPresentation();
    if (!this._paintUsesFixedClock) return nativeFlush.call(this, dt);
    this._drawQuads();
  };
  if (nativeClear) proto.clear = function issue264Clear(...args) {
    const result = nativeClear.apply(this, args);
    this._clearPaintOwnership();
    return result;
  };
  if (nativeDispose) proto.dispose = function issue264Dispose(...args) {
    const result = nativeDispose.apply(this, args);
    this._clearPaintOwnership();
    this._paintOwnershipOrder = null;
    this._paintOrderRecords = null;
    this._paintOrderIds = null;
    return result;
  };
  Object.defineProperty(proto, INSTALLED, { value: true });
  return true;
}

export { prepareAncillary as preparePaintAncillary };
